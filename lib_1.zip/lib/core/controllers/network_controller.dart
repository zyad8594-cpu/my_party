import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:get/get.dart';
import '../routes/app_routes.dart';

class NetworkController extends GetxController {
  final Connectivity _connectivity = Connectivity();

  @override
  void onInit() {
    super.onInit();
    _connectivity.onConnectivityChanged.listen(_updateConnectionStatus);
  }

  void _updateConnectionStatus(ConnectivityResult result) {
    if (result == ConnectivityResult.none) {
      if (Get.currentRoute != AppRoutes.networkError) {
        Get.toNamed(AppRoutes.networkError);
      }
    } else {
      // If we are on the network error screen and connection is back, go back
      if (Get.currentRoute == AppRoutes.networkError) {
        Get.back();
      }
    }
  }
}
