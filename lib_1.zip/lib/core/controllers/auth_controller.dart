// ignore_for_file: unused_local_variable

import 'package:flutter/material.dart';
import 'dart:io' show File;
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;
import 'package:dio/dio.dart' as dio;
import '../../data/models/user.dart' show User;
import 'validtor.dart' show MyPValidator;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/api/auth_service.dart' show AuthService;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../../features/auth/data/repository/auth_repository.dart' show AuthRepository;
import '../api/api_service.dart';
import '../services/fcm_service.dart';

class AuthController extends GetxController 
{
  final AuthRepository _authRepository = Get.find<AuthRepository>();

  final email = ''.obs;
  final password = ''.obs;
  final name = ''.obs;
  final phone = ''.obs;
  final isPasswordVisible = false.obs;
  final selectedDialCode = '+967'.obs;

  Rx<User> get user => AuthService.user;
  final emailController = TextEditingController();
  final passwordController = TextEditingController();
  final nameController = TextEditingController();
  final phoneController = TextEditingController();

  final selectedRole = 'coordinator'.obs;
  final profileImage = Rxn<File>();
  final selectedServiceIds = <int>[].obs;

  final agreedToTerms = false.obs;
  final isLoading = false.obs;

  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      profileImage.value = File(image.path);
    }
  }

  @override
  void onInit() {
    super.onInit();
    loadUserData();
  }
  
  Future<void> loadUserData() async {
  await AuthService.onRefresh();
}

  void login() async 
  {
    email.value = emailController.text;
    password.value = passwordController.text;
    
    if(isLoading.value) return;
    var contactMsg = MyPValidator.cocatMsg([
      MyPValidator.email(email),
      MyPValidator.password(password, 6),
      
    ]); 
    if(contactMsg != null)
    {
      return MyPUtils.showSnackbar('خطأ', contactMsg, isError: true);
    }
    else 
    {
      isLoading.value = true;
      final result = await _authRepository.login(email.value, password.value);
      debugPrint("Login result: ${result.data}");
      debugPrint("Login result: email: ${email.value}, password: ${password.value}");
      result.fold(
        (error) => MyPUtils.showSnackbar('خطأ', 'error.message', isError: true),
        (response) async {
          final token = response['token'] ?? response['data']?['token'];
          final userData = response['user'] ?? response['data']?['user'];
          
          await AuthService.updateData(token, userData);
          await AuthService.saveAuthData(token, userData);
          Get.find<ApiService>().setToken(token);
          
          // Register FCM Token
          Get.find<FCMService>().updateTokenOnBackend();

          if (userData['role_name'] == 'SUPPLIER') {
            Get.offAllNamed(AppRoutes.supplierHome);
          } else {
            Get.offAllNamed(AppRoutes.home);
          }

          MyPUtils.showSnackbar('نجاح', 'تم تسجيل الدخول بنجاح', position: SnackPosition.TOP);
        },
      );
      isLoading.value = false;
    }
  }

  void register() async 
  {
    name.value = nameController.text;
    email.value = emailController.text;
    password.value = passwordController.text;
    phone.value = phoneController.text;

    if(isLoading.value) return;
    var contactMsg = MyPValidator.cocatMsg([
      MyPValidator.name(name),
      MyPValidator.email(email),
      MyPValidator.phone(phone),
      MyPValidator.password(password, 6),
      
    ]); 
    if(contactMsg != null)
    {
      return MyPUtils.showSnackbar('خطأ', contactMsg, isError: true);
    }

    if (!agreedToTerms.value) {
      return MyPUtils.showSnackbar('تنبيه', 'يجب الموافقة على الشروط والأحكام للمتابعة', isError: true);
    }
    
    isLoading.value = true;
  
    dio.FormData finalData = dio.FormData.fromMap({
      'full_name': name.value,
      'email': email.value,
      'password': password.value,
      'phone_number': '${selectedDialCode.value}${phone.value}',
      'role_name': selectedRole.value,
      if (selectedRole.value == 'supplier' && selectedServiceIds.isNotEmpty) 'service_ids[]': selectedServiceIds,
      if (profileImage.value != null) 
        'img_url': await dio.MultipartFile.fromFile(
          profileImage.value!.path,
          filename: profileImage.value!.path.split('/').last,
        )
    });

    final result = await _authRepository.register(finalData);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', '${error.message}\n${error.statusCode}\n$error', isError: true),
      (response) {
        Get.offAllNamed(AppRoutes.login);
        MyPUtils.showSnackbar('نجاح', 'تم التسجيل بنجاح، يمكنك تسجيل الدخول حينما يتم تفعيل الحساب');
        // Clear data
        _clearForm();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateProfile({
    required String newName,
    required String newEmail,
    required String newPhone,
    File? newImage,
    Map<String, dynamic>? extraDetails,
  }) async {
    if(isLoading.value) return;
    final user = AuthService.user;
    final userId = user.value.id;
    if (userId <= 0) return;

    isLoading.value = true;
    try {
      Map<String, dynamic> details = extraDetails ?? {};
      
      dio.FormData data = dio.FormData.fromMap({
        'full_name': newName,
        'email': newEmail,
        'phone_number': newPhone,
        'details': details,
      });

      if (newImage != null) {
        data.files.add(MapEntry(
          'img_url',
          await dio.MultipartFile.fromFile(
            newImage.path,
            filename: newImage.path.split('/').last,
          ),
        ));
      }

      final response = await Get.find<ApiService>().put(
        '/users/$userId',
        data: data,
      );
      
      if (response != null && (response['user'] != null || response['data'] != null)) {
        // Backend might return user directly or inside 'data'
        final backendUser = response['user'] ?? response['data']?['user'] ?? {};
        
        // Merge current local user data with backend response to avoid data loss
        final updatedUser = {...user.value.toMap(), ...backendUser};
        
        // Ensure critical fields are updated in the merged map
        updatedUser['full_name'] = newName;
        updatedUser['email'] = newEmail;
        updatedUser['phone_number'] = newPhone;
        if (extraDetails != null) {
          updatedUser.addAll(extraDetails);
        }

        // Handle case where backend might return a new token (or reuse current)
        final newToken = response['token'] ?? response['data']?['token'] ?? AuthService.token.value;
        
        await AuthService.updateData(newToken, Map<String, dynamic>.from(updatedUser));
        profileImage.value = null; // Clear pending image
        MyPUtils.showSnackbar('نجاح', 'تم تحديث الملف الشخصي بنجاح');
      }
    } 
    catch (e) {
      MyPUtils.showSnackbar('خطأ', 'فشل تحديث الملف الشخصي', isError: true);
    }
    finally
    {
      isLoading.value = false;
    }
  }

  Future<void> changePassword(String oldPassword, String newPassword) async {
    final user = AuthService.user;
    final userId = user.value.id;
    if (userId == 0) return;

    isLoading.value = true;
    try {
      final response = await Get.find<ApiService>().put(
        '/users/change-password/$userId',
        data: {
          'old_password': oldPassword,
          'new_password': newPassword,
        },
      );
      
      MyPUtils.showSnackbar('نجاح', 'تم تغيير كلمة المرور بنجاح');
      
    } 
    catch (e) {
      MyPUtils.showSnackbar('خطأ', 'فشل تغيير كلمة المرور. تأكد من كلمة المرور الحالية.\n$e', isError: true);
    }
    isLoading.value = false;
  }

  void _clearForm() {
    name.value = '';
    email.value = '';
    password.value = '';
    phone.value = '';
    
    nameController.clear();
    emailController.clear();
    passwordController.clear();
    phoneController.clear();
    
    profileImage.value = null;
    selectedServiceIds.clear();
    agreedToTerms.value = false;
  }

  void logout() async {
    await Get.find<FCMService>().clearTokenOnBackend();
    AuthService.logout();
  }

}