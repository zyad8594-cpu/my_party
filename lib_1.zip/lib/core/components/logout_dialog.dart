import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../controllers/auth_controller.dart' show AuthController;

void logoutDialog()
{
  
  Get.defaultDialog(
    title: 'تسجيل الخروج',
    middleText: 'هل أنت متأكد من رغبتك في تسجيل الخروج؟',
    textConfirm: 'نعم',
    textCancel: 'إلغاء',
    confirmTextColor: Colors.white,
    buttonColor: Colors.red,
    onConfirm: ()=> Get.find<AuthController>().logout(),
  );
}