import 'package:flutter/material.dart';
import 'package:get/get.dart';

class MyPListView 
{
   static Widget builder<T>(BuildContext context,{
    required RxBool isLoading,
    required Widget Function() loadingWidget,
    required Widget Function() emptyWidget,
    required List<T> Function() filters,
    required Widget? Function(int index, T item) itemBuilder
  }) {
    return Obx(() {
      var filtersList = filters();
      if (isLoading.value) return loadingWidget();
      if (filtersList.isEmpty) return emptyWidget();
      return ListView.builder(
        padding: const EdgeInsets.only(left: 20, right: 20, bottom: 150),
        itemCount: filtersList.length,
        itemBuilder: (context, index) {
          return itemBuilder(index, filtersList[index]);
        },
      );
    });
  }

  static Widget expandedBuilder<T>(BuildContext context,{
    required RxBool isLoading,
    required Widget Function() loadingWidget,
    required Widget Function() emptyWidget,
    required List<T> Function() filters,
    required Widget? Function(int index, T item) itemBuilder
  }) {
    return Expanded(
      child: builder<T>(
        context, 
        isLoading: isLoading, 
        loadingWidget: loadingWidget, 
        emptyWidget: emptyWidget, 
        filters: filters, 
        itemBuilder: itemBuilder
      ),
    );
  }
}