import 'package:flutter/material.dart';
import '../../themes/app_colors.dart' show AppColors;

class MyPActions  {
  static Widget floatButton(BuildContext context, {required IconData icon, required Function() onPressed, Object? heroTag}) {
    final brightness = Theme.of(context).brightness;
    return Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          heroTag: heroTag,
          onPressed: onPressed,
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Icon(icon, color: AppColors.w_b.getByBrightness(brightness), size: 30),
        ),
      );
  }
}