import 'package:flutter/material.dart';

class AppImage {
  static ImageProvider? provider(String? url) {
    if (url == null || url.trim().isEmpty || !url.startsWith('http')) {
      return null;
    }
    return NetworkImage(url);
  }

  static Widget getAvatarFallback({required Brightness brightness, IconData icon = Icons.person, double size = 28}) {
    return Icon(icon, color: brightness == Brightness.dark ? Colors.white54 : Colors.black54, size: size);
  }

  static Widget network(
    String? url, {
    double? width,
    double? height,
    BoxFit fit = BoxFit.cover,
    Widget? fallbackWidget,
    Color? fallbackColor,
    IconData fallbackIcon = Icons.image_not_supported_rounded,
    double fallbackIconSize = 24.0,
  }) {
    if (url == null || url.trim().isEmpty || !url.startsWith('http')) {
      return _buildFallback(width, height, fallbackColor, fallbackWidget, fallbackIcon, fallbackIconSize);
    }

    return Image.network(
      url,
      width: width,
      height: height,
      fit: fit,
      errorBuilder: (context, error, stackTrace) {
        return _buildFallback(width, height, fallbackColor, fallbackWidget, fallbackIcon, fallbackIconSize);
      },
    );
  }

  static Widget _buildFallback(double? w, double? h, Color? color, Widget? widget, IconData icon, double iconSize) {
    if (widget != null) return widget;
    return Container(
      width: w,
      height: h,
      color: color ?? Colors.grey.withValues(alpha: 0.1),
      child: Center(
        child: Icon(icon, color: Colors.grey.withValues(alpha: 0.5), size: iconSize),
      ),
    );
  }
}
