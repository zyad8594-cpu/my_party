import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../components/loading_widget.dart' show LoadingWidget;

class MyPUtils 
{
  static final _showSnackbar = false.obs;
  static void showSnackbar(
    String title, 
    String message, {
      bool isError = false, 
      SnackPosition position = SnackPosition.BOTTOM,
    Widget? icon 
  }) 
  {
    if(_showSnackbar.value) return;
    _showSnackbar.value = true;
    Get.snackbar(
      title,
      message,
      snackPosition: position,
      backgroundColor: isError ? Colors.red : Colors.green,
      colorText: Colors.white,
      margin: const EdgeInsets.all(8),
      icon: icon
    );
    Future.delayed(const Duration(seconds: 3), () {
      _showSnackbar.value = false;
    });
  }

  static void showLoading() 
  {
    Get.dialog(
      const LoadingWidget(),
      barrierDismissible: false,
    );
  }

  static void hideLoading() 
  {
    if (Get.isDialogOpen ?? false) Get.back();
  }

  static void showConfirmDialog({
    required BuildContext context,
    required String title,
    required String message,
    required VoidCallback onConfirm,
    String confirmLabel = 'تأكيد',
    String cancelLabel = 'إلغاء',
    bool isDanger = false,
  }) {
    Get.dialog(
      AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        content: Text(message),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text(cancelLabel, style: TextStyle(color: Colors.grey[600])),
          ),
          ElevatedButton(
            onPressed: () {
              Get.back();
              onConfirm();
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: isDanger ? Colors.red : Colors.green,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            child: Text(confirmLabel),
          ),
        ],
      ),
    );
  }
}






// num toNum(val, [num defaultValue = 0]) 
// {
//   if (val is num) return val;
//   if (val is String) return num.parse(val);
//   return defaultValue;
// }

// String toStr(val, [String defaultValue = '']) 
// {
//   if (val is String) return val;
//   try 
//   {
//     return val.toString();
//   } 
//   catch (e) 
//   {
//     return defaultValue;
//   }
// }