
String translateDurationUnit(String unit, int value) {
  switch (unit.toLowerCase()) {
    case 'day':
      return value <= 1 ? '$value يوم' : '$value أيام';
    case 'week':
      return value <= 1 ? '$value أسبوع' : '$value أسابيع';
    case 'month':
      return value <= 1 ? '$value شهر' : '$value أشهر';
    case 'year':
      return value <= 1 ? '$value سنة' : '$value سنوات';
    default:
      return unit;
  }
}