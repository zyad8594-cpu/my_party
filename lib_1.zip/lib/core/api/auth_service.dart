import 'dart:convert' show jsonDecode, jsonEncode;

import 'package:get/get.dart';
import 'package:my_party/data/models/user.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../routes/app_routes.dart' show AppRoutes;
import 'api_constants.dart';

class AuthService extends GetxService {
  // static AuthService get to => Get.find<AuthService>();
  
  // private variables
  final _token = ''.obs;
  final _user = Rx<User>(User.fromJson({}));

  // public variables
  static Rx<User> get user => Get.find<AuthService>()._user;
  static RxString get token => Get.find<AuthService>()._token;
  
  static set token(value){
    var defualtVal = '';
    String? val;
    if(value is String){
      val = value; defualtVal = val;
    }
    else if(value is RxString){
      val = value.value; defualtVal = val;
    }
    else if(value is (dynamic, dynamic)){
      if(value.$1 is String?) {val = value.$1;}
      else if(value.$1 is RxString?) {val = value.$1.value;}
      
      if(value.$2 is String?) {defualtVal = (value.$2 ?? val) ?? defualtVal;}
      else if(value.$2 is RxString?) {defualtVal = (value.$2?.value ?? val) ?? defualtVal;}
    }
    Get.find<AuthService>()._token.value = val ?? defualtVal;
  }
  
  static Future<void> onRefresh() async
  {
    final user = AuthService.user;
    final prefs = await SharedPreferences.getInstance();
    final newUser = prefs.getString(ApiKeys.userKey);
    if(newUser != null){
      user.value = User.fromJson(Map<String, dynamic>.from(jsonDecode(newUser)));
    }
  }  

  static bool get userIsSupplier => _compareStr('SUPPLIER', Get.find<AuthService>()._user.value.role, isCaseSensitive: false);
  static bool get userIsAdmin => _compareStr('ADMIN', Get.find<AuthService>()._user.value.role, isCaseSensitive: false);
  static bool get userIsNotSupplier => !userIsSupplier;


  



  bool get isLoggedIn => _token.isNotEmpty;
  final isLoding = false.obs;


  // public methods
  Future<AuthService> init() async {
    isLoding.value = true; 
    final prefs = await SharedPreferences.getInstance();
    _token.value = prefs.getString(ApiKeys.tokenKey) ?? _token.value ;
    final userJs = prefs.getString(ApiKeys.userKey);
    if (_token.isNotEmpty) {
      if(userJs != null){
        _user.value = User.fromJson(Map<String, dynamic>.from(jsonDecode(userJs)));
      }
    }
    isLoding.value = false; 
    return this;
  }

  static Future<void> updateData(String newToken, Map<String, dynamic> userData) async
  {
    await Get.find<AuthService>()._saveAuthData(newToken, userData, rememberMe: false);
  }
  
  static Future<void> saveAuthData(
    String newToken, 
    userData,
    {bool rememberMe = true}
  ) async {
    await Get.find<AuthService>()._saveAuthData(newToken, userData, rememberMe: rememberMe);
  }

  static void logout()=>Get.find<AuthService>()._logout();
  static Future<void> logoutAsync() async => await Get.find<AuthService>()._logout();
  
  // private methods
  Future<void> _saveAuthData(
    String newToken,
    userData,
    {bool rememberMe = false}
  ) async {
    _token.value = newToken;
    if(userData is Map<String, dynamic>)
    {
      user.value = User.fromJson(userData);
    }
    else if(userData is User){
      user.value = userData;
    }

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiKeys.tokenKey, newToken);
    await prefs.setString(ApiKeys.userKey, jsonEncode(user.value.toJson()));
    await prefs.setBool('rememberMe', rememberMe);
  }
  
  Future<void> _logout() async {
    if(isLoding.value) return;
    isLoding.value = true;
    _token.value = '';
    _user.value = User.fromJson({});
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('rememberMe', false);
    await prefs.remove(ApiKeys.tokenKey);
    await prefs.remove(ApiKeys.userKey);
    isLoding.value = false; 
    Get.offAllNamed(AppRoutes.login);
  }

  static bool _compareStr(String value, dValue, {bool isCaseSensitive = true}){
    if(dValue != null && dValue is String){
      if(isCaseSensitive){
        return value == dValue;
      }
      else{
        return value.toLowerCase() == dValue.toLowerCase();
      }
    }
    return false;
  }
}


/*
  static T? userGet<T>(String detailName, {T? defualtVal}){
    final user = Get.find<AuthService>()._user;
    return (user.containsKey(detailName) && user[detailName] && user[detailName] is T)? user[detailName]  : defualtVal;
  }

  static int? get userGetId => userGet<int>('user_id');
  static String? get userGetRole => userGet<String>('role_name');
  static String? get userGetFullName => userGet<String>('full_name');
  static String? get userGetName => userGetFullName;
  static String? get userGetPhone => userGet<String>('phone_number');
  static String? get userGetEmail => userGet<String>('email');
  static String? get userGetImgUrl => userGet<String>('img_url');

  static bool userHas(String detailName) => Get.find<AuthService>()._user.containsKey(detailName);
  static bool userDetailIs(String detailName, value){
    final user = Get.find<AuthService>()._user;
    return user.containsKey(detailName) && _compareStr(value, user[detailName]);
  }
  
  static bool userIdIs(int id) => userDetailIs('user_id', id);
  static bool get userIdIsNull => Get.find<AuthService>()._user['user_id'] == null;
  static bool get userIdIsNotNull => !userIdIsNull;

  static bool get userIsActiv => userDetailIs('is_active', 1);
  static bool get userIsNotActiv => !userIsActiv;
  
  static bool userRoleIs(String role) => userDetailIs('role_name', role);
  static bool get userRoleIsNull => Get.find<AuthService>()._user['role_name'] == null;
  static bool get userRoleIsEmpty => Get.find<AuthService>()._user['role_name'] == '';
  static bool get userRoleIsNotNull => !userRoleIsNull && !userRoleIsEmpty;
  static bool get userRoleIsNotEmpty => !userRoleIsNull && !userRoleIsEmpty;
  static bool get userRoleIsNotNullOrEmpty => !userRoleIsNull && !userRoleIsEmpty;

  static bool userNameIs(String name) => userDetailIs('full_name', name);
  static bool get userNameIsNull => Get.find<AuthService>()._user['full_name'] == null;
  static bool get userNameIsEmpty => Get.find<AuthService>()._user['full_name'] == '';
  static bool get userNameIsNotNull => !userNameIsNull && !userNameIsEmpty;
  static bool get userNameIsNotEmpty => !userNameIsNull && !userNameIsEmpty;
  static bool get userNameIsNotNullOrEmpty => !userNameIsNull && !userNameIsEmpty;

  static bool userPhoneIs(String phone) => userDetailIs('phone_number', phone);
  static bool get userPhoneIsNull => Get.find<AuthService>()._user['phone_number'] == null;
  static bool get userPhoneIsEmpty => Get.find<AuthService>()._user['phone_number'] == '';
  static bool get userPhoneIsNotNull => !userPhoneIsNull && !userPhoneIsEmpty;
  static bool get userPhoneIsNotEmpty => !userPhoneIsNull && !userPhoneIsEmpty;
  static bool get userPhoneIsNotNullOrEmpty => !userPhoneIsNull && !userPhoneIsEmpty;

  static bool userEmailIs(String email) => userDetailIs('email', email);
  static bool get userEmailIsNull => Get.find<AuthService>()._user['email'] == null;
  static bool get userEmailIsEmpty => Get.find<AuthService>()._user['email'] == '';
  static bool get userEmailIsNotNull => !userEmailIsNull && !userEmailIsEmpty;
  static bool get userEmailIsNotEmpty => !userEmailIsNull && !userEmailIsEmpty;
  static bool get userEmailIsNotNullOrEmpty => !userEmailIsNull && !userEmailIsEmpty;

  static bool userImgUrlIs(String imgUrl) => userDetailIs('img_url', imgUrl);
  static bool get userImgUrlIsNull => Get.find<AuthService>()._user['img_url'] == null;
  static bool get userImgUrlIsEmpty => Get.find<AuthService>()._user['img_url'] == '';
  static bool get userImgUrlIsNotNull => !userImgUrlIsNull && !userImgUrlIsEmpty;
  static bool get userImgUrlIsNotEmpty => !userImgUrlIsNull && !userImgUrlIsEmpty;
  static bool get userImgUrlIsNotNullOrEmpty => !userImgUrlIsNull && !userImgUrlIsEmpty;

 */