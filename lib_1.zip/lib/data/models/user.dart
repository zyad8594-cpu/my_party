
 import 'package:my_party/core/utils/bool_toolse.dart';

import 'package:equatable/equatable.dart';
import '../../core/utils/number_toolse.dart';
import '../../core/utils/string_toolse.dart';

class User extends Equatable {
  final int id;
  final String role;
  final String name;
  final String? email;
  final String? phoneNumber;
  final String? imgUrl;
  final bool isActive;
  final bool isDeleted;
  final String createdAt;
  final String updatedAt;
  final Map<String, dynamic> details;
  

  User({
    required this.id,
    required this.name,
    required this.role,
    required this.email,
    this.phoneNumber,
    this.imgUrl,
    this.isActive = false,
    this.isDeleted = false,
    this.createdAt = '',
    this.updatedAt = '',
    this.details = const {},
  });
  
  factory User.fromJson(json) {
    return User(
      id: NumberTools.tryParseInt(json, keys: ['id', 'user_id', 'userId']),
      name: StrTools.tryParse(json, keys: [
        'name', 'full_name', 'fullName', 
        'user_name', 'userName', 'userFullName',
        'user_full_name',
      ]),
      role: StrTools.tryParse(json, keys: [
        'role', 'role_name', 'roleName',
        'user_role', 'userRole',
        'user_role_name', 'userRoleName',
      ]),
      email: StrTools.tryParse(json, keys: ['email', 'user_email', 'userEmail']),
      phoneNumber: StrTools.tryParse(json, keys: [
        'phone', 'phone_number', 'phoneNumber',
        'user_phone', 'userPhone',
        'user_phone_number', 'userPhoneNumber',
      ]),
      imgUrl: StrTools.tryParse(json, keys: [
        'img', 'img_url', 'imgUrl',
        'user_img', 'userImg',
        'user_img_url', 'userImgUrl',
        'urlImg', 'url_img', 'user_img_url', 'userImgUrl'
      ]),
      isActive: BoolTools.tryParse(json, keys: ['is_active', 'isActive']),
      isDeleted: BoolTools.tryParse(json, keys: ['is_deleted', 'isDeleted']),
      createdAt: StrTools.tryParse(json, keys: ['created_at', 'createdAt']),
      updatedAt: StrTools.tryParse(json, keys: ['updated_at', 'updatedAt']),
      details: Map<String, dynamic>.from(json['details'] ?? {}),
    );
  }

  Map<String, dynamic> toMap()=> toJson();
  toJson() {
    return {
      'id': id,
      'full_name': name,
      'role_name': role,
      'email': email,
      'phone_number': phoneNumber,
      'img_url': imgUrl,
      'is_active': isActive,
      'is_deleted': isDeleted,
      'created_at': createdAt,
      'updated_at': updatedAt,
      ...details,
    };
  }
  
  User copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    Map<String, dynamic>? details,
  })
  {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      role: role ?? this.role,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      imgUrl: imgUrl ?? this.imgUrl,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      details: {...this.details, ...(details ?? {})},
    );
  }

  T cast<T extends User>()=> this as T;
  
  @override
  List<Object?> get props => [
        id,
        role,
        name,
        email,
        phoneNumber,
        imgUrl,
        isActive,
        isDeleted,
        createdAt,
        updatedAt,
        details,
      ];

  @override
  String toString() => toJson().toString();
}