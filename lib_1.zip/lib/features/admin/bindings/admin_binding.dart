import 'package:get/get.dart';
import '../controller/admin_controller.dart';
import '../data/repository/admin_repository.dart';

class AdminBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AdminRepository>(() => AdminRepository());
    Get.lazyPut<AdminController>(() => AdminController(repository: Get.find()));
  }
}
