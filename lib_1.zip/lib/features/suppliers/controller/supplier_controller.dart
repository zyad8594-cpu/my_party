import 'dart:io' show File;
import 'package:get/get.dart' hide Response;
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;
import '../../services/data/models/service.dart' show Service;
import '../data/repository/supplier_repository.dart' show SupplierRepository;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../../../core/api/auth_service.dart' show AuthService;
import '../data/models/supplier.dart' show Supplier;

class SupplierController extends GetxController 
{
  final SupplierRepository _repository = Get.find<SupplierRepository>();

  // Reactive state for Supplier Add/Edit
  final servicesRx = <Service>[].obs;
  final nameRx = ''.obs;
  final phoneRx = ''.obs;
  final emailRx = ''.obs;
  final addressRx = ''.obs;
  final notesRx = ''.obs;
  final passwordRx = ''.obs;
  final isPasswordVisible = false.obs;
  final isActiveRx = true.obs;
  final showPasswordEdit = false.obs;

  final suppliers = <Supplier>[].obs;
  final selectedSupplier = Rxn<Supplier>();
  final isLoading = false.obs;
  final profileImage = Rxn<File>();
  final searchQuery = ''.obs;

  List<Supplier> get filteredSuppliers => suppliers.where((s) {
    final query = searchQuery.value.toLowerCase();
    return s.name.toLowerCase().contains(query) || 
           s.email.toLowerCase().contains(query) ||
           (s.phoneNumber?.contains(query) ?? false);
  }).toList();

  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      profileImage.value = File(image.path);
    }
  }

  @override
  void onInit() {
    super.onInit();
    fetchAll();
  }

 
  void clearFields() {
    servicesRx.value = [];
    nameRx.value = '';
    phoneRx.value = '';
    emailRx.value = '';
    addressRx.value = '';
    notesRx.value = '';
    profileImage.value = null;
    passwordRx.value = '';
    isActiveRx.value = true;
    showPasswordEdit.value = false;
  }

  void populateFields(Supplier supplier) {
    servicesRx.value = supplier.services.toList();
    nameRx.value = supplier.name;
    phoneRx.value = supplier.phoneNumber??'';
    emailRx.value = supplier.email;
    addressRx.value = supplier.address ?? '';
    notesRx.value = supplier.notes ?? '';
    isActiveRx.value = supplier.isActive;
    showPasswordEdit.value = false;
  }

  Future<void> fetchAll({bool force = false}) async {
    if (!force && suppliers.isNotEmpty) return;
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', "msg: ${error.message} code: ${error.statusCode}", isError: true),
      (data) => suppliers.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (supplier) => selectedSupplier.value = supplier,
    );
    isLoading.value = false;
  }

  // Future<void> fetchAllByServiceId(int serviceId) async {
  //   isLoading.value = true;
  //   try {
  //     final list = await _repository.getAllByServiceId(serviceId);
  //     suppliers.value = list;
  //   } catch (e) {
  //     MyPUtils.showSnackbar('خطأ', e.toString(), isError: true);
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }
  

  // Future<void> fetchByIdAndServiceId(int id, int serviceId) async {
  //   isLoading.value = true;
  //   try {
  //     final supplier = await _repository.getByIdAndServiceId(id, serviceId);
  //     selectedSupplier.value = supplier;
  //   } catch (e) {
  //     MyPUtils.showSnackbar('خطأ', e.toString(), isError: true);
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }
  
  Future<void> create() async {
    isLoading.value = true;
    final data = {
      'services': servicesRx.map((e) => e.id).toList(),
      'full_name': nameRx.value,
      'phone_number': phoneRx.value,
      'email': emailRx.value,
      'address': addressRx.value,
      'notes': notesRx.value,
      'is_active': isActiveRx.value ? 1 : 0,
      'password': passwordRx.value.isNotEmpty ? passwordRx.value : 'password123',
    };

    final dio.FormData formData = dio.FormData.fromMap(data);
    if (profileImage.value != null) {
      formData.files.add(MapEntry(
        'img_url',
        await dio.MultipartFile.fromFile(
          profileImage.value!.path,
          filename: profileImage.value!.path.split('/').last,
        ),
      ));
    }

    final result = await _repository.create(formData as dynamic);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (newSupplier) {
        suppliers.add(newSupplier);
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم إضافة المورد');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> edit(int id) async {
    isLoading.value = true;
    try {
      final data = {
        'services': servicesRx.map((e) => e.id).toList(),
        'full_name': nameRx.value,
        'phone_number': phoneRx.value,
        'email': emailRx.value,
        'address': addressRx.value,
        'notes': notesRx.value,
        'is_active': isActiveRx.value,
        if (showPasswordEdit.value && passwordRx.value.isNotEmpty) 'password': passwordRx.value,
      };

      final dio.FormData formData = dio.FormData.fromMap(data);
      if (profileImage.value != null) {
        formData.files.add(MapEntry(
          'img_url',
          await dio.MultipartFile.fromFile(
            profileImage.value!.path,
            filename: profileImage.value!.path.split('/').last,
          ),
        ));
      }

      final result = await _repository.update(id, formData);
      result.fold(
        (error) => MyPUtils.showSnackbar('خطأ', '${error.message}\n${error}', isError: true),
        (updated) {
          final index = suppliers.indexWhere((c) => c.id == id);
          if (index != -1) suppliers[index] = updated;
          selectedSupplier.value = updated;
          Get.back();
          MyPUtils.showSnackbar('نجاح', 'تم تحديث المورد');
          clearFields();
        },
      );
    } catch (e) {
      MyPUtils.showSnackbar('خطأ غير متوقع', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> delete(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        suppliers.removeWhere((c) => c.id == id);
        if (selectedSupplier.value?.id == id) {
          selectedSupplier.value = null;
        }
        MyPUtils.showSnackbar('نجاح', 'تم حذف المورد');
      },
    );
  }

  Future<void> proposeService(String serviceName, String description) async {
    isLoading.value = true;
    try {
      // Assuming AuthService.user['user_id'] holds the ID of the logged-in user
      final int supplierId = AuthService.user.value.id;
      if(supplierId <= 0) {
        throw Exception("Invalid user ID");
      }
      
      final result = await _repository.proposeService(supplierId, serviceName, description);
      result.fold(
        (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
        (_) {
          Get.back(); // close bottom sheet
          MyPUtils.showSnackbar('نجاح', 'تم إرسال اقتراحك للخدمة بنجاح، وهو قيد المراجعة الآن.', isError: false);
        },
      );
    } catch (e) {
      MyPUtils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> assignService(int supplierId, int serviceId) async {
    isLoading.value = true;
    final result = await _repository.assignServiceToSupplier(supplierId, serviceId);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        MyPUtils.showSnackbar('نجاح', 'تمت إضافة الخدمة بنجاح');
      },
    );
    isLoading.value = false;
  }

  Future<void> removeService(int supplierId, int serviceId) async {
    isLoading.value = true;
    final result = await _repository.deleteService(supplierId, serviceId);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        MyPUtils.showSnackbar('نجاح', 'تمت إزالة الخدمة بنجاح');
      },
    );
    isLoading.value = false;
  }

  // --- Proposal Management ---
  final myProposals = <dynamic>[].obs;
  final isProposalsLoading = false.obs;
  final proposalSearchQuery = ''.obs;

  List<dynamic> get filteredProposals => myProposals.where((p) {
    final query = proposalSearchQuery.value.toLowerCase();
    if (query.isEmpty) return true;
    return (p.serviceName?.toLowerCase().contains(query) ?? false) ||
           (p.description?.toLowerCase().contains(query) ?? false);
  }).toList();

  Future<void> fetchMyProposals() async {
    isProposalsLoading.value = true;
    final result = await _repository.getMyProposals();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) {
        myProposals.value = data;
      },
    );
    isProposalsLoading.value = false;
  }

  Future<void> withdrawProposal(int proposalId) async {
    isProposalsLoading.value = true;
    final result = await _repository.withdrawProposal(proposalId);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        myProposals.removeWhere((p) => p.id == proposalId);
        MyPUtils.showSnackbar('نجاح', 'تم التراجع عن الاقتراح بنجاح');
      },
    );
    isProposalsLoading.value = false;
  }

  Future<void> toggleStatus(int id, bool isActive) async {
    isLoading.value = true;
    final result = await _repository.toggleStatus(id, isActive);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = suppliers.indexWhere((s) => s.id == id);
        if (index != -1) {
          suppliers[index] = suppliers[index].copyWith(isActive: isActive);
        }
        if (selectedSupplier.value?.id == id) {
          selectedSupplier.value = selectedSupplier.value!.copyWith(isActive: isActive);
        }
        MyPUtils.showSnackbar('نجاح', isActive ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب');
      },
    );
    isLoading.value = false;
  }
}
