import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../../core/utils/status.dart' show StatusExtension;
import '../../../core/api/auth_service.dart' show AuthService;
import '../../tasks/controller/task_controller.dart' show TaskController;
import '../../tasks/data/models/task.dart' show Task;

class SupplierDashboardController extends GetxController 
{
  final isLoading = false.obs;
  final selectedFilter = 'الكل'.obs;
  final searchQuery = ''.obs;

  // Real data from TaskController
  final activeTasks = <Task>[].obs;
  final allMyTasks = <Task>[].obs;
  final completedTasksCount = 0.obs;
  final pendingTasksCount = 0.obs;
  final totalEarnings = 0.0.obs;
  final rating = 4.8.obs; // Mock rating since it might not be in the model yet

  // final authUser = AuthService.to.user;

  List<Task> get filteredTasks{
     return allMyTasks.where((t) {
        final query = searchQuery.value.toLowerCase();
        final matchesSearch = query.isEmpty ||
            (t.typeTask?.toLowerCase().contains(query) ?? false) ||
            (t.description?.toLowerCase().contains(query) ?? false) ||
            (t.eventName.toLowerCase().contains(query));

        if (selectedFilter.value == 'الكل') return matchesSearch;
        return matchesSearch && t.status.tryText() == selectedFilter.value;
    }).toList();
  }
  @override
  void onInit() {
    super.onInit();
    refreshDashboard();
  }

  Future<void> refreshDashboard() async {
    isLoading.value = true;
    try {
      // In a real app, we would fetch supplier-specific stats from an API
      // Here we filter the tasks from the general TaskController if available
      if (Get.isRegistered<TaskController>()) {
        final taskController = Get.find<TaskController>();
        await taskController.fetchTasks();

        final supplierId = AuthService.user.value.id;
        
        final myTasks = taskController.tasks
            .where((t) => t.userAssignId == supplierId)
            .toList();

        allMyTasks.value = myTasks;

        activeTasks.value = myTasks
            .where(
              (t) =>
                  t.status.isInProgress ||
                  t.status.isPending,
            )
            .toList();

        completedTasksCount.value = myTasks
            .where((t) => t.status.isCompleted)
            .length;

        pendingTasksCount.value = myTasks
            .where((t) => t.status.isPending)
            .length;

        totalEarnings.value = myTasks
            .where((t) => t.status.isCompleted)
            .fold(0.0, (sum, item) => sum + (item.cost));
      }
    } catch (e) {
      // print('Dashboard error: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<bool> updateTaskStatus(int taskId, newStatus, {String? note, dynamic urlImage}) async {
    isLoading.value = true;
    bool success = false;
    try {
      if (Get.isRegistered<TaskController>()) {
        final taskController = Get.find<TaskController>();
        // Wait for update
        await taskController.updateTaskStatus(taskId, newStatus, note: note, urlImage: urlImage);
        
        // We consider it a success if the task status locally reflects it (assuming TaskController handles its own errors properly)
        final updatedTask = taskController.tasks.firstWhereOrNull((t) => t.id == taskId);
        if (updatedTask != null) {
          success = true;
        }
        await refreshDashboard();
      }
    } catch (e, stackTrace) {
      debugPrint('=== ERROR in updateTaskStatus ===\n$e\n$stackTrace');
      Get.snackbar('خطأ', 'فشل تحديث حالة المهمة: $e');
    } finally {
      isLoading.value = false;
    }
    return success;
  }
}
