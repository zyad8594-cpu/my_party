// ignore_for_file: unused_local_variable

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../../../core/api/auth_service.dart' show AuthService;
import '../controller/supplier_dashboard_controller.dart' show SupplierDashboardController;
import '../../tasks/data/models/task.dart' show Task;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/components/widgets/app_form_widgets.dart' show AppFormWidgets;

import 'dart:io' show File;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource;
import '../../tasks/widgets/task_utils.dart' show showRejectTaskBottomSheet;

class SupplierDashboardWidgets {
  static Widget buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
    BuildContext context,
  ) {
    final brightness = Theme.of(context).brightness;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppFormWidgets.cardDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textBody.getByBrightness(brightness),
                ),
              ),
              Text(
                title,
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.textSubtitle.getByBrightness(brightness),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SupplierGreeting extends StatelessWidget {

  const SupplierGreeting({super.key,});

  @override
  Widget build(BuildContext context) 
  {
    final authUser = AuthService.user;
    final brightness = Theme.of(context).brightness;
    final name = authUser.value.name.isNotEmpty? authUser.value.name : 'شريكنا العزيز';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'مرحباً بك، $name ',
          style: TextStyle(
            color: AppColors.textBody.getByBrightness(brightness),
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'نظرة سريعة على أدائك ومهامك اليوم',
          style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
        ),
      ],
    );
  }
}

class SupplierStatsGrid extends GetView<SupplierDashboardController> {

  const SupplierStatsGrid({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.4,
      children: [
        SupplierDashboardWidgets.buildStatCard(
          'إجمالي الأرباح',
          '${controller.totalEarnings.value.toStringAsFixed(0)} ر.س',
          Icons.account_balance_wallet_rounded,
          AppColors.success.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'مهام مكتملة',
          '${controller.completedTasksCount.value}',
          Icons.check_circle_rounded,
          AppColors.primary.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'طلبات معلقة',
          '${controller.pendingTasksCount.value}',
          Icons.pending_actions_rounded,
          AppColors.warning.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'تقييمك الحالي',
          '${controller.rating.value}',
          Icons.star_rounded,
          const Color(0xFFFFC107),
          context
        ),
      ],
    );
  }
}

class SupplierActiveTasksList extends GetView<SupplierDashboardController> {
  

  const SupplierActiveTasksList({super.key});

  @override
  Widget build(BuildContext context) 
  {
    return Obx(() => Column(
      children: controller.activeTasks
          .map((task) => _buildTaskCard(task, context))
          .take(3).toList(),
    ));
  }

  Widget _buildTaskCard(Task task, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    // final bool isPending = ;
    final bool isInProgress = task.status.isInProgress;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: AppFormWidgets.cardDecoration(context),
      child: InkWell(
        onTap: () => Get.toNamed(AppRoutes.taskDetail, arguments: task),
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      Icons.assignment_rounded,
                      color: AppColors.primary.getByBrightness(brightness),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          task.typeTask!,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.textBody.getByBrightness(brightness),
                          ),
                        ),
                        Text(
                          task.eventName,
                          style: TextStyle(
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: (isInProgress ? AppColors.info : AppColors.warning).getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Obx(() {
                      final bool val = controller.isLoading.value;
                      return Text(
                        task.status.tryText(),
                        style: TextStyle(
                          color: task.status.tryColor(brightness),
                          fontSize: 10,
                          fontWeight: FontWeight.bold,
                        ),
                      );
                    }),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  // Expanded(
                  //   child: OutlinedButton(
                  //     onPressed: () =>
                  //         Get.toNamed(AppRoutes.taskDetail, arguments: task),
                  //     style: OutlinedButton.styleFrom(
                  //       shape: RoundedRectangleBorder(
                  //         borderRadius: BorderRadius.circular(12),
                  //       ),
                  //       side: BorderSide(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
                  //     ),
                  //     child: Text(
                  //       'التفاصيل',
                  //       style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                  //     ),
                  //   ),
                  // ),
                  if (task.status.isPending || task.status.isInProgress)
                    Expanded(
                      child: Row(
                        children: [
                          if (task.status.isPending) ...[
                            Expanded(
                              child: OutlinedButton(
                                onPressed: () => showRejectTaskBottomSheet(context, controller, task.id, brightness),
                                style: OutlinedButton.styleFrom(
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  side: BorderSide(color: AppColors.accent.getByBrightness(brightness)),
                                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                ),
                                child: Text(
                                  'رفض',
                                  style: TextStyle(color: AppColors.accent.getByBrightness(brightness), fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                          ],
                          Expanded(
                            flex: 2,
                            child: Obx(() => ElevatedButton(
                              onPressed: controller.isLoading.value ? null : () {
                                if (task.status.isPending) {
                                  controller.updateTaskStatus(task.id, Status.IN_PROGRESS);
                                  return;
                                }
                                showProofOfWorkBottomSheet(context, task);
                              },
                              style: ElevatedButton.styleFrom(
                                backgroundColor: task.status.tryColor(brightness),
                                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                                padding: const EdgeInsets.symmetric(vertical: 12),
                              ),
                              child: controller.isLoading.value && task.status.isPending
                                ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                                : Text(
                                task.status.isPending ? 'بدء المهمة' : 'تسليم للمراجعة',
                                textAlign: TextAlign.center,
                                style: const TextStyle(fontSize: 12, color: Colors.white),
                              ),
                            )),
                          ),
                        ],
                      ),
                    ),
                  if (task.status.isUnderReview || task.status.isCompleted || task.status.isCancelled || task.status.isRejected)
                    const Spacer(),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SupplierEmptyTasksState extends StatelessWidget {
  const SupplierEmptyTasksState({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: AppFormWidgets.cardDecoration(context),
      child: Column(
        children: [
          Icon(
            Icons.assignment_turned_in_rounded,
            size: 60,
            color: Colors.grey[200],
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد مهام نشطة حالياً',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        ],
      ),
    );
  }
}

  void showProofOfWorkBottomSheet(BuildContext context, Task task) 
  {
    final brightness = Theme.of(context).brightness;
    final controller = Get.find<SupplierDashboardController>();
    
    final noteController = TextEditingController();
    final imageFile = Rxn<File>();
    final picker = ImagePicker();

    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surface.getByBrightness(brightness),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'إرفاق إثبات التنفيذ',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            Obx(() => imageFile.value == null
              ? OutlinedButton.icon(
                  onPressed: () async {
                    final picked = await picker.pickImage(source: ImageSource.gallery);
                    if (picked != null) {
                      imageFile.value = File(picked.path);
                    }
                  },
                  icon: const Icon(Icons.camera_alt_rounded),
                  label: const Text('التقاط أو اختيار صورة إثبات'),
                  style: OutlinedButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                )
              : Container(
                  height: 150,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: AppColors.primary.getByBrightness(brightness)),
                    image: DecorationImage(
                      image: FileImage(imageFile.value!),
                      fit: BoxFit.cover,
                    ),
                  ),
                  child: Align(
                    alignment: Alignment.topRight,
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded, color: Colors.white, size: 28),
                      style: IconButton.styleFrom(backgroundColor: Colors.black54),
                      onPressed: () => imageFile.value = null,
                    ),
                  ),
                )),
            const SizedBox(height: 16),
            TextField(
              controller: noteController,
              decoration: InputDecoration(
                hintText: 'ملاحظات إضافية للمنسق (اختياري)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              ),
              maxLines: 3,
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              onPressed: () {
                Get.back(); // close bottom sheet
                controller.updateTaskStatus(task.id, Status.UNDER_REVIEW, note: noteController.text, urlImage: imageFile.value);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.primary.getByBrightness(brightness),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 16),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              child: const Text('تأكيد التسليم للمراجعة', style: TextStyle(fontWeight: FontWeight.bold)),
            ),
          ],
        ),
      ),
      isScrollControlled: true,
    );
  }
  