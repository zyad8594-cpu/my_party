import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../data/models/supplier.dart' show Supplier;
import '../controller/supplier_controller.dart' show SupplierController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/empty_state_widget.dart' show EmptyStateWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart';
import '../../../core/utils/utils.dart';

class SupplierListScreen extends GetView<SupplierController> 
{
  SupplierListScreen({super.key});
final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Scaffold(
      appBar: CustomAppBar(
        // authController: authController, 
        title: 'قائمة الموردين'),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          heroTag: 'add_supplier',
          onPressed: () => Get.toNamed(AppRoutes.supplierAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: TextFormField(
                onChanged: (value) => controller.searchQuery.value = value,
                style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                decoration: InputDecoration(
                  hintText: 'ابحث عن مورد بالاسم أو البريد أو الهاتف...',
                  hintStyle: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary.getByBrightness(brightness)),
                  filled: true,
                  fillColor: AppColors.surface.getByBrightness(brightness),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
              ),
            ),
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const LoadingWidget();
                }
                if (controller.filteredSuppliers.isEmpty) {
                  return const EmptyStateWidget(message: 'لا يوجد نتائج للبحث', icon: Icons.store_mall_directory_outlined);
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.filteredSuppliers.length,
                  itemBuilder: (context, index) {
                    final supplier = controller.filteredSuppliers[index];
                    return _buildSupplierCard(supplier, context);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSupplierCard(Supplier supplier, BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => Get.toNamed(AppRoutes.supplierDetail, arguments: supplier),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient.getByBrightness(brightness),
                    shape: BoxShape.circle,
                  ),
                  child: supplier.imgUrl != null
                      ? ClipOval(
                          child: Image.network(
                            supplier.imgUrl!,
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) => const Icon(
                              Icons.storefront_rounded,
                              color: Colors.white,
                              size: 24,
                            ),
                          ),
                        )
                      : const Icon(
                          Icons.storefront_rounded,
                          color: Colors.white,
                          size: 24,
                        ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            supplier.name,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textBody.getByBrightness(brightness),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: supplier.isActive ? Colors.green.withValues(alpha: 0.1) : Colors.red.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              supplier.isActive ? 'نشط' : 'معطل',
                              style: TextStyle(
                                color: supplier.isActive ? Colors.green : Colors.red,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        supplier.email,
                        style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  icon: Icon(
                    Icons.more_vert_rounded,
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  color: AppColors.surface.getByBrightness(brightness),
                  elevation: 4,
                  onSelected: (value) {
                    if (value == 'status') {
                      controller.toggleStatus(supplier.id, !supplier.isActive);
                    } else if (value == 'edit') {
                      Get.toNamed(AppRoutes.supplierAdd, arguments: supplier);
                    } else if (value == 'delete') {
                      _delete(supplier.id, context);
                    }
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'status',
                      child: Row(
                        children: [
                          Icon(
                            supplier.isActive ? Icons.block_rounded : Icons.check_circle_outline_rounded,
                            color: supplier.isActive ? AppColors.accent.getByBrightness(brightness) : Colors.green,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(supplier.isActive ? 'تعطيل الحساب' : 'تفعيل الحساب'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_rounded, color: Colors.orange, size: 18),
                          SizedBox(width: 8),
                          Text('تعديل'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_rounded, color: AppColors.accent.getByBrightness(brightness), size: 18),
                          const SizedBox(width: 8),
                          Text('حذف'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }



  void _delete(int id, BuildContext context) {
    MyPUtils.showConfirmDialog(
      context: context,
      title: 'حذف المورد',
      message: 'هل أنت متأكد من حذف هذا المورد نهائياً؟',
      confirmLabel: 'حذف',
      isDanger: true,
      onConfirm: () {
        controller.delete(id);
      },
    );
  }
}
