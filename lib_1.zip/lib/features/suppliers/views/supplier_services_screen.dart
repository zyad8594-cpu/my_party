import 'package:flutter/material.dart';
import 'package:get/get.dart';

import '../../../core/api/auth_service.dart';
import '../../../core/themes/app_colors.dart';
import '../../../core/components/custom_app_bar.dart';
import '../../services/controller/service_controller.dart' show ServiceController;
import '../controller/supplier_controller.dart';

class SupplierServicesScreen extends GetView<SupplierController> {
  const SupplierServicesScreen({super.key});

  void _showProposeServiceDialog(BuildContext context) {
    String serviceName = '';
    String description = '';
    final brightness = Theme.of(context).brightness;

    Get.bottomSheet(
      Container(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(context).viewInsets.bottom + 24,
          top: 24, left: 24, right: 24
        ),
        decoration: BoxDecoration(
          color: AppColors.background.getByBrightness(brightness),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'اقتراح خدمة جديدة',
                style: TextStyle(
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textBody.getByBrightness(brightness),
                ),
              ),
              const SizedBox(height: 16),
              TextField(
                decoration: InputDecoration(
                  labelText: 'اسم الخدمة المقترحة',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.design_services_outlined)
                ),
                onChanged: (val) => serviceName = val,
              ),
              const SizedBox(height: 16),

              TextField(
                decoration: InputDecoration(
                  labelText: 'تفاصيل الخدمة وكيفية تسعيرها...',
                  border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                  prefixIcon: const Icon(Icons.description_outlined)
                ),
                maxLines: 4,
                onChanged: (val) => description = val,
              ),
              const SizedBox(height: 24),

              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary.getByBrightness(brightness),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                  ),
                  onPressed: () {
                    if (serviceName.trim().isNotEmpty) {
                      controller.proposeService(serviceName, description);
                    } else {
                      Get.snackbar('تنبيه', 'الرجاء إدخال اسم الخدمة', backgroundColor: Colors.red[100], colorText: Colors.red[900]);
                    }
                  },
                  child: const Text('إرسال الاقتراح للإدارة', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              ),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final supplierId = AuthService.user.value.id;
    WidgetsBinding.instance.addPostFrameCallback((_) {
       controller.fetch(supplierId);
       controller.fetchMyProposals();
       if(!Get.isRegistered<ServiceController>()){
        Get.put(ServiceController()).fetchServices();
       } else {
        Get.find<ServiceController>().fetchServices();
       }
    });

    final brightness = Theme.of(context).brightness;
    final serviceController = Get.find<ServiceController>();

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        backgroundColor: AppColors.background.getByBrightness(brightness),
        appBar: CustomAppBar(
          title: 'الخدمات', 
          showBackButton: false,
          bottom: TabBar(
            tabs: [
              Tab(text: 'خدماتي', icon: Icon(Icons.star_rounded, color: AppColors.primary.getByBrightness(brightness))),
              Tab(text: 'اقتراحاتي', icon: Icon(Icons.inbox_outlined, color: AppColors.primary.getByBrightness(brightness))),
            ],
            indicatorColor: AppColors.primary.getByBrightness(brightness),
            labelColor: AppColors.primary.getByBrightness(brightness),
            unselectedLabelColor: AppColors.primary.getByBrightness(brightness),
          ),
        ),
        
        floatingActionButton: FloatingActionButton.extended(
          onPressed: () => _showProposeServiceDialog(context),
          backgroundColor: AppColors.primary.getByBrightness(brightness),
          icon: const Icon(Icons.add_circle_outline, color: Colors.white),
          label: const Text('اقتراح خدمة جديدة', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
        ),
        body: TabBarView(
          children: [
            // Tab 1: Current general services available to assign
            Obx(() {
              final services = serviceController.filteredServices;

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                    child: TextFormField(
                      onChanged: (val) => serviceController.searchQuery.value = val,
                      decoration: InputDecoration(
                        hintText: 'بحث في الخدمات المتاحة...',
                        prefixIcon: const Icon(Icons.search_rounded),
                        filled: true,
                        fillColor: AppColors.card.getByBrightness(brightness),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  
                  if (serviceController.isLoading.value)
                    Expanded(child: Center(child: CircularProgressIndicator(color: AppColors.primary.getByBrightness(brightness))))
                  
                  else if (services.isEmpty)
                    Expanded(
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.inventory_2_outlined, size: 80, color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5)),
                            const SizedBox(height: 16),
                            Text(
                              serviceController.searchQuery.value.isEmpty 
                                  ? 'لا يوجد لديك خدمات مسجلة' 
                                  : 'لا توجد نتائج بحث مطابقة', 
                              style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 16)
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    Expanded(
                      child: RefreshIndicator(
                        onRefresh: () async => serviceController.fetchServices(),
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(20, 12, 20, 80),
                          itemCount: services.length,
                          itemBuilder: (context, index) {
                            final svc = services[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 16),
                              decoration: BoxDecoration(
                                color: AppColors.surface.getByBrightness(brightness),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.03),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                                border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
                              ),
                              child: ListTile(
                                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                                trailing: IconButton(
                                  onPressed: () {
                                    final hasService = svc.suppliers.any((sup) => sup.id == supplierId);
                                    Get.defaultDialog(
                                      title: hasService ? 'إزالة الخدمة' : 'إضافة الخدمة',
                                      middleText: hasService
                                          ? 'هل أنت متأكد من إزالة هذه الخدمة من قائمة خدماتك؟'
                                          : 'هل تريد إضافة هذه الخدمة إلى خدماتك؟',
                                      textConfirm: 'نعم',
                                      textCancel: 'إلغاء',
                                      confirmTextColor: Colors.white,
                                      onConfirm: () async {
                                        Get.back();
                                        if (hasService) {
                                          await controller.removeService(supplierId, svc.id);
                                        } else {
                                          await controller.assignService(supplierId, svc.id);
                                        }
                                        serviceController.fetchServices();
                                      },
                                    );
                                  },
                                  icon: Icon(
                                    svc.suppliers.any((sup) => sup.id == supplierId) 
                                        ? Icons.remove_circle_outline 
                                        : Icons.add_circle_outline,
                                    color: svc.suppliers.any((sup) => sup.id == supplierId) 
                                        ? Colors.red 
                                        : AppColors.primary.getByBrightness(brightness),
                                    size: 28,
                                  ),
                                ),
                                title: Text(
                                  svc.serviceName,
                                  style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness)),
                                ),
                                subtitle: Padding(
                                  padding: const EdgeInsets.only(top: 8.0),
                                  child: Text(
                                    svc.description ?? 'لا يوجد وصف متاح لهذه الخدمة.',
                                    style: TextStyle(fontSize: 12, color: AppColors.textSubtitle.getByBrightness(brightness)),
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                ],
              );
            }),
            
            // Tab 2: My Proposals
            Obx(() {
              final proposals = controller.filteredProposals;

              return Column(
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
                    child: TextFormField(
                      onChanged: (val) => controller.proposalSearchQuery.value = val,
                      decoration: InputDecoration(
                        hintText: 'بحث في اقتراحاتي...',
                        prefixIcon: const Icon(Icons.search_rounded),
                        filled: true,
                        fillColor: AppColors.card.getByBrightness(brightness),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(16),
                          borderSide: BorderSide.none,
                        ),
                        contentPadding: const EdgeInsets.symmetric(vertical: 12),
                      ),
                    ),
                  ),
                  if (controller.isProposalsLoading.value)
                    Expanded(child: Center(child: CircularProgressIndicator(color: AppColors.primary.getByBrightness(brightness))))
                  else if (proposals.isEmpty)
                    Expanded(
                      child: Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.inbox_outlined, size: 80, color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5)),
                            const SizedBox(height: 16),
                            Text(
                              controller.proposalSearchQuery.value.isEmpty 
                                  ? 'لم تقم باقتراح أي خدمة بعد' 
                                  : 'لا توجد نتائج بحث مطابقة',
                              style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 16)
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    Expanded(
                      child: RefreshIndicator(
                        onRefresh: controller.fetchMyProposals,
                        child: ListView.builder(
                          padding: const EdgeInsets.fromLTRB(20, 12, 20, 80),
                          itemCount: proposals.length,
                          itemBuilder: (context, index) {
                            final proposal = proposals[index];
                            return Container(
                              margin: const EdgeInsets.only(bottom: 16),
                              padding: const EdgeInsets.all(16),
                              decoration: BoxDecoration(
                                color: AppColors.surface.getByBrightness(brightness),
                                borderRadius: BorderRadius.circular(16),
                                boxShadow: [
                                  BoxShadow(
                                    color: Colors.black.withValues(alpha: 0.03),
                                    blurRadius: 10,
                                    offset: const Offset(0, 4),
                                  ),
                                ],
                                border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
                              ),
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Icon(Icons.new_releases_rounded, color: AppColors.secondary.getByBrightness(brightness)),
                                      const SizedBox(width: 8),
                                      Expanded(
                                        child: Text(
                                          proposal.serviceName,
                                          style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness)),
                                        ),
                                      ),
                                      Container(
                                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                        decoration: BoxDecoration(
                                          color: proposal.status == 'PENDING' ? Colors.orange.withValues(alpha: 0.1) : 
                                                proposal.status == 'APPROVED' ? Colors.green.withValues(alpha: 0.1) : Colors.red.withValues(alpha: 0.1),
                                          borderRadius: BorderRadius.circular(8),
                                        ),
                                        child: Text(
                                          proposal.status == 'PENDING' ? 'قيد المراجعة' : 
                                          proposal.status == 'APPROVED' ? 'مقبول' : 'مرفوض',
                                          style: TextStyle(
                                            fontSize: 12,
                                            color: proposal.status == 'PENDING' ? Colors.orange : 
                                                  proposal.status == 'APPROVED' ? Colors.green : Colors.red,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  const SizedBox(height: 8),
                                  Text(
                                    proposal.description ?? 'لا يوجد تفاصيل إضافية',
                                    style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 13),
                                  ),
                                  if (proposal.status == 'PENDING') ...[
                                    const SizedBox(height: 16),
                                    SizedBox(
                                      width: double.infinity,
                                      child: ElevatedButton.icon(
                                        style: ElevatedButton.styleFrom(
                                          backgroundColor: Colors.red.withValues(alpha: 0.1),
                                          foregroundColor: Colors.red,
                                          elevation: 0,
                                        ),
                                        onPressed: () {
                                          Get.defaultDialog(
                                            title: 'سحب الاقتراح',
                                            middleText: 'هل ترغب في التراجع عن هذا الاقتراح؟',
                                            textConfirm: 'سحب والتراجع',
                                            textCancel: 'إلغاء',
                                            confirmTextColor: Colors.white,
                                            onConfirm: () {
                                              Get.back();
                                              controller.withdrawProposal(proposal.id);
                                            },
                                          );
                                        },
                                        icon: const Icon(Icons.outbox_rounded, size: 18),
                                        label: const Text('التراجع عن الاقتراح'),
                                      ),
                                    ),
                                  ]
                                ],
                              ),
                            );
                          },
                        ),
                      ),
                    ),
                ],
              );
            }),
          ],
        ),
      ),
    );
  }
}
