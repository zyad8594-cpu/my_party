import 'package:flutter/material.dart';
import 'package:get/get.dart';
// import '../../../core/api/auth_service.dart';
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/logout_dialog.dart' show logoutDialog;
import '../controller/auth_controller.dart' show AuthController;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/themes/theme_service.dart' show ThemeService;
import '../../../core/services/config_service.dart' show ConfigService;
import '../../../core/routes/app_routes.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter_system_ringtones/flutter_system_ringtones.dart';

class ProfileScreen extends GetView<AuthController> {
  const ProfileScreen({super.key});

  // static const _basicFields = {
  //   'id', 'user_id', 'full_name', 'email', 'phone_number', 
  //   'role_name', 'img_url', 'phone', 'is_active', 'is_deleted', 
  //   'created_at', 'updated_at', 'token', 'role', 'password'
  // };

  // Map<String, dynamic> _getExtraDetails() {
  //   return Map.fromEntries(
  //     controller.user.entries.where((e) => !_basicFields.contains(e.key) && e.value != null)
  //   );
  // }

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      body: Obx(() {
        final extraDetails = controller.user.value.details;
        return RefreshIndicator(
          onRefresh: () async {
            await controller.loadUserData();
          },
          child: CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              _buildSliverAppBar(context),
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 24.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildSectionTitle(context, 'المعلومات الشخصية'),
                      const SizedBox(height: 12),
                      _buildPersonalInfoSection(context),
                      
                      const SizedBox(height: 24),
                      if (extraDetails.isNotEmpty) ...[
                        _buildSectionTitle(context, 'تفاصيل إضافية'),
                        const SizedBox(height: 12),
                        _buildExtraDetailsSection(context, extraDetails),
                      ],
                      
                      const SizedBox(height: 32),
                      _buildEditProfileButton(context),
                      
                      const SizedBox(height: 48),
                      _buildSectionTitle(context, 'إعدادات النظام'),
                      const SizedBox(height: 12),
                      _buildSystemSettingsSection(context),
                      
                      const SizedBox(height: 32),
                      _buildSectionTitle(context, 'الأمان والحساب'),
                      const SizedBox(height: 12),
                      _buildSecurityAndAccountSection(context),
                      
                      const SizedBox(height: 48),
                      _buildLogoutButton(context),
                      const SizedBox(height: 60),
                    ],
                  ),
                ),
              ),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildSliverAppBar(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return SliverAppBar(
      title: Text(
        'الملف الشخصي',
        style: TextStyle(
          color: AppColors.textBasec.getByBrightness(brightness),
          fontWeight: FontWeight.bold,
        ),
      ),
      expandedHeight: 260,
      pinned: true,
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      elevation: 0,
      scrolledUnderElevation: 0,
      flexibleSpace: FlexibleSpaceBar(
        background: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient.getByBrightness(brightness),
              ),
            ),
            Positioned(
              bottom: -30,
              right: -60,
              child: Icon(
                Icons.celebration_rounded,
                size: 250,
                color: Colors.white.withValues(alpha: 0.05),
              ),
            ),
            SafeArea(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Hero(
                    tag: 'profile_avatar',
                    child: Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.1),
                            blurRadius: 20,
                            offset: const Offset(0, 10),
                          ),
                        ],
                      ),
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: AppColors.primary.getByBrightness(brightness),
                        child: ClipOval(
                          child: controller.user.value.imgUrl != null && controller.user.value.imgUrl!.isNotEmpty
                            ? Image.network(
                                controller.user.value.imgUrl!,
                                width: 100,
                                height: 100,
                                fit: BoxFit.cover,
                                errorBuilder: (_, __, ___) => const Icon(Icons.person_rounded, size: 50, color: Colors.white),
                              )
                            : const Icon(Icons.person_rounded, size: 50, color: Colors.white),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withValues(alpha: 0.2),
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      controller.user.value.name.isNotEmpty?  controller.user.value.name:  'مستخدم',
                      style: const TextStyle(
                        fontSize: 22,
                        fontWeight: FontWeight.bold,
                        color: Colors.white,
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    controller.user.value.role == 'supplier' ? 'مزود خدمة' : (controller.user.value.role == 'coordinator' ? 'منسق حفلات' : (controller.user.value.role.isNotEmpty? controller.user.value.role: '')),
                    style: TextStyle(
                      color: Colors.white.withValues(alpha: 0.9),
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ],
        ),
      ),
      leading: IconButton(
        icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
        onPressed: () => Get.back(),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title) {
    final brightness = Theme.of(context).brightness;
    return Padding(
      padding: const EdgeInsets.only(left: 8.0, bottom: 4.0),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 16,
          fontWeight: FontWeight.bold,
          letterSpacing: 0.5,
          color: AppColors.textBody.getByBrightness(brightness),
        ),
      ),
    );
  }

  Widget _buildPersonalInfoSection(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return GlassCard(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          _buildProfileTile(
            context,
            icon: Icons.email_rounded,
            color: AppColors.info.getByBrightness(brightness),
            label: 'البريد الإلكتروني',
            value: controller.user.value.email ?? 'غير متوفر',
            showBorder: true,
          ),
          _buildProfileTile(
            context,
            icon: Icons.phone_rounded,
            color: AppColors.success.getByBrightness(brightness),
            label: 'رقم الجوال',
            value: controller.user.value.phoneNumber ?? 'غير متوفر',
            showBorder: false,
          ),
        ],
      ),
    );
  }

  Widget _buildExtraDetailsSection(BuildContext context, Map<String, dynamic> extraDetails) {
    final brightness = Theme.of(context).brightness;

    return GlassCard(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          if (extraDetails.isEmpty)
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: Text(
                'لا توجد تفاصيل إضافية',
                style: TextStyle(
                  color: AppColors.textSubtitle.getByBrightness(brightness),
                  fontStyle: FontStyle.italic,
                ),
              ),
            ),
          ...extraDetails.entries.toList().asMap().entries.map((entry) {
            final isLast = entry.key == extraDetails.length - 1;
            final e = entry.value;
            return _buildProfileTile(
              context,
              icon: Icons.info_outline_rounded,
              color: AppColors.primary.getByBrightness(brightness),
              label: e.key.replaceAll('_', ' ').capitalizeFirst!,
              value: e.value.toString(),
              showBorder: !isLast,
            );
          }),
        ],
      ),
    );
  }

  Widget _buildEditProfileButton(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.primary.getByBrightness(brightness),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 18),
          elevation: 4,
          shadowColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
        onPressed: () => _showEditProfileBottomSheet(context),
        icon: const Icon(Icons.edit_rounded, color: Colors.white, size: 22),
        label: const Text(
          'تعديل الملف الشخصي', 
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)
        ),
      ),
    );
  }

  Widget _buildSystemSettingsSection(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return GlassCard(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          ListTile(
            leading: _buildIconContainer(context, Icons.dark_mode_rounded, AppColors.primary.getByBrightness(brightness)),
            title: Text('الوضع الداكن', style: _settingTextStyle(context)),
            trailing: Switch(
              value: Get.isDarkMode,
              activeThumbColor: AppColors.primary.getByBrightness(brightness),
              onChanged: (value) {
                Get.find<ThemeService>().saveThemeToBox(value);
                Get.changeThemeMode(value ? ThemeMode.dark : ThemeMode.light);
              },
            ),
          ),
          _divider(context),
          Obx(() => ListTile(
            leading: _buildIconContainer(
              context, 
              Get.find<ConfigService>().notificationsEnabled.value ? Icons.notifications_active_rounded : Icons.notifications_off_rounded,
              AppColors.primary.getByBrightness(brightness),
            ),
            title: Text('تفعيل الإشعارات', style: _settingTextStyle(context)),
            trailing: Switch(
              value: Get.find<ConfigService>().notificationsEnabled.value,
              activeThumbColor: AppColors.primary.getByBrightness(brightness),
              onChanged: (value) => Get.find<ConfigService>().setNotificationsEnabled(value),
            ),
          )),
          _divider(context),
          Obx(() => ListTile(
            leading: _buildIconContainer(
              context,
              Get.find<ConfigService>().notificationSoundEnabled.value ? Icons.volume_up_rounded : Icons.volume_off_rounded,
              AppColors.accent.getByBrightness(brightness),
            ),
            title: Text('صوت الإشعارات', style: _settingTextStyle(context)),
            trailing: Switch(
              value: Get.find<ConfigService>().notificationSoundEnabled.value,
              activeThumbColor: AppColors.accent.getByBrightness(brightness),
              onChanged: (value) => Get.find<ConfigService>().setNotificationSoundEnabled(value),
            ),
          )),
          Obx(() => Visibility(
            visible: Get.find<ConfigService>().notificationSoundEnabled.value,
            child: ListTile(
              contentPadding: const EdgeInsets.symmetric(horizontal: 16),
              title: Text('نغمة التنبيه', style: TextStyle(fontSize: 14, color: AppColors.textBody.getByBrightness(brightness))),
              subtitle: Text(
                Get.find<ConfigService>().notificationSoundName.value,
                style: TextStyle(fontSize: 12, color: AppColors.textSubtitle.getByBrightness(brightness)),
              ),
              trailing: Icon(Icons.arrow_forward_ios_rounded, size: 14, color: AppColors.textSubtitle.getByBrightness(brightness)),
              onTap: () => _showSoundPicker(context),
            ),
          )),
        ],
      ),
    );
  }

  Widget _buildSecurityAndAccountSection(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return GlassCard(
      padding: const EdgeInsets.all(8),
      child: Column(
        children: [
          ListTile(
            onTap: () => _showChangePasswordBottomSheet(context, controller),
            leading: _buildIconContainer(context, Icons.lock_reset_rounded, AppColors.accent.getByBrightness(brightness)),
            title: Text('تغيير كلمة المرور', style: _settingTextStyle(context)),
            trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.textSubtitle.getByBrightness(brightness)),
          ),
          _divider(context),
          ListTile(
            onTap: () => Get.toNamed(AppRoutes.privacyPolicy),
            leading: _buildIconContainer(context, Icons.privacy_tip_rounded, AppColors.primary.getByBrightness(brightness)),
            title: Text('سياسة الخصوصية', style: _settingTextStyle(context)),
            trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.textSubtitle.getByBrightness(brightness)),
          ),
          _divider(context),
          ListTile(
            onTap: () => Get.toNamed(AppRoutes.termsConditions),
            leading: _buildIconContainer(context, Icons.gavel_rounded, AppColors.primary.getByBrightness(brightness)),
            title: Text('الشروط والأحكام', style: _settingTextStyle(context)),
            trailing: Icon(Icons.arrow_forward_ios_rounded, size: 16, color: AppColors.textSubtitle.getByBrightness(brightness)),
          ),
        ],
      ),
    );
  }

  Widget _buildLogoutButton(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return SizedBox(
      width: double.infinity,
      child: OutlinedButton.icon(
        onPressed: logoutDialog,
        icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
        label: Text(
          'تسجيل الخروج',
          style: TextStyle(
            color: AppColors.accent.getByBrightness(brightness),
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
        style: OutlinedButton.styleFrom(
          padding: const EdgeInsets.symmetric(vertical: 18),
          side: BorderSide(color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.5), width: 2),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
    );
  }

  // --- Helpers ---

  Widget _buildIconContainer(BuildContext context, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Icon(icon, color: color, size: 22),
    );
  }

  TextStyle _settingTextStyle(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return TextStyle(
      fontWeight: FontWeight.w600,
      color: AppColors.textBody.getByBrightness(brightness),
    );
  }

  Widget _divider(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return Divider(
      height: 1,
      indent: 70,
      color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1),
    );
  }

  Widget _buildProfileTile(
    BuildContext context, {
    required IconData icon,
    required Color color,
    required String label,
    required String value,
    required bool showBorder,
  }) {
    final brightness = Theme.of(context).brightness;
    return Container(
      decoration: BoxDecoration(
        border: showBorder
            ? Border(
                bottom: BorderSide(
                  color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1),
                  width: 1,
                ),
              )
            : null,
      ),
      child: ListTile(
        leading: _buildIconContainer(context, icon, color),
        title: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppColors.textSubtitle.getByBrightness(brightness),
          ),
        ),
        subtitle: Text(
          value,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.bold,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
      ),
    );
  }

  // --- Bottom Sheets ---

  void _showEditProfileBottomSheet(BuildContext context) {
    final nameController = TextEditingController(text: controller.user.value.name);
    final emailController = TextEditingController(text: controller.user.value.email ?? '');
    final phoneController = TextEditingController(text: controller.user.value.phoneNumber ?? '');
    
    final extraDetails = controller.user.value.details;
    final extraControllers = <String, TextEditingController>{};
    extraDetails.forEach((key, value) {
      extraControllers[key] = TextEditingController(text: value.toString());
    });
    
    final brightness = Theme.of(context).brightness;

    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24.0),
        decoration: BoxDecoration(
          color: AppColors.surface.getByBrightness(brightness),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: SingleChildScrollView(
          physics: const BouncingScrollPhysics(),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text('تعديل الملف الشخصي', 
                style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))
              ),
              const SizedBox(height: 24),
              Center(
                child: Stack(
                  children: [
                    Obx(() => Container(
                      padding: const EdgeInsets.all(4),
                      decoration: BoxDecoration(
                        color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                        shape: BoxShape.circle,
                      ),
                      child: CircleAvatar(
                        radius: 50,
                        backgroundColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
                        backgroundImage: controller.profileImage.value != null 
                            ? FileImage(controller.profileImage.value!) 
                            : (controller.user.value.imgUrl != null ? NetworkImage(controller.user.value.imgUrl!) : null) as ImageProvider?,
                        child: (controller.profileImage.value == null && controller.user.value.imgUrl == null)
                            ? Icon(Icons.person_rounded, size: 50, color: AppColors.primary.getByBrightness(brightness))
                            : null,
                      ),
                    )),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: GestureDetector(
                        onTap: () => controller.pickImage(),
                        child: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.accent.getByBrightness(brightness),
                            shape: BoxShape.circle,
                            border: Border.all(color: AppColors.surface.getByBrightness(brightness), width: 3),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withValues(alpha: 0.2),
                                blurRadius: 8,
                                offset: const Offset(0, 4),
                              )
                            ]
                          ),
                          child: const Icon(Icons.camera_alt_rounded, color: Colors.white, size: 16),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              _buildTextInputField(nameController, 'الاسم الكامل', Icons.person_rounded, brightness),
              const SizedBox(height: 16),
              _buildTextInputField(emailController, 'البريد الإلكتروني', Icons.email_rounded, brightness, keyboardType: TextInputType.emailAddress),
              const SizedBox(height: 16),
              _buildTextInputField(phoneController, 'رقم الجوال', Icons.phone_rounded, brightness, keyboardType: TextInputType.phone),
              const SizedBox(height: 16),
              ...extraControllers.entries.map((e) => Padding(
                padding: const EdgeInsets.only(bottom: 16),
                child: _buildTextInputField(e.value, e.key.replaceAll('_', ' ').capitalizeFirst!, Icons.info_outline_rounded, brightness),
              )),
              const SizedBox(height: 32),
              Obx(() => SizedBox(
                width: double.infinity,
                child: controller.isLoading.value? const LoadingWidget() : ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: AppColors.primary.getByBrightness(brightness),
                    foregroundColor: Colors.white,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  ),
                  onPressed: controller.isLoading.value ? null : () async {
                    final updatedExtra = <String, dynamic>{};
                    extraControllers.forEach((key, ctrl) {
                      updatedExtra[key] = ctrl.text.trim();
                    });
                    
                    await controller.updateProfile(
                      newName: nameController.text.trim(),
                      newEmail: emailController.text.trim(),
                      newPhone: phoneController.text.trim(),
                      newImage: controller.profileImage.value,
                      extraDetails: updatedExtra,
                    );
                    if (Get.isBottomSheetOpen == true) 
                    {
                      Get.back();
                      controller.isLoading.value = false;
                    }
                  },
                  child: controller.isLoading.value 
                    ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                    : const Text('حفظ التعديلات', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ),
              )),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  void _showChangePasswordBottomSheet(BuildContext context, AuthController controller) {
    final oldPasswordController = TextEditingController();
    final newPasswordController = TextEditingController();
    final confirmPasswordController = TextEditingController();
    final formKey = GlobalKey<FormState>();
    final brightness = Theme.of(context).brightness;

    Get.bottomSheet(
      Container(
        padding: EdgeInsets.only(
          left: 24.0, right: 24.0, top: 24.0, 
          bottom: MediaQuery.of(context).viewInsets.bottom + 24.0
        ),
        decoration: BoxDecoration(
          color: AppColors.surface.getByBrightness(brightness),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Form(
          key: formKey,
          child: SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Container(
                    width: 40,
                    height: 4,
                    decoration: BoxDecoration(
                      color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.3),
                      borderRadius: BorderRadius.circular(2),
                    ),
                  ),
                ),
                const SizedBox(height: 24),
                Text('تغيير كلمة المرور', 
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))
                ),
                const SizedBox(height: 24),
                _buildTextInputField(
                  oldPasswordController, 'كلمة المرور الحالية', Icons.lock_outline_rounded, brightness, 
                  obscureText: true,
                  validator: (v) => v!.isEmpty ? 'مطلوب' : null,
                ),
                const SizedBox(height: 16),
                _buildTextInputField(
                  newPasswordController, 'كلمة المرور الجديدة', Icons.lock_rounded, brightness, 
                  obscureText: true,
                  validator: (v) => v!.length < 6 ? 'يجب أن تكون 6 أحرف على الأقل' : null,
                ),
                const SizedBox(height: 16),
                _buildTextInputField(
                  confirmPasswordController, 'تأكيد كلمة المرور الجديدة', Icons.lock_clock_rounded, brightness, 
                  obscureText: true,
                  validator: (v) => v != newPasswordController.text ? 'كلمات المرور غير متطابقة' : null,
                ),
                const SizedBox(height: 32),
                Obx(() => SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.accent.getByBrightness(brightness),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: controller.isLoading.value ? null : () async {
                      if (formKey.currentState!.validate()) {
                        await controller.changePassword(
                          oldPasswordController.text,
                          newPasswordController.text,
                        );
                        if (Get.isBottomSheetOpen == true) Get.back();
                      }
                    },
                    child: controller.isLoading.value 
                      ? const SizedBox(width: 20, height: 20, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.white))
                      : const Text('تغيير كلمة المرور', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                  ),
                )),
                const SizedBox(height: 12),
              ],
            ),
          ),
        ),
      ),
      isScrollControlled: true,
    );
  }

  Widget _buildTextInputField(
    TextEditingController controller, String label, IconData icon, Brightness brightness, 
    {bool obscureText = false, TextInputType? keyboardType, String? Function(String?)? validator}
  ) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      keyboardType: keyboardType,
      validator: validator,
      style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      decoration: InputDecoration(
        labelText: label,
        labelStyle: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness)),
        filled: true,
        fillColor: AppColors.background.getByBrightness(brightness),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide.none,
        ),
        prefixIcon: Icon(icon, color: AppColors.primary.getByBrightness(brightness)),
        contentPadding: const EdgeInsets.symmetric(vertical: 18),
      ),
    );
  }

  void _showSoundPicker(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    Get.bottomSheet(
      Container(
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          color: AppColors.surface.getByBrightness(brightness),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.3),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 24),
            Text(
              'اختر صوت الإشعارات',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
            const SizedBox(height: 20),
            _buildPickerOption(
              context,
              icon: Icons.phonelink_ring_rounded,
              title: 'أصوات الهاتف الافتراضية',
              onTap: () {
                Get.back();
                _pickSystemSound(context);
              },
              brightness: brightness,
            ),
            const SizedBox(height: 12),
            _buildPickerOption(
              context,
              icon: Icons.audio_file_rounded,
              title: 'إضافة صوت من ملفاتك',
              onTap: () {
                Get.back();
                _pickCustomSound();
              },
              brightness: brightness,
            ),
            const SizedBox(height: 12),
            _buildPickerOption(
              context,
              icon: Icons.restore_rounded,
              title: 'استعادة الافتراضي',
              onTap: () {
                Get.back();
                Get.find<ConfigService>().setNotificationSound('', 'Default', 'default');
              },
              brightness: brightness,
            ),
            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget _buildPickerOption(
    BuildContext context, {
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required Brightness brightness,
  }) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
          borderRadius: BorderRadius.circular(16),
          color: AppColors.background.getByBrightness(brightness),
        ),
        child: Row(
          children: [
            _buildIconContainer(context, icon, AppColors.primary.getByBrightness(brightness)),
            const SizedBox(width: 16),
            Text(title, style: TextStyle(fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
          ],
        ),
      ),
    );
  }

  Future<void> _pickCustomSound() async {
    try {
      final dynamic picker = (FilePicker as dynamic).platform;
      final result = await picker.pickFiles(
        type: FileType.audio,
        allowMultiple: false,
      );

      if (result != null && result.files.single.path != null) {
        final String path = result.files.single.path!;
        final String name = result.files.single.name;
        Get.find<ConfigService>().setNotificationSound(path, name, 'custom');
      }
    } catch (e) {
      Get.snackbar('خطأ', 'فشل في اختيار الملف الصوتي');
    }
  }

  Future<void> _pickSystemSound(BuildContext context) async {
    final brightness = Theme.of(context).brightness;
    try {
      final dynamic ringtones = await (FlutterSystemRingtones as dynamic).getRingtones();
      if (ringtones.isEmpty) {
        Get.snackbar('تنبيه', 'لا توجد أصوات هاتف مكتشفة');
        return;
      }

      Get.bottomSheet(
        Container(
          padding: const EdgeInsets.all(24),
          height: Get.height * 0.6,
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(32)),
          ),
          child: Column(
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  decoration: BoxDecoration(
                    color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.3),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
              ),
              const SizedBox(height: 24),
              Text(
                'أصوات الهاتف',
                style: TextStyle(
                  fontSize: 18, 
                  fontWeight: FontWeight.bold,
                  color: AppColors.textBody.getByBrightness(brightness),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.separated(
                  physics: const BouncingScrollPhysics(),
                  itemCount: ringtones.length,
                  separatorBuilder: (context, index) => Divider(
                    color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1),
                  ),
                  itemBuilder: (context, index) {
                    final dynamic ringtone = ringtones[index];
                    return ListTile(
                      leading: _buildIconContainer(context, Icons.music_note_rounded, AppColors.info.getByBrightness(brightness)),
                      title: Text(
                        ringtone.title,
                        style: TextStyle(fontWeight: FontWeight.w600, color: AppColors.textBody.getByBrightness(brightness)),
                      ),
                      onTap: () {
                        Get.back();
                        Get.find<ConfigService>().setNotificationSound(ringtone.uri, ringtone.title, 'system');
                      },
                    );
                  },
                ),
              ),
            ],
          ),
        ),
      );
    } catch (e) {
      Get.snackbar('خطأ', 'فشل في جلب أصوات الهاتف');
    }
  }
}
