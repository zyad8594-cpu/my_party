import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter_ringtone_player/flutter_ringtone_player.dart';
import '../../../core/api/auth_service.dart' show AuthService;
import '../../../features/notifications/data/repository/notification_repository.dart' show NotificationRepository;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../../../data/models/notification.dart' show NotificationModel;
import '../../../core/services/socket_service.dart' show SocketService;
import '../../../core/services/config_service.dart' show ConfigService;

class NotificationController extends GetxController 
{
  final NotificationRepository _repository = Get.find<NotificationRepository>();
  late final SocketService _socketService;
  final ConfigService _configService = Get.find<ConfigService>();
  final AudioPlayer _audioPlayer = AudioPlayer();

  final notifications = <NotificationModel>[].obs;
  final searchQuery = ''.obs;
  final isLoading = false.obs;
  final isMoreLoading = false.obs;
  final notiNotReadCount = 0.obs;

  List<NotificationModel> get filteredNotifications {
    if (searchQuery.isEmpty) return notifications;
    return notifications.where((n) {
      return (n.title.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
             n.message.toLowerCase().contains(searchQuery.value.toLowerCase())) &&
             (n.userId == AuthService.user.value.id || n.supplierId == AuthService.user.value.id);
    }).toList();
  }

  @override
  void onInit() {
    _socketService = Get.find<SocketService>();
    
    // Fetch only if already logged in (e.g. app restart with saved token)
    if (AuthService.token.isNotEmpty) {
      fetchNotifications(force: true);
    }

    // React to token changes (Login/Logout)
    ever(AuthService.token, (String token) {
      if (token.isNotEmpty) {
        fetchNotifications(force: true);
      } else {
        notifications.clear();
        notiNotReadCount.value = 0;
      }
    });

    // Listening to notification stream from socket server
    _socketService.onNotification.listen(_handleNewNotification);
    super.onInit();
  }

  @override
  void onClose() {
    _audioPlayer.dispose();
    super.onClose();
  }

  void _handleNewNotification(NotificationModel notification) 
  {
    bool isForMe = (notification.userId != null && notification.userId == AuthService.user.value.id) ||
                   (notification.supplierId != null && notification.supplierId == AuthService.user.value.id);
    
    if (isForMe) {
      bool exists = notifications.any((n) => n.id == notification.id);
      if (!exists) {
        notifications.insert(0, notification);
        if (!notification.isRead) {
          notiNotReadCount.value++;
          
          // Check user preferences from ConfigService
          if (_configService.notificationsEnabled.value) {
            Get.snackbar(notification.title, notification.message, snackPosition: SnackPosition.TOP);
            
            // Play sound if enabled
            if (_configService.notificationSoundEnabled.value) {
              _playNotificationSound();
            }
          }
        }
      }
    }
  }

  Future<void> _playNotificationSound() async {
    if (!_configService.notificationSoundEnabled.value) return;

    try {
      final type = _configService.notificationSoundType.value;
      final path = _configService.notificationSoundPath.value;

      if (type == 'custom' && path.isNotEmpty) {
        // Play custom file picked by user
        await _audioPlayer.play(DeviceFileSource(path));
      } else if (type == 'system' && path.isNotEmpty) {
        // Play system sound by URI (common on Android)
        await _audioPlayer.play(UrlSource(path));
      } else {
        // Default behavior: custom asset or fallback to system notification
        try {
          await _audioPlayer.play(AssetSource('sounds/notification.mp3'));
        } catch (e) {
          await FlutterRingtonePlayer().play(
            android: AndroidSounds.notification,
            ios: IosSounds.glass,
            looping: false,
            volume: 1.0,
          );
        }
      }
    } catch (e) {
      debugPrint('Error playing notification sound: $e');
    }
  }

  /// Fetches notifications from repository
  Future<void> fetchNotifications({bool force = false}) async {
    if (AuthService.token.isEmpty) return;
    if (!force && notifications.isNotEmpty) return;
    
    try {
      isLoading.value = true;
      final result = await _repository.getAll();
      notifications.assignAll(result);
      notifications.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      notiNotReadCount.value = notifications.where((notification) => !notification.isRead).length;
    } catch (e) {
      MyPUtils.showSnackbar('خطاء', '$e', isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  /// Marks a specific notification as read
  Future<void> markAsRead(int id) async {
    try {
      await _repository.markAsRead(id);
      final index = notifications.indexWhere((n) => n.id == id);
      if (index != -1) {
        notifications[index] = notifications[index].copyWith(isRead: true);
        if (notiNotReadCount.value > 0) {
          notiNotReadCount.value--;
        }
      }
    } catch (e) {
      MyPUtils.showSnackbar('Error', 'Failed to mark notification as read', isError: true);
    }
  }

  /// Clears all notifications (matches repository.clearAll)
  Future<void> clearAll() async {
    try {
      await _repository.clearAll();
      notifications.clear();
      notiNotReadCount.value = 0;
    } catch (e) {
      MyPUtils.showSnackbar('Error', 'Failed to clear all notifications', isError: true);
    }
  }

  /// Marks all as read (if needed by UI)
  Future<void> markAllAsRead() async {
    try {
      // If repository doesn't have a specific markAllAsRead, we might need a loop or update repository
      // Let's assume clearAll was intended as MarkAllAsRead in some contexts, but here it's ClearAll.
      // I'll stick to what the repository has.
      for (var n in notifications) {
        if (!n.isRead) {
          await _repository.markAsRead(n.id);
        }
      }
      fetchNotifications();
    } catch (e) {
      MyPUtils.showSnackbar('Error', 'Failed to mark all as read', isError: true);
    }
  }

  /// Deletes a specific notification
  Future<void> deleteNotification(int id) async {
    try {
      await _repository.delete(id);
      notifications.removeWhere((n) => n.id == id);
      notiNotReadCount.value = notifications.where((n) => !n.isRead).length;
    } catch (e) {
      MyPUtils.showSnackbar('Error', 'Failed to delete notification', isError: true);
    }
  }
}
