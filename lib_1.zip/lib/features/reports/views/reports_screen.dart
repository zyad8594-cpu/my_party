import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/globle_card.dart' show GlobleCard;
import '../controller/reports_controller.dart' show ReportsController;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../events/data/models/event.dart';
import '../../tasks/data/models/task.dart';
import '../../suppliers/data/models/supplier.dart';
import '../../../core/utils/status.dart';

class ReportsScreen extends GetView<ReportsController> {
  const ReportsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    return DefaultTabController(
      length: 4,
      child: Scaffold(
        backgroundColor: AppColors.background.getByBrightness(brightness),
        appBar: CustomAppBar(
          title: 'التقارير التحليلية',
          bottom: TabBar(
            isScrollable: true,
            indicatorColor: AppColors.primary.getByBrightness(brightness),
            labelColor: AppColors.primary.getByBrightness(brightness),
            unselectedLabelColor: Colors.grey,
            tabs: const [
              Tab(text: 'المناسبات', icon: Icon(Icons.event_note)),
              Tab(text: 'المهام', icon: Icon(Icons.task_alt)),
              Tab(text: 'الموردين', icon: Icon(Icons.people_outline)),
              Tab(text: 'المالية', icon: Icon(Icons.account_balance_wallet_outlined)),
            ],
          ),
        ),
        body: Obx(() {
          if (controller.isLoading.value) {
            return const LoadingWidget();
          }
          return TabBarView(
            children: [
              _buildEventsTab(context),
              _buildTasksTab(context),
              _buildSuppliersTab(context),
              _buildFinancialTab(context),
            ],
          );
        }),
      ),
    );
  }

  // --- Common Components ---

  Widget _buildSearchAndFilter(BuildContext context, RxString searchQuery, VoidCallback onExport) {
    final brightness = Theme.of(context).brightness;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              onChanged: (v) => searchQuery.value = v,
              decoration: InputDecoration(
                hintText: 'بحث...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: AppColors.surface.getByBrightness(brightness),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                  borderSide: BorderSide.none,
                ),
                contentPadding: const EdgeInsets.symmetric(vertical: 0),
              ),
            ),
          ),
          const SizedBox(width: 8),

          // IconButton(
          //   icon: const Icon(Icons.date_range),
          //   onPressed: () => _showDateFilter(context),
          //   color: AppColors.primary.getByBrightness(brightness),
          // ),
          IconButton(
            icon: const Icon(Icons.picture_as_pdf),
            onPressed: onExport,
            color: Colors.red,
          ),
        ],
      ),
    );
  }

  Future<void> _showDateFilter(BuildContext context) async {
    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime(2030),
      initialDateRange: controller.customDateRange.value,
    );
    if (picked != null) {
      controller.customDateRange.value = picked;
      controller.selectedTimeFilter.value = 'مخصص';
    }
  }

  Widget _buildStatHeader(List<Widget> children) {
    return Container(
      padding: const EdgeInsets.all(16),
      child: Wrap(
        spacing: 12,
        runSpacing: 12,
        children: children.map((w) => SizedBox(width: Get.width * 0.44, child: w)).toList(),
      ),
    );
  }

  // --- Events Tab ---

  Widget _buildEventsTab(BuildContext context) {
    final stats = controller.eventStats;
    final events = controller.displayEvents;

    return Column(
      children: [
        _buildSearchAndFilter(context, controller.eventsSearchQuery, () => controller.exportReport('PDF', tabName: 'المناسبات')),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 20),
            children: [
              _buildStatHeader([
                GlobleCard(title: 'إجمالي المناسبات', value: '${stats['total']}', icon: Icons.event, color: Colors.blue),
                GlobleCard(title: 'مكتملة', value: '${stats['completed']}', icon: Icons.check_circle, color: Colors.green),
                GlobleCard(title: 'قيد الانتظار', value: '${stats['pending']}', icon: Icons.hourglass_empty, color: Colors.orange),
                GlobleCard(title: 'قيد التنفيذ', value: '${stats['inProgress']}', icon: Icons.run_circle_outlined, color: Colors.blueAccent),
                GlobleCard(title: 'ملغاة', value: '${stats['cancelled']}', icon: Icons.cancel, color: Colors.red),
                GlobleCard(title: 'إجمالي الميزانية', value: '${stats['totalBudget'].toStringAsFixed(0)}', icon: Icons.money, color: Colors.purple),
                GlobleCard(title: 'إجمالي المصروفات', value: '${stats['totalExpenses'].toStringAsFixed(0)}', icon: Icons.outbox, color: Colors.deepOrange),
                GlobleCard(title: 'إجمالي الدفعات', value: '${stats['totalPayments'].toStringAsFixed(0)}', icon: Icons.payments, color: Colors.teal),
              ]),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Text('قائمة المناسبات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...events.map((e) => _buildEventCard(context, e)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildEventCard(BuildContext context, Event event) {
    final brightness = Theme.of(context).brightness;
    final progress = event.totalTasks > 0 ? (event.completedTasks / event.totalTasks) : 0.0;

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: ExpansionTile(
        shape: const RoundedRectangleBorder(side: BorderSide.none),
        collapsedShape: const RoundedRectangleBorder(side: BorderSide.none),
        leading: CircleAvatar(
          backgroundImage: NetworkImage(event.imgUrl),
          onBackgroundImageError: (_, __) => const Icon(Icons.event),
        ),
        title: Text(event.eventName, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(event.eventDate, style: const TextStyle(fontSize: 12)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.print, size: 20, color: Colors.blueAccent),
              onPressed: () => controller.exportSingleItem('Event', event),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: event.status.tryColor(brightness).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Text(event.status.tryText(), style: TextStyle(color: event.status.tryColor(brightness), fontSize: 10, fontWeight: FontWeight.bold)),
            ),
            const Icon(Icons.keyboard_arrow_down_rounded),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildSmallInfo('المهام', '${event.totalTasks.toInt()}'),
                    _buildSmallInfo('مكتملة', '${event.completedTasks.toInt()}'),
                    _buildSmallInfo('انتظار', '${event.pendingTasks.toInt()}'),
                    _buildSmallInfo('تنفيذ', '${(event.totalTasks - event.completedTasks - event.pendingTasks - event.cancelledTasks).toInt()}'),
                  ],
                ),
                const Divider(height: 24),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildSmallInfo('الميزانية', event.budget.toStringAsFixed(0)),
                    _buildSmallInfo('المصروفات', event.totalExpenses.toStringAsFixed(0)),
                    _buildSmallInfo('الدفعات', event.totalIncome.toStringAsFixed(0)),
                    _buildSmallInfo('المتبقي', (event.budget - event.totalExpenses).toStringAsFixed(0), color: Colors.blue),
                  ],
                ),
                const SizedBox(height: 16),
                LinearProgressIndicator(
                  value: progress,
                  backgroundColor: Colors.grey[300],
                  valueColor: AlwaysStoppedAnimation<Color>(AppColors.primary.getByBrightness(brightness)),
                  borderRadius: BorderRadius.circular(4),
                ),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text('نسبة الإنجاز: ${(progress * 100).toStringAsFixed(0)}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                    Text('الموردين: ${controller.getSuppliersCountForEvent(event.id)}', style: const TextStyle(fontSize: 12)),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Tasks Tab ---

  Widget _buildTasksTab(BuildContext context) {
    final stats = controller.taskStats;
    final tasks = controller.displayTasks;

    return Column(
      children: [
        _buildSearchAndFilter(context, controller.tasksSearchQuery, () => controller.exportReport('PDF', tabName: 'المهام')),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 20),
            children: [
              _buildStatHeader([
                GlobleCard(title: 'إجمالي المهام', value: '${stats['total']}', icon: Icons.task, color: Colors.blue),
                GlobleCard(title: 'مكتملة', value: '${stats['completed']}', icon: Icons.check_circle, color: Colors.green),
                GlobleCard(title: 'قيد التنفيذ', value: '${stats['inProgress']}', icon: Icons.run_circle_outlined, color: Colors.orange),
                GlobleCard(title: 'قيد الانتظار', value: '${stats['pending']}', icon: Icons.hourglass_empty, color: Colors.blueAccent),
                GlobleCard(title: 'ملغاة', value: '${stats['cancelled']}', icon: Icons.cancel, color: Colors.red),
                GlobleCard(title: 'مرفوضة', value: '${stats['rejected']}', icon: Icons.thumb_down, color: Colors.black),
                GlobleCard(title: 'قيد المراجعة', value: '${stats['inReview']}', icon: Icons.rate_review, color: Colors.purple),
                GlobleCard(title: 'إجمالي المصروفات', value: '${stats['totalExpenses'].toStringAsFixed(0)}', icon: Icons.money_off, color: Colors.deepOrange),
              ]),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Text('قائمة المهام', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...tasks.map((t) => _buildTaskCard(context, t)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildTaskCard(BuildContext context, Task task) {
    final brightness = Theme.of(context).brightness;
    final supplier = controller.supplierController.suppliers.firstWhereOrNull((s) => s.id == task.userAssignId);
    final event = controller.eventController.events.firstWhereOrNull((e) => e.id == task.eventId);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      clipBehavior: Clip.antiAlias,
      child: ExpansionTile(
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(color: task.status.tryColor(brightness).withValues(alpha: 0.1), shape: BoxShape.circle),
              child: Icon(Icons.task, color: task.status.tryColor(brightness)),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(task.typeTask ?? 'مهمة', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                  Text(task.status.tryText(), style: TextStyle(color: task.status.tryColor(brightness), fontSize: 12)),
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text('${task.cost.toStringAsFixed(0)} ر.س', style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
                const SizedBox(height: 4),
                InkWell(
                  onTap: () => controller.exportSingleItem('Task', task),
                  child: const Icon(Icons.print, size: 20, color: Colors.blueAccent),
                ),
              ],
            ),
          ],
        ),
        childrenPadding: const EdgeInsets.all(16.0),
        children: [
          // Event info
          if (event != null) ...[
            Row(
              children: [
                CircleAvatar(
                  radius: 20,
                  backgroundImage: event.imgUrl.isNotEmpty ? NetworkImage(event.imgUrl) : null,
                  child: event.imgUrl.isEmpty ? const Icon(Icons.event) : null,
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(event.eventName, style: const TextStyle(fontWeight: FontWeight.bold)),
                      Text('المناسبة', style: TextStyle(fontSize: 10, color: Colors.grey[600])),
                    ],
                  ),
                ),
              ],
            ),
            const Divider(height: 24),
          ],

          // Supplier Info
          Row(
            children: [
              CircleAvatar(
                radius: 20,
                backgroundImage: (supplier?.imgUrl != null && supplier!.imgUrl!.isNotEmpty) ? NetworkImage(supplier.imgUrl!) : null,
                child: (supplier?.imgUrl == null || supplier!.imgUrl!.isEmpty) ? const Icon(Icons.person) : null,
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(task.assigneName ?? supplier?.name ?? 'غير معين', style: const TextStyle(fontWeight: FontWeight.bold)),
                    if (supplier?.email != null && supplier!.email.isNotEmpty) 
                      Text(supplier.email, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                    if (supplier?.phoneNumber != null && supplier!.phoneNumber!.isNotEmpty) 
                      Text(supplier.phoneNumber!, style: TextStyle(fontSize: 11, color: Colors.grey[600])),
                    if (supplier == null)
                      Text('المورد المكلّف', style: TextStyle(fontSize: 10, color: Colors.grey[600])),
                  ],
                ),
              ),
              if (task.rating != null)
                Row(
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 16),
                    Text(' ${task.rating!.toStringAsFixed(1)}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
            ],
          ),
          
          const Divider(height: 24),
          
          // Dates & Description
          Align(
            alignment: Alignment.centerRight,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (task.description != null && task.description!.isNotEmpty) ...[
                  const Text('وصف المهمة:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 4),
                  Text(task.description!, style: const TextStyle(fontSize: 12)),
                  const SizedBox(height: 12),
                ],
                _buildDateRow('تاريخ المهمة', task.createdAt),
                _buildDateRow('تاريخ الاستحقاق', task.dateDue),
                _buildDateRow('تاريخ التسليم', task.dateCompletion),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDateRow(String label, String? dateStr) {
    if (dateStr == null || dateStr.isEmpty) return const SizedBox.shrink();
    return Padding(
      padding: const EdgeInsets.only(bottom: 6.0),
      child: Row(
        children: [
          const Icon(Icons.calendar_today, size: 14, color: Colors.grey),
          const SizedBox(width: 8),
          Text('$label: ', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
          Text(dateStr.split(' ')[0], style: const TextStyle(fontSize: 13)),
        ],
      ),
    );
  }

  // --- Suppliers Tab ---

  Widget _buildSuppliersTab(BuildContext context) {
    final stats = controller.supplierStats;
    final suppliers = controller.displaySuppliers;

    return Column(
      children: [
        _buildSearchAndFilter(context, controller.suppliersSearchQuery, () => controller.exportReport('PDF', tabName: 'الموردين')),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.only(bottom: 20),
            children: [
              _buildStatHeader([
                GlobleCard(title: 'إجمالي الموردين النشطين', value: '${stats['total']}', icon: Icons.people, color: Colors.blue),
              ]),
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 16.0),
                child: Text('قائمة الموردين وأدائهم', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              ),
              ...suppliers.map((s) => _buildSupplierCard(context, s)),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSupplierCard(BuildContext context, Supplier supplier) {
    final stats = controller.getSupplierDetailedStats(supplier);

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ExpansionTile(
        leading: CircleAvatar(
          backgroundImage: NetworkImage(supplier.imgUrl ?? ''),
          onBackgroundImageError: (_, __) => const Icon(Icons.person),
        ),
        title: Text(supplier.name, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(supplier.email, style: const TextStyle(fontSize: 10)),
        trailing: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            IconButton(
              icon: const Icon(Icons.print, size: 20, color: Colors.blueAccent),
              onPressed: () => controller.exportSingleItem('Supplier', supplier),
            ),
            Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.star, color: Colors.amber, size: 16),
                    Text(' ${supplier.averageRating?.toStringAsFixed(1) ?? '0.0'}', style: const TextStyle(fontWeight: FontWeight.bold)),
                  ],
                ),
                Text('${stats['servicesCount']} خدمات', style: const TextStyle(fontSize: 10, color: Colors.grey)),
              ],
            ),
          ],
        ),
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('إحصائيات المهام', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                _buildDetailedRow('الكل', stats['taskCounts']['total'].toString(), '${stats['taskCosts']['total']} ر.س'),
                _buildDetailedRow('مكتملة', stats['taskCounts']['completed'].toString(), '${stats['taskCosts']['completed']} ر.س', color: Colors.green),
                _buildDetailedRow('تنفيذ', stats['taskCounts']['inProgress'].toString(), '${stats['taskCosts']['inProgress']} ر.س', color: Colors.orange),
                _buildDetailedRow('انتظار', stats['taskCounts']['pending'].toString(), '${stats['taskCosts']['pending']} ر.س', color: Colors.blue),
                _buildDetailedRow('ملغاة/مرفوضة', (stats['taskCounts']['cancelled'] + stats['taskCounts']['rejected']).toString(), '${stats['taskCosts']['cancelled'] + stats['taskCosts']['rejected']} ر.س', color: Colors.red),
                const Divider(),
                const Text('المشاركة في المناسبات', style: TextStyle(fontWeight: FontWeight.bold)),
                const SizedBox(height: 8),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    _buildSmallInfo('الكل', '${stats['totalEvents']}'),
                    _buildSmallInfo('مكتملة', '${stats['eventsCompleted']}'),
                    _buildSmallInfo('تنفيذ', '${stats['eventsInProgress']}'),
                    _buildSmallInfo('انتظار', '${stats['eventsPending']}'),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- Financial Tab ---

  Widget _buildFinancialTab(BuildContext context) {
    final stats = controller.financialStats;
    final brightness = Theme.of(context).brightness;

    return SingleChildScrollView(
      padding: const EdgeInsets.only(bottom: 20),
      child: Column(
        children: [
          _buildSearchAndFilter(context, controller.financialSearchQuery, () => controller.exportReport('PDF')),
          _buildStatHeader([
            GlobleCard(title: 'إجمالي الميزانية', value: '${stats['totalBudget'].toStringAsFixed(0)}', icon: Icons.account_balance, color: Colors.blue),
            GlobleCard(title: 'إجمالي الدخل', value: '${stats['totalIncome'].toStringAsFixed(0)}', icon: Icons.trending_up, color: Colors.green),
            GlobleCard(title: 'إجمالي المصروفات', value: '${stats['totalExpenses'].toStringAsFixed(0)}', icon: Icons.trending_down, color: Colors.red),
            GlobleCard(title: 'إجمالي المتبقي', value: '${stats['totalRemaining'].toStringAsFixed(0)}', icon: Icons.account_balance_wallet, color: Colors.purple),
            GlobleCard(title: 'إجمالي الأرباح', value: '${stats['totalProfit'].toStringAsFixed(0)}', icon: Icons.monetization_on, color: Colors.teal),
            GlobleCard(title: 'إجمالي الخسارة', value: '${stats['totalLoss'].toStringAsFixed(0)}', icon: Icons.money_off, color: Colors.redAccent),
          ]),
          const SizedBox(height: 20),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(colors: [AppColors.primary.getByBrightness(brightness), AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.7)]),
                borderRadius: BorderRadius.circular(20),
              ),
              child: Column(
                children: [
                  const Text('تحليل كفاءة الميزانية', style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 20),
                  _buildFinancialCircularIndicator(stats['totalExpenses'], stats['totalBudget'], 'المصروفات من الميزانية'),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          _buildSectionHeader('التدفق المالي'),
          _buildFinancialSummaryCard(context, 'صافي التدفق النقدي', '${(stats['totalIncome'] - stats['totalExpenses']).toStringAsFixed(0)} ر.س', Icons.swap_vert),
        ],
      ),
    );
  }

  Widget _buildFinancialCircularIndicator(double value, double total, String label) {
    final percent = total > 0 ? (value / total).clamp(0.0, 1.0) : 0.0;
    return Column(
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            SizedBox(
              height: 120,
              width: 120,
              child: CircularProgressIndicator(
                value: percent,
                strokeWidth: 10,
                backgroundColor: Colors.white.withValues(alpha: 0.2),
                valueColor: const AlwaysStoppedAnimation<Color>(Colors.white),
              ),
            ),
            Text('${(percent * 100).toStringAsFixed(1)}%', style: const TextStyle(color: Colors.white, fontSize: 24, fontWeight: FontWeight.bold)),
          ],
        ),
        const SizedBox(height: 12),
        Text(label, style: const TextStyle(color: Colors.white, fontSize: 14)),
      ],
    );
  }

  Widget _buildFinancialSummaryCard(BuildContext context, String title, String value, IconData icon) {
    final brightness = Theme.of(context).brightness;
    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: ListTile(
        leading: Icon(icon, color: AppColors.primary.getByBrightness(brightness)),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)),
        trailing: Text(value, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.blue)),
      ),
    );
  }

  // --- Helpers ---

  Widget _buildSmallInfo(String label, String value, {Color? color}) {
    return Column(
      children: [
        Text(value, style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: color)),
        Text(label, style: const TextStyle(fontSize: 10, color: Colors.grey)),
      ],
    );
  }

  Widget _buildDetailedRow(String label, String count, String cost, {Color? color}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(label, style: TextStyle(color: color, fontWeight: color != null ? FontWeight.bold : FontWeight.normal)),
          Text('$count مهام', style: const TextStyle(fontSize: 12)),
          Text(cost, style: const TextStyle(fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }

  Widget _buildSectionHeader(String title) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Container(width: 4, height: 20, color: Colors.blue),
          const SizedBox(width: 8),
          Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}
