import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../../../core/api/api_constants.dart' show ApiEndpoints;
import '../../../core/api/api_service.dart' show ApiService;
import '../../../core/utils/translate_duration_unit.dart' show translateDurationUnit;
import '../../clients/data/models/client.dart' show Client;
import '../../events/controller/event_controller.dart' show EventController;
import '../../events/data/models/event.dart' show Event;
import '../../incomes/data/models/income.dart' show Income;
import '../../suppliers/data/models/supplier.dart' show Supplier;
import '../../tasks/controller/task_controller.dart' show TaskController;
import '../../incomes/controller/income_controller.dart' show IncomeController;
import '../../clients/controller/client_controller.dart' show ClientController;
import '../../suppliers/controller/supplier_controller.dart' show SupplierController;
import 'dart:io' as dart_io;
import 'package:path_provider/path_provider.dart' as path_provider;
import 'package:share_plus/share_plus.dart' as share_plus;
import 'package:excel/excel.dart' as excel_pkg;

import '../../tasks/data/models/task.dart' show Task;
import '../../../core/utils/status.dart' show Status, StatusExtension;

class ReportsController extends GetxController {
  late final EventController eventController;
  late final TaskController taskController;
  late final IncomeController incomeController;
  late final ClientController clientController;
  late final SupplierController supplierController;

  final isLoading = false.obs;

  // BI Filter State
  final RxString selectedTimeFilter = 'الكل'.obs; 
  final Rxn<DateTimeRange> customDateRange = Rxn<DateTimeRange>();
  
  final RxString reportScope = 'عام'.obs; // عام, لمناسبة محددة, لعميل محدد, لمورد محدد
  final RxnInt selectedScopeId = RxnInt();

  // Search Queries
  final RxString eventsSearchQuery = ''.obs;
  final RxString tasksSearchQuery = ''.obs;
  final RxString suppliersSearchQuery = ''.obs;
  final RxString financialSearchQuery = ''.obs;

  final RxList<dynamic> ratingsList = <dynamic>[].obs;

  @override
  void onInit() {
    super.onInit();
    eventController = Get.put(EventController());
    taskController = Get.put(TaskController());
    incomeController = Get.put(IncomeController());
    clientController = Get.put(ClientController());
    supplierController = Get.put(SupplierController());

    fetchDetailedData();
  }

  Future<void> fetchDetailedData() async {
    try {
      final res = await Get.find<ApiService>().get('${ApiEndpoints.dashboard}/ratings'); 
      if (res != null && res is Map && res['result'] != null) {
        ratingsList.value = res['result'];
      }
    } catch (e) {
      // Ignored if unsupported natively yet
    }
  }

  Future<void> refreshStatistics() async {
    isLoading.value = true;
    await Future.delayed(const Duration(milliseconds: 500)); // Simulating refresh calculation delay
    await fetchDetailedData();
    isLoading.value = false;
  }

  // ============== 1. FILTERING ENGINE ============== //

  List<Event> get filteredEvents {
    var raw = eventController.events.toList();
    if (reportScope.value == 'لعميل محدد' && selectedScopeId.value != null) {
      raw = raw.where((e) => e.clientId == selectedScopeId.value).toList();
    } else if (reportScope.value == 'لمناسبة محددة' && selectedScopeId.value != null) {
      raw = raw.where((e) => e.id == selectedScopeId.value).toList();
    }
    return _applyTimeFilter<Event>(raw, 'event_date', 'eventDate');
  }

  List<Task> get filteredTasks {
    final events = eventController.events; 
    var raw = taskController.tasks.toList();
    if (reportScope.value == 'لمناسبة محددة' && selectedScopeId.value != null) {
      raw = raw.where((t) => t.eventId == selectedScopeId.value).toList();
    } else if (reportScope.value == 'لمورد محدد' && selectedScopeId.value != null) {
      raw = raw.where((t) => t.userAssignId == selectedScopeId.value).toList();
    }
    return _applyTimeFilter<Task>(raw.where((task){
      var event = events.firstWhereOrNull((e) => e.id == task.eventId);
      if(event == null) return false;
      
      return !event.status.isCancelled;
    }).toList(), 'created_at', 'dateStart');
  }
  
  List<Income> get filteredIncomes {
    var raw = incomeController.incomes.toList();
    if (reportScope.value == 'لمناسبة محددة' && selectedScopeId.value != null) {
      raw = raw.where((i) => i.eventId == selectedScopeId.value).toList();
    }
    return _applyTimeFilter<Income>(raw, 'date', 'paymentDate');
  }

  List<Client> get filteredClients {
    if (reportScope.value == 'لعميل محدد' && selectedScopeId.value != null) {
      return clientController.clients.where((c) => c.id == selectedScopeId.value).toList();
    }
    return _applyTimeFilter<Client>(clientController.clients.toList(), 'created_at');
  }

  List<Supplier> get filteredSuppliers {
    if (reportScope.value == 'لمورد محدد' && selectedScopeId.value != null) {
      return supplierController.suppliers.where((s) => s.id == selectedScopeId.value).toList();
    }
    return _applyTimeFilter<Supplier>(supplierController.suppliers.toList(), 'created_at');
  }

  List<T> _applyTimeFilter<T>(List<T> list, String dateKey, [String? objectField]) {
    if (selectedTimeFilter.value == 'الكل') return list;
    
    final now = DateTime.now();
    return list.where((item) {
      dynamic dateRaw;
      try {
        if (item is Map) {
          dateRaw = item[dateKey] ?? item['created_at'];
        } else {
          if (objectField != null && objectField == 'eventDate') {
            dateRaw = (item as dynamic).eventDate;
          } else if (objectField != null && objectField == 'dateStart') {
            dateRaw = (item as dynamic).dateStart;
          } else if (objectField != null && objectField == 'paymentDate') {
            dateRaw = (item as dynamic).paymentDate;
          } else if (objectField != null && objectField == 'createdAt') {
            dateRaw = (item as dynamic).createdAt;
          }
        }
      } catch(_) { dateRaw = ''; }

      final dateStr = dateRaw?.toString() ?? '';
      if (dateStr.isEmpty) return false;

      try {
        final date = DateTime.parse(dateStr);
        
        if (selectedTimeFilter.value == 'مخصص' && customDateRange.value != null) {
           return date.isAfter(customDateRange.value!.start.subtract(const Duration(days: 1))) && 
                  date.isBefore(customDateRange.value!.end.add(const Duration(days: 1)));
        }

        final diff = now.difference(date).abs();
        switch (selectedTimeFilter.value) {
          case 'يومي': return diff.inDays == 0 && now.day == date.day;
          case 'أسبوعي': return diff.inDays <= 7;
          case 'شهري': return diff.inDays <= 30;
          case 'سنوي': return diff.inDays <= 365;
          default: return true;
        }
      } catch (e) {
        return true; 
      }
    }).toList();
  }

  // ============== 2. DATA PROCESSING FOR TABS ============== //

  // --- Events Tab ---
  List<Event> get displayEvents {
    var list = filteredEvents;
    if (eventsSearchQuery.value.isNotEmpty) {
      list = list.where((e) => e.eventName.toLowerCase().contains(eventsSearchQuery.value.toLowerCase())).toList();
    }
    return list;
  }

  Map<String, dynamic> get eventStats {
    final list = filteredEvents;
    double totalBudget = 0;
    double totalExpenses = 0;
    double totalPayments = 0;
    int completed = 0;
    int pending = 0;
    int inProgress = 0;
    int cancelled = 0;

    for (var e in list) {
      totalBudget += e.budget;
      totalExpenses += e.totalExpenses;
      totalPayments += e.totalIncome;
      if (e.status.isCompleted) {
        completed++;
      } else if (e.status.isPending) {
        pending++;
      } else if (e.status.isInProgress) {
        inProgress++;
      } else if (e.status.isCancelled) {
        cancelled++;
      }
    }

    return {
      'total': list.length,
      'completed': completed,
      'pending': pending,
      'inProgress': inProgress,
      'cancelled': cancelled,
      'totalBudget': totalBudget,
      'totalExpenses': totalExpenses,
      'totalPayments': totalPayments,
    };
  }

  int getSuppliersCountForEvent(int eventId) {
    final tasks = taskController.tasks.where((t) => t.eventId == eventId).toList();
    final uniqueSuppliers = tasks.map((t) => t.userAssignId).toSet();
    return uniqueSuppliers.length;
  }

  // --- Tasks Tab ---
  List<Task> get displayTasks {
    var list = filteredTasks;
    if (tasksSearchQuery.value.isNotEmpty) {
      list = list.where((t) => (t.typeTask ?? '').toLowerCase().contains(tasksSearchQuery.value.toLowerCase()) || 
                               (t.assigneName ?? '').toLowerCase().contains(tasksSearchQuery.value.toLowerCase())).toList();
    }
    return list;
  }

  Map<String, dynamic> get taskStats {
    final list = filteredTasks;
    double totalExpenses = 0;
    int completed = 0;
    int inProgress = 0;
    int pending = 0;
    int cancelled = 0;
    int rejected = 0;
    int inReview = 0;

    for (var t in list) {
      totalExpenses += t.status == Status.CANCELLED? 0 : t.cost;
      if (t.status.isCompleted) {
        completed++;
      } else if (t.status.isInProgress) {
        inProgress++;
      } else if (t.status.isPending) {
        pending++;
      } else if (t.status.isCancelled) {
        cancelled++;
      } else if (t.status.isRejected) {
        rejected++;
      } else if (t.status.isUnderReview) {
        inReview++;
      }
    }

    return {
      'total': list.length,
      'completed': completed,
      'inProgress': inProgress,
      'pending': pending,
      'cancelled': cancelled,
      'rejected': rejected,
      'inReview': inReview,
      'totalExpenses': totalExpenses,
    };
  }

  // --- Suppliers Tab ---
  List<Supplier> get displaySuppliers {
    var tasks = taskController.tasks;
    // Only show suppliers with tasks
    var list = filteredSuppliers.where((s) => tasks.any((t) => t.userAssignId == s.id)).toList();
    
    if (suppliersSearchQuery.value.isNotEmpty) {
      list = list.where((s) => s.name.toLowerCase().contains(suppliersSearchQuery.value.toLowerCase())).toList();
    }
    return list;
  }

  Map<String, dynamic> get supplierStats {
    final list = displaySuppliers;
    return {
      'total': list.length,
    };
  }

  // Helper for supplier card stats
  Map<String, dynamic> getSupplierDetailedStats(Supplier supplier) {
    final tasks = supplier.tasks;
    Map<String, int> taskCounts = {
      'total': tasks.length,
      'completed': 0,
      'inProgress': 0,
      'pending': 0,
      'cancelled': 0,
      'rejected': 0,
      'inReview': 0,
    };
    Map<String, double> taskCosts = {
      'total': 0,
      'completed': 0,
      'inProgress': 0,
      'pending': 0,
      'cancelled': 0,
      'rejected': 0,
      'inReview': 0,
    };
    Set<int> eventIds = {};
    Map<Status, Set<int>> eventsByStatus = {
        Status.PENDING: {},
        Status.IN_PROGRESS: {},
        Status.COMPLETED: {},
        Status.CANCELLED: {},
    };

    for (var t in tasks) {
      taskCosts['total'] = (taskCosts['total'] ?? 0) + t.cost;
      eventIds.add(t.eventId);
      
      // We need event status to count events by status for this supplier
      final event = eventController.events.firstWhereOrNull((e) => e.id == t.eventId);
      if (event != null) {
          eventsByStatus[event.status]?.add(event.id);
      }

      if (t.status.isCompleted) {
        taskCounts['completed'] = (taskCounts['completed'] ?? 0) + 1;
        taskCosts['completed'] = (taskCosts['completed'] ?? 0) + t.cost;
      } else if (t.status.isInProgress) {
        taskCounts['inProgress'] = (taskCounts['inProgress'] ?? 0) + 1;
        taskCosts['inProgress'] = (taskCosts['inProgress'] ?? 0) + t.cost;
      } else if (t.status.isPending) {
        taskCounts['pending'] = (taskCounts['pending'] ?? 0) + 1;
        taskCosts['pending'] = (taskCosts['pending'] ?? 0) + t.cost;
      } else if (t.status.isCancelled) {
        taskCounts['cancelled'] = (taskCounts['cancelled'] ?? 0) + 1;
        taskCosts['cancelled'] = (taskCosts['cancelled'] ?? 0) + t.cost;
      } else if (t.status.isRejected) {
        taskCounts['rejected'] = (taskCounts['rejected'] ?? 0) + 1;
        taskCosts['rejected'] = (taskCosts['rejected'] ?? 0) + t.cost;
      } else if (t.status.isUnderReview) {
        taskCounts['inReview'] = (taskCounts['inReview'] ?? 0) + 1;
        taskCosts['inReview'] = (taskCosts['inReview'] ?? 0) + t.cost;
      }
    }

    return {
      'taskCounts': taskCounts,
      'taskCosts': taskCosts,
      'totalEvents': eventIds.length,
      'eventsPending': eventsByStatus[Status.PENDING]?.length ?? 0,
      'eventsInProgress': eventsByStatus[Status.IN_PROGRESS]?.length ?? 0,
      'eventsCompleted': eventsByStatus[Status.COMPLETED]?.length ?? 0,
      'eventsCancelled': eventsByStatus[Status.CANCELLED]?.length ?? 0,
      'servicesCount': supplier.services.length,
    };
  }

  // --- Financial Tab ---
  Map<String, dynamic> get financialStats {
    final events = filteredEvents;
    final incomes = filteredIncomes;
    final tasks = filteredTasks;

    double totalBudget = events.fold(0.0, (sum, e) => sum + e.budget);
    double totalIncome = incomes.fold(0.0, (sum, i) => sum + i.amount);
    double totalExpenses = tasks.fold(0.0, (sum, t) => sum + t.cost);
    double remaining = totalBudget - totalExpenses;
    double profit = totalIncome - totalExpenses;
    double loss = profit < 0 ? profit.abs() : 0;
    if (profit < 0) profit = 0;

    return {
      'totalBudget': totalBudget,
      'totalIncome': totalIncome,
      'totalExpenses': totalExpenses,
      'totalRemaining': remaining,
      'totalLoss': loss,
      'totalProfit': profit,
    };
  }

  // ============== 3. CALCULATION ENGINE ============== //

  double get calculatedTotalRevenue {
    return filteredIncomes.fold(0.0, (sum, i) => sum + (double.tryParse(i.amount.toString()) ?? 0.0));
  }

  double get calculatedTotalExpenses {
    return filteredTasks.fold(0.0, (sum, t) => sum + (double.tryParse(t.cost.toString()) ?? 0.0));
  }

  double get netProfit {
    return calculatedTotalRevenue - calculatedTotalExpenses;
  }

  double get taskSuccessRate {
    if (filteredTasks.isEmpty) return 0.0;
    int completed = filteredTasks.where((t) => t.status.name == 'COMPLETED' || t.status.name == 'completed').length;
    return (completed / filteredTasks.length) * 100;
  }

  double get budgetAdherence {
    double totalBudgets = filteredEvents.fold(0.0, (sum, e) => sum + (double.tryParse(e.budget.toString()) ?? 0.0));
    if (totalBudgets == 0) return 0.0;
    return (calculatedTotalExpenses / totalBudgets) * 100;
  }

  Map<String, int> get calculatedTaskStats {
    int pending = 0, ongoing = 0, completed = 0, cancelled = 0;
    for (var t in filteredTasks) {
       final status = t.status.name.toString().toUpperCase();
       if (status == 'COMPLETED') {
         completed++;
       } else if (status == 'IN_PROGRESS' || status == 'IN PROGRESS') {
         ongoing++;
       } else if (status == 'CANCELLED') {
         cancelled++;
       } else {
         pending++;
       }
    }
    return {'pending': pending, 'in_progress': ongoing, 'completed': completed, 'cancelled': cancelled};
  }

  // ============== 3. EXPORT ENGINE ============== //

  Future<void> exportReport(String type, {String? tabName}) async {
    try {
      if (tabName != null) {
         await _exportTabReportExcel(tabName);
         return;
      }
      await _exportExcelBI();
    } catch (e) {
      Get.snackbar('خطأ', 'فشل تصدير التقرير: $e',
          snackPosition: SnackPosition.BOTTOM,
          backgroundColor: Colors.red.withValues(alpha: 0.1),
          colorText: Colors.red);
    }
  }

  Future<void> _exportExcelBI() async {
    var excel = excel_pkg.Excel.createExcel();
    var sheet = excel.sheets[excel.getDefaultSheet()]!;
    
    // Style for Headers
    final headerStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#2C3E50"),
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#FFFFFF"),
      bold: true,
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
    );

    final subHeaderStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#ECF0F1"),
      bold: true,
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#2C3E50"),
    );

    // Title
    var cell = sheet.cell(excel_pkg.CellIndex.indexByString('A1'));
    sheet.merge(
      excel_pkg.CellIndex.indexByString('A1'), 
      excel_pkg.CellIndex.indexByString('D1'),
      customValue: excel_pkg.TextCellValue('تقرير ذكاء الأعمال My Party')
    );
    // cell.value = excel_pkg.TextCellValue('تقرير ذكاء الأعمال My Party');
    cell.cellStyle = headerStyle;
    sheet.merge(excel_pkg.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: 0), excel_pkg.CellIndex.indexByColumnRow(columnIndex: 3, rowIndex: 0));

    sheet.appendRow([excel_pkg.TextCellValue('النطاق:'), excel_pkg.TextCellValue(reportScope.value)]);
    sheet.appendRow([excel_pkg.TextCellValue('فترة التقرير:'), excel_pkg.TextCellValue(selectedTimeFilter.value)]);
    sheet.appendRow([excel_pkg.TextCellValue('')]);
    
    sheet.appendRow([excel_pkg.TextCellValue('-- الملخص المالي والتنفيذي --')]);
    sheet.appendRow([excel_pkg.TextCellValue('إجمالي الإيرادات'), excel_pkg.TextCellValue('${calculatedTotalRevenue.toStringAsFixed(2)} ر.س')]);
    sheet.appendRow([excel_pkg.TextCellValue('إجمالي التكاليف (المهام)'), excel_pkg.TextCellValue('${calculatedTotalExpenses.toStringAsFixed(2)} ر.س')]);
    sheet.appendRow([excel_pkg.TextCellValue('صافي الربح'), excel_pkg.TextCellValue('${netProfit.toStringAsFixed(2)} ر.س')]);
    sheet.appendRow([excel_pkg.TextCellValue('نسبة نجاح المهام'), excel_pkg.TextCellValue('${taskSuccessRate.toStringAsFixed(1)}%')]);
    sheet.appendRow([excel_pkg.TextCellValue('نسبة الاستهلاك من الميزانية'), excel_pkg.TextCellValue('${budgetAdherence.toStringAsFixed(1)}%')]);
    sheet.appendRow([excel_pkg.TextCellValue('')]);
    sheet.appendRow([excel_pkg.TextCellValue('حالة المهام التفصيلية'), excel_pkg.TextCellValue('قيد الانتظار: ${calculatedTaskStats['pending']} | قيد التنفيذ: ${calculatedTaskStats['in_progress']} | مكتملة: ${calculatedTaskStats['completed']} | ملغاة: ${calculatedTaskStats['cancelled']}')]);

    if (filteredEvents.isNotEmpty) {
      sheet.appendRow([excel_pkg.TextCellValue('')]);
      sheet.appendRow([excel_pkg.TextCellValue('تفاصيل المناسبات المدرجة')]);
      
      final eventHeaderRow = sheet.maxRows;
      sheet.appendRow([excel_pkg.TextCellValue('العنوان'), excel_pkg.TextCellValue('الحالة'), excel_pkg.TextCellValue('الميزانية المعتمدة'), excel_pkg.TextCellValue('التاريخ')]);
      for(int i=0; i<4; i++) {
        sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: eventHeaderRow)).cellStyle = subHeaderStyle;
      }

      for (var ev in filteredEvents) {
        sheet.appendRow([
          excel_pkg.TextCellValue(ev.eventName),
          excel_pkg.TextCellValue(ev.status.name),
          excel_pkg.TextCellValue('${ev.budget} ر.س'),
          excel_pkg.TextCellValue(ev.eventDate)
        ]);
      }
    }

    if (filteredTasks.isNotEmpty) {
      sheet.appendRow([excel_pkg.TextCellValue('')]);
      sheet.appendRow([excel_pkg.TextCellValue('تفاصيل المهام المدرجة')]);
      
      final taskHeaderRow = sheet.maxRows;
      sheet.appendRow([excel_pkg.TextCellValue('نوع المهمة'), excel_pkg.TextCellValue('الوصف'), excel_pkg.TextCellValue('التكلفة'), excel_pkg.TextCellValue('الحالة')]);
      for(int i=0; i<4; i++) {
        sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: taskHeaderRow)).cellStyle = subHeaderStyle;
      }

      for (var ts in filteredTasks) {
        sheet.appendRow([
          excel_pkg.TextCellValue(ts.typeTask ?? ''),
          excel_pkg.TextCellValue(ts.description ?? ''),
          excel_pkg.TextCellValue('${ts.cost} ر.س'),
          excel_pkg.TextCellValue(ts.status.name)
        ]);
      }
    }

    final directory = await path_provider.getApplicationDocumentsDirectory();
    final fileName = 'BI_Report_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final path = '${directory.path}/$fileName';
    
    final fileBytes = excel.save();
    if (fileBytes != null) {
      final file = dart_io.File(path);
      await file.writeAsBytes(fileBytes);
      await share_plus.Share.shareXFiles([share_plus.XFile(path)], text: 'تقرير أعمال My Party');
    }
  }

  Future<void> _exportTabReportExcel(String tabName) async 
  {
    var excel = excel_pkg.Excel.createExcel();
    var sheet = excel.sheets[excel.getDefaultSheet()]!;
    
    final headerStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#34495E"),
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#FFFFFF"),
      bold: true,
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
      fontSize: 20,
    );

    final summaryHeaderStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#D5D8DC"),
      bold: true,
      horizontalAlign: excel_pkg.HorizontalAlign.Right,
    );

    final columnHeaderStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#2E86C1"),
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#FFFFFF"),
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
      bold: true,
    );

    // Title
    // var t = sheet.row(0);
  
    sheet.merge(
      excel_pkg.CellIndex.indexByString('A1'),
      excel_pkg.CellIndex.indexByString('P1'),
      customValue: excel_pkg.TextCellValue('تقرير بيانات $tabName')
    );
    sheet.cell(excel_pkg.CellIndex.indexByString('A1')).cellStyle = headerStyle;

    sheet.merge(
      excel_pkg.CellIndex.indexByString('A2'),
      excel_pkg.CellIndex.indexByString('P2'),
      customValue: excel_pkg.TextCellValue('تاريخ التصدير:')
    );
    sheet.cell(excel_pkg.CellIndex.indexByString('A2')).cellStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#34495E"),
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#FFFFFF"),
      bold: false,
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
      fontSize: 16,
    );
    sheet.merge(
      excel_pkg.CellIndex.indexByString('A3'),
      excel_pkg.CellIndex.indexByString('P3'),
      customValue: excel_pkg.TextCellValue(DateTime.now().toString())
    );
    sheet.cell(excel_pkg.CellIndex.indexByString('A3')).cellStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#34495E"),
      fontColorHex: excel_pkg.ExcelColor.fromHexString("#FFFFFF"),
      bold: false,
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
      fontSize: 10,
    );
    sheet.appendRow([excel_pkg.TextCellValue('')]);

    // Summary Section
    sheet.merge(
      excel_pkg.CellIndex.indexByString('A5'),
      excel_pkg.CellIndex.indexByString('P5'),
      customValue: excel_pkg.TextCellValue('-- إحصائيات إجمالية --')
    );
    sheet.cell(excel_pkg.CellIndex.indexByString('A5')).cellStyle = excel_pkg.CellStyle(
      backgroundColorHex: excel_pkg.ExcelColor.fromHexString("#D5D8DC"),
      bold: true,
      horizontalAlign: excel_pkg.HorizontalAlign.Center,
      verticalAlign: excel_pkg.VerticalAlign.Center,
    );
    // var summaryTitle = sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: 0, rowIndex: sheet.maxRows));
    // summaryTitle.value = excel_pkg.TextCellValue('-- إحصائيات إجمالية --');
    // summaryTitle.cellStyle = summaryHeaderStyle;
    sheet.appendRow([]); // spacer row after styling above cell

    if (tabName == 'المناسبات') {
        final stats = eventStats;
        sheet.appendRow([
          excel_pkg.TextCellValue('إجمالي المناسبات:'), 
          excel_pkg.TextCellValue('قيد الإنتظار:'),
          excel_pkg.TextCellValue('قيد التنفيذ:'),
          excel_pkg.TextCellValue('مكتملة:'),
          excel_pkg.TextCellValue('ملغاة:'),
          excel_pkg.TextCellValue('إجمالي الميزانية:'),
          excel_pkg.TextCellValue('إجمالي المصروفات:'),
          excel_pkg.TextCellValue('إجمالي الدفعات:'),
        ]);
        
        sheet.appendRow([
          excel_pkg.TextCellValue('${stats['total']}'), 
          excel_pkg.TextCellValue('${stats['pending']}'), 
          excel_pkg.TextCellValue('${stats['inProgress']}'), 
          excel_pkg.TextCellValue('${stats['completed']}'),
          excel_pkg.TextCellValue('${stats['cancelled']}'),
          excel_pkg.TextCellValue('${stats['totalBudget'].toStringAsFixed(2)}'),
          excel_pkg.TextCellValue('${stats['totalExpenses'].toStringAsFixed(2)}'),
          excel_pkg.TextCellValue('${stats['totalPayments'].toStringAsFixed(2)}'),
        ]);
        for(int i=0; i<stats.length; i++) {
          sheet.cell(
            excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 5)
          ).cellStyle = columnHeaderStyle;
          sheet.cell(
            excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 6)
          ).cellStyle = excel_pkg.CellStyle(
            horizontalAlign: excel_pkg.HorizontalAlign.Center,
            verticalAlign: excel_pkg.VerticalAlign.Center,
          );
        }
    } 
    else if (tabName == 'المهام') 
    {
        final stats = taskStats;
        sheet.appendRow([
          excel_pkg.TextCellValue('إجمالي المهام:'), 
          excel_pkg.TextCellValue('قيد الإنتظار:'),
          excel_pkg.TextCellValue('قيد التنفيذ:'),
          excel_pkg.TextCellValue('قيد المراجعة:'),
          excel_pkg.TextCellValue('مكتملة:'),
          excel_pkg.TextCellValue('ملغاة:'),
          excel_pkg.TextCellValue('مرفوضة:'),
          excel_pkg.TextCellValue('إجمالي التكاليف:')
        ]);
        
        sheet.appendRow([
          excel_pkg.TextCellValue('${stats['total']}'), 
          excel_pkg.TextCellValue('${stats['pending']}'), 
          excel_pkg.TextCellValue('${stats['inProgress']}'), 
          excel_pkg.TextCellValue('${stats['inReview']}'),
          excel_pkg.TextCellValue('${stats['completed']}'),
          excel_pkg.TextCellValue('${stats['cancelled']}'),
          excel_pkg.TextCellValue('${stats['rejected']}'),
          excel_pkg.TextCellValue('${stats['totalExpenses'].toStringAsFixed(2)}')
        ]);
        for(int i=0; i<stats.length; i++) {
          sheet.cell(
            excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 5)
          ).cellStyle = columnHeaderStyle;
          sheet.cell(
            excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: 6)
          ).cellStyle = excel_pkg.CellStyle(
            horizontalAlign: excel_pkg.HorizontalAlign.Center,
            verticalAlign: excel_pkg.VerticalAlign.Center,
          );
        }
    } 
    else if (tabName == 'الموردين') 
    {
        final stats = supplierStats;
        sheet.appendRow([excel_pkg.TextCellValue('إجمالي الموردين المدرجين:'), excel_pkg.TextCellValue('${stats['total']}')]);
    }
    sheet.appendRow([excel_pkg.TextCellValue('')]);

    // Data Table
    if (tabName == 'المناسبات') {
      final headers = [
        'العنوان', 'الحالة', 'الميزانية', 'المصروفات', 'الدفعات', 
        'المتبقي على العميل', 'الربح المتوقع', 'الربح الفعلي', 'نسبة الإنجاز',
        'إجمالي المهام', 'المكتملة', 'قيد التنفيذ', 'قيد الانتظار', 'الملغاة', 
        'المدة', 'التاريخ'
      ];
      final headerRowIndex = sheet.maxRows;
      sheet.appendRow(headers.map((h) => excel_pkg.TextCellValue(h)).toList());
      for(int i=0; i<headers.length; i++) {
        sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: headerRowIndex)).cellStyle = columnHeaderStyle;
      }

      for (var e in displayEvents) {
        sheet.appendRow([
          excel_pkg.TextCellValue(e.eventName),
          excel_pkg.TextCellValue(e.status.tryText()),
          excel_pkg.TextCellValue(e.budget.toStringAsFixed(2)),
          excel_pkg.TextCellValue(e.totalExpenses.toStringAsFixed(2)),
          excel_pkg.TextCellValue(e.totalIncome.toStringAsFixed(2)),
          excel_pkg.TextCellValue((e.budget - e.totalIncome).toStringAsFixed(2)),
          excel_pkg.TextCellValue((e.budget - e.totalExpenses).toStringAsFixed(2)),
          excel_pkg.TextCellValue((e.totalIncome - e.totalExpenses).toStringAsFixed(2)),
          excel_pkg.TextCellValue('${(e.totalTasks > 0 ? (e.completedTasks / e.totalTasks * 100) : 0.0).toStringAsFixed(2)}%'),
          excel_pkg.TextCellValue(e.totalTasks.toInt().toString()),
          excel_pkg.TextCellValue(e.completedTasks.toInt().toString()),
          excel_pkg.TextCellValue((e.totalTasks - e.completedTasks - e.pendingTasks - e.cancelledTasks).toInt().toString()),
          excel_pkg.TextCellValue(e.pendingTasks.toInt().toString()),
          excel_pkg.TextCellValue(e.cancelledTasks.toInt().toString()),
          excel_pkg.TextCellValue(translateDurationUnit(e.eventDurationUnit, e.eventDuration)),
          excel_pkg.TextCellValue(e.eventDate)
        ]);
        for(int i=0; i<16; i++) {
          sheet.cell(
            excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: sheet.maxRows + 1)
          ).cellStyle = excel_pkg.CellStyle(
            horizontalAlign: excel_pkg.HorizontalAlign.Center,
            verticalAlign: excel_pkg.VerticalAlign.Center,
          );
        }
      }
    } else if (tabName == 'المهام') {
      final headers = [
        'النوع', 'الوصف', 'الحالة', 'التكلفة', 'التقييم', 
        'المورد', 'الملاحظات', 'المناسبة', 'تاريخ المهمة', 'تاريخ الاستحقاق', 'تاريخ التسليم'
      ];
      final headerRowIndex = sheet.maxRows;
      sheet.appendRow(headers.map((h) => excel_pkg.TextCellValue(h)).toList());
      for(int i=0; i<headers.length; i++) {
        sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: headerRowIndex)).cellStyle = columnHeaderStyle;
      }

      for (var t in displayTasks) {
        sheet.appendRow([
          excel_pkg.TextCellValue(t.typeTask ?? 'غير محدد'),
          excel_pkg.TextCellValue(t.description ?? ''),
          excel_pkg.TextCellValue(t.status.name),
          excel_pkg.TextCellValue(t.cost.toStringAsFixed(2)),
          excel_pkg.TextCellValue((t.rating ?? 0.0).toInt().toString()),
          excel_pkg.TextCellValue(t.assigneName ?? 'غير محدد'),
          excel_pkg.TextCellValue(t.notes ?? ''),
          excel_pkg.TextCellValue(t.eventName),
          excel_pkg.TextCellValue(t.dateStart ?? 'لم يحدد'),
          excel_pkg.TextCellValue(t.dateDue ?? 'لم يحدد'),
          excel_pkg.TextCellValue(t.dateCompletion ?? 'لم يحدد'),
        ]);
      }
    } else if (tabName == 'الموردين') {
      final headers = ['الاسم', 'التقييم', 'عدد الخدمات'];
      final headerRowIndex = sheet.maxRows;
      sheet.appendRow(headers.map((h) => excel_pkg.TextCellValue(h)).toList());
      for(int i=0; i<headers.length; i++) {
        sheet.cell(excel_pkg.CellIndex.indexByColumnRow(columnIndex: i, rowIndex: headerRowIndex)).cellStyle = columnHeaderStyle;
      }

      for (var s in displaySuppliers) {
        sheet.appendRow([
          excel_pkg.TextCellValue(s.name),
          excel_pkg.TextCellValue((s.averageRating ?? 0).toString()),
          excel_pkg.TextCellValue(s.services.length.toString())
        ]);
      }
    }

    final directory = await path_provider.getApplicationDocumentsDirectory();
    final fileName = '${tabName}_Report_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final path = '${directory.path}/$fileName';
    
    final fileBytes = excel.save();
    if (fileBytes != null) {
      final file = dart_io.File(path);
      await file.writeAsBytes(fileBytes);
      await share_plus.Share.shareXFiles([share_plus.XFile(path)], text: 'تقرير $tabName');
    }
  }

  Future<void> exportSingleItem(String type, dynamic item) async {
    var excel = excel_pkg.Excel.createExcel();
    var sheet = excel.sheets[excel.getDefaultSheet()]!;
    
    String title = '';
    List<List<String>> data = [];
    
    if (item is Event) {
       title = 'تفاصيل المناسبة: ${item.eventName}';
       data = [
         ['التاريخ', item.eventDate],
         ['الميزانية', '${item.budget}'],
         ['المصروفات', '${item.totalExpenses}'],
         ['الحالة', item.status.name],
       ];
    } else if (item is Task) {
       title = 'تفاصيل المهمة: ${item.typeTask}';
       data = [
         ['التكلفة', '${item.cost}'],
         ['المورد', item.assigneName ?? 'غير محدد'],
         ['الوصف', item.description ?? 'بدون وصف'],
         ['الحالة', item.status.name],
       ];
    } else if (item is Supplier) {
       title = 'بيانات المورد: ${item.name}';
       data = [
         ['البريد', item.email],
         ['الجوال', item.phoneNumber?.toString() ?? 'غير محدد'],
         ['التقييم', '${item.averageRating ?? 0}'],
       ];
    }
    
    sheet.appendRow([excel_pkg.TextCellValue(title)]);
    sheet.appendRow([excel_pkg.TextCellValue('')]);
    for(var row in data) {
      sheet.appendRow([excel_pkg.TextCellValue(row[0]), excel_pkg.TextCellValue(row[1])]);
    }

    final directory = await path_provider.getApplicationDocumentsDirectory();
    final fileName = 'Card_${DateTime.now().millisecondsSinceEpoch}.xlsx';
    final path = '${directory.path}/$fileName';
    
    final fileBytes = excel.save();
    if (fileBytes != null) {
      final file = dart_io.File(path);
      await file.writeAsBytes(fileBytes);
      await share_plus.Share.shareXFiles([share_plus.XFile(path)], text: 'مشاركة البطاقة');
    }
  }
}
