import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
// import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../data/models/task.dart' show Task;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/api/auth_service.dart' show AuthService;
import '../controller/task_controller.dart' show TaskController;
import '../../events/controller/event_controller.dart' show EventController;
import '../../coordinators/controller/coordinator_controller.dart' show CoordinatorController;
import '../../suppliers/controller/supplier_controller.dart' show SupplierController;
import '../../clients/controller/client_controller.dart' show ClientController;
import '../widgets/task_detail/task_proof_of_work_section.dart';
import '../widgets/task_detail/task_action_buttons_section.dart';
import '../widgets/task_detail/task_evaluation_section.dart';
import '../widgets/task_detail/event_client_section.dart';
import '../widgets/task_detail/task_assignment_section.dart';

class TaskDetailScreen extends GetView<TaskController> {
  TaskDetailScreen({super.key}){
    _fetchMissingData();
  }

  Future<void> _fetchMissingData() async {
    final eventController = Get.find<EventController>();
    final coordinatorController = Get.find<CoordinatorController>();
    final supplierController = Get.find<SupplierController>();
    final clientController = Get.find<ClientController>();

    final dynamic args = Get.arguments;
    if (args == null || args is! Task) return;
    final Task task = args;

    // Fetch event if missing
    if (eventController.events.every((e) => e.id != task.eventId)) {
      await eventController.fetch(task.eventId);
      if (eventController.selectedEvent.value != null) {
        // Add to main list to make it available for firstWhereOrNull
        eventController.events.add(eventController.selectedEvent.value!);
      }
    }

    final event = eventController.events.firstWhereOrNull((e) => e.id == task.eventId);

    // Fetch coordinator if missing
    if (coordinatorController.coordinators.every((c) => c.id != task.coordinatorId)) {
      await coordinatorController.fetch(task.coordinatorId);
      if (coordinatorController.selectedCoordinator.value != null) {
        coordinatorController.coordinators.add(coordinatorController.selectedCoordinator.value!);
      }
    }

    // Fetch client if missing
    if (event != null && clientController.clients.every((c) => c.id != event.clientId)) {
      await clientController.fetchClient(event.clientId);
      if (clientController.selectedClient.value != null) {
        clientController.clients.add(clientController.selectedClient.value!);
      }
    }

    // Fetch supplier if missing
    if (task.assignmentType.toUpperCase() == 'SUPPLIER' &&
        supplierController.suppliers.every((s) => s.id != task.userAssignId)) {
      await supplierController.fetch(task.userAssignId);
      if (supplierController.selectedSupplier.value != null) {
        supplierController.suppliers.add(supplierController.selectedSupplier.value!);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final eventController = Get.find<EventController>();
    final coordinatorController = Get.find<CoordinatorController>();
    final supplierController = Get.find<SupplierController>();
    // final clientController = Get.find<ClientController>();

    final brightness = Theme.of(context).brightness;
    final dynamic args = Get.arguments;
    if (args == null || args is! Task) {
      return Scaffold(
        appBar: AppBar(title: const Text('خطأ')),
        body: const Center(child: Text('بيانات المهمة غير متوفرة')),
      );
    }
    final Task task = args;
    final role = AuthService.user.value.role.isNotEmpty? AuthService.user.value.role : 'coordinator';

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
          showBackButton: true, title: task.typeTask ?? 'تفاصيل المهمة'),
      body: Obx(() {
        // Find the latest task from the controller to ensure reactivity
        final currentTask = controller.tasks.firstWhere(
          (t) => t.id == task.id,
          orElse: () => task,
        );

        // Fetch related data from other controllers
        final event = eventController.events
            .firstWhereOrNull((e) => e.id == currentTask.eventId);
        final coordinator = coordinatorController.coordinators
            .firstWhereOrNull((c) => c.id == currentTask.coordinatorId);
        final supplier = currentTask.assignmentType.toUpperCase() == 'SUPPLIER'
            ? supplierController.suppliers
                .firstWhereOrNull((s) => s.id == currentTask.userAssignId)
            : null;
        // final client = clientController.clients
        //     .firstWhereOrNull((c) => c.id == event?.clientId);

        return RefreshIndicator(
          onRefresh: () async {
            await controller.fetchTasks();
            await _fetchMissingData();
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(24),
            child: Column(
              children: [
                // بيانات المهمة
                TaskAssignmentSection(
                  task: currentTask,
                  assignedName: AuthService.userIsSupplier
                      ? (event?.coordinatorName ?? currentTask.takCreatorName)
                      : (supplier != null
                          ? (currentTask.assigneName ?? supplier.name)
                          : null),
                  assignedPhone: AuthService.userIsSupplier
                      ? (event?.coordinatorPhone ?? coordinator?.phoneNumber)
                      : (supplier?.phoneNumber),
                  assignedEmail: AuthService.userIsSupplier
                      ? coordinator?.email
                      : supplier?.email,
                  assignedImageUrl: AuthService.userIsSupplier
                      ? coordinator?.imgUrl
                      : supplier?.imgUrl,
                  assignedRoleTitle: AuthService.userIsSupplier
                      ? 'منسق المناسبة'
                      : (supplier != null ? 'مورد الخدمات' : null),
                ),
                const SizedBox(height: 24),

                // بيانات العميل والمناسبة
                EventClientSection(
                  event: event
                ),
                const SizedBox(height: 24),

                if (currentTask.status.isCompleted ||
                    currentTask.status.isUnderReview) ...[
                  const SizedBox(height: 24),
                  TaskProofOfWorkSection(task: currentTask),
                ],

                if (currentTask.status.isCompleted) ...[
                  const SizedBox(height: 24),
                  
                  TaskEvaluationSection(
                    task: currentTask,
                    role: role,
                  ),
                ],
                const SizedBox(height: 32),

                TaskActionButtonsSection(task: currentTask, role: role),
              ],
            ),
          ),
        );
      }),
    );
  }
}
