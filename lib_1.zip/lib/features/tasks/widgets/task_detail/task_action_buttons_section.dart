import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/themes/app_colors.dart';
import '../../../../core/utils/status.dart';
import '../../../../core/api/auth_service.dart';
import '../../../../core/routes/app_routes.dart';
import '../../data/models/task.dart';
import '../../controller/task_controller.dart';
import '../../../suppliers/widgets/supplier_dashboard_widgets.dart' show showProofOfWorkBottomSheet;
import '../task_utils.dart' show showRejectTaskBottomSheet;

class TaskActionButtonsSection extends GetView<TaskController> {
  final Task task;
  final String role;

  const TaskActionButtonsSection({
    super.key,
    required this.task,
    required this.role,
  });

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    final bool isSupplier = role.toLowerCase() == 'supplier';
    final bool isAdmin = role.toLowerCase() == 'admin';
    final bool isCoordinator = role.toLowerCase() == 'coordinator' || isAdmin;
    final bool assignedToSupplier = task.assignmentType.toUpperCase() == 'SUPPLIER';

    final currentUserId = AuthService.user.value.id;
    final bool isMyTask = task.userAssignId == currentUserId;

    final bool hasReminder = task.reminderType != null && task.reminderType != 'none';

    // If task is assigned to the current user (My Task)
    if (isMyTask) {
      if (task.status.isCancelled || task.status.isCompleted || task.status.isRejected) return const SizedBox.shrink();

      // If supplier task is under review, supplier can't do anything else.
      if (assignedToSupplier && isSupplier && task.status.isUnderReview) {
        return const SizedBox.shrink();
      }

      return Row(
        children: [
          if (task.status.isPending || task.status.isInProgress) ...[
            Expanded(
              child: OutlinedButton.icon(
                onPressed: () {
                  if (assignedToSupplier && isSupplier) {
                    showRejectTaskBottomSheet(context, controller, task.id, brightness);
                  } else {
                    Get.defaultDialog(
                      title: 'تأكيد الإلغاء',
                      middleText: 'هل أنت متأكد من رغبتك في إلغاء هذه المهمة؟',
                      textConfirm: 'نعم، إلغاء',
                      textCancel: 'تراجع',
                      confirmTextColor: Colors.white,
                      onConfirm: () {
                        Get.back();
                        controller.updateTaskStatus(task.id, Status.CANCELLED);
                      },
                    );
                  }
                },
                icon: Obx(() => controller.isLoading.value
                    ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: Colors.grey))
                    : Icon(Icons.close_rounded, color: AppColors.accent.getByBrightness(brightness))),
                label: Text(
                  isSupplier ? 'رفض المهمة' : 'إلغاء المهمة',
                  style: TextStyle(
                    color: AppColors.accent.getByBrightness(brightness),
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: OutlinedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  side: BorderSide(color: AppColors.accent.getByBrightness(brightness)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
            const SizedBox(width: 16),
          ],
          Expanded(
            flex: 2,
            child: Container(
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient.getByBrightness(brightness),
                borderRadius: BorderRadius.circular(16),
              ),
              child: ElevatedButton.icon(
                onPressed: () {
                  if (task.status.isPending) {
                    Get.defaultDialog(
                      title: 'تأكيد البدء',
                      middleText: 'هل أنت متأكد من رغبتك في بدء تنفيذ هذه المهمة الآن؟',
                      textConfirm: 'نعم، ابدأ',
                      textCancel: 'تراجع',
                      confirmTextColor: Colors.white,
                      onConfirm: () {
                        Get.back();
                        controller.updateTaskStatus(task.id, Status.IN_PROGRESS);
                      },
                    );
                  } else if (task.status.isInProgress || task.status.isUnderReview) {
                    _showProofOfWorkBottomSheet(context, isSupplier);
                  }
                },
                icon: Icon(
                  task.status.isPending ? Icons.play_arrow_rounded : (isSupplier ? Icons.file_upload_outlined : Icons.check_circle_rounded),
                  color: Colors.white,
                ),
                label: Text(
                  task.status.isPending
                      ? (isSupplier ? 'بدء المهمة' : 'بدء التنفيذ')
                      : (isSupplier ? 'تسليم للإعتماد' : 'إكمال المهمة'),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 16,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
          ),
          if (isSupplier || isCoordinator) ...[
            const SizedBox(width: 8),
            Container(
              decoration: BoxDecoration(
                color: (hasReminder ? Colors.orange : AppColors.primary.getByBrightness(brightness)).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(16),
              ),
              child: Stack(
                children: [
                  IconButton(
                    onPressed: () => _showReminderBottomSheet(context),
                    icon: Icon(
                        hasReminder ? Icons.notifications_active_rounded : Icons.add_alarm_rounded,
                        color: hasReminder ? Colors.orange : AppColors.primary.getByBrightness(brightness)),
                    tooltip: hasReminder ? 'تعديل التذكير' : 'إضافة تذكير',
                  ),
                  if (hasReminder)
                    Positioned(
                      top: 5,
                      right: 5,
                      child: GestureDetector(
                        onTap: () => _confirmDeleteReminder(context),
                        child: Container(
                          padding: const EdgeInsets.all(2),
                          decoration: const BoxDecoration(
                            color: Colors.red,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, size: 10, color: Colors.white),
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      );
    }

    // Default view for Coordinators monitoring or editing OTHERS' tasks (e.g. Suppliers')
    if (isCoordinator && !isMyTask) {
      return Row(
        children: [
          Expanded(
            child: OutlinedButton.icon(
              onPressed: () => Get.toNamed(AppRoutes.taskAdd, arguments: task),
              icon: const Icon(Icons.edit_rounded, size: 20),
              label: const Text('تعديل البيانات'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
                side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
              ),
            ),
          ),
          const SizedBox(width: 16),
          if (task.status.isUnderReview)
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient.getByBrightness(brightness),
                  borderRadius: BorderRadius.circular(16),
                ),
                child: ElevatedButton.icon(
                  onPressed: () {
                    controller.updateTaskStatus(task.id, Status.COMPLETED);
                  },
                  icon: const Icon(Icons.check_circle_rounded, size: 20),
                  label: const Text('اعتماد الإنجاز'),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.transparent,
                    shadowColor: Colors.transparent,
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(16),
                    ),
                  ),
                ),
              ),
            ),
        ],
      );
    }

    return const SizedBox.shrink();
  }

  void _showProofOfWorkBottomSheet(BuildContext context, bool isSupplier) {
    if (!isSupplier) {
      controller.updateTaskStatus(task.id, Status.COMPLETED);
      return;
    }
    showProofOfWorkBottomSheet(context, task);
  }


  void _showReminderBottomSheet(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    final allowedTypes = ['BEFORE_DUE', 'INTERVAL', 'none'];
    final allowedUnits = ['MINUTE', 'HOUR', 'DAY', 'WEEK'];

    String selectedType = allowedTypes.contains(task.reminderType) ? task.reminderType! : 'none';
    TextEditingController valueController = TextEditingController(text: task.reminderValue?.toString());
    String selectedUnit = allowedUnits.contains(task.reminderUnit) ? task.reminderUnit! : 'DAY';

    Get.bottomSheet(
      StatefulBuilder(builder: (BuildContext context, StateSetter setState) {
        return Container(
          padding: EdgeInsets.only(
              left: 24, right: 24, top: 24,
              bottom: MediaQuery.of(context).viewInsets.bottom + 24),
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(30)),
          ),
          child: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Center(
                  child: Icon(Icons.notifications_active_rounded, size: 48, color: AppColors.primary.getByBrightness(brightness)),
                ),
                const SizedBox(height: 16),
                Center(
                  child: Text('إعداد تذكير للمهمة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                ),
                const SizedBox(height: 24),
                Text('نوع التذكير', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  decoration: BoxDecoration(
                    color: AppColors.background.getByBrightness(brightness),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: DropdownButtonHideUnderline(
                    child: DropdownButton<String>(
                      dropdownColor: AppColors.surface.getByBrightness(brightness),
                      value: selectedType,
                      isExpanded: true,
                      style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                      onChanged: (String? newValue) {
                        setState(() {
                          selectedType = newValue ?? 'none';
                        });
                      },
                      items: allowedTypes.map<DropdownMenuItem<String>>((String value) {
                        return DropdownMenuItem<String>(
                          value: value,
                          child: Text(switch (value) {
                            'BEFORE_DUE' => 'قبل تاريخ التسليم',
                            'INTERVAL' => 'تذكير متكرر',
                            _ => 'بدون تذكير',
                          }),
                        );
                      }).toList(),
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('القيمة', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                          const SizedBox(height: 8),
                          TextField(
                            controller: valueController,
                            keyboardType: TextInputType.number,
                            style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                            decoration: InputDecoration(
                              hintText: 'مثال: 15',
                              hintStyle: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness)),
                              filled: true,
                              fillColor: AppColors.background.getByBrightness(brightness),
                              border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('الوحدة', style: TextStyle(fontSize: 14, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                          const SizedBox(height: 8),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 16),
                            decoration: BoxDecoration(
                              color: AppColors.background.getByBrightness(brightness),
                              borderRadius: BorderRadius.circular(16),
                            ),
                            child: DropdownButtonHideUnderline(
                              child: DropdownButton<String>(
                                dropdownColor: AppColors.surface.getByBrightness(brightness),
                                value: selectedUnit,
                                isExpanded: true,
                                style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                                onChanged: (String? newValue) {
                                  setState(() {
                                    selectedUnit = newValue ?? 'DAY';
                                  });
                                },
                                items: allowedUnits.map<DropdownMenuItem<String>>((String value) {
                                  return DropdownMenuItem<String>(
                                    value: value,
                                    child: Text(switch (value) {
                                      'MINUTE' => 'دقيقة',
                                      'HOUR' => 'ساعة',
                                      'DAY' => 'يوم',
                                      _ => 'أسبوع'
                                    }),
                                  );
                                }).toList(),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary.getByBrightness(brightness),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                    ),
                    onPressed: () async {
                      final val = int.tryParse(valueController.text);
                      if (selectedType != 'none' && (val == null || val <= 0)) {
                        Get.snackbar('تنبيه', 'يرجى إدخال قيمة صحيحة للاستمرار أو اختيار بدون تذكير', snackPosition: SnackPosition.BOTTOM);
                        return;
                      }
                      
                      if (task.reminderType != null && task.reminderType != 'none') {
                        await controller.updateTaskReminder(task.id, selectedType, val ?? 0, selectedUnit);
                      } else {
                        await controller.addTaskReminder(task.id, selectedType, val ?? 0, selectedUnit);
                      }
                      if (Get.isBottomSheetOpen ?? false) Get.back();
                    },
                    child: Obx(() => controller.isLoading.value
                        ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: Colors.white, strokeWidth: 2))
                        : Text((task.reminderType != null && task.reminderType != 'none') ? 'تحديث التذكير' : 'إنشاء التذكير', style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16))),
                  ),
                ),
              ],
            ),
          ),
        );
      }),
      isScrollControlled: true,
    );
  }

  void _confirmDeleteReminder(BuildContext context) {
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      middleText: 'هل أنت متأكد من رغبتك في حذف هذا التذكير؟',
      textConfirm: 'نعم، حذف',
      textCancel: 'تراجع',
      confirmTextColor: Colors.white,
      onConfirm: () {
        Get.back();
        controller.deleteTaskReminder(task.id);
      },
    );
  }
}
