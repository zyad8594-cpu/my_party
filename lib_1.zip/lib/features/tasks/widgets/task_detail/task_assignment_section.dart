import 'package:flutter/material.dart';
import '../../../../core/themes/app_colors.dart';
import '../../../../core/utils/date_formatter.dart';
import '../../../../core/utils/status.dart';
import '../../data/models/task.dart';
import '../../../../core/components/widgets/app_detail_widgets.dart';

class TaskAssignmentSection extends StatelessWidget {
  final Task task;
  final String? assignedName;
  final String? assignedPhone;
  final String? assignedEmail;
  final String? assignedImageUrl;
  final String? assignedRoleTitle;

  const TaskAssignmentSection({
    super.key,
    required this.task,
    this.assignedName,
    this.assignedPhone,
    this.assignedEmail,
    this.assignedImageUrl,
    this.assignedRoleTitle,
  });

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final statusColor = task.status.color(brightness);

    return AppDetailWidgets.buildInfoCard(
      context,
      title: 'تفاصيل المهمة والمسؤول',
      icon: Icons.assignment_ind_rounded,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Icon(
                  Icons.design_services_rounded,
                  color: AppColors.primary.getByBrightness(brightness),
                  size: 24,
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      task.typeTask ?? 'مهمة عامة',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textBody.getByBrightness(brightness),
                      ),
                    ),
                    const SizedBox(height: 4),
                    _buildStatusBadge(task.status.tryText(), statusColor),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 24),
          const Divider(height: 1),
          const SizedBox(height: 24),

          Row(
            children: [
              Expanded(
                child: _buildCompactDetail(
                  context,
                  Icons.attach_money_rounded,
                  'التكلفة',
                  '${task.cost} ر.ي',
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _buildCompactDetail(
                  context,
                  Icons.calendar_today_rounded,
                  'البداية',
                  DateFormatter.format(task.dateStart),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _buildCompactDetail(
            context,
            Icons.calendar_month_rounded,
            'موعد الاستحقاق النهائي',
            DateFormatter.format(task.dateDue),
          ),

          const SizedBox(height: 24),
          const Divider(height: 1),
          const SizedBox(height: 24),

          Text(
            'الوصف والملاحظات',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.bold,
              color: AppColors.primary.getByBrightness(brightness),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            task.description ?? 'لا يوجد وصف متاح.',
            style: TextStyle(
              color: AppColors.textBody.getByBrightness(brightness),
              fontSize: 14,
              height: 1.5,
            ),
          ),
          if (task.notes != null && task.notes!.isNotEmpty) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppColors.background.getByBrightness(brightness).withValues(alpha: 0.5),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1)),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'ملاحظات إضافية:',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    task.notes!,
                    style: TextStyle(
                      color: AppColors.textBody.getByBrightness(brightness),
                      fontSize: 13,
                    ),
                  ),
                ],
              ),
            ),
          ],

          if (assignedName != null) ...[
            const SizedBox(height: 24),
            const Divider(height: 1),
            const SizedBox(height: 24),

            Text(
              'المسؤول عن التنفيذ',
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.bold,
                color: AppColors.primary.getByBrightness(brightness),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                CircleAvatar(
                  radius: 28,
                  backgroundColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                  backgroundImage: assignedImageUrl != null && assignedImageUrl!.isNotEmpty
                      ? NetworkImage(assignedImageUrl!)
                      : null,
                  child: assignedImageUrl == null || assignedImageUrl!.isEmpty
                      ? Icon(Icons.person, color: AppColors.primary.getByBrightness(brightness), size: 30)
                      : null,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        assignedName!,
                        style: TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: AppColors.textBody.getByBrightness(brightness),
                        ),
                      ),
                      Text(
                        assignedRoleTitle ?? 'جهة اتصال',
                        style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 20),
            if (assignedPhone != null && assignedPhone!.isNotEmpty)
              _buildContactRow(context, Icons.phone_android_rounded, 'الهاتف', assignedPhone!),
            if (assignedEmail != null && assignedEmail!.isNotEmpty) ...[
              const SizedBox(height: 12),
              _buildContactRow(context, Icons.email_outlined, 'البريد الإلكتروني', assignedEmail!),
            ],
          ],
        ],
      ),
    );
  }

  Widget _buildStatusBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 11,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildCompactDetail(BuildContext context, IconData icon, String label, String value) {
    final brightness = Theme.of(context).brightness;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 14, color: AppColors.textSubtitle.getByBrightness(brightness)),
            const SizedBox(width: 6),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                color: AppColors.textSubtitle.getByBrightness(brightness),
              ),
            ),
          ],
        ),
        const SizedBox(height: 6),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
      ],
    );
  }

  Widget _buildContactRow(BuildContext context, IconData icon, String label, String value) {
    final brightness = Theme.of(context).brightness;
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
            borderRadius: BorderRadius.circular(8),
          ),
          child: Icon(icon, size: 16, color: AppColors.primary.getByBrightness(brightness)),
        ),
        const SizedBox(width: 12),
        Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              label,
              style: TextStyle(
                fontSize: 10,
                color: AppColors.textSubtitle.getByBrightness(brightness),
              ),
            ),
            Text(
              value,
              style: TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
