import 'package:flutter/material.dart';
import '../../data/models/task.dart';
import '../../../../core/components/widgets/app_detail_widgets.dart';

class TaskProofOfWorkSection extends StatelessWidget {
  final Task task;

  const TaskProofOfWorkSection({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    return AppDetailWidgets.buildInfoCard(
      context,
      title: 'إثبات الإنجاز',
      icon: Icons.photo_library_rounded,
      child: task.urlImage != null && task.urlImage!.isNotEmpty
          ? GestureDetector(
              onTap: () {
                showDialog(
                  context: context,
                  builder: (context) => Dialog(
                    backgroundColor: Colors.transparent,
                    insetPadding: const EdgeInsets.all(16),
                    child: Stack(
                      alignment: Alignment.topRight,
                      children: [
                        InteractiveViewer(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(16),
                            child: Image.network(task.urlImage!, fit: BoxFit.contain),
                          ),
                        ),
                        IconButton(
                          icon: const Icon(Icons.close, color: Colors.white, size: 30),
                          onPressed: () => Navigator.pop(context),
                        )
                      ],
                    ),
                  ),
                );
              },
              child: _buildImageContainer(),
            )
          : _buildImageContainer(),
    );
  }

  Widget _buildImageContainer() {
    return Container(
      height: 200,
      width: double.infinity,
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(16),
        image: task.urlImage != null && task.urlImage!.isNotEmpty
            ? DecorationImage(
                image: NetworkImage(task.urlImage!),
                fit: BoxFit.cover,
              )
            : null,
      ),
      child: task.urlImage == null || task.urlImage!.isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    Icons.photo_rounded,
                    color: Colors.grey[400],
                    size: 48,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'لم يتم رفع صورة للإنجاز',
                    style: TextStyle(color: Colors.grey[500], fontSize: 12),
                  ),
                ],
              ),
            )
          : null,
    );
  }
}
