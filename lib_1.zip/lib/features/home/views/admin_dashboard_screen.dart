import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart';
import '../../../core/components/custom_app_bar.dart';
import '../../../core/components/loading_widget.dart';
import '../../notifications/controller/notification_controller.dart' show NotificationController;
import '../controller/admin_dashboard_controller.dart';
import '../../../core/routes/app_routes.dart';
import '../../../core/api/auth_service.dart';

class AdminDashboardScreen extends GetView<AdminDashboardController> {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) 
  {
    Get.find<NotificationController>().fetchNotifications();
    final brightness = Theme.of(context).brightness;
    final userName = AuthService.user.value.name.isNotEmpty ? AuthService.user.value.name : 'مدير النظام';

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: const CustomAppBar(
        title: 'لوحة تحكم الإدارة',
        showBackButton: false,
        showLogoutButton: true,
      ),
      body: RefreshIndicator(
        onRefresh: () async => controller.fetchAdminStats(),
        child: Obx(() {
          if (controller.isLoading.value) {
            return const LoadingWidget();
          }

          return SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 24.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildWelcomeHeader(brightness, userName),
                const SizedBox(height: 24),
                Text('نظرة عامة', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                const SizedBox(height: 16),
                _buildStatGrid(brightness),
                const SizedBox(height: 32),
                Text('آخر الإشعارات', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                const SizedBox(height: 16),
                _buildRecentNotifications(brightness),
                const SizedBox(height: 48),
              ],
            ),
          );
        }),
      ),
    );
  }

  Widget _buildWelcomeHeader(Brightness brightness, String userName) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppColors.primary.getByBrightness(brightness),
            AppColors.secondary.getByBrightness(brightness),
          ],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
            blurRadius: 15,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.white24,
            backgroundImage: AuthService.user.value.imgUrl != null ? NetworkImage(AuthService.user.value.imgUrl!) : null,
            child: AuthService.user.value.imgUrl == null ? const Icon(Icons.shield_rounded, size: 30, color: Colors.white) : null,
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'أهلاً بك',
                  style: TextStyle(color: Colors.white70, fontSize: 14),
                ),
                Text(
                  userName,
                  style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white24,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('Admin', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
          ),
        ],
      ),
    );
  }

  Widget _buildStatGrid(Brightness brightness) {
    return GridView.count(
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      childAspectRatio: 1.1,
      children: [
        _buildStatCard(
          brightness,
          'مدراء النظام',
          controller.usersStats['ADMIN']?.toString() ?? '0',
          Icons.admin_panel_settings_rounded,
          Colors.purple,
          onTap: () => Get.toNamed(AppRoutes.systemUsers),
        ),
        _buildStatCard(
          brightness,
          'المنسقين',
          controller.usersStats['COORDINATOR']?.toString() ?? '0',
          Icons.badge_rounded,
          Colors.indigo,
          onTap: () => Get.toNamed(AppRoutes.coordinators),
        ),
        _buildStatCard(
          brightness,
          'الموردين',
          controller.usersStats['SUPPLIER']?.toString() ?? '0',
          Icons.local_shipping_rounded,
          Colors.brown,
          onTap: () => Get.toNamed(AppRoutes.suppliers),
        ),
        _buildStatCard(
          brightness,
          'الخدمات',
          controller.servicesStats.value.toString(),
          Icons.room_service_rounded,
          Colors.deepOrange,
          onTap: () => Get.toNamed(AppRoutes.services),
        ),
        _buildStatCard(
          brightness,
          'الاقتراحات المعلقة',
          controller.pendingProposals.value.toString(),
          Icons.inbox_rounded,
          controller.pendingProposals.value > 0 ? Colors.red : Colors.green,
          onTap: () => Get.toNamed(AppRoutes.services), // Proposed services are in the same screen
        ),
      ],
    );
  }

  Widget _buildStatCard(Brightness brightness, String title, String count, IconData icon, Color color, {VoidCallback? onTap}) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(16),
        child: Container(
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 8,
                offset: const Offset(0, 2),
              )
            ],
          ),
          child: Stack(
            children: [
              Positioned(
                right: -10,
                top: -10,
                child: Icon(icon, size: 70, color: color.withValues(alpha: 0.05)),
              ),
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: color.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Icon(icon, color: color, size: 24),
                    ),
                    const SizedBox(height: 12),
                    Text(count, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: AppColors.textBody.getByBrightness(brightness))),
                    const SizedBox(height: 4),
                    Text(title, style: TextStyle(fontSize: 12, color: AppColors.textSubtitle.getByBrightness(brightness))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildRecentNotifications(Brightness brightness) {
    if (controller.recentNotifications.isEmpty) {
      return Center(
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 24.0),
          child: Text(
            'لا توجد إشعارات حديثة',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness)),
          ),
        ),
      );
    }
    
    return Column(
      children: controller.recentNotifications.map((notification) {
        final title = notification['title'] ?? 'إشعار';
        final message = notification['message'] ?? '';
        final isRead = (notification['is_read'] is int) 
            ? notification['is_read'] == 1 
            : notification['is_read'] == true;
            
        return Container(
          margin: const EdgeInsets.only(bottom: 12),
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(16),
            border: isRead ? null : Border.all(color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3)),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.02),
                blurRadius: 8,
                offset: const Offset(0, 2),
              )
            ],
          ),
          child: ListTile(
            contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            leading: CircleAvatar(
              backgroundColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
              child: Icon(Icons.notifications_active_rounded, color: AppColors.primary.getByBrightness(brightness), size: 20),
            ),
            title: Text(
              title,
              style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14, color: AppColors.textBody.getByBrightness(brightness)),
            ),
            subtitle: Text(
              message,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: TextStyle(fontSize: 12, color: AppColors.textSubtitle.getByBrightness(brightness)),
            ),
          ),
        );
      }).toList(),
    );
  }
}
