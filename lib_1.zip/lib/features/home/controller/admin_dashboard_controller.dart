import 'package:get/get.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/utils/utils.dart';

class AdminDashboardController extends GetxController {
  final ApiService _apiService = Get.find<ApiService>();

  final isLoading = true.obs;
  
  final usersStats = {}.obs;
  final servicesStats = 0.obs;
  final pendingProposals = 0.obs;
  final recentNotifications = [].obs;

  @override
  void onInit() {
    super.onInit();
    fetchAdminStats();
  }

  Future<void> fetchAdminStats() async {
    isLoading.value = true;
    try {
      final response = await _apiService.get('/dashboard/admin_stats');
      
      if (response != null) {
        usersStats.value = Map<String, dynamic>.from(response['users'] ?? {});
        servicesStats.value = int.tryParse(response['services']?['total']?.toString() ?? '0') ?? 0;
        pendingProposals.value = int.tryParse(response['proposals']?['pending']?.toString() ?? '0') ?? 0;
      }

      try {
        final notifResponse = await _apiService.get('/notifications');
        if (notifResponse != null && notifResponse is List) {
          recentNotifications.value = notifResponse.take(4).toList();
        }
      } catch (_) {
        // Ignore notification fetch error if any
      }

    } catch (e) {
      MyPUtils.showSnackbar('خطأ', 'فشل جلب إحصائيات الداشبورد', isError: true);
    } finally {
      isLoading.value = false;
    }
  }
}
