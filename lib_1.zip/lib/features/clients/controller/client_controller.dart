import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/api/auth_service.dart';
import '../../../core/controllers/validtor.dart' show MyPValidator;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../data/repository/client_repository.dart' show ClientRepository;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../data/models/client.dart' show Client;
import '../../events/controller/event_controller.dart' show EventController;

import 'dart:io' show File;
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;

class ClientController extends GetxController 
{
  final ClientRepository _repository = Get.find<ClientRepository>();
  final EventController _eventController = Get.find<EventController>();
  final name = ''.obs;
  final phone = ''.obs;
  final email = ''.obs;
  final address = ''.obs;

  final clients = <Client>[].obs;
  final searchQuery = ''.obs;
  final currentFilter = 'الكل'.obs;
  final selectedClient = Rxn<Client>();
  final isLoading = false.obs;
  RxBool get eventsIsLoading  => _eventController.isLoading;

  final profileImage = Rxn<File>();
  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      profileImage.value = File(image.path);
    }
  }

 
  @override
  void onInit() {
    super.onInit();
    _eventController.onInit();
    fetchAll();
  }

  void clearFields() {
    name.value = '';
    phone.value = '';
    email.value = '';
    address.value = '';
    profileImage.value = null;
  }

  void populateFields(Client client) {
    name.value = client.name;
    phone.value = client.phoneNumber;
    email.value = client.email ?? '';
    address.value = client.address ?? '';
  }

  List<Client> get filteredClients {
    List<Client> list = clients;
    
    // Filter by chips
    if (currentFilter.value == 'نشط') {
      list = list.where((c) => c.isActive == true).toList();
    } else if (currentFilter.value == 'المؤرشف') {
      list = list.where((c) => c.isDeleted == true).toList();
    } else if (currentFilter.value == 'كبار الشخصيات') {
      // Assuming a VIP property, or just an empty list if not supported yet
      // For now we simulate.
      list = list.where((c) => c.name.toLowerCase().contains('vip')).toList();
    }
    
    if (searchQuery.isNotEmpty) {
      list = list.where((c) {
        return c.name.toLowerCase().contains(
              searchQuery.value.toLowerCase(),
            ) ||
            c.phoneNumber.contains(searchQuery.value);
      }).toList();
    }
    return list;
  }

  Future<void> fetchAll({bool force = false}) async {
    if (!force && clients.isNotEmpty) return;
    
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) => clients.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetchClient(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (client) => selectedClient.value = client,
    );
    isLoading.value = false;
  }

  Future<void> createClient() async {
    if(isLoading.value) return;
    var contactMsg = MyPValidator.cocatMsg([
                                  MyPValidator.name(name.value),
                                  MyPValidator.email(email.value),
                                  MyPValidator.phone(phone.value),
                                  
                                ]); 
    if(contactMsg != null)
    {

      return MyPUtils.showSnackbar('تنبيه', contactMsg, isError: true,position: SnackPosition.TOP,
        icon: Icon(Icons.warning_amber_rounded, color: AppColors.accent.getByBrightness(Get.theme.brightness)));
    }
    isLoading.value = true;
    final Map<String, dynamic> dataMap = {
      'full_name': name.value,
      'phone_number': phone.value,
      'email': email.value,
      'address': address.value,
      'coordinator_email': AuthService.user.value.email,
    };
    if (profileImage.value != null) {
      dataMap['img_url'] = await dio.MultipartFile.fromFile(
        profileImage.value!.path,
        filename: profileImage.value!.path.split('/').last,
      );
    }
    final data = dio.FormData.fromMap(dataMap);
    
    final result = await _repository.create(data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (response) {
        clients.add(response);
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم إضافة العميل');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  
  Future<void> updateClient(int id) async {
    isLoading.value = true;
    final Map<String, dynamic> dataMap = {
      'full_name': name.value,
      'phone_number': phone.value,
      'email': email.value,
      'address': address.value,
      'coordinator_email': AuthService.user.value.email,
    };
    if (profileImage.value != null) {
      dataMap['img_url'] = await dio.MultipartFile.fromFile(
        profileImage.value!.path,
        filename: profileImage.value!.path.split('/').last,
      );
    }
    final data = dio.FormData.fromMap(dataMap);
    final result = await _repository.update(id, data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) clients[index] = updated;
        selectedClient.value = updated;
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم تحديث البيانات');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteClient(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) {
          clients[index] = clients[index].copyWith(isDeleted: true);
        }
        MyPUtils.showSnackbar('نجاح', 'تم حذف العميل');
      },
    );
  }

  Future<void> restoreClient(int id) async {
    isLoading.value = true;
    final result = await _repository.restore(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) {
          clients[index] = clients[index].copyWith(isDeleted: false);
        }
        MyPUtils.showSnackbar('نجاح', 'تم استعادة العميل');
      },
    );
    isLoading.value = false;
  }

  @override
  void onClose() {
    super.onClose();
  }
}
