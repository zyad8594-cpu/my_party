import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/components/custom_app_bar.dart';
import '../../../core/controllers/main_layout_controller.dart' show MainLayoutController;
import '../../../core/components/widgets/myp_actions.dart';
import '../../../core/components/widgets/myp_list_view_widget.dart';
import '../../../core/components/widgets/search_box_widget.dart';
import '../data/models/client.dart' show Client;
import '../controller/client_controller.dart' show ClientController;
import '../../events/controller/event_controller.dart' show EventController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/empty_state_widget.dart' show EmptyStateWidget;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import 'package:intl/intl.dart' show DateFormat;

class ClientListScreen extends GetView<ClientController> {
  ClientListScreen({super.key});
  
  final MainLayoutController mainController = Get.find<MainLayoutController>();

  @override
  Widget build(BuildContext context) {
    
    final brightness = Theme.of(context).brightness;
return Scaffold(
      appBar: CustomAppBar(title: 'إدارة العملاء'),
      backgroundColor: AppColors.background.getByBrightness(brightness),
      body: RefreshIndicator(
        onRefresh: controller.fetchAll,
        child: SafeArea(
          child: Column(
            children: [
              /// صندوق البحث والفلاتر
              SearchBox.withNotLayout(
                context, 
                'بحث عن عميل...',
                searchOnChanged: (value) => controller.searchQuery.value = value,
              ),
              const SizedBox(height: 8),
              /// قائمة العملاء
              MyPListView.expandedBuilder(context, 
                ///  حالة التحميل
                isLoading: controller.isLoading, 
                loadingWidget: ()=> LoadingWidget(), 
                ///  حالة عدم وجود عملاء
                emptyWidget: ()=>  const EmptyStateWidget(message: 'لا يوجد عملاء مضافين', icon: Icons.people_outline_rounded), 
                ///  قائمة العملاء
                filters: () => controller.filteredClients, 
                ///  بناء بطاقة عرض العميل 
                itemBuilder: (index, client)=> _buildClientCard(context, client),
              ),
            ],
          ),
        ),
      ),

      ///  زر إضافة عميل
      floatingActionButton: MyPActions.floatButton(
        context, 
        icon: Icons.add_rounded, 
        heroTag: 'add_client',
        onPressed: () => Get.toNamed(AppRoutes.clientAdd),
      ),
    );
  }

  Widget _buildClientCard(BuildContext context, Client client) 
  {
    final brightness = Theme.of(context).brightness;
    final String clientAvatar = client.imgUrl ?? '';

    // Resolve latest event
    final eventController = Get.find<EventController>();
    final clientEvents = eventController.events.where((e) => e.clientId == client.id).toList();
    clientEvents.sort((a, b) => b.eventDate.compareTo(a.eventDate));
    final latestEvent = clientEvents.isNotEmpty ? clientEvents.first : null;

    String recentEventText = 'لا يوجد سجل مناسبات سابقة';
    IconData recentEventIcon = Icons.history_rounded;
    if (latestEvent != null) {
      try {
        final date = DateTime.parse(latestEvent.eventDate);
        final dateStr = DateFormat('d MMMM', 'ar').format(date);
        recentEventText = 'آخر مناسبة: ${latestEvent.eventName} ($dateStr)';
        recentEventIcon = latestEvent.eventName.contains('عمل') || latestEvent.eventName.contains('مؤتمر') 
            ? Icons.work_outline_rounded 
            : Icons.cake_outlined;
      } catch (_) {
        recentEventText = 'آخر مناسبة: ${latestEvent.eventName}';
        recentEventIcon = Icons.event_rounded;
      }
    }

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.05)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: client.isDeleted
              ? () => _restoreClient(context, client)
              : () => Get.toNamed(AppRoutes.clientDetail, arguments: client),
          borderRadius: BorderRadius.circular(24),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              children: [
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // Avatar
                    Stack(
                      children: [
                        Container(
                          width: 64,
                          height: 64,
                          decoration: BoxDecoration(
                            shape: BoxShape.circle,
                            border: Border.all(color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3), width: 2),
                            color: AppColors.background.getByBrightness(brightness),
                          ),
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(32),
                            child: clientAvatar.isNotEmpty
                                ? Image.network(clientAvatar, fit: BoxFit.cover, errorBuilder: (c, e, s) => _fallbackAvatar(context))
                                : _fallbackAvatar(context),
                          ),
                        ),
                      
                      ],
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            client.name.isNotEmpty ? client.name : 'عميل بدون اسم',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: client.isDeleted
                                  ? AppColors.textSubtitle.getByBrightness(brightness)
                                  : AppColors.textBody.getByBrightness(brightness),
                            ),
                          ),
                          const SizedBox(height: 4),
                          Row(
                            children: [
                              Text(
                                client.phoneNumber,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: AppColors.textSubtitle.getByBrightness(brightness),
                                ),
                              ),
                              const SizedBox(width: 6),
                              Icon(
                                Icons.phone_rounded,
                                size: 14,
                                color: AppColors.primary.getByBrightness(brightness),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                    _buildActionButtons(context, client),
                  ],
                ),
                const SizedBox(height: 16),
                Align(
                  alignment: Alignment.centerRight,
                  child: FractionallySizedBox(
                    widthFactor: 0.85,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 10),
                      decoration: BoxDecoration(
                        color: AppColors.background.getByBrightness(brightness),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Row(
                        children: [
                          Expanded(
                            child: Text(
                              recentEventText,
                              style: TextStyle(
                                fontSize: 13,
                                color: AppColors.textSubtitle.getByBrightness(brightness),
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Icon(
                            recentEventIcon,
                            size: 16,
                            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.8),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _fallbackAvatar(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Icon(Icons.person_rounded, color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.5), size: 30);
  }

  Widget _buildActionButtons(BuildContext context, Client client) 
  {
    final brightness = Theme.of(context).brightness;
    return PopupMenuButton<String>(
      icon: Icon(Icons.more_vert_rounded, color: AppColors.textSubtitle.getByBrightness(brightness), size: 20),
      onSelected: (value) {
        if (value == 'edit') {
          Get.toNamed(AppRoutes.clientAdd, arguments: client);
        } else if (value == 'delete') {
          _delete(context, client.id);
        } else if (value == 'restore') 
        {
          _restoreClient(context, client);
        }
      },
      itemBuilder: (context) => client.isDeleted
          ? [
              const PopupMenuItem(
                value: 'restore',
                child: Row(
                  children: [
                    Icon(Icons.restore_from_trash_rounded, size: 18),
                    SizedBox(width: 8),
                    Text('استعادة'),
                  ],
                ),
              ),
            ]
          : [
              const PopupMenuItem(
                value: 'edit',
                child: Row(
                  children: [
                    Icon(Icons.edit_rounded, size: 18),
                    SizedBox(width: 8),
                    Text('تعديل'),
                  ],
                ),
              ),
              const PopupMenuItem(
                value: 'delete',
                child: Row(
                  children: [
                    Icon(Icons.delete_rounded, size: 18, color: Colors.red),
                    SizedBox(width: 8),
                    Text('حذف', style: TextStyle(color: Colors.red)),
                  ],
                ),
              ),
            ],
    );
  }


  void _delete(BuildContext context, int id) async 
  {
    final brightness = Theme.of(context).brightness;
Get.defaultDialog(
      title: 'تأكيد الحذف',
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      radius: 12,
      confirm: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: AppColors.accent.getByBrightness(brightness)),
        onPressed: () {
          Get.back();
          controller.deleteClient(id);
        },
        child: const Text('نعم، احذف', style: TextStyle(color: Colors.white)),
      ),
      cancel: OutlinedButton(
        style: OutlinedButton.styleFrom(side: BorderSide(color: AppColors.primary.getByBrightness(brightness))),
        onPressed: () => Get.back(),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }

  void _restoreClient(BuildContext context, Client client) 
  {
    final brightness = Theme.of(context).brightness;
Get.defaultDialog(
      title: 'تأكيد الاستعادة',
      middleText: 'هل أنت متأكد من استعادة هذا العميل؟',
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      radius: 12,
      confirm: ElevatedButton(
        style: ElevatedButton.styleFrom(backgroundColor: AppColors.primary.getByBrightness(brightness)),
        onPressed: () {
          Get.back();
          controller.restoreClient(client.id);
        },
        child: const Text('نعم، استعد', style: TextStyle(color: Colors.white)),
      ),
      cancel: OutlinedButton(
        style: OutlinedButton.styleFrom(side: BorderSide(color: AppColors.primary.getByBrightness(brightness))),
        onPressed: () => Get.back(),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }
}
