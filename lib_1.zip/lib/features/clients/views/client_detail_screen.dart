import 'package:get/get.dart';
import 'package:flutter/material.dart' show 
  Icons, Scaffold, CustomScrollView, SliverAppBar, SliverToBoxAdapter, 
  Padding, Column, EdgeInsets, TextStyle, FontWeight, 
  StatelessWidget, Widget, BuildContext, Theme, Brightness, Container, 
  BoxDecoration, Icon, IconButton, CircleAvatar, NetworkImage,
  Colors, SizedBox, CrossAxisAlignment, Text, FlexibleSpaceBar, Center;
  
import '../data/models/client.dart' show Client;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../widgets/client_detail_widgets.dart' show ClientDetailHeader, ClientContactSection, ClientEventsList;

class ClientDetailScreen extends StatelessWidget 
{
  const ClientDetailScreen({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final Client client = Get.arguments;

    return Scaffold
    (
      backgroundColor: AppColors.background.getByBrightness(brightness),
      body: CustomScrollView
      (
        slivers: <Widget>
        [
          _buildSliverAppBar(client, brightness),
          SliverToBoxAdapter
          (
            child: Padding
            (
              padding: const EdgeInsets.all(20),
              child: Column
              (
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>
                [
                  ClientDetailHeader(client: client),
                  const SizedBox(height: 24),

                  ClientContactSection(client: client),
                  const SizedBox(height: 32),

                  Text
                  (
                    'المناسبات المرتبطة',
                    style: TextStyle
                    (
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: AppColors.textBody.getByBrightness(brightness),
                    ),
                  ),
                  const SizedBox(height: 16),

                  ClientEventsList(client: client),

                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSliverAppBar(Client client, Brightness brightness) 
  {
    return SliverAppBar
    (
      expandedHeight: 180,
      pinned: true,
      backgroundColor: AppColors.primary.getByBrightness(brightness),
      flexibleSpace: FlexibleSpaceBar
      (
        background: Container(
          decoration: BoxDecoration(gradient: AppColors.primaryGradient.getByBrightness(brightness)),
          child: Center
          (
            child: CircleAvatar(
              radius: 50,
              backgroundColor: Colors.white.withValues(alpha: 0.2),
              backgroundImage: client.imgUrl != null && client.imgUrl!.isNotEmpty
                  ? NetworkImage(client.imgUrl!)
                  : null,
              child: client.imgUrl == null || client.imgUrl!.isEmpty
                  ? const Icon(
                      Icons.person_rounded,
                      color: Colors.white,
                      size: 60,
                    )
                  : null,
            ),
          ),
        ),
      ),
      leading: IconButton
      (
        icon: const Icon(Icons.arrow_back_ios_new, color: Colors.white),
        onPressed: () => Get.back(),
      ),
    );
  }
}
