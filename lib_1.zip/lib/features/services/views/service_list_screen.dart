import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../data/models/service.dart' show Service;
import '../controller/service_controller.dart' show ServiceController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/empty_state_widget.dart' show EmptyStateWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/api/auth_service.dart' show AuthService;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/components/widgets/app_form_widgets.dart' show AppFormWidgets;

class ServiceListScreen extends GetView<ServiceController> {
  const ServiceListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final String role = AuthService.user.value.role.isNotEmpty? AuthService.user.value.role.toLowerCase() : 'user';
    final bool isSupplier = role == 'supplier';
    
    // Automatically fetch on build (GetX handles cache usually)
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (isSupplier) {
        controller.fetchMyServiceRequests();
      } else {
        controller.fetchServiceRequests();
      }
    });
    
    final brightness = Theme.of(context).brightness;

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: CustomAppBar(
          title: 'قائمة الخدمات',
          bottom: const TabBar(
            tabs: [
              Tab(text: 'الخدمات الحالية', icon: Icon(Icons.list_alt_rounded)),
              Tab(text: 'الخدمات المقترحة', icon: Icon(Icons.new_releases_outlined)),
            ],
            indicatorColor: Colors.white,
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white70,
          ),
        ),
        floatingActionButton: Container(
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(16),
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
                blurRadius: 12,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: FloatingActionButton(
            heroTag: 'add_service',
            onPressed: () => Get.toNamed(AppRoutes.serviceAdd),
            backgroundColor: Colors.transparent,
            elevation: 0,
            child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
          ),
        ),
        body: Container(
          decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
          child: Column(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                child: TextFormField(
                  onChanged: (value) => controller.searchQuery.value = value,
                  style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                  decoration: InputDecoration(
                    hintText: 'ابحث في الخدمات المعروضة والمقترحة...',
                    hintStyle: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
                    prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary.getByBrightness(brightness)),
                    filled: true,
                    fillColor: AppColors.surface.getByBrightness(brightness),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(16),
                      borderSide: BorderSide.none,
                    ),
                    contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                  ),
                ),
              ),
              Expanded(
                child: TabBarView(
                  children: [
                    // Tab 1: Current Services
                    RefreshIndicator(
                      onRefresh: () async => controller.fetchServices(),
                      child: Obx(() {
                        if (controller.isLoading.value) {
                          return const LoadingWidget();
                        }
                        if (controller.filteredServices.isEmpty) {
                          return const EmptyStateWidget(message: 'لا يوجد نتائج للبحث', icon: Icons.category_outlined);
                        }
                        return ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: controller.filteredServices.length,
                          itemBuilder: (context, index) {
                            final service = controller.filteredServices[index];
                            return _buildServiceCard(service, context, brightness);
                          },
                        );
                      }),
                    ),
                    // Tab 2: Proposed Services
                    RefreshIndicator(
                      onRefresh: () async {
                        if (isSupplier) {
                          await controller.fetchMyServiceRequests();
                        } else {
                          await controller.fetchServiceRequests();
                        }
                      },
                      child: Obx(() {
                        if (controller.isRequestsLoading.value) {
                          return const LoadingWidget();
                        }
                        final filteredPending = controller.filteredServiceRequests.where((r) => r.status == 'PENDING').toList();
                        if (filteredPending.isEmpty) {
                          return const EmptyStateWidget(message: 'لا يوجد نتائج للبحث في المقترحات', icon: Icons.inbox_outlined);
                        }
                        return ListView.builder(
                          padding: const EdgeInsets.all(16),
                          itemCount: filteredPending.length,
                          itemBuilder: (context, index) {
                            final request = filteredPending[index];
                            return _buildProposedServiceCard(request, context, brightness);
                          },
                        );
                      }),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProposedServiceCard(dynamic request, BuildContext context, Brightness brightness) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        decoration: AppFormWidgets.cardDecoration(context),
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.new_releases_rounded, color: AppColors.secondary.getByBrightness(brightness)),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    request.serviceName,
                    style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.white),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.orange.withValues(alpha: 0.2),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: const Text('قيد المراجعة', style: TextStyle(color: Colors.orange, fontSize: 12)),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              request.description ?? 'لا يوجد تفاصيل',
              style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 13),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Icon(Icons.storefront_outlined, size: 16, color: AppColors.textSubtitle.getByBrightness(brightness)),
                const SizedBox(width: 4),
                Text('المورد: ${request.supplierName}', style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 12)),
              ],
            ),
            const SizedBox(height: 16),
            if (AuthService.user.value.role.toLowerCase() == 'admin' || AuthService.user.value.role.toLowerCase() == 'coordinator')
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.red.withValues(alpha: 0.1),
                      foregroundColor: Colors.red,
                      elevation: 0,
                    ),
                    onPressed: () {
                      Get.defaultDialog(
                        title: 'رفض الاقتراح',
                        middleText: 'هل أنت متأكد من رفض هذه الخدمة المقترحة؟',
                        textConfirm: 'نعم',
                        textCancel: 'تراجع',
                        confirmTextColor: Colors.white,
                        onConfirm: () {
                          Get.back();
                          controller.updateRequestStatus(request.id, 'REJECTED');
                        },
                      );
                    },
                    icon: const Icon(Icons.close_rounded, size: 18),
                    label: const Text('رفض'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.green.withValues(alpha: 0.1),
                      foregroundColor: Colors.green,
                      elevation: 0,
                    ),
                    onPressed: () {
                      Get.defaultDialog(
                        title: 'اعتماد الخدمة',
                        middleText: 'هل تريد اعتماد هذه الخدمة لتصبح خدمة نشطة في النظام؟\nسيتم نقلك لشاشة الإضافة مع تعبئة البيانات تلقائياً.',
                        textConfirm: 'متابعة',
                        textCancel: 'إلغاء',
                        confirmTextColor: Colors.white,
                        onConfirm: () {
                          Get.back();
                          controller.updateRequestStatus(request.id, 'APPROVED');
                          // Navigate to service add and pre-fill form
                          // we pass dynamic service map manually to the add screen argument
                          controller.serviceNameRx.value = request.serviceName;
                          controller.descriptionRx.value = request.description ?? '';
                          controller.nameController.text = request.serviceName;
                          controller.descriptionController.text = request.description ?? '';
                          Get.toNamed(AppRoutes.serviceAdd);
                        },
                      );
                    },
                    icon: const Icon(Icons.check_rounded, size: 18),
                    label: const Text('اعتماد والإضافة'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildServiceCard(Service service, BuildContext context, Brightness brightness) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        decoration: AppFormWidgets.cardDecoration(context),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.secondary.getByBrightness(brightness).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.category_outlined,
                color: AppColors.secondary.getByBrightness(brightness),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    service.serviceName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    service.description ?? 'لا يوجد وصف',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.edit_rounded,
                      color: AppColors.warning.getByBrightness(brightness),
                      size: 18,
                    ),
                  ),
                  onPressed: () =>
                      Get.toNamed(AppRoutes.serviceAdd, arguments: service),
                ),
                const SizedBox(width: 4),
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.delete_rounded,
                      color: AppColors.accent.getByBrightness(brightness),
                      size: 18,
                    ),
                  ),
                  onPressed: () => _delete(service.id, brightness),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }



  void _delete(int id, Brightness brightness) async {
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      titleStyle: TextStyle(color: AppColors.primary.getByBrightness(brightness)),
      middleText: 'هل أنت متأكد من حذف هذه الخدمة؟',
      middleTextStyle: const TextStyle(color: Colors.white),
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      textConfirm: 'نعم',
      textCancel: 'لا',
      confirmTextColor: Colors.black,
      cancelTextColor: AppColors.primary.getByBrightness(brightness),
      onConfirm: () {
        Get.back();
        controller.deleteService(id);
      },
    );
  }
}
