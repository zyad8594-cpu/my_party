import 'package:equatable/equatable.dart';

class ServiceRequest extends Equatable {
  final int id;
  final int supplierId;
  final String supplierName;
  final String serviceName;
  final String? description;
  final String status;
  final String? createdAt;

  const ServiceRequest({
    required this.id,
    required this.supplierId,
    required this.supplierName,
    required this.serviceName,
    this.description,
    required this.status,
    this.createdAt,
  });

  factory ServiceRequest.fromJson(Map<String, dynamic> json) {
    return ServiceRequest(
      id: json['id'] ?? 0,
      supplierId: json['supplier_id'] ?? 0,
      supplierName: json['supplier_name'] ?? 'غير معروف',
      serviceName: json['service_name'] ?? '',
      description: json['description'],
      status: json['status'] ?? 'PENDING',
      createdAt: json['created_at'],
    );
  }

  @override
  List<Object?> get props => [
        id,
        supplierId,
        supplierName,
        serviceName,
        description,
        status,
        createdAt,
      ];
}
