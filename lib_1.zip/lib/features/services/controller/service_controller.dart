import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../suppliers/data/models/supplier.dart' show Supplier;
import '../data/repository/service_repository.dart' show ServiceRepository;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../data/models/service.dart' show Service;

class ServiceController extends GetxController 
{
  final ServiceRepository _repository = Get.find<ServiceRepository>();

  final services = <Service>[].obs;
  final selectedService = Rxn<Service>();
  final isLoading = false.obs;
  final searchQuery = ''.obs;
  final supplierSearchQuery = ''.obs;

  List<Service> get filteredServices => services.where((s) {
    final query = searchQuery.value.toLowerCase();
    return s.serviceName.toLowerCase().contains(query) || 
           (s.description?.toLowerCase().contains(query) ?? false);
  }).toList();

  List<dynamic> get filteredServiceRequests => serviceRequests.where((r) {
    final query = searchQuery.value.toLowerCase();
    return r.serviceName.toLowerCase().contains(query) || 
           (r.description?.toLowerCase().contains(query) ?? false) ||
           (r.supplierName?.toLowerCase().contains(query) ?? false);
  }).toList();

  // Reactive state for Service Add/Edit
  final serviceNameRx = ''.obs;
  final descriptionRx = ''.obs;

  final nameController = TextEditingController();
  final descriptionController = TextEditingController();
  final supplierSearchController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    nameController.addListener(() {
      serviceNameRx.value = nameController.text;
    });
    descriptionController.addListener(() {
      descriptionRx.value = descriptionController.text;
    });
    fetchServices();
  }
  
  RxList<Supplier> get serviceSuppliers{
    return (selectedService.value?.suppliers ?? []).obs;
  }
  void clearFields() {
    serviceNameRx.value = '';
    descriptionRx.value = '';

    nameController.clear();
    descriptionController.clear();
  }

  void populateFields(Service service) {
    serviceNameRx.value = service.serviceName;
    descriptionRx.value = service.description ?? '';

    nameController.text = service.serviceName;
    descriptionController.text = service.description ?? '';
  }

  Future<void> fetchServices({bool force = false}) async 
  {
    if(isLoading.value == true) return;
    if(!force && services.isNotEmpty) return;
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data){
        services.assignAll(data);
      },
    );
    isLoading.value = false;
  }

  Future<void> fetchService(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (service) => selectedService.value = service,
    );
    isLoading.value = false;
  }

  Future<void> createService() async {
    if (serviceNameRx.value.isEmpty) {
      MyPUtils.showSnackbar('تنبيه', 'يرجى إدخال اسم الخدمة', isError: true);
      return;
    }
    isLoading.value = true;
    final data = {
      'service_name': serviceNameRx.value,
      'description': descriptionRx.value,
    };
    final result = await _repository.create(data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (newService) {
        services.add(newService);
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم إضافة الخدمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateService(int id) async {
    isLoading.value = true;
    final data = {
      'service_name': serviceNameRx.value,
      'description': descriptionRx.value,
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = services.indexWhere((c) => c.id == id);
        if (index != -1) services[index] = updated;
        selectedService.value = updated;
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم تحديث الخدمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteService(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        services.removeWhere((c) => c.id == id);
        if (selectedService.value?.id == id) {
          selectedService.value = null;
        }
        MyPUtils.showSnackbar('نجاح', 'تم حذف الخدمة');
      },
    );
  }

  // --- Proposed Services Logic ---
  final serviceRequests = <dynamic>[].obs; // Using dynamic or ServiceRequest model
  final isRequestsLoading = false.obs;

  Future<void> fetchServiceRequests() async {
    isRequestsLoading.value = true;
    final result = await _repository.getAllRequests();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) {
        serviceRequests.value = data;
      },
    );
    isRequestsLoading.value = false;
  }

  Future<void> fetchMyServiceRequests() async {
    isRequestsLoading.value = true;
    final result = await _repository.getMyRequests();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) {
        serviceRequests.value = data;
      },
    );
    isRequestsLoading.value = false;
  }

  Future<void> updateRequestStatus(int id, String status) async {
    isRequestsLoading.value = true;
    final result = await _repository.updateRequestStatus(id, status);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) {
        // remove or update locally
        final index = serviceRequests.indexWhere((r) => r.id == id);
        if (index != -1) {
          if (status == 'APPROVED' || status == 'REJECTED') {
            serviceRequests.removeAt(index);
          }
        }
        MyPUtils.showSnackbar('نجاح', 'تم تحديث حالة الاقتراح');
      },
    );
    isRequestsLoading.value = false;
  }
}
