import 'package:flutter/material.dart';
  
import 'package:get/get.dart';
import '../../../../core/themes/app_colors.dart' show AppColors;
import '../../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../controller/event_controller.dart' show EventController;
import '../../../clients/controller/client_controller.dart' show ClientController;
import '../../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../../core/components/widgets/app_form_widgets.dart' show AppFormWidgets;

class EventClientSelectionScreen extends StatelessWidget {
  EventClientSelectionScreen({super.key});

  final EventController controller = Get.find<EventController>();
  final ClientController clientController = Get.find<ClientController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final event = Get.arguments;
    
    if (clientController.clients.isEmpty) {
      clientController.fetchAll();
    }

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: AppBar(
        title: const Text('إضافة مناسبة جديدة'),
        backgroundColor: AppColors.card.getByBrightness(brightness),
        elevation: 0,
        centerTitle: true,
        actions: [
          TextButton.icon(
            onPressed: () => Get.toNamed(AppRoutes.clientAdd),
            icon: Icon(Icons.add_rounded, color: AppColors.textBody.getByBrightness(brightness)),
            label: Text(
              'إضافة عميل',
              style: TextStyle(
                color: AppColors.textBody.getByBrightness(brightness),
                fontWeight: FontWeight.bold,
              ),
            ),
          ),
        ],

        bottom: PreferredSize(preferredSize: Size(Get.size.width, 10), child: const Text('اختيار العميل')),
      ),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          children: [
            TextField(
              onChanged: (value) => clientController.searchQuery.value = value,
              decoration: AppFormWidgets.searchDecoration('البحث عن عميل...', context),
            ),
            const SizedBox(height: 16),

            Expanded(
              child: Obx(() {
                if (clientController.isLoading.value) {
                  return const LoadingWidget();
                }
                if (clientController.filteredClients.isEmpty) {
                  return Center(
                    child: Text(
                      'لا يوجد عملاء. أضف عميلاً جديداً.',
                      style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness)),
                    ),
                  );
                }

                return ListView.builder(
                  itemCount: clientController.filteredClients.length,
                  itemBuilder: (context, index) {
                    final client = clientController.filteredClients[index];
                    return Obx(() {
                      final isSelected =
                          controller.clientIdRx.value == client.id;
                      return Container(
                        margin: const EdgeInsets.only(bottom: 12),
                        decoration: BoxDecoration(
                          color: isSelected
                              ? AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1)
                              : AppColors.card.getByBrightness(brightness),
                          borderRadius: BorderRadius.circular(16),
                          border: Border.all(
                            color: isSelected
                                ? AppColors.primary.getByBrightness(brightness)
                                : Colors.grey[200]!,
                            width: isSelected ? 2 : 1,
                          ),
                        ),
                        child: ListTile(
                          onTap: () => controller.clientIdRx.value = client.id,
                          leading: CircleAvatar(
                            backgroundColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                            backgroundImage: client.imgUrl != null && client.imgUrl!.isNotEmpty 
                                ? NetworkImage(client.imgUrl!) 
                                : null,
                            child: client.imgUrl == null || client.imgUrl!.isEmpty
                                ? Icon(
                                    Icons.person_rounded,
                                    color: AppColors.primary.getByBrightness(brightness),
                                  )
                                : null,
                          ),
                          title: Text(
                            client.name.isNotEmpty ? client.name : 'بدون اسم',
                            style: const TextStyle(fontWeight: FontWeight.bold),
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(client.phoneNumber, style: const TextStyle(fontSize: 13)),
                              if (client.email != null && client.email!.isNotEmpty)
                                Text(client.email!, style: TextStyle(fontSize: 12, color: Colors.grey[600])),
                            ],
                          ),
                          trailing: isSelected
                              ? Icon(
                                  Icons.check_circle_rounded,
                                  color: AppColors.primary.getByBrightness(brightness),
                                )
                              : null,
                        ),
                      );
                    });
                  },
                );
              }),
            ),
            const SizedBox(height: 16),

            Obx(
              () => SizedBox(
                width: double.infinity,
                height: 55,
                child: Container(
                  decoration: BoxDecoration(
                    gradient: controller.clientIdRx.value != 0
                        ? AppColors.primaryGradient.getByBrightness(brightness)
                        : LinearGradient(
                            colors: [Colors.grey[400]!, Colors.grey[400]!],
                          ),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: controller.clientIdRx.value != 0 ? [
                      BoxShadow(
                        color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
                        blurRadius: 12,
                        offset: const Offset(0, 4),
                      ),
                    ] : null,
                  ),
                  child: ElevatedButton(
                    onPressed: controller.clientIdRx.value != 0
                        ? () {
                            
                            
                            controller.eventNameRx.value = event['nameEvent'];
                            controller.dateRx.value = event['dateEvent'];
                            controller.locationRx.value = event['location'];
                            controller.descriptionRx.value = event['description'];
                            controller.budgetRx.value = event['budget'];

                            controller.create();
                            // controller.fetchEvents();
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(16),
                      ),
                    ),
                    child: controller.isLoading.value
                        ? const LoadingWidget(color: Colors.white, size: 20)
                        : const Text(
                            'إنشاء المناسبة',
                            style: TextStyle(
                              color: Colors.white,
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                            ),
                          ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
