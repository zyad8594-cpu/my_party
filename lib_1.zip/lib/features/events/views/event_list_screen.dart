import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/utils/status.dart';
import '../../../core/components/widgets/myp_actions.dart';
import '../../../core/components/widgets/myp_list_view_widget.dart';
import '../../../core/components/widgets/search_box_widget.dart' show SearchBox;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../../core/controllers/main_layout_controller.dart' show MainLayoutController;
import '../controller/event_controller.dart' show EventController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../widgets/even_widgets.dart' show 
  EventEmptyState, EventCard;

class EventListScreen extends GetView<EventController> 
{
  EventListScreen({super.key});
final MainLayoutController mainController = Get.find<MainLayoutController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    controller.fetchAll();
    final brightness = Theme.of(context).brightness;
    // final tabs = StatusTools.getAllStatusText(prepend: ['الكل'], append: ['محذوفة']);
            
    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),

      /**
       *         شريط العنوان
       */
      appBar: CustomAppBar(
        title: 'المناسبات',
       
      ),

      ///  زر إضافة مناسبة
      floatingActionButton: MyPActions.floatButton(
        context, 
        icon: Icons.add_rounded, 
        heroTag: 'add_event',
        onPressed: () => Get.toNamed(AppRoutes.eventAdd)
      ),

      ///  جسم الصفحة
      body: RefreshIndicator(
        onRefresh: () => controller.fetchAll(force: true),
        child: Column(
          children: [
            
            ///  شريط البحث والفلاتر
            SearchBox.withNLOtFilters(
              context, 'البحث عن مناسبة...',
              searchOnChanged: (value) => controller.searchQuery.value = value,
              filtersNames: StatusTools.getAllStatusText(prepend: ['الكل'], remove: ['قيد المراجعة']),
              initSelect: controller.selectedStatus,
              onSelected: (selected, status) {
                if (selected) controller.selectedStatus.value = status;
              },
              selectedFontWeight: FontWeight.bold,
              unSelectedFontWeight: FontWeight.normal,
            ),

            ///  قائمة المناسبات
            MyPListView.expandedBuilder(
              context, 
              ///  حالة التحميل
              isLoading: controller.isLoading, 
              loadingWidget: ()=> LoadingWidget(), 
              ///  حالة عدم وجود مناسبات
              emptyWidget: ()=> EventEmptyState(), 
              ///  قائمة المناسبات
              filters: () => controller.filteredEvents, 
              ///  بناء بطاقة عرض المناسبة 
              itemBuilder: (index, event)=> EventCard(event: event, controller: controller),
            ),
          ],
        ),
      ),
    );
  }
}
