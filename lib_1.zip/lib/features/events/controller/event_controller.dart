import 'dart:convert' show jsonDecode;

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart' show SharedPreferences;
import '../../../core/api/api_constants.dart' show ApiKeys;
import '../../../core/api/auth_service.dart';
import '../../../core/utils/status.dart';
import '../../../core/utils/utils.dart' show MyPUtils;
import '../data/repository/event_repository.dart' show EventRepository;
import '../data/models/event.dart' show Event;

import 'dart:io' show File;
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;

class EventController extends GetxController 
{
  final EventRepository _repository = Get.find<EventRepository>();

  get currentUser async {
    final sharedPreferences = await SharedPreferences.getInstance();
    return Map<String, dynamic>.from(jsonDecode(sharedPreferences.getString(ApiKeys.userKey) ?? '{}'));
  }
  final events = <Event>[].obs;
  final searchQuery = ''.obs;
  final selectedStatus = 'الكل'.obs;
  final selectedFilterTab = 'كل المهام'.obs;
  final selectedFilterBudget = 'الدفعات'.obs;
  final selectedEvent = Rxn<Event>();
  final isLoading = false.obs;

  // Reactive state for Event Add/Edit
  final eventNameRx = ''.obs;
  final locationRx = ''.obs;
  final descriptionRx = ''.obs;
  final budgetRx = 0.0.obs;
  final dateRx = DateTime.now().obs;
  final durationRx = 1.obs;
  final durationUnitRx = 'DAY'.obs;
  final clientIdRx = 0.obs;

  final eventImage = Rxn<File>();
  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      eventImage.value = File(image.path);
    }
  }

  List<Event> get filteredEvents {
    return events.where((e) {
      final matchCoordinator = AuthService.userIsSupplier || e.coordinatorId == AuthService.user.value.id;
      final matchesSearch =
          e.eventName.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
          (e.location?.toLowerCase().contains(searchQuery.value.toLowerCase()) ?? false);
      
      if (selectedStatus.value == 'الكل') return !e.isDeleted && matchesSearch && matchCoordinator;
      if(selectedStatus.value == 'محذوفة') return matchesSearch && e.isDeleted && matchCoordinator;
      return !e.isDeleted && matchesSearch && e.status.tryText() == selectedStatus.value && matchCoordinator;
    }).toList();
  }

  @override
  void onInit() {
    super.onInit();

    fetchAll();
  }

  void clearFields() {
    eventNameRx.value = '';
    locationRx.value = '';
    descriptionRx.value = '';
    budgetRx.value = 0.0;
    dateRx.value = DateTime.now();
    durationRx.value = 1;
    durationUnitRx.value = 'DAY';
    clientIdRx.value = 0;
    eventImage.value = null;
  }

  void populateFields(Event event) {
    eventNameRx.value = event.eventName;
    locationRx.value = event.location ?? '';
    descriptionRx.value = event.description ?? '';
    budgetRx.value = event.budget;
    dateRx.value = DateTime.tryParse(event.eventDate) ?? DateTime.now();
    durationRx.value = event.eventDuration;
    
    final unit = event.eventDurationUnit.toUpperCase();
    durationUnitRx.value = ['DAY', 'WEEK', 'MONTH'].contains(unit) ? unit : 'DAY';
    
    clientIdRx.value = event.clientId;
  }

  Future<void> fetchAll({bool force = false}) async {
    if (!force && events.isNotEmpty) return;
    
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) => events.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (event) => selectedEvent.value = event,
    );
    isLoading.value = false;
  }

  Future<void> create() async {
    isLoading.value = true;
    final user = await currentUser;
    final Map<String, dynamic> dataMap = {
      'client_id': clientIdRx.value,
      'coordinator_id': user['user_id'],
      'event_name': eventNameRx.value,
      'description': descriptionRx.value,
      'event_date': dateRx.value.toIso8601String(),
      'event_duration': durationRx.value,
      'event_duration_unit': durationUnitRx.value,
      'location': locationRx.value,
      'budget': budgetRx.value
    };
    if (eventImage.value != null) {
      dataMap['img_url'] = await dio.MultipartFile.fromFile(
        eventImage.value!.path,
        filename: eventImage.value!.path.split('/').last,
      );
    }
    final data = dio.FormData.fromMap(dataMap);
    final result = await _repository.create(data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (newEvent) {
        events.add(newEvent);
        Get.back();
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم إضافة المناسبة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  
  Future<void> updateEvent(int id) async {
    isLoading.value = true;
    final event = events.firstWhereOrNull((e) => e.id == id);
    final Map<String, dynamic> dataMap = {
      'client_id': clientIdRx.value,
      'event_name': eventNameRx.value,
      'description': descriptionRx.value,
      'event_date': dateRx.value.toIso8601String(),
      'event_duration': durationRx.value,
      'event_duration_unit': durationUnitRx.value,
      'location': locationRx.value,
      'budget': budgetRx.value,
      'status': event?.status.tryText() ?? Status.PENDING.tryText(),
    };
    if (eventImage.value != null) {
      dataMap['img_url'] = await dio.MultipartFile.fromFile(
        eventImage.value!.path,
        filename: eventImage.value!.path.split('/').last,
      );
    }
    final data = dio.FormData.fromMap(dataMap);
    final result = await _repository.update(id, data);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = events.indexWhere((c) => c.id == id);
        if (index != -1) events[index] = updated;
        selectedEvent.value = updated;
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم تحديث المناسبة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateEventStatus(int id, Status status) async {
    isLoading.value = true;
    final result = await _repository.updateStatus(id,  status.tryValue());
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = events.indexWhere((c) => c.id == id);
        if (index != -1) events[index] = events[index].copyWith(status: status);
        if (selectedEvent.value?.id == id) {
          selectedEvent.value = events[index];
        }
        MyPUtils.showSnackbar('نجاح', 'تم تحديث حالة المناسبة');
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteEvent(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        events.removeWhere((c) => c.id == id);
        if (selectedEvent.value?.id == id) {
          selectedEvent.value = null;
        }
        MyPUtils.showSnackbar('نجاح', 'تم حذف المناسبة');
      },
    );
  }

  void rateTask(int id, int rating, String text) {}
}
