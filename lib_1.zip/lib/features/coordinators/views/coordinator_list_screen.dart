import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../data/models/coordinator.dart' show Coordinator;
import '../controller/coordinator_controller.dart' show CoordinatorController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/empty_state_widget.dart' show EmptyStateWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart';
import '../../../core/components/widgets/app_form_widgets.dart';
import '../../../core/utils/utils.dart';

class CoordinatorListScreen extends GetView<CoordinatorController> {
  CoordinatorListScreen({super.key});
final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Scaffold(
      appBar: CustomAppBar(
        // authController: authController, 
        title: 'قائمة المنسقين'),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          heroTag: 'add_coordinator',
          onPressed: () => Get.toNamed(AppRoutes.coordinatorAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
              child: TextFormField(
                onChanged: (value) => controller.searchQuery.value = value,
                style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                decoration: InputDecoration(
                  hintText: 'ابحث عن منسق بالاسم أو البريد...',
                  hintStyle: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
                  prefixIcon: Icon(Icons.search_rounded, color: AppColors.primary.getByBrightness(brightness)),
                  filled: true,
                  fillColor: AppColors.surface.getByBrightness(brightness),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(16),
                    borderSide: BorderSide.none,
                  ),
                  contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
                ),
              ),
            ),
            Expanded(
              child: Obx(() {
                if (controller.isLoading.value) {
                  return const LoadingWidget();
                }
                if (controller.filteredCoordinators.isEmpty) {
                  return const EmptyStateWidget(message: 'لا يوجد نتائج للبحث', icon: Icons.person_off_outlined);
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(16),
                  itemCount: controller.filteredCoordinators.length,
                  itemBuilder: (context, index) {
                    final coordinator = controller.filteredCoordinators[index];
                    return _buildCoordinatorCard(coordinator, context);
                  },
                );
              }),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildCoordinatorCard(Coordinator coordinator, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: AppFormWidgets.cardDecoration(context),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () =>
              Get.toNamed(AppRoutes.coordinatorDetail, arguments: coordinator),
          borderRadius: BorderRadius.circular(20),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    gradient: AppColors.primaryGradient.getByBrightness(brightness),
                    shape: BoxShape.circle,
                  ),
                  child: Center(
                    child: coordinator.imgUrl != null
                        ? ClipOval(
                            child: Image.network(
                              coordinator.imgUrl!,
                              width: 50,
                              height: 50,
                              fit: BoxFit.cover,
                              errorBuilder: (context, error, stackTrace) => Text(
                                coordinator.name.substring(0, 1).toUpperCase(),
                                style: TextStyle(
                                  color: AppColors.w_b.getByBrightness(brightness),
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                            ),
                          )
                        : Text(
                            coordinator.name.isNotEmpty
                                ? coordinator.name.substring(0, 1).toUpperCase()
                                : '?',
                            style: TextStyle(
                              color: AppColors.w_b.getByBrightness(brightness),
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                  ),
                ),
                const SizedBox(width: 16),

                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(
                            coordinator.name,
                            style: TextStyle(
                              fontSize: 15,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textBody.getByBrightness(brightness),
                            ),
                          ),
                          const SizedBox(width: 8),
                          
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: coordinator.isActive ? Colors.green.withValues(alpha: 0.1) : Colors.red.withValues(alpha: 0.1),
                              borderRadius: BorderRadius.circular(4),
                            ),
                            child: Text(
                              coordinator.isActive ? 'نشط' : 'معطل',
                              style: TextStyle(
                                color: coordinator.isActive ? Colors.green : Colors.red,
                                fontSize: 10,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        coordinator.email,
                        style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                        ),
                      ),
                    ],
                  ),
                ),
                PopupMenuButton<String>(
                  icon: Icon(
                    Icons.more_vert_rounded,
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                  ),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                  color: AppColors.surface.getByBrightness(brightness),
                  elevation: 4,
                  onSelected: (value) {
                    if (value == 'status') {
                      controller.toggleStatus(coordinator.id, !coordinator.isActive);
                    } else if (value == 'edit') {
                      Get.toNamed(AppRoutes.coordinatorAdd, arguments: coordinator);
                    } else if (value == 'delete') {
                      _delete(coordinator.id, context);
                    }
                  },
                  itemBuilder: (context) => [
                    PopupMenuItem(
                      value: 'status',
                      child: Row(
                        children: [
                          Icon(
                            coordinator.isActive ? Icons.block_rounded : Icons.check_circle_outline_rounded,
                            color: coordinator.isActive ? AppColors.accent.getByBrightness(brightness) : Colors.green,
                            size: 18,
                          ),
                          const SizedBox(width: 8),
                          Text(coordinator.isActive ? 'تعطيل الحساب' : 'تفعيل الحساب'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_rounded, color: Colors.orange, size: 18),
                          SizedBox(width: 8),
                          Text('تعديل'),
                        ],
                      ),
                    ),
                    PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_rounded, color: AppColors.accent.getByBrightness(brightness), size: 18),
                          const SizedBox(width: 8),
                          Text('حذف'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }



  void _delete(int id, BuildContext context) {
    MyPUtils.showConfirmDialog(
      context: context,
      title: 'حذف المنسق',
      message: 'هل أنت متأكد من حذف هذا المنسق نهائياً؟',
      confirmLabel: 'حذف',
      isDanger: true,
      onConfirm: () {
        controller.delete(id);
      },
    );
  }
}
