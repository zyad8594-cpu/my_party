import 'dart:io' show File;
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide Response;
import 'package:dio/dio.dart' as dio;
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;
import '../../../core/utils/utils.dart' show MyPUtils;
import '../data/models/coordinator.dart' show Coordinator;
import '../data/repository/coordinator_repository.dart' show CoordinatorRepository;

class CoordinatorController extends GetxController 
{
  final CoordinatorRepository _repository = Get.find<CoordinatorRepository>();

  // Reactive state for Coordinator Add/Edit
  final fullNameRx = ''.obs;
  final emailRx = ''.obs;
  final phoneNumberRx = ''.obs;
  final passwordRx = ''.obs;
  final isPasswordVisible = false.obs;
  final isActiveRx = true.obs;
  final showPasswordEdit = false.obs;

  final coordinators = <Coordinator>[].obs;
  final selectedCoordinator = Rxn<Coordinator>();
  final isLoading = false.obs;
  final profileImage = Rxn<File>();
  final searchQuery = ''.obs;

  List<Coordinator> get filteredCoordinators => coordinators.where((c) {
    final query = searchQuery.value.toLowerCase();
    return c.name.toLowerCase().contains(query) || 
           c.email.toLowerCase().contains(query) ||
           (c.phoneNumber?.contains(query) ?? false);
  }).toList();

  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      profileImage.value = File(image.path);
    }
  }

  @override
  void onInit() 
  {
    super.onInit();
    fetchAll();
  }

  void clearFields() 
  {
    fullNameRx.value = '';
    emailRx.value = '';
    phoneNumberRx.value = '';
    passwordRx.value = '';
    profileImage.value = null;
    isActiveRx.value = true;
    showPasswordEdit.value = false;
  }

  void populateFields(Coordinator coordinator) 
  {
    fullNameRx.value = coordinator.name;
    emailRx.value = coordinator.email;
    phoneNumberRx.value = coordinator.phoneNumber ?? '';
    isActiveRx.value = coordinator.isActive;
    showPasswordEdit.value = false;
  }

  Future<void> fetchAll() async 
  {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (data) => coordinators.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (coordinator) => selectedCoordinator.value = coordinator,
    );
    isLoading.value = false;
  }

  Future<void> create() async {
    isLoading.value = true;
    final data = {
      'full_name': fullNameRx.value,
      'email': emailRx.value,
      'phone_number': phoneNumberRx.value,
      'is_active': isActiveRx.value ? 1 : 0,
      if (passwordRx.value.isNotEmpty) 'password': passwordRx.value,
    };

    final dio.FormData formData = dio.FormData.fromMap(data);
    if (profileImage.value != null) {
      formData.files.add(MapEntry(
        'img_url',
        await dio.MultipartFile.fromFile(
          profileImage.value!.path,
          filename: profileImage.value!.path.split('/').last,
        ),
      ));
    }

    final result = await _repository.create(formData as dynamic);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (newCoordinator) {
        coordinators.add(newCoordinator);
        Get.back();
        MyPUtils.showSnackbar('نجاح', 'تم إضافة المنسق');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> edit(int id) async {
    isLoading.value = true;
    try {
      final data = {
        'full_name': fullNameRx.value,
        'email': emailRx.value,
        'phone_number': phoneNumberRx.value,
        'is_active': isActiveRx.value,
        if (showPasswordEdit.value && passwordRx.value.isNotEmpty) 'password': passwordRx.value,
      };
      
      final dio.FormData formData = dio.FormData.fromMap(data);
      if (profileImage.value != null) {
        formData.files.add(MapEntry(
          'img_url',
          await dio.MultipartFile.fromFile(
            profileImage.value!.path,
            filename: profileImage.value!.path.split('/').last,
          ),
        ));
      }
      debugPrint('length: ${formData.length}');
      debugPrint('data: $data');

      final result = await _repository.update(id, formData);
      result.fold(
        (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
        (updated) {
          final index = coordinators.indexWhere((c) => c.id == id);
          if (index != -1) coordinators[index] = updated;
          selectedCoordinator.value = updated;
          Get.back();
          MyPUtils.showSnackbar('نجاح', 'تم تحديث المنسق');
          clearFields();
        },
      );
    } catch (e) {
      MyPUtils.showSnackbar('خطأ غير متوقع', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> delete(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        coordinators.removeWhere((c) => c.id == id);
        if (selectedCoordinator.value?.id == id) {
          selectedCoordinator.value = null;
        }
        MyPUtils.showSnackbar('نجاح', 'تم حذف المنسق');
      },
    );
  }

  Future<void> toggleStatus(int id, bool isActive) async {
    isLoading.value = true;
    final result = await _repository.toggleStatus(id, isActive);
    result.fold(
      (error) => MyPUtils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = coordinators.indexWhere((c) => c.id == id);
        if (index != -1) {
          coordinators[index] = coordinators[index].copyWith(isActive: isActive);
        }
        if (selectedCoordinator.value?.id == id) {
          selectedCoordinator.value = selectedCoordinator.value!.copyWith(isActive: isActive);
        }
        MyPUtils.showSnackbar('نجاح', isActive ? 'تم تفعيل الحساب' : 'تم تعطيل الحساب');
      },
    );
    isLoading.value = false;
  }
}
