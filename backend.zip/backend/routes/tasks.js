const express = require('express');
const router = express.Router();
const tasksController = require('../controllers/tasksController');
const { authenticateToken, authorizeRole } = require('../middlewares/auth');

router.use(authenticateToken);

router.get('/', tasksController.getAllTasks);
router.get('/:id', tasksController.getTaskById);
router.get('/event/:eventId', tasksController.getTasksByEventId);
router.post('/', tasksController.createTask);
router.put('/:id', tasksController.updateTask);
router.delete('/:id', tasksController.deleteTask);
router.put('/:id/status', tasksController.updateTaskStatus);
router.post('/:id/rating', authorizeRole(['coordinator', 'admin']), tasksController.addTaskRating);

module.exports = router;
