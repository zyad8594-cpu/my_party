const express = require('express');
const router = express.Router();
const suppliersController = require('../controllers/suppliersController');
const { authenticateToken, authorizeRole } = require('../middlewares/auth');

router.use(authenticateToken);

router.get('/', suppliersController.getAllSuppliers);
router.get('/:id', suppliersController.getSupplierById);
router.post('/', authorizeRole(['admin', 'coordinator']), suppliersController.createSupplier);
router.put('/:id', authorizeRole(['admin', 'coordinator']), suppliersController.updateSupplier);
router.delete('/:id', authorizeRole(['admin', 'coordinator']), suppliersController.deleteSupplier);

router.get('/:id/services/:serviceId', suppliersController.getByIdAndServiceId);
router.get('/services/:serviceId', suppliersController.getAllByServiceId);
// router.delete('/:id/services/:serviceId', suppliersController.deleteService);
router.delete('/:id/services', suppliersController.clearAllServices);
router.get('/:id/notifications', suppliersController.getNotifications);
router.get('/:id/notifications/:notificationId', suppliersController.getNotification);
router.delete('/:id/notifications/:notificationId', suppliersController.deleteNotification);
router.delete('/:id/notifications', suppliersController.clearAllNotifications);
router.post('/assign-service', authorizeRole(['admin', 'coordinator']), suppliersController.assignServiceToSupplier);
router.post('/remove-service', authorizeRole(['admin', 'coordinator']), suppliersController.removeServiceFromSupplier);

module.exports = router;
