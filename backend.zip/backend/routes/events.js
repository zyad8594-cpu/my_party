const express = require('express');
const router = express.Router();
const eventsController = require('../controllers/eventsController');
const { authenticateToken, authorizeRole } = require('../middlewares/auth');

router.use(authenticateToken); // Protect all event routes

router.get('/', eventsController.getAllEvents);
router.get('/:id', eventsController.getEventById);
router.post('/', authorizeRole(['admin', 'coordinator']), eventsController.createEvent);
router.put('/:id', authorizeRole(['admin', 'coordinator']), eventsController.updateEvent);
router.delete('/:id', authorizeRole(['admin', 'coordinator']), eventsController.deleteEvent);
router.put('/:id/status', authorizeRole(['admin', 'coordinator']), eventsController.updateEventStatus);
router.post('/:id/cancel', authorizeRole(['admin', 'coordinator']), eventsController.cancelEvent);

module.exports = router;
