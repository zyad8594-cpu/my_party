const express = require('express');
const router = express.Router();
const coordinatorsController = require('../controllers/coordinatorsController');
const { authenticateToken, authorizeRole } = require('../middlewares/auth');

router.use(authenticateToken);

router.get('/', coordinatorsController.getAllCoordinators);
router.get('/:id', coordinatorsController.getCoordinatorById);
router.post('/', authorizeRole(['admin']), coordinatorsController.createCoordinator);
router.put('/:id', authorizeRole(['admin', 'coordinator']), coordinatorsController.updateCoordinator);
router.delete('/:id', authorizeRole(['admin']), coordinatorsController.deleteCoordinator);

module.exports = router;
