// const express = require('express');
// const router = express.Router();
// const clientController = require('../controllers/userController');

// router.get('/', clientController.getAllUsers);
// router.get('/:id', clientController.getUserById);
// router.post('/', clientController.create);
// router.put('/:id', clientController.update);
// router.delete('/:id', clientController.delete);
// router.put('/:id', clientController.set_active);

// module.exports = router;