const express = require('express');
const router = express.Router();
const servicesController = require('../controllers/servicesController');
const { authenticateToken, authorizeRole } = require('../middlewares/auth');

router.use(authenticateToken);

router.get('/', servicesController.getAllServices);
router.get('/:id', servicesController.getServiceById);
router.post('/', authorizeRole(['admin']), servicesController.createService);
router.put('/:id', authorizeRole(['admin']), servicesController.updateService);
router.delete('/:id', authorizeRole(['admin']), servicesController.deleteService);

module.exports = router;
