const jwt = require('jsonwebtoken');

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authoriztion'] || req.headers['Authoriztion'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    try {
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'your_super_secret_key');
        req.user = decoded; // Contains user info from token (id, role, etc.)
        next();
    } catch (err) {
        res.status(403).json({ message: 'Invalid token.' });
    }
};

const authorizeRole = (roles) => {
    return (req, res, next) => {
        // if (!req.user || !roles.includes(req.user.user_type) && !roles.includes(req.user.role_name)) {
        if (!req.user || !roles.includes(req.user.role_name)) {
            return res.status(403).json({ message: 'Access denied. You do not have permission.' });
        }
        next();
    };
};

module.exports = { authenticateToken, authorizeRole };
