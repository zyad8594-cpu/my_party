const pool = require('../config/db');

exports.getAllServices = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Services');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Services' });
    }
};

exports.getServiceById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Services WHERE service_id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: 'Service not found' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Service' });
    }
};

exports.createService = async (req, res) => {
    const { service_name, description } = req.body;
    try {
        const [result] = await pool.execute(
            'CALL sp_create_service(?, ?)',
            [service_name, description]
        );
        res.status(201).json({ message: 'Service created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating service' });
    }
};

exports.updateService = async (req, res) => {
    const { service_name, description } = req.body;
    try {
        const [result] = await pool.execute(
            'CALL sp_update_service(?, ?, ?)',
            [req.params.id, service_name, description]
        );
        res.json({ message: 'Service updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating service' });
    }
};

exports.deleteService = async (req, res) => {
    try {
        await pool.execute('CALL sp_delete_service(?)', [req.params.id]);
        res.json({ message: 'Service deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting service' });
    }
};
