const pool = require('../config/db');

exports.getAllIncomes = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Incomes');
        console.log(rows);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Income' });
    }
};

exports.getIncomeById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Incomes WHERE income_id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: 'Income not found' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Income' });
    }
};

exports.createIncome = async (req, res) => {
    const { event_id, amount, description, payment_date, payment_method, url_image } = req.body;
    console.log({ event_id, amount, description, payment_date, payment_method, url_image: url_image || '' });
    try {
        const [result] = await pool.execute(
            'CALL sp_create_income(?, ?, ?, ?, ?, ?)',
            [event_id, amount, description, payment_date, payment_method, url_image || 'null']
        );

        res.status(201).json({ message: 'Income created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating income', error: err.message });
    }
};

exports.updateIncome = async (req, res) => {
    try {
        const { amount, description, payment_date, payment_method, url_image } = req.body;
        const [result] = await pool.execute(
            'CALL sp_update_income(?, ?, ?, ?, ?, ?)', 
            [req.params.id, amount, description, payment_date, payment_method, url_image]
        );
        res.json({ message: 'Income updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating income' });
    }
};

exports.deleteIncome = async (req, res) => {
    try {
        await pool.execute('CALL sp_delete_income(?)', [req.params.id]);
        res.json({ message: 'Income deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting income' });
    }
};