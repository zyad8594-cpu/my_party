const pool = require('../config/db');

exports.getAllSuppliers = async (req, res) => {
    try {
        const [suppliers] = await pool.execute(
            'SELECT * FROM vw_get_all_suppliers WHERE is_deleted = 0');

        for (const supplier of suppliers) {
            const [services] = await pool.execute(
                'SELECT sv.* FROM Supplier_Services ss JOIN Services sv ON ss.service_id = sv.service_id WHERE ss.supplier_id = ?',
                [supplier.user_id]
            );
            supplier.services = services;
        }
        res.json(suppliers);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Suppliers' });
    }
};

exports.getSupplierById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_get_all_suppliers WHERE user_id = ? AND is_deleted = 0', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: 'Supplier not found' });

        // Also fetch services for this supplier
        const [services] = await pool.execute(
            'SELECT sv.service_id, sv.service_name FROM Supplier_Services ss JOIN Services sv ON ss.service_id = sv.service_id WHERE ss.supplier_id = ?',
            [req.params.id]
        );

        const supplier = rows[0];
        supplier.services = services;

        res.json(supplier);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving supplier' });
    }
};


exports.createSupplier = async (req, res) => {

    const role_name = 'supplier';
    const { full_name, phone_number, img_url, email, password } = req.body;
    const details = JSON.stringify({
        address: req.body.address,
        notes: req.body.notes
    });

    try {
        const [result] = await pool.execute('CALL sp_create_user(?, ?, ?, ?, ?, ?, ?)', [role_name, full_name, phone_number, img_url, email, password, details]);
        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
        res.status(201).json({ message: 'User registered successfully', user_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

exports.updateSupplier = async (req, res) => {
    const { full_name, phone_number, img_url, email } = req.body;
    const details = JSON.stringify({
        address: req.body.address,
        notes: req.body.notes
    });

    try {
        const [result] = await pool.execute('CALL sp_update_user(?, ?, ?, ?, ?, ?)', [req.params.id, full_name, phone_number, img_url, email, details]);

        const user = result[0] && result[0][0];
        res.status(201).json({ message: 'supplier updated successfully', user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'supplier update failed', error: err.message });
    }
};

exports.deleteSupplier = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
        const deleted_user = result[0] && result[0][0];
        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
};


exports.assignServiceToSupplier = async (req, res) => {
    const { supplier_id, service_id } = req.body;
    try {
        await pool.execute('CALL sp_assign_service_to_supplier(?, ?)', [supplier_id, service_id]);
        res.status(201).json({ message: 'Service assigned successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error assigning service' });
    }
};

exports.removeServiceFromSupplier = async (req, res) => {
    const { supplier_id, service_id } = req.body;
    try {
        await pool.execute('CALL sp_remove_service_from_supplier(?, ?)', [supplier_id, service_id]);
        res.json({ message: 'Service removed successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error removing service' });
    }
};

exports.getAllByServiceId = async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT sp.* FROM Supplier_Services ss JOIN vw_get_all_suppliers sp ON ss.supplier_id = sp.user_id WHERE ss.service_id = ?',
            [req.params.serviceId]
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving supplier services' });
    }
};

exports.getByIdAndServiceId = async (req, res) => {
    try {
        const [rows] = await pool.execute(
            'SELECT sp.* FROM Supplier_Services ss JOIN vw_get_all_suppliers sp ON ss.supplier_id = sp.user_id WHERE ss.supplier_id = ? AND ss.service_id = ?',
            [req.params.id, req.params.serviceId]
        );
        if (rows.length === 0) return res.status(404).json({ message: 'Service not found for this supplier' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving supplier service' });
    }
};


exports.clearAllServices = async (req, res) => {
    try {
        await pool.execute('DELETE FROM Supplier_Services WHERE supplier_id = ?', [req.params.id]);
        res.json({ message: 'All services cleared for this supplier' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error clearing services' });
    }
};





exports. getNotifications = async (req, res) => 
{
    try {
        const [rows] = await pool.execute('SELECT * FROM Notifications WHERE supplier_id = ? AND deleted_at IS NULL', [req.params.id]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving notifications' });
    }
}

exports. getNotification = async (req, res) => 
{
    try {
        const [rows] = await pool.execute('SELECT * FROM Notifications WHERE supplier_id = ? AND notification_id = ? AND deleted_at IS NULL', [req.params.id, req.params.notificationId]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving notification' });
    }
}


exports.deleteNotification = async (req, res) => 
{
    try {
        const [rows] = await pool.execute('UPDATE Notifications SET deleted_at = NOW() WHERE supplier_id = ? AND notification_id = ?', [req.params.id, req.params.notificationId]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting notification' });
    }
}

exports.clearAllNotifications = async (req, res) => 
{
    try {
        const [rows] = await pool.execute('UPDATE Notifications SET deleted_at = NOW() WHERE supplier_id = ?', [req.params.id]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error clearing notifications' });
    }
}
