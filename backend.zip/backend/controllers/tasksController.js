const pool = require('../config/db');

exports.getAllTasks = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_tasks_full');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Tasks' });
    }
};

exports.getTaskById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_tasks_full WHERE task_id = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: 'Task not found' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Task' });
    }
};

exports.getTasksByEventId = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_tasks_full WHERE event_id = ?', [req.params.eventId]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving tasks' });
    }
};

exports.createTask = async (req, res) => {
    const { event_id, coordinator_id, type_task, status, date_start, date_due, user_assign_id, description, cost, notes, url_image } = req.body;
    try {
        
        const [result] = await pool.execute(
            'CALL sp_create_task(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [event_id, coordinator_id, type_task, status, date_start, date_due, user_assign_id, description, cost, notes, url_image]
        );
        res.status(201).json({ message: 'Task created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        console.log(user_assign_id);
        res.status(500).json({ message: 'Error creating task', error: err.message });
    }
};

exports.updateTask = async (req, res) => {
    const { type_task, status, date_start, date_due, description, cost, notes, url_image } = req.body;
    try {
        const [result] = await pool.execute(
            'CALL sp_update_task(?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [req.params.id, type_task, status, date_start, date_due, description, cost, notes, url_image]
        );
        res.json({ message: 'Task updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        
        res.status(500).json({ message: 'Error updating task', error: err.message });
    }
};

exports.deleteTask = async (req, res) => {
    try {
        await pool.execute('CALL sp_delete_task(?)', [req.params.id]);
        res.json({ message: 'Task deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting task' });
    }
};

exports.updateTaskStatus = async (req, res) => {
    const { status, notes } = req.body;
    try {
        await pool.execute('CALL sp_update_task_status(?, ?, ?)', [req.params.id, status, notes || null]);
        res.json({ message: 'Task status updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating task status' });
    }
};

exports.addTaskRating = async (req, res) => {
    const { value_rating, comment } = req.body;
    try {
        const coordinator_id = req.user.profile_id; // Assume user is a coordinator
        await pool.execute('CALL sp_add_task_rating(?, ?, ?, ?)', [req.params.id, coordinator_id, value_rating, comment || null]);
        res.status(201).json({ message: 'Rating added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error adding rating', error: err.message });
    }
}
