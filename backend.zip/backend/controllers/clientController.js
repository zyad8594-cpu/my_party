const pool = require('../config/db');

async function getClientEvents(client_id) {
    const [events] = await pool.execute('SELECT * FROM Events WHERE client_id = ?', [client_id]);
    for (const event of events) {
        event.tasks = await getClientEventsTasks(event.event_id);
    }
    return events;
}
async function getClientEventsTasks(event_id){
    const [tasks] = await pool.execute('SELECT * FROM Tasks WHERE event_id = ?', [event_id]);
    for (const task of tasks) {
        task.assigne = await pool.execute('SELECT * FROM Task_Assigns WHERE task_id = ? LIMIT 1', [task.task_id]);
    }
    return tasks;
}


exports.getAllClients = async (req, res) => {
    try {
        const [clients] = await pool.execute('SELECT * FROM vw_get_all_clients');
        
        for (const client of clients) {
            client.events = await getClientEvents(client.user_id);
        }
        res.json(clients);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Clients' });
    }
};

exports.getClientById = async (req, res) => {
    try {
        const [client] = await pool.execute('SELECT * FROM vw_get_all_clients WHERE user_id = ? LIMIT 1', [req.params.id]);
        if (client.length === 0) return res.status(404).json({ message: 'Client not found' });
        client[0].events = await getClientEvents(client[0].user_id);
        res.json(client[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Client' });
    }
};

exports.createClient = async (req, res) => {

    const role_name = 'client';
    const { full_name, phone_number, img_url, email } = req.body;
    const details = JSON.stringify({ address: req.body.address });

    try {
        const [result] = await pool.execute('CALL sp_create_user(?, ?, ?, ?, ?, ?, ?)', [role_name, full_name, phone_number, img_url, email, null, details]);
        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        res.status(201).json({ message: 'User registered successfully', user: new_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

exports.updateClient = async (req, res) => {
    const { full_name, phone_number, img_url, email } = req.body;
    const details = JSON.stringify({ address: req.body.address });

    try {
        const [result] = await pool.execute('CALL sp_update_user(?, ?, ?, ?, ?, ?)', [req.params.id, full_name, phone_number, img_url, email, details]);

        const client = result[0] && result[0][0];
        res.status(201).json({ message: 'client updated successfully', user: client });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'client update failed', error: err.message });
    }
};

exports.deleteClient = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
        const deleted_user = result[0] && result[0][0];
        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
};

exports.restoreClient = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_restore_user(?)', [req.params.id]);
        const restored_user = result[0] && result[0][0];
        if (!restored_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User restored successfully', restored_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Restore failed', error: err.message });
    }
};