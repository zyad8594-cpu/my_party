const pool = require('../config/db');
/**
 * eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyLCJyb2xlX25hbWUiOiJjb29yZGluYXRvciIsImlzX2FjdGl2ZSI6MSwiaXNfZGVsZXRlZCI6MCwiZW1haWwiOiJhaG1lZEBteXBhcnR5LmNvbSIsImltZ191cmwiOiJodHRwczovL2kucHJhdmF0YXIuY2MvMTUwP3U9Y29vcmRpbmF0b3IiLCJwYXNzd29yZCI6IjEyMzQ1NiIsImZ1bGxfbmFtZSI6Itin2K3ZhdivIiwicGhvbmVfbnVtYmVyIjoiNzczOTM2NDgxIiwiY3JlYXRlZF9hdCI6IjIwMjYtMDMtMjBUMDA6MjM6MDkuMDAwWiIsInVwZGF0ZWRfYXQiOm51bGwsImFkZHJlc3MiOiIiLCJpYXQiOjE3NzQxNzU2OTEsImV4cCI6MTc3NDI2MjA5MX0.l8er67EeGwvtU9rH1jFoOf8WVrguxGzboIiEeHa4M_4
 */

async function getCoordinatorEvents(coordinator_id) {
    const [events] = await pool.execute('SELECT * FROM Events WHERE coordinator_id = ?', [coordinator_id]);
    for (const event of events) {
        event.tasks = await getCoordinatorEventsTasks(event.event_id);
    }
    return events;
}
async function getCoordinatorEventsTasks(event_id){
    const [tasks] = await pool.execute('SELECT * FROM Tasks WHERE event_id = ?', [event_id]);
    for (const task of tasks) {
        task.assigne = await pool.execute('SELECT * FROM Task_Assigns WHERE task_id = ? LIMIT 1', [task.task_id]);
    }
    return tasks;
}


exports.getAllCoordinators = async (req, res) => {
    try {
        const [coordinators] = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE is_deleted = 0');
        for (const coordinator of coordinators) {
            coordinator.events = await getCoordinatorEvents(coordinator.user_id);
        }
        res.json(coordinators);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Coordinators' });
    }
};

exports.getCoordinatorById = async (req, res) => {
    try {
        const [coordinator] = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE user_id = ? AND is_deleted = 0', [req.params.id]);
        if (coordinator.length === 0) return res.status(404).json({ message: 'Coordinator not found' });
        coordinator[0].events = await getCoordinatorEvents(coordinator[0].user_id);
        res.json(coordinator[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Coordinator' });
    }
};

exports.createCoordinator = async (req, res) => {

    const role_name = 'coordinator';
    const { full_name, phone_number, img_url, email, password } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_create_user(?, ?, ?, ?, ?, ?, ?)', [role_name, full_name, phone_number, img_url, email, password, JSON.stringify({})]);
        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
        res.status(201).json({ message: 'User registered successfully', user_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

exports.updateCoordinator = async (req, res) => {
    const { full_name, phone_number, img_url, email } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_update_user(?, ?, ?, ?, ?, ?)', [req.params.id, full_name, phone_number, img_url, email, JSON.stringify({})]);

        const user = result[0] && result[0][0];
        res.status(201).json({ message: 'coordinator updated successfully', user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'coordinator update failed', error: err.message });
    }
};



exports.deleteCoordinator = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
        const deleted_user = result[0] && result[0][0];
        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
};