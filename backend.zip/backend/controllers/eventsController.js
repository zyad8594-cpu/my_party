const pool = require('../config/db');

async function getEventTasks(event_id){
    const [tasks] = await pool.execute('SELECT * FROM Tasks WHERE event_id = ?', [event_id]);
    for (const task of tasks) {
        task.assigne = await pool.execute('SELECT * FROM Task_Assigns WHERE task_id = ? LIMIT 1', [task.task_id]);
    }
    return tasks;
}

exports.getAllEvents = async (req, res) => {
    try {
        const [events] = await pool.execute('SELECT * FROM Events');
        for (const event of events) {
            event.tasks = await getEventTasks(event.event_id);
            event.client = await pool.execute('SELECT * FROM vw_get_all_clients WHERE user_id = ? LIMIT 1', [event.client_id]);
            event.coordinator = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE user_id = ? LIMIT 1', [event.coordinator_id]);
            event.is_deleted = event.deleted_at !== null;
        }
        res.json(events);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Events' });
    }
};

exports.getEventById = async (req, res) => {
    try {
        const [event] = await pool.execute('SELECT * FROM vw_events_detailed WHERE event_id = ? LIMIT 1', [req.params.id]);
        if (event.length === 0) return res.status(404).json({ message: 'Event not found' });
        event[0].tasks = await getEventTasks(event[0].event_id);
        event[0].client = await pool.execute('SELECT * FROM vw_get_all_clients WHERE user_id = ? LIMIT 1', [event[0].client_id]);
        event[0].coordinator = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE user_id = ? LIMIT 1', [event[0].coordinator_id]);
        event[0].is_deleted = event[0].deleted_at !== null;
        
        res.json(event[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving event' });
    }
};

exports.createEvent = async (req, res) => {
    const { client_id, coordinator_id, event_name, description, event_date, location, budget, status, tasks } = req.body;

    try {
        const tasksJson = tasks ? JSON.stringify(tasks) : '[]';
        const [result] = await pool.execute(
            'CALL sp_create_event_full(?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [client_id, coordinator_id, event_name, description, event_date, location, budget || 0, status || 'PLANNING', tasksJson]
        );

        res.status(201).json({ message: 'Event created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating event(' + status + ')', error: err.message });
    }
};

exports.updateEvent = async (req, res) => {
    try {
        const { event_name, description, event_date, location, budget, status } = req.body;
        const [result] = await pool.execute(
            'CALL sp_update_event(?, ?, ?, ?, ?, ?, ?)',
            [req.params.id, event_name, description, event_date, location, budget, status]
        );
        res.json({ message: 'Event updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating event' });
    }
};

exports.deleteEvent = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_delete_event(?)', [req.params.id]);
        res.json({ message: 'Event deleted (soft delete) successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting event' });
    }
};

exports.updateEventStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const [result] = await pool.execute('UPDATE Events SET status = ? WHERE event_id = ?', [status, req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: 'Event not found' });
        res.json({ message: 'Event status updated' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating event status' });
    }
};

exports.cancelEvent = async (req, res) => {
    try {
        const { reason } = req.body;
        await pool.execute('CALL sp_cancel_event(?, ?)', [req.params.id, reason || 'Cancelled by coordinator']);
        res.json({ message: 'Event cancelled successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error cancelling event' });
    }
}
