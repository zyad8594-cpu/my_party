const pool = require('../config/db');

exports.getAllUsers = async (req, res) => {
    const [users] = await pool.execute("SELECT * FROM vw_get_all_usersWithPermissionsAndDetailes");
    res.json(users);
};

exports.getUserById = async (req, res) => {
    const [user] = await pool.execute("SELECT * FROM vw_get_all_usersWithPermissionsAndDetailes WHERE user_id = ?", [req.params.id]);
    res.json(user);
};

exports.create = async (req, res) => {
    const { role_name, is_active, details } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_create_user(?, ?, ?)', [role_name, is_active, details]);
        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
        res.status(201).json({ message: 'User registered successfully', user_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

exports.update = async (req, res) => {
    const user_id = req.params.id;
    const { details } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_update_user(?, ?)', [user_id, details]);
        const updated_user = result[0] && result[0][0];
        if (!updated_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User details updated successfully', updated_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Update failed', error: err.message });
    }
};

exports.delete = async (req, res) => {

    try {
        const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
        const deleted_user = result[0] && result[0][0];
        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
};

exports.set_active = async (req, res) => {
    const user_id = req.params.id;
    const { is_active } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_set_user_active(?, ?)', [user_id, is_active]);
        const updated_user = result[0] && result[0][0];
        if (!updated_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User active status updated successfully', updated_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Update failed', error: err.message });
    }
};
