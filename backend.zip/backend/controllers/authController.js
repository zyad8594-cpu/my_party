const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

exports.login = async (req, res) => {
    const { email, password } = req.body;

    try {
        // Find user by email 
        
        let [users] = await pool.execute('CALL sp_login_user(?)', [email]);
        // throw { message: { ...user } };
        if (!users || !users[0] || !users[0][0] || !users[0][0].user_id) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const user = users[0][0];

        // Check password
        // const isMatch = await bcrypt.compare(password, user.password);
        const isMatch = password == user.password;
        if (!isMatch) {

            return res.status(400).json({ message: 'Invalid email or password', isMatch: isMatch, password: password, user_password: user.password });
        }


        // user.full_name = user.full_name || '';
        // user.phone_number = user.phone_number || '';
        // user.address = user.address || '';
        // user.img_url = user.img_url || '';
        // Generate JWT token

        const token = jwt.sign(user, process.env.JWT_SECRET || 'your_super_secret_key', { expiresIn: '1d' });

        res.json({ token: token, user: user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Server error', error: err.message });
    }
};

exports.register = async (req, res) => {
    const { role_name, full_name, phone_number, img_url, email, password, details } = req.body;

    try {
        if (role_name == 'client' || role_name == 'admin') {
            res.status(500).json({ message: 'Registration failed', error: 'err.message' });
        }
        else {
            const [result] = await pool.execute('CALL sp_create_user(?, ?, ?, ?, ?, ?, ?)', [role_name, full_name, phone_number, img_url, email, password, JSON.stringify(details)]);
            const new_user = result[0] && result[0][0];
            if (!new_user) return res.status(400).json({ message: 'Invalid role' });
            const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
            res.status(201).json({ message: 'User registered successfully', user_id });
        }
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};
