const pool = require('../config/db');

exports.getNotifications = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Notifications');
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Notifications' });
    }
};

exports.deleteNotification = async (req, res) => {
    const { id } = req.params;
    try {
        await pool.execute('DELETE FROM Notifications WHERE id = ?', [id]);
        res.json({ message: 'Notification deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting notification' });
    }
};

exports.clearAllNotifications = async (req, res) => {
    try {
        await pool.execute('DELETE FROM Notifications');
        res.json({ message: 'All Notifications cleared successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error clearing Notifications' });
    }
};