const express = require('express');
const cors = require('cors');
// require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());

// Import Routes
const authRoutes = require('./routes/auth');
const eventsRoutes = require('./routes/events');
const tasksRoutes = require('./routes/tasks');
const suppliersRoutes = require('./routes/suppliers');
const servicesRoutes = require('./routes/services');
const coordinatorsRoutes = require('./routes/coordinators');
const notificationsRoutes = require('./routes/notifications');
const clientsRoutes = require('./routes/clients');
const incomesRoutes = require('./routes/incomes');
// const usersRoutes = require('./routes/users');

// Use Routes
app.use('/api/auth', authRoutes);
app.use('/api/events', eventsRoutes);
app.use('/api/tasks', tasksRoutes);
app.use('/api/suppliers', suppliersRoutes);
app.use('/api/services', servicesRoutes);
app.use('/api/coordinators', coordinatorsRoutes);
app.use('/api/notifications', notificationsRoutes);
app.use('/api/clients', clientsRoutes);
app.use('/api/incomes', incomesRoutes);
// app.use('/api/users', usersRoutes);

// Base route for testing
app.get('/', (req, res) => {
    res.json({ message: 'Welcome to My Party Pro API' });
});

// Error handling middlewware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!', error: err.message });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
