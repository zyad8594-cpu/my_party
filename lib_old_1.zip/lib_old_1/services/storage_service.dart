import 'dart:convert';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:get/get.dart';
import 'package:my_party/models/coordinator.dart';

class StorageService extends GetxService {
  late FlutterSecureStorage storage;

  Future<StorageService> init() async {
    storage = const FlutterSecureStorage();
    return this;
  }

  Future<void> setToken(String token) async {
    await storage.write(key: 'auth_token', value: token);
  }

  Future<String?> getToken() async {
    return await storage.read(key: 'auth_token');
  }

  Future<void> setUser(Coordinator user) async {
    await storage.write(key: 'user', value: jsonEncode(user.toJson()));
  }

  Future<Coordinator?> getUser() async {
    final userStr = await storage.read(key: 'user');
    if (userStr != null) {
      return Coordinator.fromJson(jsonDecode(userStr));
    }
    return null;
  }

  Future<void> clearToken() async {
    await storage.delete(key: 'auth_token');
  }

  Future<void> clearUser() async {
    await storage.delete(key: 'user');
  }

  Future<void> clearAll() async {
    await storage.deleteAll();
  }
}