import 'package:get/get.dart';
import 'package:my_party/controllers/supplier_controller.dart';

class SupplierBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<SupplierController>(() => SupplierController());
  }
}