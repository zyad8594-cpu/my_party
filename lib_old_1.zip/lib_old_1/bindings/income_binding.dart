import 'package:get/get.dart';
import 'package:my_party/controllers/income_controller.dart';

class IncomeBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<IncomeController>(() => IncomeController());
  }
}