import 'package:get/get.dart';
import 'package:my_party/controllers/auth_controller.dart';
import 'package:my_party/services/auth_service.dart';

class AuthBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<AuthController>(() => AuthController(), fenix: true);
    Get.lazyPut<AuthService>(() => AuthService(), fenix: true);
  }
}