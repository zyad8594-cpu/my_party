import 'package:get/get.dart';
import 'package:my_party/services/api_service.dart';
import 'package:my_party/services/storage_service.dart';

class AppBindings extends Bindings {
  @override
  void dependencies() {
    // الخدمات الأساسية
    Get.lazyPut<StorageService>(() => StorageService(), fenix: true);
    Get.lazyPut<ApiService>(() => ApiService(), fenix: true);
  }
}