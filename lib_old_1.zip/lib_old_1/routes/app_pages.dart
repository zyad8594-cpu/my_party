import 'package:get/get.dart';
import 'package:my_party/bindings/auth_binding.dart';
import 'package:my_party/bindings/client_binding.dart';
import 'package:my_party/bindings/event_binding.dart';
import 'package:my_party/bindings/home_binding.dart';
import 'package:my_party/bindings/income_binding.dart';
import 'package:my_party/bindings/notification_binding.dart';
import 'package:my_party/bindings/service_binding.dart';
import 'package:my_party/bindings/supplier_binding.dart';
import 'package:my_party/bindings/task_binding.dart';
import 'package:my_party/views/auth/login_page.dart';
import 'package:my_party/views/auth/register_page.dart';
import 'package:my_party/views/clients/client_detail_page.dart';
import 'package:my_party/views/clients/client_form_page.dart';
import 'package:my_party/views/clients/client_list_page.dart';
import 'package:my_party/views/events/event_detail_page.dart';
import 'package:my_party/views/events/event_form_page.dart';
import 'package:my_party/views/events/event_list_page.dart';
import 'package:my_party/views/home/home_page.dart';
import 'package:my_party/views/incomes/income_detail_page.dart';
import 'package:my_party/views/incomes/income_form_page.dart';
import 'package:my_party/views/incomes/income_list_page.dart';
import 'package:my_party/views/notifications/notification_list_page.dart';
import 'package:my_party/views/services/service_detail_page.dart';
import 'package:my_party/views/services/service_form_page.dart';
import 'package:my_party/views/services/service_list_page.dart';
import 'package:my_party/views/suppliers/supplier_detail_page.dart';
import 'package:my_party/views/suppliers/supplier_form_page.dart';
import 'package:my_party/views/suppliers/supplier_list_page.dart';
import 'package:my_party/views/tasks/task_detail_page.dart';
import 'package:my_party/views/tasks/task_form_page.dart';
import 'package:my_party/views/tasks/task_list_page.dart';

// import 'package:my_party/views/tasks/task_rate_page.dart';

part 'app_routes.dart';

class AppPages {
  static final pages = [
    GetPage(
      name: AppRoutes.LOGIN,
      page: () => LoginPage(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRoutes.REGISTER,
      page: () => RegisterPage(),
      binding: AuthBinding(),
    ),
    GetPage(
      name: AppRoutes.HOME,
      page: () => HomePage(),
      binding: HomeBinding(),
    ),
    // Clients
    GetPage(
      name: AppRoutes.CLIENTS,
      page: () => ClientListPage(),
      binding: ClientBinding(),
    ),
    GetPage(
      name: AppRoutes.CLIENT_DETAIL,
      page: () => ClientDetailPage(),
      binding: ClientBinding(),
    ),
    GetPage(
      name: AppRoutes.CLIENT_FORM,
      page: () => ClientFormPage(),
      binding: ClientBinding(),
    ),
    // Events
    GetPage(
      name: AppRoutes.EVENTS,
      page: () => EventListPage(),
      binding: EventBinding(),
    ),
    GetPage(
      name: AppRoutes.EVENT_DETAIL,
      page: () => EventDetailPage(),
      binding: EventBinding(),
    ),
    GetPage(
      name: AppRoutes.EVENT_FORM,
      page: () => EventFormPage(),
      binding: EventBinding(),
    ),
    // Tasks
    GetPage(
      name: AppRoutes.TASKS,
      page: () => TaskListPage(),
      binding: TaskBinding(),
    ),
    GetPage(
      name: AppRoutes.TASK_DETAIL,
      page: () => TaskDetailPage(),
      binding: TaskBinding(),
    ),
    GetPage(
      name: AppRoutes.TASK_FORM,
      page: () => TaskFormPage(),
      binding: TaskBinding(),
    ),
    // GetPage(
    //   name: AppRoutes.TASK_RATE,
    //   page: () => TaskRatePage(),
    //   binding: TaskBinding(),
    // ),
    // Suppliers
    GetPage(
      name: AppRoutes.SUPPLIERS,
      page: () => SupplierListPage(),
      binding: SupplierBinding(),
    ),
    GetPage(
      name: AppRoutes.SUPPLIER_DETAIL,
      page: () => SupplierDetailPage(),
      binding: SupplierBinding(),
    ),
    GetPage(
      name: AppRoutes.SUPPLIER_FORM,
      page: () => SupplierFormPage(),
      binding: SupplierBinding(),
    ),
    // Services
    GetPage(
      name: AppRoutes.SERVICES,
      page: () => ServiceListPage(),
      binding: ServiceBinding(),
    ),
    GetPage(
      name: AppRoutes.SERVICE_DETAIL,
      page: () => ServiceDetailPage(),
      binding: ServiceBinding(),
    ),
    GetPage(
      name: AppRoutes.SERVICE_FORM,
      page: () => ServiceFormPage(),
      binding: ServiceBinding(),
    ),
    // Incomes
    GetPage(
      name: AppRoutes.INCOMES,
      page: () => IncomeListPage(),
      binding: IncomeBinding(),
    ),
    GetPage(
      name: AppRoutes.INCOME_DETAIL,
      page: () => IncomeDetailPage(),
      binding: IncomeBinding(),
    ),
    GetPage(
      name: AppRoutes.INCOME_FORM,
      page: () => IncomeFormPage(),
      binding: IncomeBinding(),
    ),
    // Notifications
    GetPage(
      name: AppRoutes.NOTIFICATIONS,
      page: () => NotificationListPage(),
      binding: NotificationBinding(),
    ),
  ];
}