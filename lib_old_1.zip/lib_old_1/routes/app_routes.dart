part of 'app_pages.dart';

abstract class AppRoutes {
  
  static const LOGIN = '/login';
  static const INITIAL = LOGIN;
  static const REGISTER = '/register';
  static const HOME = '/home';
  
  // Clients
  static const CLIENTS = '/clients';
  static const CLIENT_DETAIL = '/client/detail';
  static const CLIENT_FORM = '/client/form';
  
  // Events
  static const EVENTS = '/events';
  static const EVENT_DETAIL = '/event/detail';
  static const EVENT_FORM = '/event/form';
  
  // Tasks
  static const TASKS = '/tasks';
  static const TASK_DETAIL = '/task/detail';
  static const TASK_FORM = '/task/form';
  static const TASK_RATE = '/task/rate';
  
  // Suppliers
  static const SUPPLIERS = '/suppliers';
  static const SUPPLIER_DETAIL = '/supplier/detail';
  static const SUPPLIER_FORM = '/supplier/form';
  
  // Services
  static const SERVICES = '/services';
  static const SERVICE_DETAIL = '/service/detail';
  static const SERVICE_FORM = '/service/form';
  
  // Incomes
  static const INCOMES = '/incomes';
  static const INCOME_DETAIL = '/income/detail';
  static const INCOME_FORM = '/income/form';
  
  // Notifications
  static const NOTIFICATIONS = '/notifications';
}