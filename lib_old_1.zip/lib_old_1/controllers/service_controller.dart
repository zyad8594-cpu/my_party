import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/service.dart';

class ServiceController extends BaseController {
  final services = <Service>[].obs;
  final selectedService = Rx<Service?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchServices();
  }

  Future<void> fetchServices() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/services')) as List;
      services.value = List<Service>.from(data.map((x) => Service.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchService(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/services/$id')) as Map<String, dynamic>;
      selectedService.value = Service.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createService(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/Services', data: data);
      Get.back();
      fetchServices();
      Get.snackbar('نجاح', 'تم إضافة العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateService(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/services/$id', data: data);
      Get.back();
      fetchServices();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteService(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/services/$id');
      fetchServices();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
}