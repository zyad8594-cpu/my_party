import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/income.dart';

class IncomeController extends BaseController {
  final incomes = <Income>[].obs;
  final selectedIncome = Rx<Income?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchIncomes();
  }

  Future<void> fetchIncomes() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/incomes')) as List;
      incomes.value = List<Income>.from(data.map((x) => Income.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchIncome(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/incomes/$id')) as Map<String, dynamic>;
      selectedIncome.value = Income.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createIncome(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/incomes', data: data);
      Get.back();
      fetchIncomes();
      Get.snackbar('نجاح', 'تم إضافة العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateIncome(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/incomes/$id', data: data);
      Get.back();
      fetchIncomes();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteIncome(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/incomes/$id');
      fetchIncomes();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
}