import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';

class HomeController extends BaseController {
  final stats = {}.obs;
  final recentEvents = [].obs;

  @override
  void onInit() {
    super.onInit();
    fetchDashboardData();
  }

  Future<void> fetchDashboardData() async {
    loading.value = true;
    try {
      // يمكن جلب الإحصائيات من API
      // stats.value = await apiService.get('/dashboard');
      // recentEvents.value = await apiService.get('/events/recent');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  void goTo(String route) {
    Get.toNamed(route);
  }

  void logout() async {
    await storageService.setToken('');
    Get.offAllNamed(AppRoutes.LOGIN);
  }
}