import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/client.dart';

class ClientController extends BaseController {
  final clients = <Client>[].obs;
  final selectedClient = Rx<Client?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchClients();
  }

  Future<void> fetchClients() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/clients')) as List;
      clients.value = List<Client>.from(data.map((x) => Client.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchClient(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/clients/$id')) as Map<String, dynamic>;
      selectedClient.value = Client.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createClient(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/clients', data: data);
      Get.back();
      fetchClients();
      Get.snackbar('نجاح', 'تم إضافة العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateClient(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/clients/$id', data: data);
      Get.back();
      fetchClients();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteClient(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/clients/$id');
      fetchClients();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

}