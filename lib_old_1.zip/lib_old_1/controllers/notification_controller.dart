import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/notifications.dart';

class NotificationController extends BaseController {
  final notifications = <Notification>[].obs;
  final selectedNotification = Rx<Notification?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchNotifications();
  }

  Future<void> fetchNotifications() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/notifications')) as List;
      notifications.value = List<Notification>.from(data.map((x) => Notification.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchNotification(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/notifications/$id')) as Map<String, dynamic>;
      selectedNotification.value = Notification.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createNotification(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/notifications', data: data);
      Get.back();
      fetchNotifications();
      Get.snackbar('نجاح', 'تم إضافة العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateNotification(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/notifications/$id', data: data);
      Get.back();
      fetchNotifications();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteNotification(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/notifications/$id');
      fetchNotifications();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
}