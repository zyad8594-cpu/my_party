import 'package:get/get.dart';
import 'package:my_party/services/api_service.dart';
import 'package:my_party/services/storage_service.dart';

abstract class BaseController extends GetxController {
  final ApiService apiService = Get.find<ApiService>();
  final StorageService storageService = Get.find<StorageService>();

  final loading = false.obs;
  final error = ''.obs;

  void handleError(dynamic e) {
    if (e.toString().contains('401')) {
      Get.offAllNamed('/login');
    } else {
      error.value = e.toString();
    }
  }

  @override
  void onInit() {
    super.onInit();
    ever(error, (m) {
      if (m.isNotEmpty) {
        Get.snackbar('خطأ', m, snackPosition: SnackPosition.BOTTOM);
      }
    });
  }
}