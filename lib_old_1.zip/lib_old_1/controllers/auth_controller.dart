import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
// import 'package:my_party/models/coordinator.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';

class AuthController extends BaseController {
  final email = ''.obs;
  final password = ''.obs;
  final ConfirmPassword = ''.obs;
  final fullName = ''.obs;
  final phone = ''.obs;
  final isLogin = true.obs;

  void toggleMode() => isLogin.toggle();

  Future<void> login() async {
    if(!loading.value)
    {
      if(isLogin.value) 
      {
        await Get.offAllNamed(AppRoutes.HOME);
        return;
      }
      loading.value = true;
      final data = {'email': email.value, 'password': password.value};
      final response = (await apiService.post('/auth/login', data: data)) as Map<String, dynamic>;

      await storageService.setToken(response['token']);
      await storageService.setUser(response['coordinator']);
      await Get.offAllNamed(AppRoutes.HOME);
      loading.value = false;
    }
  }

  Future<void> register() async {
    if(!loading.value)
    {
      loading.value = true;
      final data = {
        'full_name': fullName.value,
        'email': email.value,
        'password': password.value,
        'phone_number': phone.value,
      };
      final response = await apiService.post('/auth/register', data: data);
      if(response.statusCode == 200)
      {
        Get.snackbar('نجاح', 'تم التسجيل بنجاح، سجل دخولك');
        await Get.offAllNamed(AppRoutes.LOGIN);
      }
      else 
      {
        Get.snackbar('فشل', 'تعذر التسجيل');
        // await Get.offAllNamed(AppRoutes.LOGIN);
      }
      loading.value = false;
    }
  }
}