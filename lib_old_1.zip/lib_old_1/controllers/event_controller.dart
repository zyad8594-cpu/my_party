import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/event.dart';

class EventController extends BaseController {
  final events = <Event>[].obs;
  final selectedEvent = Rx<Event?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchEvents();
  }

  Future<void> fetchEvents() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/events')) as List;
      events.value = List<Event>.from(data.map((x) => Event.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchEvent(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/events/$id')) as Map<String, dynamic>;
      selectedEvent.value = Event.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createEvent(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/events', data: data);
      Get.back();
      fetchEvents();
      Get.snackbar('نجاح', 'تم إضافة المناسبة');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateEvent(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/events/$id', data: data);
      Get.back();
      fetchEvents();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteEvent(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/events/$id');
      fetchEvents();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
  
}