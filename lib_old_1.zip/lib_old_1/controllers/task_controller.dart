import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/task.dart';

class TaskController extends BaseController {
  final tasks = <Task>[].obs;
  final selectedTask = Rx<Task?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchTasks();
  }

  Future<void> fetchTasks() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/tasks')) as List;
      tasks.value = List<Task>.from(data.map((x) => Task.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchTask(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/tasks/$id')) as Map<String, dynamic>;
      selectedTask.value = Task.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createTask(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/tasks', data: data);
      Get.back();
      fetchTasks();
      Get.snackbar('نجاح', 'تم إضافة المهمة');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> rateTask(int taskId, int rating, {String? comment}) async {
    loading.value = true;
    try {
      await apiService.post('/tasks/$taskId/rate', data: {
        'value_rating': rating,
        'comment': comment,
      });
      Get.back();
      Get.snackbar('نجاح', 'تم حفظ التقييم');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
}