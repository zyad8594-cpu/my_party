import 'package:get/get.dart';
import 'package:my_party/controllers/base_controller.dart';
import 'package:my_party/models/supplier.dart';

class SupplierController extends BaseController {
  final suppliers = <Supplier>[].obs;
  final selectedSupplier = Rx<Supplier?>(null);

  @override
  void onInit() {
    super.onInit();
    fetchSuppliers();
  }

  Future<void> fetchSuppliers() async {
    loading.value = true;
    try {
      final data = (await apiService.get('/suppliers')) as List;
      suppliers.value = List<Supplier>.from(data.map((x) => Supplier.fromJson(x)));
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> fetchSupplier(int id) async {
    loading.value = true;
    try {
      final data = (await apiService.get('/suppliers/$id')) as Map<String, dynamic>;
      selectedSupplier.value = Supplier.fromJson(data);
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> createSupplier(Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.post('/suppliers', data: data);
      Get.back();
      fetchSuppliers();
      Get.snackbar('نجاح', 'تم إضافة العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> updateSupplier(int id, Map<String, dynamic> data) async {
    loading.value = true;
    try {
      await apiService.put('/suppliers/$id', data: data);
      Get.back();
      fetchSuppliers();
      Get.snackbar('نجاح', 'تم تحديث العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }

  Future<void> deleteSupplier(int id) async {
    loading.value = true;
    try {
      await apiService.delete('/suppliers/$id');
      fetchSuppliers();
      Get.snackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      handleError(e);
    } finally {
      loading.value = false;
    }
  }
}