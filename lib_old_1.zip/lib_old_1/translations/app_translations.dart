import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'ar': {
          'app_name': 'تطبيق المناسبات',
          'login': 'تسجيل الدخول',
          'register': 'تسجيل جديد',
          'email': 'البريد الإلكتروني',
          'password': 'كلمة المرور',
          'full_name': 'الاسم الكامل',
          'phone': 'رقم الهاتف',
          'clients': 'العملاء',
          'events': 'المناسبات',
          'tasks': 'المهام',
        },
        'en': {
          'app_name': 'Events App',
          'login': 'Login',
          'register': 'Register',
          'email': 'Email',
          'password': 'Password',
          'full_name': 'Full Name',
          'phone': 'Phone',
          'clients': 'Clients',
          'events': 'Events',
          'tasks': 'Tasks',
        },
      };
}