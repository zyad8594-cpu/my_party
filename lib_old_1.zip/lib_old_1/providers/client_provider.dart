import 'package:dio/dio.dart';
import 'package:get/get.dart';
import 'package:my_party/core/constants/api_endpoints.dart';
import 'package:my_party/services/api_service.dart';
import 'package:my_party/models/client.dart';

class ClientProvider {
  final ApiService _apiService = Get.find<ApiService>();

  Future<List<Client>> getClients() async {
    try {
      final response = await _apiService.get(ApiEndpoints.clients);
      if (response.statusCode == 200) {
        final List data = response.data;
        return data.map((json) => Client.fromJson(json)).toList();
      }
      return [];
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<Client> getClient(int id) async {
    try {
      final response = await _apiService.get('${ApiEndpoints.clients}/$id');
      if (response.statusCode == 200) {
        return Client.fromJson(response.data);
      }
      throw Exception('Client not found');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<int> createClient(Map<String, dynamic> data) async {
    try {
      final response = await _apiService.post(ApiEndpoints.clients, data: data);
      if (response.statusCode == 201) {
        return response.data['data']['id'];
      }
      throw Exception('Creation failed');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> updateClient(int id, Map<String, dynamic> data) async {
    try {
      await _apiService.put('${ApiEndpoints.clients}/$id', data: data);
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  Future<void> deleteClient(int id) async {
    try {
      await _apiService.delete('${ApiEndpoints.clients}/$id');
    } on DioException catch (e) {
      throw _handleError(e);
    }
  }

  String _handleError(DioException e) {
    if (e.response != null) {
      return e.response?.data['error'] ?? 'Unknown error';
    }
    return e.message ?? 'Connection error';
  }
}