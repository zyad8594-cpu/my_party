class ApiEndpoints {
  static const String baseUrl = 'http://localhost/projects/my_party_app/api';

  // Auth
  static const String login = '$baseUrl/auth/login';
  static const String register = '/auth/register';

  // Coordinators
  static const String coordinators = '$baseUrl/coordinators';

  // Suppliers
  static const String suppliers = '$baseUrl/suppliers';

  // Services
  static const String services = '$baseUrl/services';

  // Clients
  static const String clients = '$baseUrl/clients';

  // Events
  static const String events = '$baseUrl/events';

  // Tasks
  static const String tasks = '$baseUrl/tasks';

  // Incomes
  static const String incomes = '$baseUrl/incomes';

  // Notifications
  static const String notifications = '$baseUrl/notifications';
}