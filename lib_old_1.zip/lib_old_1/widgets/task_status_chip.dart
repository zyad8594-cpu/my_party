import 'package:flutter/material.dart';
import 'package:my_party/models/task.dart';

class TaskStatusChip extends StatelessWidget {
  final TaskStatus status;

  const TaskStatusChip({required this.status});

  @override
  Widget build(BuildContext context) {
    Color color;
    String text;
    switch (status) {
      case TaskStatus.pending:
        color = Colors.orange;
        text = 'قيد الانتظار';
        break;
      case TaskStatus.inProgress:
        color = Colors.blue;
        text = 'قيد التنفيذ';
        break;
      case TaskStatus.underReview:
        color = Colors.purple;
        text = 'قيد المراجعة';
        break;
      case TaskStatus.completed:
        color = Colors.green;
        text = 'منتهية';
        break;
      case TaskStatus.cancelled:
        color = Colors.red;
        text = 'ملغية';
        break;
    }
    return Container(
      padding: EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.2),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: color),
      ),
      child: Text(text, style: TextStyle(color: color, fontSize: 12)),
    );
  }
}