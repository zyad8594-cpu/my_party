import 'package:flutter/material.dart' hide ErrorWidget;
import 'package:get/get.dart';
import 'package:my_party/controllers/notification_controller.dart';
import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';
import 'package:my_party/widgets/error_widget.dart';
// import 'package:my_party/widgets/empty_widget.dart';

class NotificationListPage extends StatelessWidget {
  final NotificationController controller = Get.find<NotificationController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('المهام'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        if (controller.error.isNotEmpty) return ErrorWidget(message: controller.error.value);
        // if (controller.tasks.isEmpty) return EmptyWidget(message: 'لا يوجد عملاء');
        return ListView.builder(
          itemCount: controller.notifications.length,
          itemBuilder: (_, index) {
            final service = controller.notifications[index];
            return ListTile(
              title: Text(service.title ),
              subtitle: Text(''),
              onTap: () => Get.toNamed(AppRoutes.CLIENT_DETAIL, arguments: service.notificationId),
            );
          },
        );
      }),
    );
  }
}