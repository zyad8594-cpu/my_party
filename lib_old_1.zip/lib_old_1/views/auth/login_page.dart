import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/auth_controller.dart';
import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';

class LoginPage extends StatelessWidget {
  final AuthController controller = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('تسجيل الدخول')),
      body: Obx(() => controller.loading.value
          ? LoadingWidget()
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextField(
                      decoration: InputDecoration(labelText: 'البريد الإلكتروني'),
                      onChanged: (v) => controller.email.value = v,
                    ),
                    SizedBox(height: 16),
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(labelText: 'كلمة المرور'),
                      onChanged: (v) => controller.password.value = v,
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: controller.login,
                      child: Text('دخول'),
                    ),
                    TextButton(
                      onPressed: () => Get.toNamed(AppRoutes.REGISTER),
                      child: Text('ليس لديك حساب؟ سجل الآن'),
                    ),
                  ],
                ),
              ),
            )),
    );
  }
}