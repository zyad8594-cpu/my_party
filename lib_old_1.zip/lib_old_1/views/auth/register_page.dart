import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/auth_controller.dart';
// import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';

class RegisterPage extends StatelessWidget {
  final AuthController controller = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('إنشاء حساب')),
      body: Obx(() => controller.loading.value
          ? LoadingWidget()
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    TextField(
                      decoration: InputDecoration(labelText: 'الإسم الكامل'),
                      onChanged: (v) => controller.fullName.value = v,
                    ),
                    SizedBox(height: 16),
                    TextField(
                      decoration: InputDecoration(labelText: 'البريد الإلكتروني'),
                      onChanged: (v) => controller.email.value = v,
                    ),
                    SizedBox(height: 16),
                    TextField(
                      obscureText: true,
                      decoration: InputDecoration(labelText: 'كلمة المرور'),
                      onChanged: (v) => controller.password.value = v,
                    ),
                    TextField(
                      decoration: InputDecoration(labelText: 'تأكيد كلمة المرور'),
                      onChanged: (v) => controller.ConfirmPassword.value = v,
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: controller.register,
                      child: Text('تسجيل'),
                    ),
                    
                  ],
                ),
              ),
            )),
    );
  }
}