import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/service_controller.dart';
import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';

class ServiceDetailPage extends StatelessWidget {
  final ServiceController controller = Get.find<ServiceController>();
  int serviceId = 0;

  ServiceDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    serviceId = Get.parameters['client_id'] as int;
    controller.fetchService(serviceId);
    return Scaffold(
      appBar: AppBar(
        title: Text('تفاصيل العميل'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM, arguments: serviceId),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _confirmDelete(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        final service = controller.selectedService.value;
        if (service == null) return Center(child: Text('لا يوجد بيانات'));
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('الاسم: ${service.serviceName}', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text('الهاتف: ${service.description}'),
              SizedBox(height: 16),
              Text('مناسبات هذا العميل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              // يمكن إضافة قائمة المناسبات هنا إذا أردنا
            ],
          ),
        );
      }),
    );
  }

  void _confirmDelete() {
    Get.defaultDialog(
      title: 'تأكيد',
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      textConfirm: 'نعم',
      textCancel: 'لا',
      onConfirm: () {
        Get.back();
        // controller.deleteClient(taskId);
        Get.back(); // العودة للقائمة بعد الحذف
      },
    );
  }
}