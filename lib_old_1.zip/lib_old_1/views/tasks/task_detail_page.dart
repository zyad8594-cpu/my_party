import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/task_controller.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';
import 'package:my_party/widgets/loading_widget.dart';

class TaskDetailPage extends StatelessWidget {
  final TaskController controller = Get.find<TaskController>();
  int taskId = 0;

  TaskDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    taskId = Get.parameters['client_id'] as int;
    controller.fetchTask(taskId);
    return Scaffold(
      appBar: AppBar(
        title: Text('تفاصيل العميل'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM, arguments: taskId),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _confirmDelete(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        final task = controller.selectedTask.value;
        if (task == null) return Center(child: Text('لا يوجد بيانات'));
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('الاسم: ${task.typeTask}', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text('الهاتف: ${task.description}'),
              if (task.cost != null) Text('البريد: ${task.cost}'),
              if (task.notes != null) Text('العنوان: ${task.notes}'),
              SizedBox(height: 16),
              Text('مناسبات هذا العميل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              // يمكن إضافة قائمة المناسبات هنا إذا أردنا
            ],
          ),
        );
      }),
    );
  }

  void _confirmDelete() {
    Get.defaultDialog(
      title: 'تأكيد',
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      textConfirm: 'نعم',
      textCancel: 'لا',
      onConfirm: () {
        Get.back();
        // controller.deleteClient(taskId);
        Get.back(); // العودة للقائمة بعد الحذف
      },
    );
  }
}