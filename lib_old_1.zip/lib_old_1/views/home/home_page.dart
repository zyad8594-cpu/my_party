import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/home_controller.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';
import 'package:my_party/widgets/custom_app_bar.dart';
import 'package:my_party/widgets/loading_widget.dart';

class HomePage extends StatelessWidget {
  final HomeController controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: CustomAppBar(
        title: 'الرئيسية',
        actions: [
          IconButton(
            icon: Icon(Icons.notifications),
            onPressed: () => Get.toNamed(AppRoutes.NOTIFICATIONS),
          ),
          IconButton(
            icon: Icon(Icons.logout),
            onPressed: controller.logout,
          ),
        ],
      ),
      body: Obx(() => controller.loading.value
          ? LoadingWidget()
          : GridView.count(
              crossAxisCount: 2,
              padding: EdgeInsets.all(16),
              children: [
                _buildCard(Icons.people, 'العملاء', AppRoutes.CLIENTS),
                _buildCard(Icons.event, 'المناسبات', AppRoutes.EVENTS),
                _buildCard(Icons.task, 'المهام', AppRoutes.TASKS),
                _buildCard(Icons.business, 'الموردين', AppRoutes.SUPPLIERS),
                _buildCard(Icons.build, 'الخدمات', AppRoutes.SERVICES),
                _buildCard(Icons.attach_money, 'الدخل', AppRoutes.INCOMES),
              ],
            )),
    );
  }

  Widget _buildCard(IconData icon, String label, String route) {
    return Card(
      child: InkWell(
        onTap: () => Get.toNamed(route),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 48),
            SizedBox(height: 8),
            Text(label),
          ],
        ),
      ),
    );
  }
}