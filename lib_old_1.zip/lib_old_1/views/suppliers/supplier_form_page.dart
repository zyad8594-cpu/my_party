import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/supplier_controller.dart';
import 'package:my_party/widgets/loading_widget.dart';

class SupplierFormPage extends StatelessWidget {
  final SupplierController controller = Get.find<SupplierController>();
  final _formKey = GlobalKey<FormState>();
  final nameController = TextEditingController();
  final phoneController = TextEditingController();
  final emailController = TextEditingController();
  final addressController = TextEditingController();
  final int? supplierId;

  SupplierFormPage({this.supplierId}) {
    if (supplierId != null) {
      final client = controller.suppliers.firstWhereOrNull((c) => c.supplierId == supplierId);
      if (client != null) {
        // nameController.text = client.fullName;
        // phoneController.text = client.phoneNumber;
        // emailController.text = client.email ?? '';
        // addressController.text = client.address ?? '';
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(supplierId == null ? 'إضافة عميل' : 'تعديل عميل')),
      body: Obx(() => controller.loading.value
          ? LoadingWidget()
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Form(
                key: _formKey,
                child: ListView(
                  children: [
                    TextFormField(
                      controller: nameController,
                      decoration: InputDecoration(labelText: 'الاسم الكامل'),
                      validator: (v) => v!.isEmpty ? 'مطلوب' : null,
                    ),
                    TextFormField(
                      controller: phoneController,
                      decoration: InputDecoration(labelText: 'رقم الهاتف'),
                      validator: (v) => v!.isEmpty ? 'مطلوب' : null,
                    ),
                    TextFormField(
                      controller: emailController,
                      decoration: InputDecoration(labelText: 'البريد الإلكتروني (اختياري)'),
                    ),
                    TextFormField(
                      controller: addressController,
                      decoration: InputDecoration(labelText: 'العنوان (اختياري)'),
                    ),
                    SizedBox(height: 24),
                    ElevatedButton(
                      onPressed: _submit,
                      child: Text('حفظ'),
                    ),
                  ],
                ),
              ),
            )),
    );
  }

  void _submit() {
    if (_formKey.currentState!.validate()) {
      final data = {
        'full_name': nameController.text,
        'phone_number': phoneController.text,
        'email': emailController.text.isEmpty ? null : emailController.text,
        'address': addressController.text.isEmpty ? null : addressController.text,
      };
      if (supplierId == null) {
        controller.createSupplier(data);
      } else {
        controller.updateSupplier(supplierId!, data);
      }
    }
  }
}