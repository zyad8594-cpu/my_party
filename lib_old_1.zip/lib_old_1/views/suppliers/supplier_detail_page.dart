import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/supplier_controller.dart';
import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';

class SupplierDetailPage extends StatelessWidget {
  final SupplierController controller = Get.find<SupplierController>();
  int supplierId = 0;

  SupplierDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    supplierId = Get.parameters['client_id'] as int;
    controller.fetchSupplier(supplierId);
    return Scaffold(
      appBar: AppBar(
        title: Text('تفاصيل العميل'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM, arguments: supplierId),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _confirmDelete(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        final task = controller.selectedSupplier.value;
        if (task == null) return Center(child: Text('لا يوجد بيانات'));
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('الاسم: ${task.name}', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text('الهاتف: ${task.phone}'),
              if (task.address != null) Text('البريد: ${task.address}'),
              if (task.notes != null) Text('العنوان: ${task.notes}'),
              SizedBox(height: 16),
              Text('مناسبات هذا العميل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              // يمكن إضافة قائمة المناسبات هنا إذا أردنا
            ],
          ),
        );
      }),
    );
  }

  void _confirmDelete() {
    Get.defaultDialog(
      title: 'تأكيد',
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      textConfirm: 'نعم',
      textCancel: 'لا',
      onConfirm: () {
        Get.back();
        // controller.deleteClient(taskId);
        Get.back(); // العودة للقائمة بعد الحذف
      },
    );
  }
}