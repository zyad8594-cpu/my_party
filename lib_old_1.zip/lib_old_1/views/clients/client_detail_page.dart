import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/controllers/client_controller.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';
import 'package:my_party/widgets/loading_widget.dart';

class ClientDetailPage extends StatelessWidget {
  final ClientController controller = Get.find<ClientController>();
  int clientId = 0;

  ClientDetailPage({super.key});

  @override
  Widget build(BuildContext context) {
    clientId = Get.parameters['client_id'] as int;
    controller.fetchClient(clientId);
    return Scaffold(
      appBar: AppBar(
        title: Text('تفاصيل العميل'),
        actions: [
          IconButton(
            icon: Icon(Icons.edit),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM, arguments: clientId),
          ),
          IconButton(
            icon: Icon(Icons.delete),
            onPressed: () => _confirmDelete(),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        final client = controller.selectedClient.value;
        if (client == null) return Center(child: Text('لا يوجد بيانات'));
        return Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('الاسم: ${client.fullName}', style: TextStyle(fontSize: 18)),
              SizedBox(height: 8),
              Text('الهاتف: ${client.phoneNumber}'),
              if (client.email != null) Text('البريد: ${client.email}'),
              if (client.address != null) Text('العنوان: ${client.address}'),
              SizedBox(height: 16),
              Text('مناسبات هذا العميل', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
              // يمكن إضافة قائمة المناسبات هنا إذا أردنا
            ],
          ),
        );
      }),
    );
  }

  void _confirmDelete() {
    Get.defaultDialog(
      title: 'تأكيد',
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      textConfirm: 'نعم',
      textCancel: 'لا',
      onConfirm: () {
        Get.back();
        controller.deleteClient(clientId);
        Get.back(); // العودة للقائمة بعد الحذف
      },
    );
  }
}