import 'package:flutter/material.dart' hide ErrorWidget;
import 'package:get/get.dart';
import 'package:my_party/controllers/client_controller.dart';
import 'package:my_party/routes/app_pages.dart';
import 'package:my_party/widgets/loading_widget.dart';
import 'package:my_party/widgets/error_widget.dart';
import 'package:my_party/widgets/empty_widget.dart';

class ClientListPage extends StatelessWidget {
  final ClientController controller = Get.find<ClientController>();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('العملاء'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: () => Get.toNamed(AppRoutes.CLIENT_FORM),
          ),
        ],
      ),
      body: Obx(() {
        if (controller.loading.value) return LoadingWidget();
        if (controller.error.isNotEmpty) return ErrorWidget(message: controller.error.value);
        if (controller.clients.isEmpty) return EmptyWidget(message: 'لا يوجد عملاء');
        return ListView.builder(
          itemCount: controller.clients.length,
          itemBuilder: (_, index) {
            final client = controller.clients[index];
            return ListTile(
              title: Text(client.fullName),
              subtitle: Text(client.phoneNumber),
              onTap: () => Get.toNamed(AppRoutes.CLIENT_DETAIL, arguments: client.clientId),
            );
          },
        );
      }),
    );
  }
}