const String baseUrl = 'http://localhost/projects/my_party_app/api'; // غير حسب البيئة
const String storageTokenKey = 'auth_token';
const String storageUserKey = 'user_data';