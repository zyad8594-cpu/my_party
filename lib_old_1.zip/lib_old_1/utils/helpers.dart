import 'package:intl/intl.dart';

String formatDate(String dateString) {
  try {
    final date = DateTime.parse(dateString);
    return DateFormat('yyyy-MM-dd').format(date);
  } catch (e) {
    return dateString;
  }
}

String formatDateTime(String dateString) {
  try {
    final date = DateTime.parse(dateString);
    return DateFormat('yyyy-MM-dd HH:mm').format(date);
  } catch (e) {
    return dateString;
  }
}