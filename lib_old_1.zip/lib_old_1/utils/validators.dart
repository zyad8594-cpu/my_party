import 'package:get/get_utils/src/get_utils/get_utils.dart';

class Validators {
  static String? required(String? value) {
    if (value == null || value.isEmpty) return 'هذا الحقل مطلوب';
    return null;
  }

  static String? email(String? value) {
    if (value == null || value.isEmpty) return null;
    if (!GetUtils.isEmail(value)) return 'بريد إلكتروني غير صحيح';
    return null;
  }

  static String? phone(String? value) {
    if (value == null || value.isEmpty) return null;
    if (!GetUtils.isPhoneNumber(value)) return 'رقم هاتف غير صحيح';
    return null;
  }
}