class Rating {
  final int ratingId;
  final int taskId;
  final int coordinatorId;
  final int valueRating;
  final String? comment;
  final String ratedAt;

  Rating({
    required this.ratingId,
    required this.taskId,
    required this.coordinatorId,
    required this.valueRating,
    this.comment,
    required this.ratedAt,
  });

  factory Rating.fromJson(Map<String, dynamic> json) {
    return Rating(
      ratingId: json['rating_id'],
      taskId: json['task_id'],
      coordinatorId: json['coordinator_id'],
      valueRating: json['value_rating'],
      comment: json['comment'],
      ratedAt: json['rated_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'value_rating': valueRating,
      'comment': comment,
    };
  }
}