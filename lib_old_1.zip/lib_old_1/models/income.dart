class Income {
  final int incomeId;
  final int eventId;
  final double amount;
  final String? paymentMethod;
  final String paymentDate;
  final String? urlImage;
  final String? description;
  final String createdAt;
  String? eventName;

  Income({
    required this.incomeId,
    required this.eventId,
    required this.amount,
    this.paymentMethod,
    required this.paymentDate,
    this.urlImage,
    this.description,
    required this.createdAt,
    this.eventName
  });

  factory Income.fromJson(Map<String, dynamic> json) {
    return Income(
      incomeId: json['income_id'],
      eventId: json['event_id'],
      amount: json['amount'],
      paymentMethod: json['paymentMethod'],
      paymentDate: json['paymentDate'],
      urlImage: json['urlImage'],
      description: json['description'],
      createdAt: json['created_at'],
      eventName: json['eventName']
    );
  }
  Map<String, dynamic> toJson() {
    return {
      'event_id': eventId,
      'amount': amount,
      'paymentMethod': paymentMethod,
      'paymentDate': paymentDate,
      'urlImage': urlImage,
      'description': description,
      'created_at': createdAt,
      'eventName': eventName,
    };
  }
}