import 'task.dart';
import 'income.dart';

class Event {
  final int eventId;
  final int clientId;
  final int coordinatorId;
  final String nameEvent;
  final String? description;
  final String eventDate;
  final String? location;
  final double? budget;
  final String status;
  final String createdAt;
  // optional joined fields
  String? clientName;
  String? coordinatorName;
  List<Task>? tasks;
  List<Income>? incomes;
  double? totalIncome;

  Event({
    required this.eventId,
    required this.clientId,
    required this.coordinatorId,
    required this.nameEvent,
    this.description,
    required this.eventDate,
    this.location,
    this.budget,
    required this.status,
    required this.createdAt,
    this.clientName,
    this.coordinatorName,
    this.tasks,
    this.incomes,
    this.totalIncome,
  });

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      eventId: json['event_id'],
      clientId: json['client_id'],
      coordinatorId: json['coordinator_id'],
      nameEvent: json['name_event'],
      description: json['description'],
      eventDate: json['event_date'],
      location: json['location'],
      budget: json['budget']?.toDouble(),
      status: json['status'],
      createdAt: json['created_at'],
      clientName: json['client_name'],
      coordinatorName: json['coordinator_name'],
      tasks: json['tasks'] != null
          ? List<Task>.from(json['tasks'].map((x) => Task.fromJson(x)))
          : null,
      incomes: json['incomes'] != null
          ? List<Income>.from(json['incomes'].map((x) => Income.fromJson(x)))
          : null,
      totalIncome: json['total_income']?.toDouble(),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'client_id': clientId,
      'coordinator_id': coordinatorId,
      'name_event': nameEvent,
      'description': description,
      'event_date': eventDate,
      'location': location,
      'budget': budget,
      'status': status,
    };
  }
}