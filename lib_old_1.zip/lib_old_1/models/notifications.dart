class Notification {
  final int notificationId;
  final int? userId;
  final int? supplierId;
  final int taskId;
  final String? type;
  final String title;
  final String message;
  final String createdAt;

  Notification({
    required this.notificationId,
    this.userId,
    this.supplierId,
    required this.taskId,
    this.type,
    required this.title,
    required this.message,
    required this.createdAt
  });

  factory Notification.fromJson(Map<String, dynamic> json) {
    return Notification(
      notificationId: json[''],
      userId: json[''],
      supplierId: json[''],
      taskId: json[''],
      type: json[''],
      title: json[''],
      message: json[''],
      createdAt: json['']
    );
  }
}