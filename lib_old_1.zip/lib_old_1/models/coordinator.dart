class Coordinator {
  final int coordinatorId;
  final String fullName;
  final String email;
  final String? phoneNumber;

  Coordinator({
    required this.coordinatorId,
    required this.fullName,
    required this.email,
    this.phoneNumber,
  });

  factory Coordinator.fromJson(Map<String, dynamic> json) {
    return Coordinator(
      coordinatorId: json['coordinator_id'],
      fullName: json['full_name'],
      email: json['email'],
      phoneNumber: json['phone_number'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'full_name': fullName,
      'email': email,
      'phone_number': phoneNumber,
    };
  }
}