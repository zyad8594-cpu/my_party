class Client {
  final int clientId;
  final String fullName;
  final String phoneNumber;
  final String? email;
  final String? address;
  final String createdAt;

  Client({
    required this.clientId,
    required this.fullName,
    required this.phoneNumber,
    this.email,
    this.address,
    required this.createdAt,
  });

  factory Client.fromJson(Map<String, dynamic> json) {
    return Client(
      clientId: json['client_id'],
      fullName: json['full_name'],
      phoneNumber: json['phone_number'],
      email: json['email'],
      address: json['address'],
      createdAt: json['created_at'],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'full_name': fullName,
      'phone_number': phoneNumber,
      'email': email,
      'address': address,
    };
  }
}