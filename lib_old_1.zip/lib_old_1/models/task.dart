import 'rating.dart';

enum AssignmentType { supplier, user }
enum TaskStatus { pending, inProgress, underReview, completed, cancelled }

class Task {
  final int taskId;
  final int eventId;
  final AssignmentType assignmentType;
  final int? assignedUserId;
  final int? assignedSupplierId;
  final String typeTask;
  final String? description;
  final double? cost;
  final TaskStatus status;
  final String? notes;
  final String? urlImage;
  final String? dateStart;
  final String? dateDue;
  final String? reminderType;
  final int? reminderValue;
  final String? reminderUnit;
  final String? dateCompletion;
  final String createdAt;
  // joined fields
  String? userName;
  String? supplierName;
  String? eventName;
  Rating? rating;

  Task({
    required this.taskId,
    required this.eventId,
    required this.assignmentType,
    this.assignedUserId,
    this.assignedSupplierId,
    required this.typeTask,
    this.description,
    this.cost,
    required this.status,
    this.notes,
    this.urlImage,
    this.dateStart,
    this.dateDue,
    this.reminderType,
    this.reminderValue,
    this.reminderUnit,
    this.dateCompletion,
    required this.createdAt,
    this.userName,
    this.supplierName,
    this.eventName,
    this.rating,
  });

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      taskId: json['task_id'],
      eventId: json['event_id'],
      assignmentType: json['assignment_type'] == 'SUPPLIER'
          ? AssignmentType.supplier
          : AssignmentType.user,
      assignedUserId: json['assigned_user_id'],
      assignedSupplierId: json['assigned_supplier_id'],
      typeTask: json['type_task'],
      description: json['description'],
      cost: json['cost']?.toDouble(),
      status: _parseStatus(json['status']),
      notes: json['notes'],
      urlImage: json['url_image'],
      dateStart: json['date_start'],
      dateDue: json['date_due'],
      reminderType: json['reminder_type'],
      reminderValue: json['reminder_value'],
      reminderUnit: json['reminder_unit'],
      dateCompletion: json['date_completion'],
      createdAt: json['created_at'],
      userName: json['user_name'],
      supplierName: json['supplier_name'],
      eventName: json['event_name'],
      rating: json['rating'] != null ? Rating.fromJson(json['rating']) : null,
    );
  }

  static TaskStatus _parseStatus(String status) {
    switch (status) {
      case 'PENDING':
        return TaskStatus.pending;
      case 'IN_PROGRESS':
        return TaskStatus.inProgress;
      case 'UNDER_REVIEW':
        return TaskStatus.underReview;
      case 'COMPLETED':
        return TaskStatus.completed;
      case 'CANCELLED':
        return TaskStatus.cancelled;
      default:
        return TaskStatus.pending;
    }
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': eventId,
      'assignment_type': assignmentType == AssignmentType.supplier ? 'SUPPLIER' : 'USER',
      'assigned_user_id': assignedUserId,
      'assigned_supplier_id': assignedSupplierId,
      'type_task': typeTask,
      'description': description,
      'cost': cost,
      'status': status.toString().split('.').last.toUpperCase(),
      'notes': notes,
      'url_image': urlImage,
      'date_start': dateStart,
      'date_due': dateDue,
      'reminder_type': reminderType,
      'reminder_value': reminderValue,
      'reminder_unit': reminderUnit,
    };
  }
}