class Supplier {
  final int supplierId;
  final int serviceId;
  final String name;
  final String email;
  final String phone;
  final String? address;
  final String? notes;
  final String createdAt;

  Supplier({
    required this.supplierId,
    required this.serviceId,
    required this.name,
    required this.email,
    required this.phone,
    this.address,
    this.notes,
    required this.createdAt
  });

  factory Supplier.fromJson(Map<String, dynamic> json) {
    return Supplier(
      supplierId: json[''], 
      serviceId: json[''], 
      name: json[''], 
      email: json[''], 
      phone: json[''], 
      address: json[''],
      notes: json[''],
      createdAt: json['']
    );
  }
  Map<String, dynamic> toJson() {
    return {};
  }
}