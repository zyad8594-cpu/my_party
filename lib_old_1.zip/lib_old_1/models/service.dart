class Service {
  final int serviceId;
  final String serviceName;
  final String? description;
  final String createdAt;

  Service({
    required this.serviceId,
    required this.serviceName,
    this.description,
    required this.createdAt
  });

  factory Service.fromJson(Map<String, dynamic> json) {
    return Service(
      serviceId: json[''], 
      serviceName: json[''], 
      description: json[''],
      createdAt: json['']
    );
  }
  Map<String, dynamic> toJson() {
    return {};
  }
}