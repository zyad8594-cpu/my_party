import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/routes/app_pages.dart';
// import 'package:my_party/routes/app_routes.dart';
import 'package:my_party/theme/app_theme.dart';
import 'package:my_party/services/storage_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Get.putAsync(() => StorageService().init());
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      title: 'منصة المناسبات',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      initialRoute: AppRoutes.INITIAL,
      getPages: AppPages.pages,
    );
  }
}