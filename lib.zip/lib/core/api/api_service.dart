import 'package:get/get.dart' hide Response;
import 'package:dio/dio.dart' as dio;
import 'api_constants.dart';

class ApiService extends GetxService 
{
  late final dio.Dio _dio;
  String? _token;
  /*
    dio.options.headers['User-Agent'] = 'MyPartyApp/1.0.0 (Android; 13)';
   */
  Future<ApiService> init() async 
  {
    _dio = dio.Dio(
      dio.BaseOptions(
        baseUrl: ApiConstants.baseUrl,
        connectTimeout: const Duration(seconds: 10),
        receiveTimeout: const Duration(seconds: 10),
        headers: <String, dynamic>
        {
          'Content-Type': 'application/json',
          'user-agent': 'my_party_pro',
        },
      )
    );

    // Optional: Add logging interceptor for debugging
    // _dio.interceptors.add(LogInterceptor(responseBody: true, requestBody: true));

    return this;
  }

  void setToken(String token) 
  {
    _token = token;
  }

  void clearToken() 
  {
    _token = null;
  }

  dio.Options _getOptions() 
  {
    return dio.Options(
      headers: 
      {
        if (_token != null) 'Authoriztion': 'Bearer $_token',
      },
    );
  }

  Future<dynamic> get(String endpoint) async 
  {
    try 
    {
      final response = await _dio.get(endpoint, options: _getOptions(),);
      return _handleResponse(response);
    } 
    on dio.DioException catch (e) 
    {
      throw _handleDioError(e);
    } 
    catch (e) 
    {
      throw Exception('Unexpected error: $e');
    }
  }

  Future<dynamic> post(String endpoint, {Map<String, dynamic>? data}) async 
  {
    try 
    {
      final response = await _dio.post(
        endpoint,
        data: data,
        options: _getOptions(),
      );
      return _handleResponse(response);
    } 
    on dio.DioException catch (e) 
    {
      throw _handleDioError(e);
    } 
    catch (e) 
    {
      throw Exception('Unexpected error: $e');
    }
  }

  Future<dynamic> put(String endpoint, {Map<String, dynamic>? data}) async 
  {
    try 
    {
      final response = await _dio.put(
        endpoint,
        data: data,
        options: _getOptions(),
      );
      return _handleResponse(response);
    } 
    on dio.DioException catch (e) 
    {
      throw _handleDioError(e);
    } 
    catch (e) 
    {
      throw Exception('Unexpected error: $e');
    }
  }

  Future<dynamic> delete(String endpoint) async 
  {
    try 
    {
      final response = await _dio.delete(
        endpoint,
        options: _getOptions(),
      );
      return _handleResponse(response);
    } 
    on dio.DioException catch (e) 
    {
      throw _handleDioError(e);
    } 
    catch (e) 
    {
      throw Exception('Unexpected error: $e');
    }
  }

  dynamic _handleResponse(dio.Response response) 
  {
    // Dio automatically decodes JSON if the content-type is application/json
    return response.data;
  }

  Exception _handleDioError(dio.DioException e) 
  {
    if (e.response != null) 
    {
      final statusCode = e.response?.statusCode;
      final data = e.response?.data;
      if (statusCode == 401) 
      {
        return Exception('Unauthorized($statusCode): $data');
      } 
      else if (statusCode == 404) 
      {
        return Exception('Not found($statusCode): $data');
      } 
      else 
      {
        return Exception('Server error($statusCode): $data');
      }
    } 
    else 
    {
      return Exception('Network error: ${e.message}');
    }
  }
}
