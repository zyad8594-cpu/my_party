import 'package:get/get.dart';
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/api/auth_service.dart' show AuthService;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../../features/auth/data/repository/auth_repository.dart' show AuthRepository;

class AuthController extends GetxController 
{
  final AuthRepository _authRepository = Get.find<AuthRepository>();
  final AuthService _authService = Get.find<AuthService>();

  final email = ''.obs;
  final password = ''.obs;
  final name = ''.obs;
  final phone = ''.obs;

  final selectedRole = 'coordinator'.obs;

  final isLoading = false.obs;
  final isErrorShow = false.obs;
  late final RxMap<String, dynamic> currentUser = _authService.user;

  @override
  void onInit() 
  {
    super.onInit();
  }

  void login() async {
    if (email.value.isEmpty || password.value.isEmpty) {
      if (!isErrorShow.value) {
        isErrorShow.value = true;
        utils.showSnackbar('خطأ', 'يرجى إدخال البريد وكلمة المرور', isError: true);
        Future.delayed(const Duration(seconds: 3), () {
          isErrorShow.value = false;
        });
      }

      return;
    }

    isLoading.value = true;
    try {
      final role = await _authRepository.login(email.value, password.value);
      

      if (role == 'SUPPLIER') {
        Get.offAllNamed(AppRoutes.supplierHome);
      } else {
        Get.offAllNamed(AppRoutes.home);
      }

      utils.showSnackbar('نجاح', 'تم تسجيل الدخول بنجاح');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  void register() async {
    if (name.value.isEmpty || email.value.isEmpty || password.value.isEmpty) {
      utils.showSnackbar('خطأ', 'يرجى ملء جميع الحقول', isError: true);
      return;
    }
    isLoading.value = true;
    try {
      final data = {
        'full_name': name.value,
        'email': email.value,
        'password': password.value,
        'phone': phone.value,
        'role_name': selectedRole.value,
      };
      // final response = await _authRepository.register(data);
      await _authRepository.register(data);
      Get.back(); // العودة إلى صفحة تسجيل الدخول
      utils.showSnackbar('نجاح', 'تم التسجيل بنجاح، يمكنك تسجيل الدخول الآن');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  void logout() {
    _authService.logout();
  }

  @override
  void onClose() {
    super.onClose();
  }
}
