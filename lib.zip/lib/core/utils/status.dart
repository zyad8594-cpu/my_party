import 'package:flutter/material.dart' show Color, Brightness;

import '../themes/app_colors.dart' show AppColorSet, AppColors;

enum Status {PENDING, IN_PROGRESS, COMPLETED, CANCELLED, OTHER }

class _StatusSelection {
  final Status? status;
  final String? value;
  final String? text;
  final AppColorSet<Color>? color;

  const _StatusSelection({
    this.status,
    this.value,
    this.text,
    this.color,
  });

  factory _StatusSelection.proccess([defaultV, isNullble = false]) 
  {
    if(defaultV is _StatusSelection) return defaultV;
    defaultV = (defaultV is String)? defaultV.toUpperCase() : defaultV;
    if(['PENDING', 'قيد الانتظار', Status.PENDING, AppColors.info].contains(defaultV)) {
      return _StatusSelection(
        status: Status.PENDING,
        value: 'PENDING',
        text: 'قيد الانتظار',
        color: AppColors.info,
      );
    }
    if(['IN_PROGRESS', 'قيد التنفيذ', Status.IN_PROGRESS, AppColors.warning].contains(defaultV)) {
      return _StatusSelection(
        status: Status.IN_PROGRESS,
        value: 'IN_PROGRESS',
        text: 'قيد التنفيذ',
        color: AppColors.warning,
      );
    }
    if(['COMPLETED', 'مكتملة', Status.COMPLETED, AppColors.success].contains(defaultV)) {
      return _StatusSelection(
        status: Status.COMPLETED,
        value: 'COMPLETED',
        text: 'مكتملة',
        color: AppColors.success,
      );
    }
    if(['CANCELLED', 'ملغاة', Status.CANCELLED, AppColors.accent].contains(defaultV)) {
      return _StatusSelection(
        status: Status.CANCELLED,
        value: 'CANCELLED',
        text: 'ملغاة',
        color: AppColors.accent,
      );
    }

    if(isNullble is _StatusSelection) return isNullble;

    return _StatusSelection(
      status: isNullble == true? null : Status.OTHER,
      value: isNullble == true? null : 'OTHER' ,
      text: isNullble == true? null : 'أخرى',
      color: isNullble == true? null : AppColors.primary,
    );

  }

}

extension StatusExtensionS on String? 
{
  Status status([defaultV]) {
    final self = _StatusSelection.proccess(this, _StatusSelection.proccess(defaultV, true));
    if(self.status != null) return self.status!;
    throw Exception('Invalid status: $this');
  }

  Status tryStatus([defaultV = Status.OTHER]) 
  {
    return _StatusSelection.proccess(
      this, _StatusSelection.proccess(
        defaultV, _StatusSelection(
          status: Status.OTHER
        )
      )
    ).status!;

  }

}

extension StatusExtension on Status? 
{
  String value([defaultV]) 
  {
    final self = _StatusSelection.proccess(this, _StatusSelection.proccess(defaultV, true));
    if(self.value != null) return self.value!;
    throw Exception('Invalid status: $this'); 
  }

  String tryValue([ defaultV ='PENDING' ]) 
  {
    return _StatusSelection.proccess(
      this, _StatusSelection.proccess(
        defaultV, _StatusSelection(
          value: 'PENDING'
        )
      )
    ).value!;

  }


  String text([ defaultV]) {
    final self = _StatusSelection.proccess(this, _StatusSelection.proccess(defaultV, true));
    if(self.text != null) return self.text!;
    throw Exception('Invalid status: $this'); 
  }

  String tryText([ defaultV = 'أخرى']) 
  {
    return _StatusSelection.proccess(
      this, _StatusSelection.proccess(
        defaultV, _StatusSelection(
          text: 'أخرى'
        )
      )
    ).text!;
  }

  Color color(Brightness brightness, {defaultV}) {
    final self = _StatusSelection.proccess(this, _StatusSelection.proccess(defaultV, true));
    if(self.color != null) return self.color!.getByBrightness(brightness);
    throw Exception('Invalid status: $this'); 
  }

  Color tryColor(Brightness brightness, {defaultV =  AppColors.primary}) {
   return _StatusSelection.proccess(
      this, _StatusSelection.proccess(
        defaultV, _StatusSelection(
          color: AppColors.primary
        )
      )
    ).color!.getByBrightness(brightness);
  }

  // CONFIRMED, PENDING, IN_PROGRESS, COMPLETED, CANCELLED
  bool get isPENDING => this == Status.PENDING;
  bool get isIN_PROGRESS => this == Status.IN_PROGRESS;
  bool get isCOMPLETED => this == Status.COMPLETED;
  bool get isCANCELLED => this == Status.CANCELLED; 

  bool isIn(List statuses){
    for (var status in statuses) {
      if( _StatusSelection.proccess(status, true).status != null) return true;
    }
    return false;
  }

  bool notIn(List statuses){
    return !isIn(statuses);
  }
  
}
class StatusTools
{
  static Status parse<K>(value, {defaultV, K? keys}){
    if(value is Map || value is List){
      
      for(var key in (keys is Iterable ? keys : [keys]))
      {
        try {
          final v = _StatusSelection.proccess(value[key], true).status;
          if(v != null) return v;
        } catch (e) {}
      }
    }
    final v = _StatusSelection.proccess(value,  _StatusSelection.proccess(defaultV, true)).status;
    if(v != null) return v;
    throw Exception('Invalid status: $value');
  }

  static Status tryParse<K>(value, {defaultV = Status.PENDING, K? keys}){
    return parse(value, defaultV: _StatusSelection.proccess(defaultV, _StatusSelection(status: Status.PENDING)).status, keys: keys);
  }

  static List<Status> getAllStatus([bool includeOther = false]) => [
    Status.PENDING, 
    Status.IN_PROGRESS, 
    Status.COMPLETED, 
    Status.CANCELLED,
    if(includeOther) Status.OTHER
  ];

  static List<String> getAllStatusText([bool includeOther = false]) => [
    Status.PENDING.text(), 
    Status.IN_PROGRESS.text(), 
    Status.COMPLETED.text(), 
    Status.CANCELLED.text(), 
    if(includeOther) Status.OTHER.text('أخرى')
  ];

  static List<String> getAllStatusValue([bool includeOther = false]) => [
    Status.PENDING.value(), 
    Status.IN_PROGRESS.value(), 
    Status.COMPLETED.value(), 
    Status.CANCELLED.value(),
    if(includeOther) Status.OTHER.value('OTHER')
  ];
  

  static List<Color> getAllStatusColor(Brightness brightness) => [
    Status.PENDING.color(brightness), 
    Status.IN_PROGRESS.color(brightness), 
    Status.COMPLETED.color(brightness), 
    Status.CANCELLED.color(brightness), 
    Status.OTHER.tryColor(brightness)
  ];
}
