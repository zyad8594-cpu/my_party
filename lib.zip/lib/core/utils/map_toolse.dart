class _MapGet
{
  final _map;
  K firstKey<K>(keys, [K? defaultK])
  {
    if(_map is! Map<K, dynamic>? || _map == null)
    {
      throw Exception('Map is null');
    }
    
    if(keys is K)
    {
      if(_map.containsKey(keys)) return keys;
      if(defaultK != null) return defaultK;
      throw Exception('No key found');
    }
    else if(keys is Iterable<K>)
    {
      for(var key in keys)
      {
        if(_map.containsKey(key)) return key;
      }
    }
    if(defaultK != null) return defaultK;
    throw Exception('No key found');
  }

  K? tryFirstKey<K>(keys, [K? defaultK])
  {
    try {
      return firstKey<K>(keys, defaultK);
    } catch (e) {
      return defaultK;
    }
  }

  V valueByFirstKey<K, V>(keys, { K? defaultK, V? defaultV, })
  {
    final value = _map[firstKey<K>(keys, defaultK)];
    if(value == null)
    {
      if(defaultV != null) return defaultV;
      throw Exception('Value is null');
    }
    return value as V;
  }

  V? tryValueByFirstKey<K, V>(keys, { K? defaultK, V? defaultV, })
  {
    try {
      return valueByFirstKey<K, V>(keys, defaultK: defaultK, defaultV: defaultV);
    } catch (e) {
      return defaultV;
    }
  }

  const _MapGet([this._map]);
}

class _Has
{
  final _map;

  bool anyKey<K>(keys)
  {
    if(_map is! Map<K, dynamic>? || _map == null)
    {
      throw Exception('Map is null');
    }
    
    if(keys is K)
    {
      return _map.containsKey(keys);
    }
    else if(keys is Iterable<K>)
    {
      for(var key in keys)
      {
        if(_map.containsKey(key)) return true;
      }
    }
    return false;
  }

  bool allKeys<K>(keys)
  {
    if(_map is! Map<K, dynamic>? || _map == null)
    {
      throw Exception('Map is null');
    }
    
    if(keys is K)
    {
      return _map.containsKey(keys);
    }
    
    else if(keys is Iterable<K>)
    {
      for(var key in keys)
      {
        if(!_map.containsKey(key)) return false;
      }
    }
    return true;
  }

  bool anyValue<K, V>(values)
  {
    if(_map is! Map<K, dynamic>? || _map == null)
    {
      throw Exception('Map is null');
    }

    try {
      if(_map.containsValue(values as V)) return true;
    } catch (e) {}
    if(values is Iterable)
    {
      for(var value in values)
      {
        try{if(_map.containsValue(value as V)) return true;}
        catch(e){}
      }
    }
     
    return false;
  }

  bool allValues<K, V>(values)
  {
    if(_map is! Map<K, V>? || _map == null)
    {
      throw Exception('Map is null');
    }
    
    try{if(_map.containsValue(values as V)) return true;}catch(e){}
    if(values is Iterable)
    {
      for(var value in values)
      {
        try{if(!_map.containsValue(value as V)) return false;}catch(e){}
      }
    }
     
    return true;
  }
  
  const _Has([this._map]);
}

class MapToolse
{
  final _map;

  _MapGet get get =>  _MapGet(_map);

  _Has get has => _Has(_map);

  const MapToolse([this._map]);
}
