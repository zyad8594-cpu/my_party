import '../../../suppliers/data/models/supplier.dart';

class Service {
  final int id;
  final String serviceName;
  final String? description;
  final String? createdAt;
  final Set<Supplier> suppliers;

  Service({
    required this.id,
    required this.serviceName,
    this.description,
    this.createdAt,
    this.suppliers = const {},
  })
  {
    for (var supplier in this.suppliers) {
      supplier.services.add(this);
    }
  }

  factory Service.fromJson(Map<String, dynamic> json) {
    return Service(
      id: json['service_id'] ?? json['id'] ?? 0,
      serviceName: json['service_name'] ?? '',
      description: json['description'],
      createdAt: json['created_at'],
      suppliers: (json['suppliers'] as List<dynamic>?)
          ?.map((e) => Supplier.fromJson(e as Map<String, dynamic>))
          .toSet() ??
      {},
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'service_name': serviceName,
      'description': description,
    };
  }
}