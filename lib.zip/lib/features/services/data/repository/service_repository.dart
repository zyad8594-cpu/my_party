import 'package:get/get.dart';
import '../models/service.dart';
import '../../provider/service_provider.dart' show ServiceProvider;

class ServiceRepository {
  final ServiceProvider _serviceProvider = Get.find<ServiceProvider>();

  Future<List<Service>> getAll() async 
  {
    final data = await _serviceProvider.getAll();
    return data.map((e) => Service.fromJson(e)).toList();
  }

  Future<Service> getById(int id) async 
  {
    final data = await _serviceProvider.getById(id);
    return Service.fromJson(data);
  }

  Future<Service> create(Map<String, dynamic> data) async 
  {
    final response = await _serviceProvider.create(data);
    return Service.fromJson(response['result']);
  }

  Future<Service> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _serviceProvider.update(id, data);
    return Service.fromJson(response['result']);
  }

  Future<void> delete(int id) async 
  {
    await _serviceProvider.delete(id);
  }
}
