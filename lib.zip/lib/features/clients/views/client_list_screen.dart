import 'package:get/get.dart';
import 'package:flutter/material.dart' show 
  Icons, Scaffold, Column, EdgeInsets, TextStyle, FontWeight, 
  StatelessWidget, Widget, BuildContext, Theme, Container, Expanded,
  BoxDecoration, BoxShape, Icon, IconButton, FloatingActionButton, Row,
  Colors, SizedBox, CrossAxisAlignment, Text, Offset, ListView, InkWell, Material,
  BorderRadius, BoxShadow, TextField, Border, Padding, Center, MainAxisAlignment,
  ElevatedButton, RoundedRectangleBorder, OutlinedButton, BorderSide;
  

import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../../core/controllers/main_layout_controller.dart' show MainLayoutController;
import '../data/models/client.dart' show Client;
import '../controller/client_controller.dart' show ClientController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;
import '../../../core/routes/app_routes.dart' show AppRoutes;

class ClientListScreen extends StatelessWidget 
{
  ClientListScreen({super.key});
  final AuthController authController = Get.find<AuthController>();
  final MainLayoutController mainController = Get.find<MainLayoutController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final ClientController controller = Get.find<ClientController>();

    return Scaffold
    (
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        title: 'العملاء', 
        authController: authController,
        actions: [
          IconButton(
            onPressed: () {mainController.changePage(4);},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          
          const SizedBox(width: 16),
        ],
      ),

      floatingActionButton: Container
      (
        decoration: BoxDecoration
        (
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: <BoxShadow>
          [
            BoxShadow
            (
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton
        (
          onPressed: () => Get.toNamed(AppRoutes.clientAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
        ),
      ),
      
      body: Column
      (
        children: <Widget>
        [
          _buildSearchSection(controller, context),
          
          Expanded
          (
            child: Obx
            (
              () 
              {
                if (controller.isLoading.value) return const LoadingWidget();
                if (controller.filteredClients.isEmpty) return _buildEmptyState(context);
                
                return ListView.builder
                (
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  itemCount: controller.filteredClients.length,
                  itemBuilder: (context, index) 
                  {
                    final client = controller.filteredClients[index];
                    return _buildClientCard(client, context);
                  },
              );
              }
            ),
          ),
        
        ],
      ),
    );
  }

  Widget _buildSearchSection(ClientController controller, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Container
    (
      padding: const EdgeInsets.fromLTRB(20, 20, 20, 10),
      child: Row
      (
        children: <Widget>
        [
          Expanded
          (
            child: TextField
            (
              onChanged: (value) => controller.searchQuery.value = value,
              decoration: AppFormWidgets.searchDecoration('البحث عن عميل...', context),
            ),
          ),
          
          IconButton
          (
            icon: Icon
            (
              Icons.refresh_rounded, 
              color: AppColors.primary.getByBrightness(brightness)
            ),
            
            onPressed: ()=> controller.fetchClients(),
          ),
        ],
      ),
    );
  }

  Widget _buildClientCard(Client client, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container
    (
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration
      (
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: <BoxShadow>
        [
          BoxShadow
          (
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),

      child: Material
      (
        color: AppColors.transparent.getByBrightness(brightness),
        child: InkWell
        (
          onTap: client.isDeleted
              ? () => _restoreClient(client, context)
              : () => Get.toNamed(AppRoutes.clientDetail, arguments: client),
          borderRadius: BorderRadius.circular(24),
          child: Padding
          (
            padding: const EdgeInsets.all(16),
            child: Row
            (
              children: <Widget>
              [
                Container
                (
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration
                  (
                    color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon
                  (
                    Icons.person_rounded,
                    color: AppColors.primary.getByBrightness(brightness),
                    size: 30,
                  ),
                ),
                const SizedBox(width: 16),

                Expanded
                (
                  child: Column
                  (
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>
                    [
                      Text
                      (
                        client.name.isNotEmpty
                            ? client.name
                            : 'عميل بدون اسم',
                        style: TextStyle
                        (
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                          color: client.isDeleted
                              ? AppColors.textSubtitle.getByBrightness(brightness)
                              : AppColors.textBody.getByBrightness(brightness),
                        ),
                      ),
                      const SizedBox(height: 4),

                      Row
                      (
                        children: <Widget>
                        [
                          Icon
                          (
                            Icons.phone_rounded,
                            size: 14,
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                          ),
                          const SizedBox(width: 4),

                          Text
                          (
                            client.phoneNumber,
                            style: TextStyle
                            (
                              fontSize: 13,
                              color: AppColors.textSubtitle.getByBrightness(brightness),
                            ),
                          ),
                        
                        ],
                      ),
                    
                    ],
                  ),
                ),
                _buildActionButtons(client, context),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildActionButtons(Client client, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Row
    (
      children: client.isDeleted ? 
      [
        // IconButton
        // (
        //   icon: Container
        //   (
        //       padding: const EdgeInsets.all(6),
        //       decoration: BoxDecoration
        //       (
        //         color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
        //         borderRadius: BorderRadius.circular(8),
        //       ),
        //       child: const Icon
        //       (
        //         Icons.restore_from_trash_rounded,
        //         color: AppColors.primary.getByBrightness(brightness),
        //         size: 18,
        //       ),
        //   ),
        //   onPressed: () => _restoreClient(client, context),
        // ),
      ] : 
      [
        IconButton
        (
          icon: Container
          (
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration
            (
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon
            (
              Icons.edit_rounded,
              color: AppColors.warning.getByBrightness(brightness),
              size: 18,
            ),
          ),
          onPressed: ()=> Get.toNamed(AppRoutes.clientAdd, arguments: client),
        ),
        
        IconButton
        (
          icon: Container
          (
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration
            (
              color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon
            (
              Icons.delete_rounded,
              color: AppColors.accent.getByBrightness(brightness),
              size: 18,
            ),
          ),
          onPressed: () => _delete(client.id, context),
        ),
      
      ],
    );
  }

  Widget _buildEmptyState(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Center
    (
      child: Column
      (
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>
        [
          Container
          (
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration
            (
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),
            child: Icon
            (
              Icons.people_outline_rounded,
              size: 80,
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
            ),
          ),
          const SizedBox(height: 24),

          Text
          (
            'لا يوجد عملاء مضافين',
            style: TextStyle
            (
              color: AppColors.textSubtitle.getByBrightness(brightness),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),

          Text
          (
            'اضغط على زر الإضافة لإضافة عميل جديد',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        
        ],
      ),
    );
  }

  void _delete(int id, BuildContext context) async 
  {
    final brightness = Theme.of(context).brightness;
    final ClientController controller = Get.find<ClientController>();

    Get.defaultDialog
    (
      title: 'تأكيد الحذف',
      titleStyle: TextStyle
      (
        color: AppColors.primary.getByBrightness(brightness),
        fontWeight: FontWeight.bold,
      ),
      middleText: 'هل أنت متأكد من حذف هذا العميل؟',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: Colors.white,
      radius: 20,
      confirm: ElevatedButton
      (
        onPressed: () 
        {
          Get.back();
          controller.deleteClient(id);
        },
        style: ElevatedButton.styleFrom
        (
          backgroundColor: AppColors.accent.getByBrightness(brightness),
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('نعم، احذف', style: TextStyle(color: AppColors.w_b.getByBrightness(brightness))),
      ),
      cancel: OutlinedButton
      (
        onPressed: () => Get.back(),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }

  void _restoreClient(Client client, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final ClientController controller = Get.find<ClientController>();

    Get.defaultDialog
    (
      title: 'تأكيد الاستعادة',
      titleStyle: TextStyle
      (
        color: AppColors.primary.getByBrightness(brightness),
        fontWeight: FontWeight.bold,
      ),
      middleText: 'هل أنت متأكد من استعادة هذا العميل؟',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: AppColors.w_b.getByBrightness(brightness),
      radius: 20,
      confirm: ElevatedButton
      (
        onPressed: () 
        {
          Get.back();
          controller.restoreClient(client.id);
        },
        style: ElevatedButton.styleFrom
        (
          backgroundColor: AppColors.primary.getByBrightness(brightness),
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('نعم، استعد', style: TextStyle(color: AppColors.w_b.getByBrightness(brightness))),
      ),
      cancel: OutlinedButton
      (
        onPressed: () => Get.back(),
        style: OutlinedButton.styleFrom
        (
          side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
          shape: RoundedRectangleBorder
          (
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }
}
