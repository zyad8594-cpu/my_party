import 'package:get/get.dart';
import '../data/repository/client_repository.dart' show ClientRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/client.dart' show Client;

class ClientController extends GetxController 
{
  final ClientRepository _repository = Get.find<ClientRepository>();

  final name = ''.obs;
  final phone = ''.obs;
  final email = ''.obs;
  final address = ''.obs;

  final clients = <Client>[].obs;
  final searchQuery = ''.obs;
  final selectedClient = Rxn<Client>();
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();

    fetchClients();
  }

  void clearFields() {
    name.value = '';
    phone.value = '';
    email.value = '';
    address.value = '';
  }

  void populateFields(Client client) {
    name.value = client.name;
    phone.value = client.phoneNumber;
    email.value = client.email ?? '';
    address.value = client.address ?? '';
  }

  List<Client> get filteredClients {
    if (searchQuery.isEmpty) return clients;
    return clients.where((c) {
      return c.name.toLowerCase().contains(
            searchQuery.value.toLowerCase(),
          ) ||
          c.phoneNumber.contains(searchQuery.value);
    }).toList();
  }

  Future<void> fetchClients() async {
    isLoading.value = true;
    try {
      final list = await _repository.getAll();
      clients.value = list;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchClient(int id) async {
    isLoading.value = true;
    try {
      final client = await _repository.getById(id);
      selectedClient.value = client;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createClient() async {
    isLoading.value = true;
    try {
      final data = {
        'full_name': name.value,
        'phone_number': phone.value,
        'email': email.value,
        'address': address.value,
      };
      final response = await _repository.create(data);
      clients.add(response);
      Get.back();
      utils.showSnackbar('نجاح', 'تم إضافة العميل');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateClient(int id) async {
    isLoading.value = true;
    try {
      final data = {
        'full_name': name.value,
        'phone_number': phone.value,
        'email': email.value,
        'address': address.value,
      };
      final updated = await _repository.update(id, data);
      final index = clients.indexWhere((c) => c.id == id);
      if (index != -1) clients[index] = updated;
      selectedClient.value = updated;
      Get.back();
      utils.showSnackbar('نجاح', 'تم تحديث البيانات');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteClient(int id) async {
    try {
      await _repository.delete(id);
      final index = clients.indexWhere((c) => c.id == id);
      if (index != -1) {
        clients[index] = clients[index].copyWith(isDeleted: true);
      }

      utils.showSnackbar('نجاح', 'تم حذف العميل');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    }
  }

  Future<void> restoreClient(int id) async {
    try {
      isLoading.value = true;
      await _repository.restore(id);
      final index = clients.indexWhere((c) => c.id == id);
      if (index != -1) {
        clients[index] = clients[index].copyWith(isDeleted: false);
      }

      utils.showSnackbar('نجاح', 'تم استعادة العميل');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  @override
  void onClose() {
    super.onClose();
  }
}
