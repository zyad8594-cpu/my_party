
import 'package:my_party/data/models/user.dart';

import '../../../events/data/models/event.dart';

class Client extends User
{
  final String? address;
  @override
  final String phoneNumber;
  final List<Event> events;
  
  Client({
    required super.id, 
    required super.name, 
    super.email,
    required this.phoneNumber, 
    super.imgUrl, 
    super.isActive,
    super.isDeleted,
    super.createdAt,
    super.updatedAt,
    this.address,
    this.events = const [],
  }):super(role: 'CLIENT')
  {
    var i = 0;
    for (var event in this.events) {
      this.events[i] = event.copyWith(client: this);
      i++;
    }
  }

  factory Client.fromJson(json) {
    return Client(
      id: json['id'] ?? 0,
      name: json['full_name'] ?? '',
      email: json['email'],
      phoneNumber: json['phone_number'],
      imgUrl: json['img_url'],
      isActive: json['is_active'] ?? false,
      isDeleted: json['is_deleted'] ?? false,
      address: json['address'],
      createdAt: json['created_at'] ?? '',
      updatedAt: json['updated_at'] ?? '',
      events: (json['events'] as List?)
          ?.map((e) => Event.fromJson(e)).toList() ?? [],
    );
  }

  @override
  toJson() {
    return {...super.toJson(), 'address': address, 'events': events.map((e) => e.toJson()).toList()};
  }
  @override
  Client copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    String? address,
    List<Event>? events,
  }) {
    return Client(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      imgUrl: imgUrl ?? this.imgUrl,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      address: address ?? this.address,
      events: events ?? this.events,
    );
  }

}
