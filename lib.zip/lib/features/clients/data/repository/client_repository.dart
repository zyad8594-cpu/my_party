import 'package:get/get.dart';
import '../models/client.dart';
import '../../provider/client_provider.dart' show ClientProvider;

class ClientRepository 
{
  final ClientProvider _clientProvider = Get.find<ClientProvider>();

  Future<List<Client>> getAll() async 
  {
    final data = await _clientProvider.getAll();
    return data.map((e) => Client.fromJson(e)).toList();
  }

  Future<Client> getById(int id) async 
  {
    final data = await _clientProvider.getById(id);
    return Client.fromJson(data);
  }

  Future<Client> create(Map<String, dynamic> data) async 
  {
    final response = await _clientProvider.create(data);
    // response قد تحتوي على id فقط، فنعيد السجل كاملاً بعد إنشائه
    return Client.fromJson(response['user']);
  }

  Future<Client> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _clientProvider.update(id, data);
    return Client.fromJson(response['user']);
  }

  Future<void> delete(int id) async 
  {
    await _clientProvider.delete(id);
  }

  Future<void> restore(int id) async 
  {
    await _clientProvider.restore(id);
  }
}
