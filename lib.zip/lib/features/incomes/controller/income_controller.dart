import 'package:get/get.dart';
import '../data/repository/income_repository.dart' show IncomeRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/income.dart' show Income;

class IncomeController extends GetxController
{
  final IncomeRepository _repository = Get.find<IncomeRepository>();

  final incomes = <Income>[].obs;
  final selectedIncome = Rxn<Income>();
  final isLoading = false.obs;

  // Reactive state for Income Add/Edit
  final eventIdRx = 0.obs;
  final amountRx = 0.0.obs;
  final paymentMethodRx = 'نقداً'.obs; // Default
  final paymentDateRx = DateTime.now().obs;
  final descriptionRx = ''.obs;

  // final amountController = TextEditingController();
  // final descriptionController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    fetchIncomes();
  }

  void clearFields() {
    eventIdRx.value = 0;
    amountRx.value = 0.0;
    paymentMethodRx.value = 'نقداً';
    paymentDateRx.value = DateTime.now();
    descriptionRx.value = '';
  }

  void populateFields(Income income) {
    eventIdRx.value = income.eventId;
    amountRx.value = income.amount;
    paymentMethodRx.value = income.paymentMethod ?? 'نقداً';
    paymentDateRx.value =
        DateTime.tryParse(income.paymentDate) ?? DateTime.now();
    descriptionRx.value = income.description ?? '';
  }

  Future<void> fetchIncomes() async {
    isLoading.value = true;
    try {
      final list = await _repository.getAll();
      incomes.value = list;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchIncome(int id) async {
    isLoading.value = true;
    try {
      final income = await _repository.getById(id);
      selectedIncome.value = income;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createIncome() async 
  {
    if (eventIdRx.value == 0) {
      utils.showSnackbar('تنبيه', 'يرجى اختيار المناسبة', isError: true);
      return;
    }
    isLoading.value = true;
    try {
      final data = {
        'event_id': eventIdRx.value,
        'amount': amountRx.value,
        'payment_method': paymentMethodRx.value,
        'payment_date': paymentDateRx.value.toIso8601String(),
        'description': descriptionRx.value,
      };
      final newIncome = await _repository.create(data);
      incomes.add(newIncome);
      Get.back();
      utils.showSnackbar('نجاح', 'تم إضافة الدفعة');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateIncome(int id) async {
    isLoading.value = true;
    try {
      final data = {
        'event_id': eventIdRx.value,
        'amount': amountRx.value,
        'payment_method': paymentMethodRx.value,
        'payment_date': paymentDateRx.value.toIso8601String(),
        'description': descriptionRx.value,
      };
      final updated = await _repository.update(id, data);
      final index = incomes.indexWhere((c) => c.id == id);
      if (index != -1) incomes[index] = updated;
      selectedIncome.value = updated;
      Get.back();
      utils.showSnackbar('نجاح', 'تم تحديث الدفعة');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteIncome(int id) async {
    try {
      await _repository.delete(id);
      incomes.removeWhere((c) => c.id == id);
      if (selectedIncome.value?.id == id) {
        selectedIncome.value = null;
      }
      utils.showSnackbar('نجاح', 'تم حذف الدفعة');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    }
  }
}
