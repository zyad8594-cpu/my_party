import 'package:get/get.dart';
import '../models/income.dart';
import '../../provider/income_provider.dart' show IncomeProvider;

class IncomeRepository 
{
  final IncomeProvider _incomeProvider = Get.find<IncomeProvider>();

  Future<List<Income>> getAll() async 
  {
    final data = await _incomeProvider.getAll();
    return data.map((e) => Income.fromJson(e)).toList();
  }

  Future<Income> getById(int id) async 
  {
    final data = await _incomeProvider.getById(id);
    return Income.fromJson(data);
  }

  Future<Income> create(Map<String, dynamic> data) async 
  {
    final response = await _incomeProvider.create(data);
    return Income.fromJson(response['result']);
  }

  Future<Income> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _incomeProvider.update(id, data);
    return Income.fromJson(response['result']);
  }

  Future<void> delete(int id) async 
  {
    await _incomeProvider.delete(id);
  }
}
