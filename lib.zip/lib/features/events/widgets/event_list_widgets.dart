import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:my_party/core/utils/status.dart';
import '../data/models/event.dart' show Event;
import '../controller/event_controller.dart' show EventController;
import '../../../core/themes/app_colors.dart' show AppColors, AppColorSet;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;

class EventListWidgets {
  static void showDeleteDialog(
    BuildContext context,
    int id,
    EventController controller,
  ) {
    final brightness = Theme.of(context).brightness;
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      titleStyle: TextStyle(
        color: AppColors.primary.getByBrightness(brightness),
        fontWeight: FontWeight.bold,
      ),
      middleText: 'هل أنت متأكد من حذف هذه المناسبة؟',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: AppColors.background.getByBrightness(brightness),
      radius: 20,
      confirm: ElevatedButton(
        onPressed: () {
          Get.back();
          controller.deleteEvent(id);
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accent.getByBrightness(brightness),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Text('نعم، احذف', style: TextStyle(color: Colors.white)),
      ),
      cancel: OutlinedButton(
        onPressed: () => Get.back(),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }
}

class EventSearchAndFilters extends StatelessWidget {
  final EventController controller;

  const EventSearchAndFilters({super.key, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          TextField(
            onChanged: (value) => controller.searchQuery.value = value,
            decoration: AppFormWidgets.searchDecoration('البحث عن مناسبة...', context),
          ),
          const SizedBox(height: 16),

          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: ['الكل', 'مجدولة', 'مؤكدة', 'قيد التنفيذ', 'مكتملة', 'ملغاة'].map((status) 
              {
                return Obx(() {
                  final isSelected = controller.selectedStatus.value == status;
                  return Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: ChoiceChip(
                      label: Text(status),
                      selected: isSelected,
                      onSelected: (selected) {
                        if (selected) controller.selectedStatus.value = status;
                      },

                      selectedColor: AppColors.primary.getByBrightness(brightness),
                      labelStyle: TextStyle(
                        color: isSelected ? 
                          AppColors.textBody.getByBrightness(brightness) : 
                          AppColors.textBody.getByBrightness(brightness).withValues(alpha: 0.5) ,
                        fontWeight: isSelected
                            ? FontWeight.bold
                            : FontWeight.normal,
                      ),
                      backgroundColor: AppColors.searchBarFillColor.getByBrightness(brightness),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      showCheckmark: false,
                    ),
                  );
                });
              }).toList(),
            ),
          ),
        ],
      ),
    );
  }
}

class EventCard extends StatelessWidget {
  final Event event;
  final EventController controller;

  const EventCard({super.key, required this.event, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final statusColor = event.status.tryColor(brightness);
    final statusText = event.status.tryText();

    return Container
    (
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration
      (
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        boxShadow: 
        [
          BoxShadow
          (
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
        border: Border.all
        (
          color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.05),
          width: 1,
        ),
      ),

      /**
       *         بطاقة المناسبة
       */
      child: Material
      (
        color: AppColors.transparent.getByBrightness(brightness),
        child: InkWell
        (
          // عند الظغط على البطاقة نذهب الى صفحة تفاصيل المناسبة
          onTap: () => Get.toNamed(AppRoutes.eventDetail, arguments: event),
          borderRadius: BorderRadius.circular(24), // جعل الحواف دائرية
          child: Padding
          (
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                // حاوية ايقونة المناسبة
                _eventCardIcon(),
                const SizedBox(width: 16),

                // بقية المعلومات
                _buildEventCardBody(event, brightness, statusText: statusText, statusColor: statusColor),
                
                _buildActionButtons([
                  _buildActionButton(context, 'تعديل', 
                    icon: Icons.edit, 
                    color: AppColors.warning, 
                    onTap: ()=>Get.toNamed(AppRoutes.eventAdd, arguments: event,),
                  ),
                  _buildActionButton(context, 'حذف', 
                    icon: Icons.delete, 
                    color: AppColors.accent, 
                    onTap: ()=>EventListWidgets.showDeleteDialog(context, event.id, controller,)
                  )
                ])
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _eventCardIcon({
    Icon? icon,
    Color? color,
    double width = 60,
    double height = 60,
    double iconSize = 30,
    
  })
  {
    return Container
                (
                  width: width,
                  height: height,
                  decoration: BoxDecoration
                  (
                    color: color?.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(20),
                  ),

                  /**
                   *         ايقونة المناسبة
                   */
                  child: icon ?? Icon
                  (
                    Icons.celebration_rounded,
                    color: color,
                    size: iconSize,
                  ),
                );
  }

  Widget _buildEventCardBody(Event event, Brightness brightness, {
    required String statusText,
    required Color statusColor,
  })
  {
    return Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      //  اسم المناسبة وحالتها
                      _buildDetailOnEventCard(
                        event.nameEvent,
                        brightness, fontSize: 16, fontWeight: FontWeight.bold,
                        textColor: AppColors.textBody,
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        //  حالة المناسبة
                        children: [_buildStatusBadge(statusText, statusColor),]
                      ),
                      const SizedBox(height: 8),

                      //  إسم العميل
                      _buildDetailOnEventCard(
                        event.client.name,
                        brightness,
                        icon: Icons.person_rounded,
                      ),
                      //  مكان المناسبة
                      _buildDetailOnEventCard(
                        event.location ?? 'غير محدد',
                        brightness,
                        icon: Icons.location_on_rounded,
                      ),
                      // تأريخ المناسبة
                      _buildDetailOnEventCard(
                          DateFormat('yyyy/MM/dd','ar',).format(DateTime.tryParse(event.eventDate) ?? DateTime.now()),
                          brightness, 
                          icon: Icons.calendar_month_rounded,
                          isExpanded: false
                        ),
                      
                    ],
                  ),
                );
  }
  //         حالة المناسبة
  Widget _buildStatusBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  Widget _buildDetailOnEventCard(
    String text, Brightness brightness,{
      IconData? icon, 
      bool isExpanded = true,
      double fontSize = 12,
      FontWeight? fontWeight,
      double iconSize = 14,
      AppColorSet<Color>? iconColor,
      AppColorSet<Color>? textColor,
      TextOverflow textOverflow = TextOverflow.ellipsis,
      MainAxisAlignment mainAxisAlignment = MainAxisAlignment.start,
      List<Widget> children = const <Widget>[]
  })
  {
    final textWidget =  Text(text,
      style: TextStyle(
        fontSize: fontSize,
        fontWeight: fontWeight,
        color: (textColor ?? AppColors.textSubtitle).getByBrightness(brightness),
      ),
      overflow: textOverflow,
    );
            
    return  Row(
      mainAxisAlignment: mainAxisAlignment,
      children: [
        if (icon != null) Icon(icon, size: iconSize,
          color: (iconColor ?? AppColors.textSubtitle).getByBrightness(brightness),
        ),
        if(icon != null) const SizedBox(width: 4),
        isExpanded ? Expanded(child: textWidget) : textWidget,
        ...children,
      ]
    );
  }

  Widget _buildActionButtons(List<PopupMenuItem<String>> items)
  {
    return PopupMenuButton<String>(
        icon: Icon(Icons.more_vert),
        itemBuilder: (BuildContext context) => items,
    );
  }

  PopupMenuItem<String> _buildActionButton(
    BuildContext context, 
    String value, {
      IconData? icon, AppColorSet<Color>? color, 
      double iconSize = 18, 
      double? fontSize,
      void Function()? onTap
    })
  {
    final brightness = Theme.of(context).brightness;
    return PopupMenuItem<String>(
              value: value,
              onTap: onTap,
              child:  Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: [
                  if (icon != null)Icon(icon, color: color?.getByBrightness(brightness), size: iconSize),
                  Text(value, style: TextStyle(fontSize: fontSize, color: color?.getByBrightness(brightness))),
                ],
              ),
            );
  }

}




//         حالة عدم وجود مناسبات
class EventEmptyState extends StatelessWidget {
  const EventEmptyState({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),

            /**
             *         ايقونة عدم وجود مناسبات
             */
            child: Icon(
              Icons.event_busy_rounded,
              size: 80,
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
            ),
          ),
          const SizedBox(height: 24),

          /**
           *         عنوان عدم وجود مناسبات
           */
          Text(
            'لا توجد مناسبات مسجلة',
            style: TextStyle(
              color: AppColors.textSubtitle.getByBrightness(brightness),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),

          /**
           *         وصف عدم وجود مناسبات
           */
          Text(
            'اضغط على زر الإضافة لإضافة مناسبة جديدة',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        ],
      ),
    );
  }
}
  