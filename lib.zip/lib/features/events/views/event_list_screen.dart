import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../controller/event_controller.dart' show EventController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../widgets/event_list_widgets.dart' show EventSearchAndFilters, EventEmptyState, EventCard;
import '../../../core/controllers/main_layout_controller.dart' show MainLayoutController;

class EventListScreen extends StatelessWidget 
{
  EventListScreen({super.key});
  final EventController controller = Get.find<EventController>();
  final MainLayoutController mainController = Get.find<MainLayoutController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),

      /**
       *         شريط العنوان
       */
      appBar: CustomAppBar(
        authController: authController, 
        title: 'المناسبات',
        actions: [
          IconButton(
            onPressed: () => mainController.changePage(4),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          
          const SizedBox(width: 16),
        ],
      ),

      /**
       *         زر إضافة مناسبة
       */
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: () => Get.toNamed(AppRoutes.eventAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: Icon(Icons.add_rounded, color: AppColors.w_b.getByBrightness(brightness), size: 30),
        ),
      ),

      /**
       *         جسم الصفحة
       */
      body: Column(
        children: [

          /**
           *         شريط البحث والفلاتر
           */
          EventSearchAndFilters(controller: controller),

          /**
           *         قائمة المناسبات
           */
          Expanded(
            child: Obx(() {

              /**
               *         حالة التحميل
               */
              if (controller.isLoading.value) {
                return const LoadingWidget();
              }

              var filteredEvents = controller.filteredEvents;

              /**
               *         حالة عدم وجود مناسبات
               */
              if (filteredEvents.isEmpty) {
                return const EventEmptyState();
              }

              /**
               *         قائمة المناسبات
               */
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: filteredEvents.length,
                itemBuilder: (context, index) {
                  final event = filteredEvents[index];
                  // بطاقة عرض المناسبة
                  return EventCard(event: event, controller: controller);
                },
              );
            }),
          ),
        ],
      ),
    );
  }
}
