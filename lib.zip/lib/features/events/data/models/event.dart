import '../../../../core/utils/status.dart';
import '../../../clients/data/models/client.dart' show Client;
import '../../../coordinators/data/models/coordinator.dart' show Coordinator;
import '../../../tasks/data/models/task.dart' show Task;

class Event {
  final int id;
  final Client client;
  final String nameEvent;
  final String? description;
  final String eventDate;
  final String? location;
  final double budget;
  final Status status;
  final String createdAt;
  final Coordinator coordinator;
  final bool isDeleted;
  final List<Task> tasks;

  Event({
    required this.id,
    required this.client,
    required this.coordinator,
    required this.nameEvent,
    required this.eventDate,
    this.description,
    this.location,
    this.budget = 0.0,
    this.status = Status.PENDING,
    this.createdAt = '',
    this.isDeleted = false,
    this.tasks = const [],
  });

  factory Event.fromJson(Map<String, dynamic> json) {
    return Event(
      id: json['event_id'] ?? json['id'] ?? 0,
      client: Client.fromJson(json['client']),
      coordinator: Coordinator.fromJson(json['coordinator']),
      nameEvent:  json['event_name'] ?? json['name_event'] ?? json['nameEvent'] ?? json['name'] ?? '',
      description: json['description'],
      eventDate: json['event_date'] ?? json['eventDate'] ?? '',
      location: json['location'],
      budget: json['budget'] ?? 0.0,
      status: StatusTools.parse(json['status'] ?? json['event_status']),
      createdAt: json['created_at'] ?? json['createdAt'],
      isDeleted: json['is_deleted'] ?? json['isDeleted'],
      tasks: (json['tasks'] as List<dynamic>?)?.map(
          (e) => Task.fromJson(e)).toList() ?? const [],
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': id,
      'client_id': client.id,
      'coordinator_id': coordinator.id,
      'client': client.toJson(),
      'coordinator': coordinator.toJson(),
      'event_name': nameEvent,
      'description': description,
      'event_date': eventDate,
      'location': location,
      'budget': budget,
      'status': status.value('PENDING'),
      'is_deleted': isDeleted,
      'tasks': tasks.map((e) => e.toJson()).toList(),
    };
  }

  Event copyWith({
    int? id,
    Client? client,
    Coordinator? coordinator,
    String? nameEvent,
    String? description,
    String? eventDate,
    String? location,
    double? budget,
    Status? status,
    String? createdAt,
    String? clientName,
    String? coordinatorName,
    bool? isDeleted,
    List<Task>? tasks,
  }) {
    return Event(
      id: id ?? this.id,
      client: client ?? this.client,
      coordinator: coordinator ?? this.coordinator,
      nameEvent: nameEvent ?? this.nameEvent,
      description: description ?? this.description,
      eventDate: eventDate ?? this.eventDate,
      location: location ?? this.location,
      budget: budget ?? this.budget,
      status: status ?? this.status,
      createdAt: createdAt ?? this.createdAt,
      isDeleted: isDeleted ?? this.isDeleted,
      tasks: tasks ?? this.tasks,
    );
  }
}
