import 'package:get/get.dart';
import '../models/event.dart' show Event;
import '../../provider/event_provider.dart' show EventProvider;

class EventRepository 
{
  final EventProvider _eventProvider = Get.find<EventProvider>();

  Future<List<Event>> getAll() async 
  {
    final data = await _eventProvider.getAll();
    return data.map((e) => Event.fromJson(e)).toList();
  }

  Future<Event> getById(int id) async 
  {
    final data = await _eventProvider.getById(id);
    return Event.fromJson(data);
  }

  Future<Event> create(event) async 
  {
    final response = await _eventProvider.create(event);
    return Event.fromJson(response['result']);
  }

  Future<Event> update(int id, event) async 
  {
    final response = await _eventProvider.update(id, event);
    return Event.fromJson(response['result']);
  }

  Future<void> delete(int id) async 
  {
    await _eventProvider.delete(id);
  }
}
