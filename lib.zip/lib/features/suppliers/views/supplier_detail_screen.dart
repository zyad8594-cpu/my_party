import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../data/models/supplier.dart' show Supplier;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;

class SupplierDetailScreen extends StatelessWidget 
{
  SupplierDetailScreen({super.key});
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final Supplier supplier = Get.arguments;

    return Scaffold(
      appBar: CustomAppBar(authController: authController,showBackButton: true, title: supplier.name),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              _buildProfileHeader(supplier, brightness),
              const SizedBox(height: 32),
              _buildInfoSection(supplier, brightness),
              const SizedBox(height: 40),
              _buildActions(context, supplier, brightness),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(Supplier supplier, Brightness brightness) {
    return Column(
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient.getByBrightness(brightness),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: const Center(
            child: Icon(
              Icons.store_mall_directory_outlined,
              size: 64,
              color: Colors.black,
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          supplier.name,
          style: const TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        Text(
          'مزود خدمات معتمد',
          style: TextStyle(color: AppColors.primary.getByBrightness(brightness), fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildInfoSection(Supplier supplier, Brightness brightness) {
    return Column(
      children: [
        _buildInfoCard(
          Icons.email_outlined,
          'البريد الإلكتروني',
          supplier.email,
          brightness,
        ),
        const SizedBox(height: 16),
        _buildInfoCard(Icons.phone_outlined, 'رقم الهاتف', supplier.phoneNumber??'', brightness),
        const SizedBox(height: 16),
        _buildInfoCard(
          Icons.notes_outlined,
          'ملاحظات',
          supplier.notes ?? 'لا توجد ملاحظات',
          brightness,
        ),
      ],
    );
  }

  Widget _buildInfoCard(IconData icon, String label, String value, Brightness brightness) {
    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary.getByBrightness(brightness)),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                    fontSize: 12,
                  ),
                ),
                Text(
                  value,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildActions(BuildContext context, Supplier supplier, Brightness brightness) {
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.edit, size: 18),
            label: const Text('تعديل'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.surface.getByBrightness(brightness),
              foregroundColor: AppColors.primary.getByBrightness(brightness),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.message_outlined, size: 18),
            label: const Text('مراسلة'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary.getByBrightness(brightness),
              foregroundColor: AppColors.w_b.getByBrightness(brightness),
            ),
          ),
        ),
      ],
    );
  }
}
