import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;
import '../controller/supplier_controller.dart' show SupplierController;
import '../data/models/supplier.dart' show Supplier;

class SupplierAddScreen extends StatelessWidget 
{
  SupplierAddScreen({super.key});

  final SupplierController controller = Get.find<SupplierController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final Supplier? supplier = Get.arguments as Supplier?;
    final isEditing = supplier != null;

    if (isEditing) {
      controller.populateFields(supplier);
    } else {
      controller.clearFields();
    }

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        authController: authController,
        showBackButton: true,
        title: isEditing ? 'تعديل بيانات المورد' : 'إضافة مورد جديد',
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isEditing ? 'تحديث المعلومات' : 'البيانات الأساسية للمورد',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
            const SizedBox(height: 16),
            GlassCard(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  TextFormField(
                    initialValue: isEditing ? supplier.name : null,
                    onChanged: (val) => controller.nameRx.value = val,
                    decoration: AppFormWidgets.fieldDecoration('اسم المورد', Icons.storefront_rounded, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? supplier.email : null,
                    onChanged: (val) => controller.emailRx.value = val,
                    keyboardType: TextInputType.emailAddress,
                    decoration: AppFormWidgets.fieldDecoration('البريد الإلكتروني', Icons.email_outlined, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? supplier.phoneNumber : null,
                    onChanged: (val) => controller.phoneRx.value = val,
                    keyboardType: TextInputType.phone,
                    decoration: AppFormWidgets.fieldDecoration('رقم الهاتف', Icons.phone_outlined, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? supplier.address : null,
                    onChanged: (val) => controller.addressRx.value = val,
                    decoration: AppFormWidgets.fieldDecoration('العنوان', Icons.location_on_outlined, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? supplier.notes : null,
                    onChanged: (val) => controller.notesRx.value = val,
                    maxLines: 3,
                    decoration: AppFormWidgets.fieldDecoration('ملاحظات إضافية', Icons.notes_rounded, context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Obx(
              () => GradientButton(
                text: isEditing ? 'حفظ التعديلات' : 'إضافة',
                isLoading: controller.isLoading.value,
                onPressed: () {
                  if (controller.nameRx.value.isEmpty) {
                    Get.snackbar(
                      'تنبيه',
                      'يرجى إدخال اسم المورد',
                      backgroundColor: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                      colorText: AppColors.accent.getByBrightness(brightness),
                      icon: Icon(Icons.warning_amber_rounded, color: AppColors.accent.getByBrightness(brightness)),
                    );
                    return;
                  }
                  if (isEditing) {
                    controller.updateSupplier(supplier.id);
                  } else {
                    controller.createSupplier();
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
