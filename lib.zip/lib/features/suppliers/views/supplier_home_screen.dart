import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../controller/supplier_dashboard_controller.dart' show SupplierDashboardController;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../widgets/supplier_dashboard_widgets.dart' show SupplierActiveTasksList, SupplierEmptyTasksState, SupplierGreeting, SupplierStatsGrid;

class SupplierDashboardScreen extends StatelessWidget {
  SupplierDashboardScreen({super.key});
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final SupplierDashboardController controller = Get.put(
      SupplierDashboardController(),
    );

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        authController: authController,
        title: 'لوحة التحكم',
        actions: [
          IconButton(
            onPressed: () => Get.toNamed(AppRoutes.notifications),
            icon: Icon(
              Icons.notifications_none_rounded,
              color: AppColors.textBody.getByBrightness(brightness),
            ),
          ),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          const SizedBox(width: 8),
          IconButton(
            onPressed: () {
              Get.toNamed(AppRoutes.profile);
            },
            icon: CircleAvatar(
              radius: 18,
              backgroundImage: NetworkImage(
                authController.currentUser['img_url'] ?? '',
              ),
            ),
          ),
          const SizedBox(width: 16),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const LoadingWidget();
        }
        return RefreshIndicator(
          onRefresh: () async => controller.refreshDashboard(),
          color: AppColors.primary.getByBrightness(brightness),
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              SupplierGreeting(authUser: controller.authUser),
              const SizedBox(height: 24),
              SupplierStatsGrid(controller: controller),
              const SizedBox(height: 32),
              _buildSectionHeader('المهام الحالية', 'عرض الكل', brightness),
              const SizedBox(height: 16),
              if (controller.activeTasks.isEmpty)
                const SupplierEmptyTasksState()
              else
                SupplierActiveTasksList(controller: controller),
              const SizedBox(height: 40),
            ],
          ),
        );
      }),
    );
  }

  Widget _buildSectionHeader(String title, String action, Brightness brightness) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.bold,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
        TextButton(
          onPressed: () => Get.toNamed('/tasks'),
          child: Text(
            action,
            style: TextStyle(
              fontSize: 13,
              color: AppColors.primary.getByBrightness(brightness),
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
      ],
    );
  }
}
