import '../../../../data/models/user.dart';
import '../../../services/data/models/service.dart' show Service;
import '../../../tasks/data/models/task.dart';

class Supplier extends User
{
  final String password;
  final String? address;
  final String? notes;
  final List<Service> services;
  final List<Task> tasks;
  

  @override
  final String email;

  Supplier({
    required super.id,
    required super.name,
    required this.email,
    super.phoneNumber,
    super.imgUrl,
    super.isActive = false,
    super.isDeleted = false,
    super.createdAt = '',
    super.updatedAt = '',
    this.services = const [],
    this.tasks = const [],
    required this.password,
    this.address,
    this.notes,
  }): super(role: 'SUPPLIER', email: email)
  {
    for (var service in this.services) {
      service.suppliers.add(this);
    }
  }

  factory Supplier.fromJson(json) {
    return Supplier(
      id: json['supplier_id'] ?? json['id'] ?? json['user_id'] ?? 0,
      imgUrl: json['img_url'],
      name: json['name'] ?? json['full_name'] ?? '',
      email: json['email'] ?? '',
      password: json['password'] ?? '',
      phoneNumber: json['phone'] ?? json['phone_number'],
      address: json['address'],
      notes: json['notes'],
      createdAt: json['created_at'],
      services: (json['services'] as List?)
          ?.map((e) => Service.fromJson(e))
          .toList() ??
      [],
      tasks: (json['tasks'] as List?)
          ?.map((e) => Task.fromJson(e))
          .toList() ??
      [],
    );
  }

  @override
  toJson() {
    return {
      'supplier_id': id,
      'img_url': imgUrl,
      'full_name': name,
      'email': email,
      'password': password,
      'phone_number': phoneNumber,
      'address': address,
      'notes': notes,
      'services': services.map((e) => e.toJson()).toList(),
      'tasks': tasks.map((e) => e.toJson()).toList(),
    };
  }

  @override
  Supplier copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    String? password,
    String? address,
    String? notes,
    List<Service>? services,
    List<Task>? tasks,
  }) {
    return Supplier(
      id: id ?? this.id,
      name: name ?? this.name,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      email: email ?? this.email,
      password: password ?? this.password,
      imgUrl: imgUrl ?? this.imgUrl,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      address: address ?? this.address,
      notes: notes ?? this.notes,
      services: services ?? this.services,
      tasks: tasks ?? this.tasks,
    );
  }
}
