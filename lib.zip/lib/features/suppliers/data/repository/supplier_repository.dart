import 'package:get/get.dart';
import '../models/supplier.dart';
import '../../provider/supplier_provider.dart' show SupplierProvider;

class SupplierRepository 
{
  final SupplierProvider _supplierProvider = Get.find<SupplierProvider>();

  Future<List<Supplier>> getAll() async 
  {
    final data = await _supplierProvider.getAll();
    
    return data.map((e) => Supplier.fromJson(e)).toList();
  }

  Future<Supplier> getById(int id) async 
  {
    final data = await _supplierProvider.getById(id);
    return Supplier.fromJson(data);
  }

  Future<Supplier> create(Map<String, dynamic> data) async 
  {
    final response = await _supplierProvider.create(data);
    // response قد تحتوي على id فقط، فنعيد السجل كاملاً بعد إنشائه
    return Supplier.fromJson(response);
  }

  Future<Supplier> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _supplierProvider.update(id, data);
    return Supplier.fromJson(response);
  }

  Future<void> delete(int id) async 
  {
    await _supplierProvider.delete(id);
  }



  // Future<List<Supplier>> getAllByServiceId(int serviceId) async 
  // {
  //   final data = await _supplierProvider.getAllByServiceId(serviceId);
  //   return data.map((e) => Supplier.fromJson(e)).toList();
  // }

  // Future<Supplier> getByIdAndServiceId(int id, int serviceId) async 
  // {
  //   final res =  await _supplierProvider.getByIdAndServiceId(id, serviceId);
  //   return Supplier.fromJson(res);
  // }

  Future<void> assignServiceToSupplier(int supplierId, int serviceId) async
  {
    await _supplierProvider.assignServiceToSupplier(supplierId, serviceId);
  }

  Future<void> deleteService(int id, int serviceId) async
  {
    await _supplierProvider.deleteService(id, serviceId);
  }
  
  Future<void> clearAllServices(int id) async
  {
    await _supplierProvider.clearAllServices(id);
  }
  


  Future<List<dynamic>> getNotifications(int id) async 
  {
    return await _supplierProvider.getNotifications(id);
  }

  Future<List<dynamic>> getNotification(int id, int notificationId) async 
  {
    return await _supplierProvider.getNotification(id, notificationId);
  }


  Future<void> deleteNotification(int id, int notificationId) async
  {
    await _supplierProvider.deleteNotification(id, notificationId);
  }
  
  
  Future<void> clearAllNotifications(int id) async
  {
    await _supplierProvider.clearAllNotifications(id);
  }
  
}
