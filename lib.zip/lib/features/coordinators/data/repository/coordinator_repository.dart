import 'package:get/get.dart';
import '../models/coordinator.dart' show Coordinator;
import '../../provider/coordinator_provider.dart' show CoordinatorProvider;

class CoordinatorRepository 
{
  final CoordinatorProvider _provider = Get.find<CoordinatorProvider>();

  Future<List<Coordinator>> getAll() async 
  {
    final data = await _provider.getAll();
    return data.map((e) => Coordinator.fromJson(e)).toList();
  }

  Future<Coordinator> getById(int id) async 
  {
    final data = await _provider.getById(id);
    return Coordinator.fromJson(data);
  }

  Future<Coordinator> create(Map<String, dynamic> data) async 
  {
    final response = await _provider.create(data);
    return Coordinator.fromJson(response);
  }

  Future<Coordinator> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _provider.update(id, data);
    return Coordinator.fromJson(response);
  }

  Future<void> delete(int id) async 
  {
    await _provider.delete(id);
  }



  Future<List<dynamic>> getNotifications(int id) async 
  {
    return await _provider.getNotifications(id);
  }

  Future<List<dynamic>> getNotification(int id, int notificationId) async 
  {
    return await _provider.getNotification(id, notificationId);
  }


  Future<void> deleteNotification(int id, int notificationId) async
  {
    await _provider.deleteNotification(id, notificationId);
  }
  
  
  Future<void> clearAllNotifications(int id) async
  {
    await _provider.clearAllNotifications(id);
  }
}
