import '../../../../data/models/user.dart';
import '../../../events/data/models/event.dart' show Event;

class Coordinator extends User
{
  final String password; 
  final List<Event> events;
  @override
  final String email;

  Coordinator({
    required super.id,
    required super.name,
    required this.email,
    super.phoneNumber,
    super.imgUrl,
    required this.password,
    super.isActive,
    super.isDeleted,
    super.createdAt,
    super.updatedAt,
    this.events = const [],
  }): super(role: 'COORDINATOR', email: email)
  {
    var i = 0;
    for (var event in this.events) {
      this.events[i] = event.copyWith(coordinator: this);
      i++;
    }
  }
  

  factory Coordinator.fromJson(json) {
    return Coordinator(
      id: json['coordinator_id'] ??
          json['coordinatorId'] ??
          json['id'] ??
          json['user_id'] ??
          0,
      name: json['full_name'] ?? json['fullName'] ?? json['name'] ?? '',
      phoneNumber: json['phone_number'] ?? json['phoneNumber'],
      email: json['email'] ?? '',
      password: json['password'] ?? '',
      imgUrl: json['imgUrl'] ?? json['img_url'],
      createdAt: json['created_at'] ?? json['createdAt'],
      updatedAt: json['updated_at'] ?? json['updatedAt'],
      isActive: json['is_active'] ?? json['isActive'],
      isDeleted: json['is_deleted'] ?? json['isDeleted'],
      events: (json['events'] as List?)
          ?.map((e) => Event.fromJson(e))
          .toList() ??
      [],
    );
  }

  @override
  toJson() {
    return {...super.toJson(), 'password': password, 'events': events.map((e) => e.toJson()).toList()};
  }
  
  @override
  Coordinator copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    String? password,
    List<Event>? events,
  }) {
    return Coordinator(
      id: id ?? this.id,
      name: name ?? this.name,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      email: email ?? this.email,
      password: password ?? this.password,
      imgUrl: imgUrl ?? this.imgUrl,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      events: events ?? this.events,
    );
  }

}
