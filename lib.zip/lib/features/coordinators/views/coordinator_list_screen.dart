import 'package:flutter/material.dart' show 
  StatelessWidget, BuildContext, Widget, Theme, Scaffold, ListView, EdgeInsets, 
  BoxDecoration, BoxShadow, Icon, Container, Center, Text, TextStyle, FontWeight, 
  SizedBox, InkWell, Row, Expanded, IconButton, Colors, Offset, 
  BoxShape, BorderRadius, FloatingActionButton, Icons,
  Padding, Column, CrossAxisAlignment, MainAxisAlignment, MainAxisSize;
  
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../data/models/coordinator.dart' show Coordinator;
import '../controller/coordinator_controller.dart' show CoordinatorController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;

class CoordinatorListScreen extends StatelessWidget {
  CoordinatorListScreen({super.key});

  final CoordinatorController controller = Get.find<CoordinatorController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Scaffold(
      appBar: CustomAppBar(authController: authController, title: 'قائمة المنسقين'),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: () => Get.toNamed(AppRoutes.coordinatorAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: Obx(() {
          if (controller.isLoading.value) {
            return const LoadingWidget();
          }
          if (controller.coordinators.isEmpty) {
            return _buildEmptyState(context);
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: controller.coordinators.length,
            itemBuilder: (context, index) {
              final coordinator = controller.coordinators[index];
              return _buildCoordinatorCard(coordinator, context);
            },
          );
        }),
      ),
    );
  }

  Widget _buildCoordinatorCard(Coordinator coordinator, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: AppFormWidgets.cardDecoration(context),
      child: InkWell(
        onTap: () =>
            Get.toNamed(AppRoutes.coordinatorDetail, arguments: coordinator),
        borderRadius: BorderRadius.circular(20),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              Container(
                width: 50,
                height: 50,
                decoration: BoxDecoration(
                  gradient: AppColors.primaryGradient.getByBrightness(brightness),
                  shape: BoxShape.circle,
                ),
                child: Center(
                  child: Text(
                    coordinator.name.isNotEmpty
                        ? coordinator.name.substring(0, 1).toUpperCase()
                        : '?',
                    style: TextStyle(
                      color: AppColors.w_b.getByBrightness(brightness),
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      coordinator.name,
                      style: TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textBody.getByBrightness(brightness),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      coordinator.email,
                      style: TextStyle(
                        fontSize: 12,
                        color: AppColors.textSubtitle.getByBrightness(brightness),
                      ),
                    ),
                  ],
                ),
              ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.edit_rounded,
                        color: AppColors.warning.getByBrightness(brightness),
                        size: 18,
                      ),
                    ),
                    onPressed: () => Get.toNamed(
                      AppRoutes.coordinatorAdd,
                      arguments: coordinator,
                    ),
                  ),
                  const SizedBox(width: 4),
                  IconButton(
                    icon: Container(
                      padding: const EdgeInsets.all(6),
                      decoration: BoxDecoration(
                        color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Icon(
                        Icons.delete_rounded,
                        color: AppColors.accent.getByBrightness(brightness),
                        size: 18,
                      ),
                    ),
                    onPressed: () => _delete(coordinator.id, context),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.person_off_outlined,
            size: 80,
            color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'لا يوجد منسقين حالياً',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 18),
          ),
        ],
      ),
    );
  }

  void _delete(int id, BuildContext context) async 
  {
    final brightness = Theme.of(context).brightness;
    
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      titleStyle: TextStyle(color: AppColors.primary.getByBrightness(brightness)),
      middleText: 'هل أنت متأكد من حذف هذا المنسق؟',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      textConfirm: 'نعم',
      textCancel: 'لا',
      confirmTextColor: AppColors.textBody.getByBrightness(brightness),
      cancelTextColor: AppColors.primary.getByBrightness(brightness),
      buttonColor: AppColors.primary.getByBrightness(brightness),
      onConfirm: () {
        Get.back();
        controller.delete(id);
      },
    );
  }
}
