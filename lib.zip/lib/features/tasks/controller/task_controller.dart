import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../data/repository/task_repository.dart' show TaskRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/task.dart' show Task;
import '../../suppliers/data/models/supplier.dart' show Supplier;

class TaskController extends GetxController 
{
  final TaskRepository _repository = Get.find<TaskRepository>();
  final AuthController authController = Get.find<AuthController>();

  // Reactive state for Task Add/Edit
  final typeRx = ''.obs;
  final descriptionRx = ''.obs;
  final costRx = 0.0.obs;
  final eventIdRx = 0.obs;
  final assignmentTypeRx = 'COORDINATOR'.obs;
  final assignmentFlowRx = 'myself'.obs;
  final selectedSupplierForNewTaskRx = Rxn<Supplier>();
  final assigneeIdRx = RxnInt();
  final startDateRx = DateTime.now().obs;
  final dueDateRx = DateTime.now().add(const Duration(days: 7)).obs;

  final tasks = <Task>[].obs;
  final searchQuery = ''.obs;
  final selectedStatus = 'الكل'.obs;
  final selectedFilterTab = 'كل المهام'.obs; // 'كل المهام', 'مهامي', 'مهام الموردين'
  final selectedTask = Rxn<Task>();
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchTasks();
  }

  void clearFields() {
    typeRx.value = '';
    descriptionRx.value = '';
    costRx.value = 0.0;
    eventIdRx.value = 0;
    assignmentTypeRx.value = 'COORDINATOR';
    assignmentFlowRx.value = 'myself';
    selectedSupplierForNewTaskRx.value = null;
    assigneeIdRx.value = null;
    startDateRx.value = DateTime.now();
    dueDateRx.value = DateTime.now().add(const Duration(days: 7));
  }

  void populateFields(Task task) {
    typeRx.value = task.typeTask!;
    descriptionRx.value = task.taskAssign?.description ?? '';
    costRx.value = task.taskAssign?.cost ?? 0.0;  
    eventIdRx.value = task.event.id;
    assignmentTypeRx.value = task.taskAssign?.assigned.role ?? 'COORDINATOR';
    if (task.taskAssign?.assigned.role == 'COORDINATOR') {
      assignmentFlowRx.value = 'myself';
      selectedSupplierForNewTaskRx.value = null;
    } else {
      assignmentFlowRx.value = 'supplier_by_service';
      // If we are editing and have a supplier, we might need to fetch it to show name,
      // but if the task object doesn't have supplier details, that's fine.
    }
    assigneeIdRx.value = task.taskAssign?.assigned.role == 'SUPPLIER'
        ? task.taskAssign?.assigned.id
        : task.creator.id;
    startDateRx.value = task.dateStart != null
        ? DateTime.parse(task.dateStart!)
        : DateTime.now();
    dueDateRx.value = task.dateDue != null
        ? DateTime.parse(task.dateDue!)
        : DateTime.now();
  }

  List<Task> get filteredTasks {
    return tasks.where((t) {
      // 1. Filter by Search Query
      final matchesSearch =
          t.typeTask!.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
          (t.taskAssign?.description?.toLowerCase().contains(
                searchQuery.value.toLowerCase(),
              ) ??
              false);
      if (!matchesSearch) return false;

      // 2. Filter by Tab (All, My, Vendor)
      bool matchesTab = true;
      if (selectedFilterTab.value == 'مهامي') {
        matchesTab = t.taskAssign?.assigned.role == 'COORDINATOR' && 
                     t.creator.id == authController.currentUser['user_id'];
      } else if (selectedFilterTab.value == 'مهام الموردين') {
        matchesTab = t.taskAssign?.assigned.role == 'SUPPLIER';
      }
      if (!matchesTab) return false;

      // 3. Filter by Status
      if (selectedStatus.value == 'الكل') return true;

      final taskStatusArabic = t.status.text;
      return taskStatusArabic == selectedStatus.value;
    }).toList();
  }

  Future<void> rateTask(int taskId, int rating, String? comment) async {
    isLoading.value = true;
    try {
      await _repository.rate(taskId, rating, comment);
      utils.showSnackbar('نجاح', 'تم تقييم المهمة بنجاح');
      fetchTasks(); // Refresh tasks to reflect any status changes if needed, 
                   // though rating doesn't necessarily change status.
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchTasks() async {
    isLoading.value = true;
    try {
      final list = await _repository.getAll();
      tasks.value = list;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> fetchTask(int id) async {
    isLoading.value = true;
    try {
      final task = await _repository.getById(id);
      selectedTask.value = task;
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> createTask() async {
    isLoading.value = true;
    try {
      final coordinatorId = authController.currentUser['user_id'];
      final data = {
        'event_id': eventIdRx.value,
        'coordinator_id': coordinatorId,
        'type_task': typeRx.value,
        'status': 'PENDING',
        'date_start': startDateRx.value.toIso8601String(),
        'date_due': dueDateRx.value.toIso8601String(),
        'notes': '',
        'user_assign_id': (assignmentTypeRx.toUpperCase() == 'COORDINATOR')? coordinatorId : assigneeIdRx.value,
        'description': descriptionRx.value,
        'cost': costRx.value,
        'url_image': '',
      };
      print({...data, 'assignmentTypeRx': assignmentTypeRx.value, 'assignmentFlowRx': assignmentFlowRx.value});
      final newTask = await _repository.create(data);
      tasks.add(newTask);
      Get.back();
      utils.showSnackbar('نجاح', 'تم إضافة المهمة');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateTask(int id, {Status? currentStatus}) async {
    isLoading.value = true;
    try {
      final data = {
        'type_task': typeRx.value,
        'status': currentStatus ?? selectedTask.value?.status ?? Status.PENDING,
        'date_start': startDateRx.value.toIso8601String(),
        'date_due': dueDateRx.value.toIso8601String(),
        'assign_description': descriptionRx.value,
        'assign_cost': costRx.value,
        'assign_notes': '',
        'assign_url_image': '',
      };
      final updated = await _repository.update(id, data);
      final index = tasks.indexWhere((c) => c.id == id);
      if (index != -1) tasks[index] = updated;
      selectedTask.value = updated;
      Get.back();
      utils.showSnackbar('نجاح', 'تم تحديث المهمة');
      clearFields();
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateTaskStatus(int id, String status) async {
    isLoading.value = true;
    try {
      final data = {'status': status};
      final updated = await _repository.update(id, data);
      final index = tasks.indexWhere((c) => c.id == id);
      if (index != -1) tasks[index] = updated;
      if (selectedTask.value?.id == id) {
        selectedTask.value = updated;
      }
      utils.showSnackbar('نجاح', 'تم تحديث حالة المهمة');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> deleteTask(int id) async {
    try {
      await _repository.delete(id);
      tasks.removeWhere((c) => c.id == id);
      if (selectedTask.value?.id == id) {
        selectedTask.value = null;
      }
      utils.showSnackbar('نجاح', 'تم حذف المنسق');
    } catch (e) {
      utils.showSnackbar('خطأ', e.toString(), isError: true);
    }
  }
}
