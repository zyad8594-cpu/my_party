import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/api/auth_service.dart';
import 'task_list_screen.dart';
import '../../suppliers/views/supplier_task_list_screen.dart';

class RoleBasedTaskListScreen extends StatelessWidget {
  const RoleBasedTaskListScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final authService = Get.find<AuthService>();
    final role = authService.user['role_name'];

    if (role == 'supplier') {
      return SupplierTaskListScreen();
    } else {
      return TaskListScreen();
    }
  }
}
