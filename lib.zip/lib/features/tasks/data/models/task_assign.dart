import '../../../../data/models/user.dart';
import 'task.dart';

class TaskAssign {
  final int id;
  final Task task;
  final User assigned;
  final String? description;
  final double cost;
  final String? notes;
  final String? urlImage;
  final String? reminderType;
  final int? reminderValue;
  final String? reminderUnit;
  TaskAssign({
    required this.id,
    required this.task,
    required this.assigned,
    this.description,
    this.cost = 0.0,
    this.notes,
    this.urlImage,
    this.reminderType,
    this.reminderValue,
    this.reminderUnit,
  })
  {
    if((assigned.role == 'COORDINATOR' && assigned.id != task.creator.id) || assigned.role != 'SUPPLIER'){
      throw Exception('Invalid task assignment');
    }
    this.task.taskAssign = this;
  }

  factory TaskAssign.fromJson(json) {
    return TaskAssign(
      id: json['id'] ?? 0,
      task: Task.fromJson(json['task'] ?? {}),
      assigned: User.fromJson(json['assigned'] ?? {}),
      description: json['description'],
      cost: json['cost'],
      notes: json['notes'],
      urlImage: json['url_image'],
      reminderType: json['reminder_type'],
      reminderValue: json['reminder_value'],
      reminderUnit: json['reminder_unit'],
    );
  }

  toJson() {
    return {
      'id': id,
      'task_id': task.id,
      'task': task.toJson(),
      'user_assigne_id': assigned.id,
      'assigned': assigned.toJson(),
      'description': description,
      'cost': cost,
      'notes': notes,
      'url_image': urlImage,
      'reminder_type': reminderType,
      'reminder_value': reminderValue,
      'reminder_unit': reminderUnit,
    };
  }

  TaskAssign copyWith({
    int? id,
    Task? task,
    User? assigned,
    String? description,
    double? cost,
    String? notes,
    String? urlImage,
    String? reminderType,
    int? reminderValue,
    String? reminderUnit,
  }) {
    return TaskAssign(
      id: id ?? this.id,
      task: task ?? this.task,
      assigned: assigned ?? this.assigned,
      description: description ?? this.description,
      cost: cost ?? this.cost,
      notes: notes ?? this.notes,
      urlImage: urlImage ?? this.urlImage,
      reminderType: reminderType ?? this.reminderType,
      reminderValue: reminderValue ?? this.reminderValue,
      reminderUnit: reminderUnit ?? this.reminderUnit,
    );
  }
}