
import '../../../../core/utils/status.dart';
import '../../../coordinators/data/models/coordinator.dart' show Coordinator;
import '../../../events/data/models/event.dart' show Event;
import 'task_assign.dart';

class Task {
  final int id;
  final Event event;
  final Coordinator creator;
  final String? typeTask;
  final Status status; 
  final String? dateStart;
  final String? dateDue;
  final String? dateCompletion;
  final String createdAt;
  TaskAssign? taskAssign;

  Task({
    required this.id,
    required this.event,
    required this.creator,
    this.typeTask,
    this.status = Status.PENDING,
    this.dateStart,
    this.dateDue,
    this.dateCompletion,
    this.createdAt = '',
    this.taskAssign,
  });
  Task copyWith({
  int? id,
  Event? event,
  Coordinator? creator,
  String? typeTask,
  Status? status, 
  String? dateStart,
  String? dateDue,
  String? dateCompletion,
  String? createdAt,
  TaskAssign? taskAssign,
  }){
    return Task(
      id: id ?? this.id,
      event: event ?? this.event,
      creator: creator ?? this.creator,
      typeTask: typeTask ?? this.typeTask,
      status: status ?? this.status, 
      dateStart: dateStart ?? this.dateStart,
      dateDue: dateDue ?? this.dateDue,
      dateCompletion: dateCompletion ?? this.dateCompletion,
      createdAt: createdAt ?? this.createdAt,
      taskAssign: taskAssign ?? this.taskAssign,
    );
  }

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      id: json['task_id'] ?? json['id'] ?? 0,
      event: Event.fromJson(json['event']),
      creator: Coordinator.fromJson(json['creator']),
      typeTask: json['type_task'],
      status: StatusTools.tryParse(json, keys: ['status', 'task_status']),
      dateStart: json['date_start'],
      dateDue: json['date_due'],
      dateCompletion: json['date_completion'],
      createdAt: json['created_at'],
      taskAssign: TaskAssign.fromJson(json['task_assign']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': event.id,
      'event': event,
      'coordinator_id': creator.id,
      'coordinator': creator,
      'type_task': typeTask,
      'status': status.tryValue(),
      'date_start': dateStart,
      'date_due': dateDue,
      'date_completion': dateCompletion,
      'created_at': createdAt,
      'task_assign': taskAssign?.toJson(),
    };
  }
}
