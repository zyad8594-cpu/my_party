import 'package:get/get.dart';
import '../models/task.dart';
import '../../provider/task_provider.dart' show TaskProvider;

class TaskRepository 
{
  final TaskProvider _apiProvider = Get.find<TaskProvider>();

  Future<List<Task>> getAll() async 
  {
    final data = await _apiProvider.getAll();
    return data.map((e) => Task.fromJson(e)).toList();
  }

  Future<Task> getById(int id) async 
  {
    final data = await _apiProvider.getById(id);
    return Task.fromJson(data);
  }

  Future<Task> create(Map<String, dynamic> data) async 
  {
    final response = await _apiProvider.create(data);
    return Task.fromJson(response['result']);
  }

  Future<Task> update(int id, Map<String, dynamic> data) async 
  {
    final response = await _apiProvider.update(id, data);
    return Task.fromJson(response['result']);
  }

  Future<void> delete(int id) async 
  {
    await _apiProvider.delete(id);
  }

  Future<Map<String, dynamic>> rate(int id, int value, String? comment) async 
  { 
    return await _apiProvider.rate(id, value, comment);
  }
}
