import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:my_party/core/utils/status.dart';
import '../data/models/task.dart' show Task;
import '../controller/task_controller.dart' show TaskController;
import '../../../core/themes/app_colors.dart' show AppColors;

class TaskDetailWidgets 
{
  


  static Widget buildInfoCard(
    BuildContext context, {
    required String title,
    required IconData icon,
    required Widget child,
  }) 
  {
    final brightness = Theme.of(context).brightness;
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: AppColors.primary.getByBrightness(brightness), size: 20),
              const SizedBox(width: 12),
              Text(
                title,
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: AppColors.primary.getByBrightness(brightness),
                ),
              ),
            ],
          ),
          const SizedBox(height: 20),
          child,
        ],
      ),
    );
  }
}

class TaskDetailHeader extends StatelessWidget {
  final Task task;

  const TaskDetailHeader({super.key, required this.task});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final statusColor = task.status.color(brightness);
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 20,
            offset: const Offset(0, 10),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: statusColor.withValues(alpha: 0.1),
              shape: BoxShape.circle,
            ),
            child: Icon(Icons.assignment_rounded, color: statusColor, size: 32),
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  task.typeTask!,
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textBody.getByBrightness(brightness),
                  ),
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 12,
                    vertical: 6,
                  ),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Text(
                    task.status.tryText(),
                    style: TextStyle(
                      color: statusColor,
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class TaskDetailGrid extends StatelessWidget {
  final Task task;

  const TaskDetailGrid({super.key, required this.task});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Column(
      children: [
        Row(
          children: [
            Expanded(
              child: _buildSmallDetailItem(
                Icons.event_rounded,
                'المناسبة',
                task.event.nameEvent,
                brightness,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildSmallDetailItem(
                Icons.attach_money_rounded,
                'التكلفة',
                '${task.taskAssign?.cost ?? 0} ر.س',
                brightness,
              ),
            ),
          ],
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildSmallDetailItem(
                Icons.person_rounded,
                task.taskAssign?.assigned.role == 'SUPPLIER' ? 'المورد' : 'المسؤول',
                (task.taskAssign?.assigned.role == 'SUPPLIER'
                        ? task.taskAssign?.assigned.name
                        : task.creator.name) ??
                    'غير معين',
                brightness,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildSmallDetailItem(
                Icons.calendar_month_rounded,
                'تاريخ الاستحقاق',
                task.dateDue != null
                    ? DateFormat(
                        'yyyy/MM/dd',
                        'ar',
                      ).format(DateTime.parse(task.dateDue!))
                    : 'غير محدد',
                brightness,
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildSmallDetailItem(IconData icon, String label, String value, Brightness brightness) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.6)),
          const SizedBox(height: 12),
          Text(
            label,
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 11),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: AppColors.textBody.getByBrightness(brightness),
              fontWeight: FontWeight.bold,
              fontSize: 13,
            ),
            overflow: TextOverflow.ellipsis,
          ),
        ],
      ),
    );
  }
}

class TaskProofOfWork extends StatelessWidget {
  final Task task;

  const TaskProofOfWork({super.key, required this.task});

  @override
  Widget build(BuildContext context) {
    return TaskDetailWidgets.buildInfoCard(
      context,
      title: 'إثبات الإنجاز',
      icon: Icons.photo_library_rounded,
      child: Container(
        height: 200,
        width: double.infinity,
        decoration: BoxDecoration(
          color: Colors.grey[100],
          borderRadius: BorderRadius.circular(16),
          image: task.taskAssign?.urlImage != null
              ? DecorationImage(
                  image: NetworkImage(task.taskAssign!.urlImage!),
                  fit: BoxFit.cover,
                )
              : null,
        ),
        child: task.taskAssign?.urlImage == null
            ? Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(
                      Icons.photo_rounded,
                      color: Colors.grey[400],
                      size: 48,
                    ),
                    const SizedBox(height: 8),
                    Text(
                      'لم يتم رفع صورة للإنجاز',
                      style: TextStyle(color: Colors.grey[500], fontSize: 12),
                    ),
                  ],
                ),
              )
            : null,
      ),
    );
  }
}

class TaskActionButtons extends StatelessWidget {
  final Task task;
  final String role;
  final TaskController controller;

  const TaskActionButtons({
    super.key,
    required this.task,
    required this.role,
    required this.controller,
  });

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    if (role == 'supplier') {
      final isPending = task.status.isPENDING;
      final isInProgress = task.status.isIN_PROGRESS;
      final isCompleted = task.status.isCOMPLETED;

      if (isCompleted) return const SizedBox.shrink();

      return SizedBox(
        width: double.infinity,
        height: 55,
        child: Container(
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(16),
          ),
          child: ElevatedButton.icon(
            onPressed: () {
              if (isPending) {
                controller.updateTaskStatus(task.id, 'in_progress');
              } else if (isInProgress) {
                controller.updateTaskStatus(task.id, 'completed');
              }
            },
            icon: Icon(
              isPending ? Icons.play_arrow_rounded : Icons.check_circle_rounded,
              color: Colors.white,
            ),
            label: Text(
              isPending ? 'بدء المهمة' : 'إكمال المهمة ورفع صورة',
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.transparent,
              shadowColor: Colors.transparent,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),
      );
    }

    return Row(
      children: [
        Expanded(
          child: OutlinedButton.icon(
            onPressed: () => Get.toNamed('/task-add', arguments: task),
            icon: const Icon(Icons.edit_rounded, size: 20),
            label: const Text('تعديل البيانات'),
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 16),
              side:  BorderSide(color: AppColors.primary.getByBrightness(brightness)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(16),
              ),
            ),
          ),
        ),
        const SizedBox(width: 16),
        if (!task.status.isCOMPLETED)
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient.getByBrightness(brightness),
                borderRadius: BorderRadius.circular(16),
              ),
              child: ElevatedButton.icon(
                onPressed: () {
                  controller.updateTaskStatus(task.id, 'completed');
                },
                icon: const Icon(Icons.check_circle_rounded, size: 20),
                label: const Text('اعتماد الإنجاز'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.transparent,
                  shadowColor: Colors.transparent,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
