import 'package:get/get.dart';
import '../../../core/api/api_service.dart' show ApiService;
import '../../../core/api/api_constants.dart' show ApiEndpoints;

class AuthProvider extends GetxService 
{
  final ApiService _service = Get.find<ApiService>();

  Future<Map<String, dynamic>> login(String email, String password) async 
  {
    final response = await _service.post(
      ApiEndpoints.login,
      data: {'email': email, 'password': password},
    );
    return Map<String, dynamic>.from(response);
  }

  Future<Map<String, dynamic>> register(Map<String, dynamic> data) async 
  {
    final response = await _service.post(ApiEndpoints.register, data: data);
    return Map<String, dynamic>.from(response);
  }
}