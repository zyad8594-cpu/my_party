import 'package:flutter/material.dart' show
  StatelessWidget, Widget, BuildContext, Theme, Scaffold,
  Stack, Positioned, Container, BoxDecoration, BoxShape, LinearGradient,
  Icons, EdgeInsets, TextStyle, FontWeight, Offset, TextButton,
  SingleChildScrollView, SizedBox, SafeArea, Center, BouncingScrollPhysics,
  Column, Hero, BoxShadow, Icon, Text, CrossAxisAlignment,
  TextAlign, TextField, TextInputType, InputDecoration, RichText, TextSpan,
  DropdownButtonFormField, DropdownMenuItem;

import 'package:get/get.dart';
import '../controller/auth_controller.dart' show AuthController;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/themes/app_colors.dart' show AppColors;

class RegisterScreen extends StatelessWidget 
{
  RegisterScreen({super.key});

  final AuthController controller = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(showBackButton: true, title: 'إنشاء حساب', authController: controller),
      body: Stack(
        children: [
          Positioned(
            bottom: -50,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppColors.secondary.getByBrightness(brightness).withValues(alpha: 0.08),
                    AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
                  ],
                ),
              ),
            ),
          ),
          
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 16),
                  Center(
                    child: Hero(
                      tag: 'register_logo',
                      child: Container(
                        padding: const EdgeInsets.all(20),
                        decoration: BoxDecoration(
                          color: AppColors.surface.getByBrightness(brightness),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                              blurRadius: 20,
                              offset: const Offset(0, 10),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.person_add_rounded,
                          size: 48,
                          color: AppColors.primary.getByBrightness(brightness),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 32),

                  Text(
                    'انضم إلينا',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: AppColors.textBody.getByBrightness(brightness),
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 8),

                  Text(
                    'ابدأ بتنظيم مناسباتك بشكل أسهل واحترافي',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 48),

                  GlassCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextField(
                          onChanged: (val) => controller.name.value = val,
                          decoration: const InputDecoration(
                            labelText: 'الاسم الكامل',
                            prefixIcon: Icon(Icons.person_outline_rounded),
                          ),
                        ),
                        const SizedBox(height: 20),

                        TextField(
                          onChanged: (val) => controller.email.value = val,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'البريد الإلكتروني',
                            hintText: 'example@mail.com',
                            prefixIcon: Icon(Icons.email_outlined),
                          ),
                        ),
                        const SizedBox(height: 20),

                        TextField(
                          onChanged: (val) => controller.phone.value = val,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(
                            labelText: 'رقم الهاتف',
                            prefixIcon: Icon(Icons.phone_outlined),
                          ),
                        ),
                        const SizedBox(height: 20),

                        TextField(
                          onChanged: (val) => controller.password.value = val,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'كلمة المرور',
                            hintText: '••••••••',
                            prefixIcon: Icon(Icons.lock_outline_rounded),
                          ),
                        ),
                        const SizedBox(height: 20),

                        Obx(
                          () => DropdownButtonFormField<String>(
                            value: controller.selectedRole.value,
                            decoration: const InputDecoration(
                              labelText: 'نوع الحساب',
                              prefixIcon: Icon(Icons.category_outlined),
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: 'coordinator',
                                child: Text('منسق حفلات'),
                              ),
                              DropdownMenuItem(
                                value: 'supplier',
                                child: Text('مزود خدمات'),
                              ),
                            ],
                            onChanged: (value) {
                              if (value != null) controller.selectedRole.value = value;
                            },
                          ),
                        ),
                        const SizedBox(height: 36),

                        Obx(
                          () => GradientButton(
                            text: 'إنشاء حساب',
                            isLoading: controller.isLoading.value,
                            onPressed: controller.register,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),

                  TextButton(
                    onPressed: () => Get.back(),
                    child: RichText(
                      text: TextSpan(
                        text: 'لديك حساب بالفعل؟ ',
                        style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontFamily: 'Cairo'),
                        children: [
                          TextSpan(
                            text: 'قم بتسجيل الدخول',
                            style: TextStyle(
                              color: AppColors.primary.getByBrightness(brightness),
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
