import 'package:flutter/material.dart' show
  StatelessWidget, Widget, BuildContext, Theme, Scaffold,
  Stack, Positioned, Container, BoxDecoration, BoxShape, LinearGradient,
  Icons, EdgeInsets, Alignment, TextStyle, FontWeight, Offset, TextButton,
  SingleChildScrollView, Align, SizedBox, SafeArea, Center, BouncingScrollPhysics,
  Column, MainAxisAlignment, Hero, BoxShadow, Icon, Text, CrossAxisAlignment,
  TextAlign, TextField, TextInputType, InputDecoration, RichText, TextSpan,
  Row, OutlinedButton, RoundedRectangleBorder, BorderRadius;
  
import 'package:get/get.dart';
import '../controller/auth_controller.dart' show AuthController;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/themes/app_colors.dart' show AppColors;

class LoginScreen extends StatelessWidget 
{
  LoginScreen({super.key});

  final AuthController controller = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    
    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      body: Stack(
        children: [
          // Background Gradient decoration
          Positioned(
            top: -100,
            right: -100,
            child: Container(
              width: 300,
              height: 300,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                    AppColors.secondary.getByBrightness(brightness).withValues(alpha: 0.05),
                  ],
                ),
              ),
            ),
          ),
          
          SafeArea(
            child: Center(
              child: SingleChildScrollView(
                padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32.0),
                physics: const BouncingScrollPhysics(),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    // Logo Section
                    Hero(
                      tag: 'app_logo',
                      child: Container(
                        padding: const EdgeInsets.all(24),
                        decoration: BoxDecoration(
                          color: AppColors.surface.getByBrightness(brightness),
                          shape: BoxShape.circle,
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.15),
                              blurRadius: 30,
                              offset: const Offset(0, 15),
                            ),
                          ],
                        ),
                        child: Icon(
                          Icons.celebration_rounded,
                          size: 64,
                          color: AppColors.primary.getByBrightness(brightness),
                        ),
                      ),
                    ),
                    const SizedBox(height: 32),

                    // titel
                    Text(
                      'MY PARTY PRO',
                      style: Theme.of(context).textTheme.titleLarge?.copyWith(
                        fontSize: 28,
                        letterSpacing: 2,
                        fontWeight: FontWeight.w900,
                        color: AppColors.textBody.getByBrightness(brightness),
                      ),
                    ),
                    const SizedBox(height: 8),

                    // sub titel
                    Text(
                      'إدارة مناسباتك بلمسة احترافية',
                      style: TextStyle(
                        color: AppColors.textSubtitle.getByBrightness(brightness),
                        fontSize: 16,
                      ),
                    ),
                    const SizedBox(height: 48),

                    // Login Card
                    GlassCard(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Text(
                            'تسجيل الدخول',
                            style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: AppColors.textBody.getByBrightness(brightness),
                            ),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 32),

                          TextField(
                            onChanged: (val) => controller.email.value = val,
                            keyboardType: TextInputType.emailAddress,
                            decoration: const InputDecoration(
                              labelText: 'البريد الإلكتروني',
                              hintText: 'example@mail.com',
                              prefixIcon: Icon(Icons.email_outlined),
                            ),
                          ),
                          const SizedBox(height: 20),

                          TextField(
                            onChanged: (val) => controller.password.value = val,
                            obscureText: true,
                            decoration: const InputDecoration(
                              labelText: 'كلمة المرور',
                              hintText: '••••••••',
                              prefixIcon: Icon(Icons.lock_outline_rounded),
                            ),
                          ),
                          const SizedBox(height: 12),

                          // forgot password button
                          Align(
                            alignment: Alignment.centerLeft, 
                            child: TextButton(
                              onPressed: () {},
                              style: TextButton.styleFrom(
                                foregroundColor: AppColors.secondary.getByBrightness(brightness),
                              ),
                              child: const Text(
                                'نسيت كلمة المرور؟',
                                style: TextStyle(
                                  fontSize: 13,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          ),
                          const SizedBox(height: 24),

                          // login button
                          Obx(
                           () => GradientButton(
                             text: 'تسجيل الدخول',
                             isLoading: controller.isLoading.value,
                             onPressed: controller.login,
                           ),
                          ),
                        ],
                      ),
                    ),
                    
                    const SizedBox(height: 32),
                    
                    // register button
                    TextButton(
                      onPressed: () => Get.toNamed(AppRoutes.register),
                      child: RichText(
                        text: TextSpan(
                          text: 'ليس لديك حساب؟ ',
                          style: TextStyle(
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                            fontFamily: 'Cairo',
                          ),
                          children: [
                            TextSpan(
                              text: 'سجل الآن',
                              style: TextStyle(
                                color: AppColors.primary.getByBrightness(brightness),
                                fontWeight: FontWeight.bold,
                                fontFamily: 'Cairo',
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),

                    const SizedBox(height: 40),
                    
                    // Quick Demo Login
                    Text(
                      '-- دخول سريع للتجربة --',
                      style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5), fontSize: 12),
                    ),
                    const SizedBox(height: 12),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        OutlinedButton.icon(
                          onPressed: () {
                            controller.email.value = 'ahmed@myparty.com';
                            controller.password.value = '123456';
                            controller.login();
                          },
                          icon: const Icon(Icons.person_rounded, size: 16),
                          label: const Text('منسق'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.textSubtitle.getByBrightness(brightness),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                        const SizedBox(width: 16),
                        OutlinedButton.icon(
                          onPressed: () {
                            controller.email.value = 'sami@myparty.com';
                            controller.password.value = '123456';
                            controller.login();
                          },
                          icon: const Icon(Icons.store_rounded, size: 16),
                          label: const Text('مورد'),
                          style: OutlinedButton.styleFrom(
                            foregroundColor: AppColors.textSubtitle.getByBrightness(brightness),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
