import 'package:flutter/material.dart' show
  StatelessWidget, Widget, BuildContext, Theme, Scaffold,
  Stack, Positioned, Container, BoxDecoration, BoxShape,
  Icons, EdgeInsets, TextStyle, FontWeight,
  SizedBox, BouncingScrollPhysics, Border,
  Column, MainAxisAlignment, Icon, Text, CrossAxisAlignment,
  OutlinedButton, RoundedRectangleBorder, BorderRadius,
  CustomScrollView, SliverAppBar, SliverToBoxAdapter, 
  FlexibleSpaceBar, StackFit, Colors, IconButton, CircleAvatar, Image, Padding,
  ListTile, Switch, ThemeMode, BorderSide, IconData;

import 'package:get/get.dart';
import '../controller/auth_controller.dart' show AuthController;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/glass_card.dart' show GlassCard;

class ProfileScreen extends StatelessWidget 
{
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final AuthController controller = Get.find<AuthController>();

    // Using GetX Obx to reactively rebuild when user data changes
    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      body: Obx(() {
        final user = controller.currentUser;
        return CustomScrollView(
          physics: const BouncingScrollPhysics(),
          slivers: [
            SliverAppBar(
              expandedHeight: 240,
              pinned: true,
              backgroundColor: AppColors.surface.getByBrightness(brightness),
              flexibleSpace: FlexibleSpaceBar(
                background: Stack(
                  fit: StackFit.expand,
                  children: [
                    Container(
                      decoration: BoxDecoration(
                        gradient: AppColors.primaryGradient.getByBrightness(brightness),
                      ),
                    ),
                    Positioned(
                      bottom: -20,
                      right: -50,
                      child: Icon(
                        Icons.celebration_rounded,
                        size: 200,
                        color: Colors.white.withValues(alpha: 0.1),
                      ),
                    ),
                    Column(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        Container(
                          padding: const EdgeInsets.all(4),
                          decoration: const BoxDecoration(
                            color: Colors.white,
                            shape: BoxShape.circle,
                          ),
                          child: CircleAvatar(
                            radius: 46,
                            backgroundColor: AppColors.primary.getByBrightness(brightness),
                            child: Image.network(
                              user['img_url'] ?? '',
                              errorBuilder: (context, error, stackTrace) {
                                return const Icon(
                                  Icons.person_rounded,
                                  size: 46,
                                  color: Colors.white,
                                );
                              },
                            ),
                          ),
                        ),
                        const SizedBox(height: 12),
                        Text(
                          user['full_name'] ?? 'مستخدم',
                          style: const TextStyle(
                            fontSize: 22,
                            fontWeight: FontWeight.bold,
                            color: Colors.white,
                          ),
                        ),
                        Text(
                          user['role_name'] == 'supplier' ? 'مزود خدمة' : (user['role_name'] == 'coordinator' ? 'منسق حفلات' : (user['role_name'] ?? '')),
                          style: TextStyle(
                            color: Colors.white.withValues(alpha: 0.8),
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                        const SizedBox(height: 24),
                      ],
                    ),
                  ],
                ),
              ),
              leading: IconButton(
                icon: const Icon(Icons.arrow_back_rounded, color: Colors.white),
                onPressed: () => Get.back(),
              ),
            ),
            SliverToBoxAdapter(
              child: Padding(
                padding: const EdgeInsets.all(24.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'المعلومات الشخصية',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textBody.getByBrightness(brightness),
                      ),
                    ),
                    const SizedBox(height: 16),
                    GlassCard(
                      padding: const EdgeInsets.all(8),
                      child: Column(
                        children: [
                          _buildProfileTile(
                            context,
                            icon: Icons.email_rounded,
                            label: 'البريد الإلكتروني',
                            value: user['email'] ?? 'غير متوفر',
                            showBorder: true,
                          ),
                          _buildProfileTile(
                            context,
                            icon: Icons.phone_rounded,
                            label: 'رقم الجوال',
                            value: user['phone'] ?? user['phone_number'] ?? 'غير متوفر',
                            showBorder: false,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 32),
                    Text(
                      'الإعدادات',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: AppColors.textBody.getByBrightness(brightness),
                      ),
                    ),
                    const SizedBox(height: 16),
                    GlassCard(
                      padding: const EdgeInsets.all(8),
                      child: ListTile(
                        leading: Container(
                          padding: const EdgeInsets.all(10),
                          decoration: BoxDecoration(
                            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Icon(Icons.dark_mode_rounded, color: AppColors.primary.getByBrightness(brightness)),
                        ),
                        title: Text(
                          'الوضع الداكن',
                          style: TextStyle(
                            fontWeight: FontWeight.w600,
                            color: AppColors.textBody.getByBrightness(brightness),
                          ),
                        ),
                        trailing: Switch(
                          value: Get.isDarkMode,
                          activeColor: AppColors.primary.getByBrightness(brightness),
                          onChanged: (value) {
                            Get.changeThemeMode(value ? ThemeMode.dark : ThemeMode.light);
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 48),
                    SizedBox(
                      width: double.infinity,
                      child: OutlinedButton.icon(
                        onPressed: () {
                          // Could add confirmation dialog here in the future
                          controller.logout();
                        },
                        icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
                        label: Text(
                          'تسجيل الخروج',
                          style: TextStyle(color: AppColors.accent.getByBrightness(brightness)),
                        ),
                        style: OutlinedButton.styleFrom(
                          padding: const EdgeInsets.symmetric(vertical: 16),
                          side: BorderSide(color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.5)),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
          ],
        );
      }),
    );
  }

  Widget _buildProfileTile(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
    required bool showBorder,
  }) {
    final brightness = Theme.of(context).brightness;
    return Container(
      decoration: BoxDecoration(
        border: showBorder
            ? Border(
                bottom: BorderSide(
                  color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1),
                  width: 1,
                ),
              )
            : null,
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, color: AppColors.primary.getByBrightness(brightness)),
        ),
        title: Text(
          label,
          style: TextStyle(
            fontSize: 12,
            color: AppColors.textSubtitle.getByBrightness(brightness),
          ),
        ),
        subtitle: Text(
          value,
          style: TextStyle(
            fontSize: 15,
            fontWeight: FontWeight.w600,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
      ),
    );
  }
}
