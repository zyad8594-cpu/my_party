import 'package:get/get.dart';
import '../../../../core/api/api_service.dart';
import '../../../../core/api/auth_service1.dart';
import '../../provider/auth_provider.dart' show AuthProvider;

class AuthRepository 
{
  final AuthProvider _authProvider = Get.find<AuthProvider>();
  final AuthService _authService = Get.find<AuthService>();

  Future<String> login(String email, String password) async 
  {
    final response = await _authProvider.login(email, password);
    final token = response['token'];
    final userData = response['user'];
    await _authService.saveAuthData(token, userData);
    Get.find<ApiService>().setToken(token);
    return userData['role_name'];
  }

  Future<Map<String, dynamic>> register(Map<String, dynamic> data) async 
  {
    return await _authProvider.register(data);
  }
}
