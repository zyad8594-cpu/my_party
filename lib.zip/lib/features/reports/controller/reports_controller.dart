import 'package:get/get.dart';
import '../../../core/utils/status.dart';
import '../../../features/events/controller/event_controller.dart';
import '../../../features/tasks/controller/task_controller.dart';
import '../../../features/incomes/controller/income_controller.dart';

class ReportsController extends GetxController {
  final isLoading = false.obs;

  // Mock data for charts
  final RxList<double> monthlyIncome = <double>[
    12000,
    15000,
    18000,
    14000,
    22000,
    25000,
    28000,
    21000,
    24000,
    30000,
    32000,
    35000,
  ].obs;

  final RxMap<String, int> taskStatusStats = <String, int>{
    'pending': 12,
    'in_progress': 8,
    'completed': 25,
    'cancelled': 3,
  }.obs;

  final RxDouble totalRevenue = 45000.0.obs;
  final RxDouble totalExpenses = 18500.0.obs;
  final RxInt activeEventsCount = 15.obs;

  @override
  void onInit() {
    super.onInit();
    refreshStatistics();
  }

  void refreshStatistics() async 
  {
    isLoading.value = true;
    // In a real app, we would fetch and aggregate data from other controllers or API
    await Future.delayed(const Duration(seconds: 1));

    // Attempt to get real data from other controllers if they are initialized
    try {
      if (Get.isRegistered<EventController>()) {
        activeEventsCount.value = Get.find<EventController>().events.length;
      }
      if (Get.isRegistered<TaskController>()) {
        final tasks = Get.find<TaskController>().filteredTasks;
        taskStatusStats['pending'] = tasks
            .where((t) => t.status.isPENDING)
            .length;
        taskStatusStats['in_progress'] = tasks
            .where((t) => t.status.isIN_PROGRESS)
            .length;
        taskStatusStats['completed'] = tasks
            .where((t) => t.status.isCOMPLETED)
            .length;
        taskStatusStats['cancelled'] = tasks
            .where((t) => t.status.isCANCELLED)
            .length;
      }
      if (Get.isRegistered<IncomeController>()) {
        final incomes = Get.find<IncomeController>().incomes;
        totalRevenue.value = incomes.fold(0, (sum, item) => sum + item.amount);
      }
    } catch (_) {}

    isLoading.value = false;
  }

  void exportReport(String type) {
    // Mock export functionality
    Get.snackbar('تصدير التقرير', 'تم بدء تصدير التقرير بصيغة $type بنجاح');
  }
}
