import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../home/controller/main_layout_controller.dart' show MainLayoutController;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../controller/reports_controller.dart' show ReportsController;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;

import '../widgets/report_stat_cards.dart' show ReportStatCards;
import '../widgets/report_income_chart.dart' show ReportIncomeChart;
import '../widgets/report_task_status_chart.dart' show ReportTaskStatusChart;
import '../widgets/report_export_section.dart' show ReportExportSection;

class ReportsScreen extends StatelessWidget 
{
  ReportsScreen({super.key});
  final AuthController authController = Get.find<AuthController>();
  final MainLayoutController mainController = Get.find<MainLayoutController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final ReportsController controller = Get.put(ReportsController());

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        authController: authController, 
        title: 'التقارير والإحصائيات',
        actions: [
          IconButton(
            onPressed: () => mainController.changePage(4),
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          
          const SizedBox(width: 16),
        ],
      ),
      body: Obx(() {
        if (controller.isLoading.value) {
          return const LoadingWidget();
        }
        return ListView(
          padding: const EdgeInsets.all(20),
          children: [
            ReportStatCards(controller: controller),
            const SizedBox(height: 24),
            ReportIncomeChart(controller: controller),
            const SizedBox(height: 24),
            ReportTaskStatusChart(controller: controller),
            const SizedBox(height: 24),
            ReportExportSection(controller: controller),
            const SizedBox(height: 40),
          ],
        );
      }),
    );
  }
}
