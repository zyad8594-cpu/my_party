import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../auth/controller/auth_controller.dart' show AuthController;

import '../controller/main_layout_controller.dart' show MainLayoutController;
import '../controller/home_controller.dart' show HomeController;

import '../widgets/home_welcome_section.dart' show HomeWelcomeSection;
import '../widgets/home_stats_grid.dart' show HomeStatsGrid;
import '../widgets/home_charts_section.dart' show HomeChartsSection;
import '../widgets/home_recent_notifications.dart' show HomeRecentNotifications;

class HomeScreen extends StatelessWidget 
{
  HomeScreen({super.key});

  final HomeController controller = Get.find<HomeController>();
  final MainLayoutController mainController = Get.find<MainLayoutController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        authController: authController,
        title: 'لوحة التحكم',
        actions: [
          IconButton(
            onPressed: () {mainController.changePage(4);},
            icon: const Icon(Icons.notifications_none_rounded),
          ),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          
          const SizedBox(width: 16),
        ],
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            HomeWelcomeSection(authController: authController),
            const SizedBox(height: 32),
            HomeStatsGrid(),
            const SizedBox(height: 32),
            const HomeChartsSection(),
            const SizedBox(height: 32),
            const HomeRecentNotifications(),
          ],
        ),
      ),
    );
  }
}
