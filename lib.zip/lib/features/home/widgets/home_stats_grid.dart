import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../controller/home_controller.dart' show HomeController;

class HomeStatsGrid extends StatelessWidget 
{
  HomeStatsGrid({super.key});

  final HomeController controller = Get.find<HomeController>();

  @override
  Widget build(BuildContext context) 
  {
    controller.onInit();
    final brightness = Theme.of(context).brightness;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: Get.width > 1200 ? 5 : (Get.width > 900 ? 4 : (Get.width > 600 ? 3 : (Get.width > 450 ? 2 : 1))),
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: Get.width > 600 ? 1.2 : (Get.width > 450 ? 1.4 : 1.8),
      children: [
        _buildStatCard(
          'المناسبات النشطة',
          controller.stats['events'].toString(), // events_active
          Icons.calendar_today_rounded,
          AppColors.primary.getByBrightness(brightness),
          brightness,
          0,
        ),
        _buildStatCard(
          'مهام قيد التنفيذ',
          controller.stats['tasks'].toString(), // tasks_in_progress
          Icons.sync_rounded,
          AppColors.info.getByBrightness(brightness),
          brightness,
          1,
        ),
        _buildStatCard(
          'مهام قيد المراجعة',
          controller.stats['tasks'].toString(), // tasks_in_review
          Icons.rate_review_rounded,
          AppColors.warning.getByBrightness(brightness),
          brightness,
          2,
        ),
        _buildStatCard(
          'مهام مكتملة',
          controller.stats['tasks'].toString(), // tasks_completed
          Icons.check_circle_rounded,
          AppColors.success.getByBrightness(brightness),
          brightness,
          3,
        ),
        _buildStatCard(
          'مواعيد قريبة',
          controller.stats['events'].toString(), // events_planned
          Icons.error_outline_rounded,
          AppColors.accent.getByBrightness(brightness),
          brightness,
          4,
        ),

        _buildStatCard(
          'الطول',
          controller.screenHeight.value.toString(),
          Icons.calendar_today_rounded,
          AppColors.primary.getByBrightness(brightness),
          brightness,
          5,
        ),
        _buildStatCard(
          'العرض',
          controller.screenWidth.value.toString(),
          Icons.calendar_today_rounded,
          AppColors.primary.getByBrightness(brightness),
          brightness,
          6,
        ),
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
    Brightness brightness,
    int index,
  ) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 600 + (index * 100)),
      curve: Curves.easeOutCubic,
      builder: (context, animValue, child) {
        return Transform.translate(
          offset: Offset(0, 30 * (1 - animValue)),
          child: Opacity(
            opacity: animValue,
            child: child,
          ),
        );
      },
      child: Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.surface.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(24),
          boxShadow: [
            BoxShadow(
              color: color.withValues(alpha: 0.1),
              blurRadius: 20,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                color: color.withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textBody.getByBrightness(brightness),
                  ),
                ),
                Text(
                  title,
                  style: TextStyle(
                    fontSize: 12,
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
