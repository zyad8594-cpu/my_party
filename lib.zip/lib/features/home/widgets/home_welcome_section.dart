import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../auth/controller/auth_controller.dart' show AuthController;

class HomeWelcomeSection extends StatelessWidget 
{
  final AuthController authController;

  const HomeWelcomeSection({super.key, required this.authController});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Obx(
          () => Text(
            'أهلاً بك، ${authController.currentUser['full_name'] ?? 'أحمد'} 👋',
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: AppColors.textBody.getByBrightness(brightness),
            ),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'إليك تحديثات أعمالك لهذا اليوم',
          style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
        ),
      ],
    );
  }
}
