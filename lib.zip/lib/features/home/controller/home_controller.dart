import 'package:get/get.dart';
import 'package:my_party/features/coordinators/controller/coordinator_controller.dart' show CoordinatorController;
import 'package:my_party/features/events/controller/event_controller.dart' show EventController;
import 'package:my_party/features/suppliers/controller/supplier_controller.dart' show SupplierController;

import '../../../core/utils/status.dart';
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../tasks/controller/task_controller.dart' show TaskController;

class HomeController extends GetxController {

  // يمكن إضافة إحصائيات أو بيانات للصفحة الرئيسية
  final TaskController taskController = Get.find<TaskController>();
  final EventController eventController = Get.find<EventController>();
  final SupplierController supplierController = Get.find<SupplierController>();
  final CoordinatorController coordinatorController = Get.find<CoordinatorController>();
  final AuthController authController = Get.find<AuthController>();
  

  final screenWidth = 0.0.obs;
  final screenHeight = 0.0.obs;
  
  @override
  void onInit() {
    super.onInit();
    screenWidth.value = Get.width;
    screenHeight.value = Get.height;
    coordinatorController.fetchAll();
    supplierController.fetchAll();
    eventController.fetchAll();
    taskController.fetchTasks();
  }
  
  RxMap<String, RxInt> get stats => {
    'coordinators': ((){ 
      return RxInt(coordinatorController.coordinators.length);})(),
    'suppliers': RxInt(supplierController.suppliers.length),
    'events': RxInt(eventController.events.length),
    'events_active': RxInt(eventController.events.where((event) => event.status.isIN_PROGRESS).length),
    'events_completed': RxInt(eventController.events.where((event) => event.status.isCOMPLETED).length),
    'events_cancelled': RxInt(eventController.events.where((event) => event.status.isCANCELLED).length),
    'tasks': RxInt(taskController.tasks.length),
    'tasks_in_progress': RxInt(taskController.tasks.where((task) => task.status.isIN_PROGRESS).length),
    'tasks_completed': RxInt(taskController.tasks.where((task) => task.status.isCOMPLETED).length),
    'tasks_pending': RxInt(taskController.tasks.where((task) => task.status.isPENDING).length),
    'tasks_cancelled': RxInt(taskController.tasks.where((task) => task.status.isCANCELLED).length),
  }.obs;


  @override
  void onClose() {
    super.onClose();
    coordinatorController.onClose();
    supplierController.onClose();
    eventController.onClose();
    taskController.onClose();
  }
}
