
 class User {
  final int id;
  final String role;
  final String name;
  final String? email;
  final String? phoneNumber;
  final String? imgUrl;
  final bool isActive;
  final bool isDeleted;
  final String createdAt;
  final String updatedAt;
  

  User({
    required this.id,
    required this.name,
    required this.role,
    required this.email,
    this.phoneNumber,
    this.imgUrl,
    this.isActive = false,
    this.isDeleted = false,
    this.createdAt = '',
    this.updatedAt = '',
  });
  
  factory User.fromJson(json) {
    return User(
      id: json['id'] ?? 0,
      name: json['full_name'] ?? '',
      role: json['role_name'] ?? '',
      email: json['email'] ?? '',
      phoneNumber: json['phone_number'],
      imgUrl: json['img_url'],
      isActive: json['is_active'] ?? false,
      isDeleted: json['is_deleted'] ?? false,
      createdAt: json['created_at'] ?? '',
      updatedAt: json['updated_at'] ?? '',
    );
  }

  toJson() {
    return {
      'id': id,
      'full_name': name,
      'role_name': role,
      'email': email,
      'phone_number': phoneNumber,
      'img_url': imgUrl,
      'is_active': isActive,
      'is_deleted': isDeleted,
      'created_at': createdAt,
      'updated_at': updatedAt,
    };
  }
  
  User copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
  })
  {
    return User(
      id: id ?? this.id,
      name: name ?? this.name,
      role: role ?? this.role,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      imgUrl: imgUrl ?? this.imgUrl,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}