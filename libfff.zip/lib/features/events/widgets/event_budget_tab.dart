import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import 'package:my_party/core/routes/app_routes.dart';
import 'package:my_party/core/utils/status.dart';
import '../../../core/utils/utils.dart' show showSnackbar;
import '../data/models/event.dart' show Event;
import '../../incomes/controller/income_controller.dart' show IncomeController;
import '../../incomes/data/models/income.dart' show Income;
import '../../../core/themes/app_colors.dart' show AppColors;

class EventBudgetTab extends StatelessWidget {
  final Event event;
  final IncomeController incomeController;

  const EventBudgetTab({
    super.key,
    required this.event,
    required this.incomeController,
  });

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Obx(() {
      final eventIncomes = incomeController.incomes
          .where((i) => i.eventId == event.id)
          .toList();
      final totalPaid = eventIncomes.fold(0.0, (sum, i) => sum + (i.amount));
      final balance = event.budget - totalPaid;

      return SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            _buildFinancialSummary(event.budget, totalPaid, balance, context),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  'سجل الدفعات',
                  style: TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textBody.getByBrightness(brightness),
                  ),
                ),
                
                TextButton.icon(
                  onPressed: (){
                    if(event.status.isIn(['plannig','confirmed', 'in_progress']))
                    {
                      Get.toNamed(AppRoutes.incomeAdd, arguments: event);
                    }
                    else
                    {
                      showSnackbar('تنبيه', 'لا يمكن إضافة دفعة لمناسبة مكتملة أو ملغاه', isError: true);
                    }
                  },
                  icon: const Icon(Icons.add_rounded, size: 18),
                  label: const Text('إضافة دفعة'),
                  style: TextButton.styleFrom(
                    foregroundColor: AppColors.textBody.getByBrightness(brightness),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            ...eventIncomes.map((income) => _buildIncomeItem(income, context)),
            if (eventIncomes.isEmpty)
              _buildEmptyState('لم يتم تسجيل أي دفعات بعد', context),
          ],
        ),
      );
    });
  }

  Widget _buildFinancialSummary(double budget, double paid, double balance, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        children: [
          _summaryRow('إجمالي الميزانية', budget, AppColors.textBody.getByBrightness(brightness), context),
          const Divider(height: 32),
          _summaryRow('المبلغ المدفوع', paid, AppColors.success.getByBrightness(brightness), context),
          const SizedBox(height: 16),
          _summaryRow(
            'المتبقي',
            balance,
            balance > 0 ? AppColors.warning.getByBrightness(brightness) : AppColors.success.getByBrightness(brightness),
            context,
          ),
        ],
      ),
    );
  }

  Widget _summaryRow(String label, double amount, Color color, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: TextStyle(
            color: AppColors.textSubtitle.getByBrightness(brightness),
            fontWeight: FontWeight.w600,
          ),
        ),
        Text(
          '${amount.toStringAsFixed(2)} ر.ي',
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 16,
          ),
        ),
      ],
    );
  }

  Widget _buildIncomeItem(Income income, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: AppColors.success.getByBrightness(brightness).withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(
              Icons.payments_rounded,
              color: AppColors.success.getByBrightness(brightness),
              size: 20,
            ),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  income.description ?? 'دفعة مالية',
                  style: const TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                  ),
                ),
                Text(
                  DateFormat(
                    'yyyy/MM/dd',
                    'ar',
                  ).format(DateTime.parse(income.paymentDate)),
                  style: TextStyle(
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                    fontSize: 11,
                  ),
                ),
              ],
            ),
          ),
          Text(
            '${income.amount.toStringAsFixed(2)} ر.س',
            style: TextStyle(
              fontWeight: FontWeight.bold,
              color: AppColors.success.getByBrightness(brightness),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(String message, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.inbox_rounded, size: 60, color: Colors.grey[300]),
            const SizedBox(height: 16),
            Text(
              message,
              style: TextStyle(
                color: AppColors.textSubtitle.getByBrightness(brightness),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
