import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;
import '../../../core/utils/status.dart';
import '../../tasks/controller/task_controller.dart';
import '../../tasks/data/models/task.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../data/models/event.dart';
import 'event_detail_widgets.dart' show buildStatusBadge;

class EventTasksTab extends StatelessWidget {
  final Event event;

  const EventTasksTab({
    super.key,
    required this.event,
  });

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final taskController = Get.find<TaskController>();

    return Obx(() {
      final eventTasks = 
      taskController.filteredTasks
          .where((t) => t.eventId == event.id)
          .toList()
          ;

      return Column(
        children: [
          _buildFilters(context, brightness),
          if (eventTasks.isEmpty)
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(horizontal: 40),
                children: [
                  if(Get.height > 750)const SizedBox(height: 40),
                  _buildEmptyState('لا توجد مهام مطابقة للبحث', brightness),
                  if(Get.height > 750)const SizedBox(height: 20),
                  
                  ElevatedButton.icon(
                    onPressed: () => Get.toNamed(AppRoutes.eventTaskAdd,
                        arguments: Get.arguments),
                    icon: const Icon(Icons.add_task_rounded),
                    label: const Text('إضافة مهمة جديدة'),
                    style: ElevatedButton.styleFrom(
                      backgroundColor:
                          AppColors.primary.getByBrightness(brightness),
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ] ,
              ),
            )
          else
            Expanded(
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 20),
                itemCount: eventTasks.length,
                itemBuilder: (context, index) {
                  final task = eventTasks[index];
                  return _buildTaskItem(context, task, brightness);
                },
              ),
            ),
        ],
      );
    });
  }

  /// بناء شريط البحث والفلترة
  Widget _buildFilters(BuildContext context, Brightness brightness) {
    final controller = Get.find<TaskController>();
    return Padding(
      padding: const EdgeInsets.all(20.0),
      child: Column(
        children: [
          /// مربع البحث
          TextField(
            onChanged: (value) => controller.searchQuery.value = value,
            decoration: InputDecoration(
              hintText: 'بحث عن مهمة...',
              prefixIcon: Icon(Icons.search,
                  color: AppColors.textSubtitle.getByBrightness(brightness)),
              fillColor: AppColors.surface.getByBrightness(brightness),
              filled: true,
              border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(15),
                borderSide: BorderSide.none,
              ),
              contentPadding: const EdgeInsets.symmetric(vertical: 0),
            ),
          ),
          const SizedBox(height: 16),

          /// شريط تبويبات المهام
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children: [
                _buildTabChip('كل المهام', brightness),
                const SizedBox(width: 8),
                _buildTabChip('مهامي', brightness),
                const SizedBox(width: 8),
                _buildTabChip('مهام الموردين', brightness),
              ],
            ),
          ),
          const SizedBox(height: 12),

          /// قائمة منسدلة لفلترة المهام وزر إضافة مهمة
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              /// قائمة منسدلة لفلترة المهام
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12),
                decoration: BoxDecoration(
                  color: AppColors.surface.getByBrightness(brightness),
                  borderRadius: BorderRadius.circular(12),
                ),

                /// قائمة منسدلة لفلترة المهام
                child: DropdownButtonHideUnderline(
                  child: Obx(
                    () => DropdownButton<String>(
                        value: controller.selectedStatus.value,
                        items:
                        StatusTools.getAllStatusText(prepend: ['الكل'])
                        //  ['الكل', 'قيد الانتظار', 'قيد التنفيذ', 'مكتملة', 'ملغاة']
                        .map(
                          (s) => DropdownMenuItem(
                            value: s,
                            child: Text(s, style: const TextStyle(fontSize: 13))
                          )
                        ).toList(),
                        onChanged: (val) 
                        {
                          if (val != null) 
                          {
                            controller.selectedStatus.value = val;
                          }
                        },
                        icon: Icon(
                          Icons.filter_list_rounded,
                          size: 18,
                          color: AppColors.primary.getByBrightness(brightness)
                        ),
                    )
                  ),
                ),
              ),
              
              TextButton.icon(
                onPressed: () => Get.toNamed(
                  AppRoutes.eventTaskAdd,
                  arguments: Get.arguments,
                ),
                icon: const Icon(Icons.add_task_rounded, size: 18),
                label: const Text('إضافة مهمة'),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildTabChip(String label, Brightness brightness) {
    final controller = Get.find<TaskController>();
    return Obx(() {
      final isSelected = controller.selectedFilterTab.value == label;
      return GestureDetector(
        onTap: () => controller.selectedFilterTab.value = label,
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.primary.getByBrightness(brightness)
                : AppColors.surface.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: isSelected
                  ? Colors.transparent
                  : AppColors.textSubtitle
                      .getByBrightness(brightness)
                      .withValues(alpha: 0.2),
            ),
          ),
          child: Text(
            label,
            style: TextStyle(
              color: isSelected
                  ? Colors.white
                  : AppColors.textBody.getByBrightness(brightness),
              fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              fontSize: 13,
            ),
          ),
        ),
      );
    });
  }

  Widget _buildTaskItem(BuildContext context, Task task, Brightness brightness) {
    final statusColor = task.status.color(brightness);
    final isVendorTask = task.assignmentType == 'SUPPLIER';
    
    // Assignment type color coding
    final typeColor = isVendorTask 
        ? AppColors.secondary.getByBrightness(brightness) 
        : AppColors.info.getByBrightness(brightness);

    final dateFormat = DateFormat('yyyy-MM-dd');
    final startDateStr = task.dateStart != null 
        ? dateFormat.format(DateTime.parse(task.dateStart!)) 
        : 'N/A';
    final dueDateStr = task.dateDue != null 
        ? dateFormat.format(DateTime.parse(task.dateDue!)) 
        : 'N/A';

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: typeColor.withValues(alpha: 0.3),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: typeColor.withValues(alpha: 0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () => Get.toNamed(AppRoutes.taskDetail, arguments: task),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(
                        color: statusColor.withValues(alpha: 0.1),
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: Icon(Icons.assignment_rounded, color: statusColor, size: 20),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            task.typeTask??'',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 15,
                              color: AppColors.textBody.getByBrightness(brightness),
                            ),
                          ),
                          Text(
                             task.assignmentType.toUpperCase() == 'SUPPLIER' 
                                ? 'المورد: ${task.assigneeName ?? 'غير محدد'}'
                                : 'المسند إليه: ${task.assigneeName ?? 'غير محدد'}',
                            style: TextStyle(
                              color: typeColor,
                              fontSize: 12,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                    ),
                    Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        buildStatusBadge(
                          task.status.tryText(),
                          statusColor,
                          small: true,
                        ),
                        PopupMenuButton<String>(
                          icon: Icon(Icons.more_vert, size: 20, color: AppColors.textSubtitle.getByBrightness(brightness)),
                          onSelected: (value) {
                            final taskController = Get.find<TaskController>();
                            if (value == 'edit') {
                              Get.toNamed(AppRoutes.taskAdd, arguments: task);
                            } else if (value == 'delete') {
                              _showDeleteTaskDialog(context, task.id, taskController, brightness);
                            }
                          },
                          itemBuilder: (context) => [
                            const PopupMenuItem(
                              value: 'edit',
                              child: Row(
                                children: [
                                  Icon(Icons.edit, size: 18),
                                  SizedBox(width: 8),
                                  Text('تعديل'),
                                ],
                              ),
                            ),
                            PopupMenuItem(
                              value: 'delete',
                              child: Row(
                                children: [
                                  Icon(Icons.delete, size: 18, color: AppColors.accent.getByBrightness(brightness)),
                                  const SizedBox(width: 8),
                                  Text('حذف', style: TextStyle(color: AppColors.accent.getByBrightness(brightness))),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
                if (task.taskDescription != null && task.taskDescription!.isNotEmpty) ...[
                  const SizedBox(height: 12),
                  Text(
                    task.taskDescription!,
                    style: TextStyle(
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                      fontSize: 12,
                    ),
                  ),
                ],
                const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Divider(height: 1, thickness: 0.5),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.calendar_today_rounded, size: 14, color: AppColors.textSubtitle.getByBrightness(brightness)),
                        const SizedBox(width: 4),
                        Text(
                          '$startDateStr / $dueDateStr',
                          style: TextStyle(
                            fontSize: 11,
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                          ),
                        ),
                      ],
                    ),
                    if (isVendorTask && task.status.isCOMPLETED)
                      TextButton.icon(
                        style: TextButton.styleFrom(
                          visualDensity: VisualDensity.compact,
                          padding: const EdgeInsets.symmetric(horizontal: 8),
                          backgroundColor: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
                        ),
                        onPressed: () => _showRatingDialog(context, task, brightness),
                        icon: const Icon(Icons.star_rounded, size: 16, color: Colors.amber),
                        label: const Text('تقييم', style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold)),
                      ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  void _showDeleteTaskDialog(BuildContext context, int id, TaskController controller, Brightness brightness) {
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      middleText: 'هل أنت متأكد من حذف هذه المهمة؟',
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      radius: 12,
      onConfirm: () {
        controller.deleteTask(id);
        Get.back();
      },
      textConfirm: 'نعم',
      textCancel: 'إلغاء',
      confirmTextColor: Colors.white,
      buttonColor: AppColors.accent.getByBrightness(brightness),
    );
  }

  void _showRatingDialog(BuildContext context, Task task, Brightness brightness) {
    int rating = 5;
    final commentController = TextEditingController();
    final controller = Get.find<TaskController>();

    Get.dialog(
      AlertDialog(
        backgroundColor: AppColors.surface.getByBrightness(brightness),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        title: const Text('تقييم المهمة', textAlign: TextAlign.center),
        content: StatefulBuilder(
          builder: (context, setState) {
            return Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                 Text(
                  'تقييم تنفيذ المهمة من قبل المورد: ${task.assigneeName}',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 13, color: AppColors.textSubtitle.getByBrightness(brightness)),
                ),
                const SizedBox(height: 20),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: List.generate(5, (index) {
                    return IconButton(
                      icon: Icon(
                        index < rating ? Icons.star_rounded : Icons.star_outline_rounded,
                        color: Colors.amber,
                        size: 32,
                      ),
                      onPressed: () => setState(() => rating = index + 1),
                    );
                  }),
                ),
                const SizedBox(height: 16),
                TextField(
                  controller: commentController,
                  maxLines: 3,
                  decoration: InputDecoration(
                    hintText: 'أضف تعليقك هنا (اختياري)',
                    filled: true,
                    fillColor: AppColors.background.getByBrightness(brightness),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(12),
                      borderSide: BorderSide.none,
                    ),
                  ),
                ),
              ],
            );
          }
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text('إلغاء', style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness))),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary.getByBrightness(brightness),
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
            ),
            onPressed: () {
              controller.rateTask(task.id, rating, commentController.text);
              Get.back();
            },
            child: const Text('إرسال التقييم'),
          ),
        ],
      ),
    );
  }

  Widget _buildEmptyState(String message, Brightness brightness) {
    return Center(
      child: Padding(
        padding:  EdgeInsets.symmetric(vertical: Get.height > 1200 ? 40 : (Get.height > 900? 20 : (Get.height > 650? 10 : 5)), horizontal: 40),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.search_off_rounded, 
              size: Get.height > 1200 ? 60 : (Get.height > 900? 40 : (Get.height > 600? 20 : 10)), 
              color: Colors.grey[300]
            ),
            const SizedBox(height: 16),
            Text(message,
              style: TextStyle(
                color: AppColors.textSubtitle.getByBrightness(brightness),
                fontSize: 14,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  
}
