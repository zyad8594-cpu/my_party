// ignore_for_file: unused_local_variable, slash_for_doc_comments

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';

import '../data/models/event.dart' show Event;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../controller/event_controller.dart' show EventController;
import '../../tasks/controller/task_controller.dart' show TaskController;
import '../../incomes/controller/income_controller.dart' show IncomeController;

import '../widgets/event_detail_widgets.dart' show buildStatusBadge;
import '../widgets/event_info_tab.dart' show EventInfoTab;
import '../widgets/event_tasks_tab.dart' show EventTasksTab;
import '../widgets/event_budget_tab.dart' show EventBudgetTab;

class EventDetailScreen extends StatelessWidget 
{
  const EventDetailScreen({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final Event event = Get.arguments;
    final EventController eventController = Get.find<EventController>();
    final TaskController taskController = Get.find<TaskController>();
    final IncomeController incomeController = Get.find<IncomeController>();

    // صفحة تفاصيل المناسبة
    return DefaultTabController(
      length: 3,
      child: Scaffold(
        backgroundColor: AppColors.background.getByBrightness(brightness),
        body: Obx(() {
          /**
           * Find the latest event from the controller to ensure reactivity
           * ابحث عن آخر حدث من وحدة التحكم لضمان التفاعلية
           */
          final currentEvent = eventController.events.firstWhere(
            (e) => e.id == event.id,
            orElse: () => event,
          );

          return NestedScrollView(
            headerSliverBuilder: (context, innerBoxIsScrolled) => [
              _buildSliverAppBar(context),

              /// رأس صفحة تفاصيل المناسبة يحتوي على
              /// 
              /// رأس صفحة تفاصيل المناسبة _buildEventHeader
              /// 
              /// شريط تبويبات صفحة تفاصيل المناسبة _buildTabBar
              SliverToBoxAdapter(
                child: Padding(
                  padding: const EdgeInsets.fromLTRB(20, 20, 20, 0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildEventHeader(event, context),
                      const SizedBox(height: 16),
                      _buildTabBar(context),
                    ],
                  ),
                ),
              ),
            ],

            // تبويبات صفحة تفاصيل المناسبة
            body: TabBarView(
              children: [
                // تبويبة المعلومات في صفحة تفاصيل المناسبة
                EventInfoTab(event: event),

                // تبويبة المهام في صفحة تفاصيل المناسبة
                EventTasksTab(
                  event: event,
                ),

                // تبويبة الميزانية في صفحة تفاصيل المناسبة
                EventBudgetTab(
                  event: event,
                  incomeController: incomeController,
                ),
              ],
            ),
          );
        }),

        
      ),
    );
  }

  /// شريط التطبيق العلوي قابل للطي في صفحة تفاصيل المناسبة
  Widget _buildSliverAppBar(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return SliverAppBar(
      expandedHeight: 200,
      pinned: true,
      stretch: true,
      backgroundColor: AppColors.primary.getByBrightness(brightness),
      flexibleSpace: FlexibleSpaceBar(
        background: Stack(
          fit: StackFit.expand,
          children: [
            Container(
              decoration: BoxDecoration(
                gradient: AppColors.primaryGradient.getByBrightness(brightness),
              ),
            ),
            Opacity(
              opacity: 0.1,
              child: Image.network(
                'https://images.unsplash.com/photo-1519741497674-611481863552?q=80&w=2070&auto=format&fit=crop',
                fit: BoxFit.cover,
              ),
            ),
          ],
        ),
      ),
      leading: IconButton(
        icon: Icon(Icons.arrow_back_ios_new, color: AppColors.w_b.getByBrightness(brightness)),
        onPressed: () => Get.back(),
      ),
    );
  }

  
  /// رأس صفحة تفاصيل المناسبة تحتوي على
  /// 
  /// id: رقم المناسبة
  /// 
  /// name: اسم المناسبة
  /// 
  /// status: حالة المناسبة
  Widget _buildEventHeader(Event event, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '#EV-${event.id}',
                  style: TextStyle(
                    color: AppColors.textSubtitle.getByBrightness(brightness),
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Text(
                  event.nameEvent,
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: AppColors.textBody.getByBrightness(brightness),
                  ),
                ),
              ],
            ),
            buildStatusBadge(
              event.status.tryText(),
              event.status.tryColor(brightness),
            ),
          ],
        ),
      ],
    );
  }

  /// شريط تبويبات صفحة تفاصيل المناسبة تحتوي على التبويبات التالية
  /// 
  /// المعلومات   -   المهام   -   الميزانية
  Widget _buildTabBar(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return TabBar(
      labelColor: AppColors.textSubtitle.getByBrightness(brightness),
      unselectedLabelColor: AppColors.primary.getByBrightness(brightness),
      indicatorColor: AppColors.primary.getByBrightness(brightness),
      indicatorWeight: 3,
      labelStyle: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
      tabs: [
        Tab(text: 'المعلومات'),
        Tab(text: 'المهام'),
        Tab(text: 'الميزانية'),
      ],
    );
  }
}
