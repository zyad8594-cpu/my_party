import 'dart:convert' show jsonDecode;

import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import 'package:shared_preferences/shared_preferences.dart' show SharedPreferences;
import '../../../core/api/api_constants.dart' show ApiKeys;
import '../data/repository/event_repository.dart' show EventRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/event.dart' show Event;

class EventController extends GetxController 
{
  final EventRepository _repository = Get.find<EventRepository>();

  get currentUser async {
    final sharedPreferences = await SharedPreferences.getInstance();
    return Map<String, dynamic>.from(jsonDecode(sharedPreferences.getString(ApiKeys.userKey) ?? '{}'));
  }
  final events = <Event>[].obs;
  final searchQuery = ''.obs;
  final selectedStatus = 'الكل'.obs;
  final selectedFilterTab = 'كل المهام'.obs;
  final selectedEvent = Rxn<Event>();
  final isLoading = false.obs;

  // Reactive state for Event Add/Edit
  final nameEventRx = ''.obs;
  final locationRx = ''.obs;
  final descriptionRx = ''.obs;
  final budgetRx = 0.0.obs;
  final dateRx = DateTime.now().obs;
  final clientIdRx = 0.obs;

  List<Event> get filteredEvents {
    return events.where((e) {
      final matchesSearch =
          e.nameEvent.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
          (e.location?.toLowerCase().contains(searchQuery.value.toLowerCase()) ?? false);

      if (selectedStatus.value == 'الكل') return matchesSearch;
      
      return matchesSearch && e.status.tryText() == selectedStatus.value;
    }).toList();
  }

  @override
  void onInit() {
    super.onInit();

    fetchAll();
  }

  void clearFields() {
    nameEventRx.value = '';
    locationRx.value = '';
    descriptionRx.value = '';
    budgetRx.value = 0.0;
    dateRx.value = DateTime.now();
    clientIdRx.value = 0;
  }

  void populateFields(Event event) {
    nameEventRx.value = event.nameEvent;
    locationRx.value = event.location ?? '';
    descriptionRx.value = event.description ?? '';
    budgetRx.value = event.budget;
    dateRx.value = DateTime.tryParse(event.eventDate) ?? DateTime.now();
    clientIdRx.value = event.clientId;
  }

  Future<void> fetchAll() async {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => events.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (event) => selectedEvent.value = event,
    );
    isLoading.value = false;
  }

  Future<void> create() async {
    isLoading.value = true;
    final user = await currentUser;
    final result = await _repository.create({
      'client_id': clientIdRx.value,
      'coordinator_id': user['user_id'],
      'name_event': nameEventRx.value,
      'description': descriptionRx.value,
      'event_date': dateRx.value.toIso8601String(),
      'location': locationRx.value,
      'budget': budgetRx.value,
      'status': Status.PENDING.tryText()
    });
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (newEvent) {
        events.add(newEvent);
        Get.back();
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة المناسبة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  
  Future<void> updateEvent(int id) async {
    isLoading.value = true;
    final event = events.firstWhereOrNull((e) => e.id == id);
    final result = await _repository.update(id, {
      'client_id': clientIdRx.value,
      'name_event': nameEventRx.value,
      'description': descriptionRx.value,
      'event_date': dateRx.value.toIso8601String(),
      'location': locationRx.value,
      'budget': budgetRx.value,
      'status': event?.status.tryText() ?? Status.PENDING.tryText(),
    });
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = events.indexWhere((c) => c.id == id);
        if (index != -1) events[index] = updated;
        selectedEvent.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث المناسبة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateEventStatus(int id, Status status) async {
    isLoading.value = true;
    final result = await _repository.updateStatus(id,  status.tryText());
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = events.indexWhere((c) => c.id == id);
        if (index != -1) events[index] = events[index].copyWith(status: status);
        if (selectedEvent.value?.id == id) {
          selectedEvent.value = events[index];
        }
        utils.showSnackbar('نجاح', 'تم تحديث حالة المناسبة');
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteEvent(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        events.removeWhere((c) => c.id == id);
        if (selectedEvent.value?.id == id) {
          selectedEvent.value = null;
        }
        utils.showSnackbar('نجاح', 'تم حذف المناسبة');
      },
    );
  }

  void rateTask(int id, int rating, String text) {}
}
