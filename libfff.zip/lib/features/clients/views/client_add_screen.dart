import 'package:get/get.dart';
import 'package:flutter/material.dart' show 
  Icons, Scaffold, SingleChildScrollView, Column, EdgeInsets, BouncingScrollPhysics, TextStyle, FontWeight, 
  StatelessWidget, Widget, BuildContext, Theme, TextFormField, TextInputType,
  CrossAxisAlignment, Text, SizedBox, Icon;
  
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../controller/client_controller.dart' show ClientController;
import '../data/models/client.dart' show Client;

class ClientAddScreen extends StatelessWidget 
{
  ClientAddScreen({super.key});

  final ClientController clientController = Get.find<ClientController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final Client? client = Get.arguments;
    final isEditing = client != null;

    if (isEditing) {
      clientController.populateFields(client);
    } else {
      clientController.clearFields();
    }

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authController,
        showBackButton: true,
        title: isEditing ? 'تعديل بيانات العميل' : 'إضافة عميل جديد',
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isEditing ? 'تحديث المعلومات' : 'البيانات الشخصية للعميل',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
            const SizedBox(height: 16),
            GlassCard(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  TextFormField(
                    initialValue: isEditing ? client.name : null,
                    onChanged: (val) => clientController.name.value = val,
                    decoration: AppFormWidgets.fieldDecoration('الاسم الكامل', Icons.person_outline_rounded, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? client.phoneNumber : null,
                    onChanged: (val) => clientController.phone.value = val,
                    keyboardType: TextInputType.phone,
                    decoration: AppFormWidgets.fieldDecoration('رقم الهاتف', Icons.phone_rounded, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? client.email : null,
                    onChanged: (val) => clientController.email.value = val,
                    keyboardType: TextInputType.emailAddress,
                    decoration: AppFormWidgets.fieldDecoration('البريد الإلكتروني', Icons.email_rounded, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? client.address : null,
                    onChanged: (val) => clientController.address.value = val,
                    decoration: AppFormWidgets.fieldDecoration('العنوان', Icons.location_on_rounded, context),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 40),
            Obx(
              () => GradientButton(
                text: isEditing ? 'حفظ التعديلات' : 'إضافة العميل',
                isLoading: clientController.isLoading.value,
                onPressed: () {
                  if (clientController.name.value.isEmpty) {
                     Get.snackbar(
                      'تنبيه',
                      'يرجى إدخال اسم العميل',
                      backgroundColor: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                      colorText: AppColors.accent.getByBrightness(brightness),
                      icon: Icon(Icons.warning_amber_rounded, color: AppColors.accent.getByBrightness(brightness)),
                    );
                    return;
                  }
                  if (isEditing) {
                    clientController.updateClient(client.id);
                  } else {
                    clientController.createClient();
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
