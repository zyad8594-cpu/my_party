import 'package:get/get.dart';
import '../data/repository/client_repository.dart' show ClientRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/client.dart' show Client;
import '../../events/controller/event_controller.dart' show EventController;

class ClientController extends GetxController 
{
  final ClientRepository _repository = Get.find<ClientRepository>();
  final EventController _eventController = Get.find<EventController>();
  final name = ''.obs;
  final phone = ''.obs;
  final email = ''.obs;
  final address = ''.obs;

  final clients = <Client>[].obs;
  final searchQuery = ''.obs;
  final selectedClient = Rxn<Client>();
  final isLoading = false.obs;
  RxBool get eventsIsLoading  => _eventController.isLoading;

 
  @override
  void onInit() {
    super.onInit();
    _eventController.onInit();
    fetchAll();
  }

  void clearFields() {
    name.value = '';
    phone.value = '';
    email.value = '';
    address.value = '';
  }

  void populateFields(Client client) {
    name.value = client.name;
    phone.value = client.phoneNumber;
    email.value = client.email ?? '';
    address.value = client.address ?? '';
  }

  List<Client> get filteredClients {
    if (searchQuery.isEmpty) return clients;
    return clients.where((c) {
      return c.name.toLowerCase().contains(
            searchQuery.value.toLowerCase(),
          ) ||
          c.phoneNumber.contains(searchQuery.value);
    }).toList();
  }

  Future<void> fetchAll() async {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => clients.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetchClient(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (client) => selectedClient.value = client,
    );
    isLoading.value = false;
  }

  Future<void> createClient() async {
    isLoading.value = true;
    final data = {
      'full_name': name.value,
      'phone_number': phone.value,
      'email': email.value,
      'address': address.value,
    };
    final result = await _repository.create(data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (response) {
        clients.add(response);
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة العميل');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  
  Future<void> updateClient(int id) async {
    isLoading.value = true;
    final data = {
      'full_name': name.value,
      'phone_number': phone.value,
      'email': email.value,
      'address': address.value,
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) clients[index] = updated;
        selectedClient.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث البيانات');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteClient(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) {
          clients[index] = clients[index].copyWith(isDeleted: true);
        }
        utils.showSnackbar('نجاح', 'تم حذف العميل');
      },
    );
  }

  Future<void> restoreClient(int id) async {
    isLoading.value = true;
    final result = await _repository.restore(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        final index = clients.indexWhere((c) => c.id == id);
        if (index != -1) {
          clients[index] = clients[index].copyWith(isDeleted: false);
        }
        utils.showSnackbar('نجاح', 'تم استعادة العميل');
      },
    );
    isLoading.value = false;
  }

  @override
  void onClose() {
    super.onClose();
  }
}
