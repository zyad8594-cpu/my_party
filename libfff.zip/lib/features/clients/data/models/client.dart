
import '../../../../core/utils/bool_toolse.dart';
import '../../../../core/utils/number_toolse.dart';
import '../../../../core/utils/string_toolse.dart';
import '../../../../data/models/user.dart';

class Client extends User
{
  final String? address;

  @override
  String get phoneNumber => super.phoneNumber ?? '';
  
  Client({
    required super.id, 
    required super.name, 
    super.email,
    required String phoneNumber, 
    super.imgUrl, 
    super.isActive,
    super.isDeleted,
    super.createdAt,
    super.updatedAt,
    this.address,
  }): super(role: 'CLIENT', phoneNumber: phoneNumber);

  factory Client.fromJson(json) {
    return Client(
      id: NumberTools.tryParseInt(json, keys: [
        'id', 'user_id', 'client_id',
        'userId', 'clientId'
      ]),
      name: StrTools.tryParse(json, keys: [
        'name', 'full_name', 'user_name', 'client_name',
        'fullName', 'clientName', 'userName',
        'userFullName', 'clientFullName',
        'user_full_name', 'client_full_name',
      ]),
      email: StrTools.tryParse(json, keys: [
        'email', 'user_email', 'client_email',
        'userEmail', 'clientEmail'
      ]),
      phoneNumber: StrTools.tryParse(json, keys: [
        'phone', 'phone_number', 'user_phone', 'client_phone',
        'userPhone', 'clientPhone', 'phoneNumber',
        'user_phone_number', 'client_phone_number',
        'userPhoneNumber', 'clientPhoneNumber'
      ]),
      imgUrl: StrTools.tryParse(json, keys: [
        'img_url', 'imgUrl', 'user_img_url', 'client_img_url',
        'userImgUrl', 'clientImgUrl'
      ]),
      isActive: BoolTools.tryParse(json, keys: [
        'is_active', 'isActive', 'user_is_active', 'client_is_active',
        'userIsActive', 'clientIsActive'
      ]),
      isDeleted: BoolTools.tryParse(json, keys: [
        'is_deleted', 'isDeleted', 'user_is_deleted', 'client_is_deleted',
        'userIsDeleted', 'clientIsDeleted'
      ]),
      address: StrTools.tryParse(json, keys: [
        'address', 'user_address', 'client_address',
        'userAddress', 'clientAddress'
      ]),
      createdAt: StrTools.tryParse(json, keys: [
        'created_at', 'createdAt', 'user_created_at', 'client_created_at',
        'userCreatedAt', 'clientCreatedAt'
      ]),
      updatedAt: StrTools.tryParse(json, keys: [
        'updated_at', 'updatedAt', 'user_updated_at', 'client_updated_at',
        'userUpdatedAt', 'clientUpdatedAt'
      ]),
    );
  }

  @override
  toJson() {
    return {...super.toJson(), if(address != null) 'address': address};
  }

  @override
  Client copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    String? address,
  }) {
    return Client(
      id: id ?? this.id,
      name: name ?? this.name,
      email: email ?? this.email,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      imgUrl: imgUrl ?? this.imgUrl,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      address: address ?? this.address,
    );
  }

  @override
  List<Object?> get props => [
        ...super.props,
        address,
      ];
}
