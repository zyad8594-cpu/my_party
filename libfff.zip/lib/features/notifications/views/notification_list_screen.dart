import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart' show DateFormat;

import '../../../core/api/auth_service.dart';
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../features/auth/controller/auth_controller.dart' show AuthController;
import '../../../features/notifications/data/models/notification.dart' show NotificationModel;
import '../../../features/notifications/controller/notification_controller.dart' show NotificationController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;


class NotificationListScreen extends StatelessWidget 
{
  NotificationListScreen({super.key});

  final NotificationController controller = Get.find<NotificationController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authController,
        title: 'الإشعارات',
        actions: [
          IconButton(
            icon: Icon(
              Icons.delete_sweep_rounded,
              color: AppColors.accent.getByBrightness(brightness),
            ),
            tooltip: 'مسح الكل',
            onPressed: () => _showClearAllConfirm(brightness),
          ),
          const SizedBox(width: 8),
          IconButton(
            onPressed: () {
              authController.logout();
              Get.offAllNamed(AppRoutes.login);
            },
            icon: Icon(Icons.logout_rounded, color: AppColors.accent.getByBrightness(brightness)),
          ),
          
          const SizedBox(width: 16),
          
        ],
      ),
      body: Obx(() {
        final userId = AuthService.user['user_id'];
        final notifications = controller.notifications
          .where((n) => n.userId == userId).toList();

        if (controller.isLoading.value) {
          return const LoadingWidget();
        }
        if (notifications.isEmpty) {
          return _buildEmptyState(brightness);
        }
        return ListView.builder(
          padding: const EdgeInsets.all(20),
          itemCount: notifications.length,
          itemBuilder: (context, index) {
            final notification = notifications[index];
            return _buildNotificationCard(notification, brightness);
          },
        );
      }),
    );
  }

  Widget _buildNotificationCard(NotificationModel notification, Brightness brightness) {
    final bool isUnread =
        true; // Placeholder for unread logic if added to model
    final iconData = _getNotificationIcon(notification.type);
    final statusColor = _getNotificationColor(notification.type, brightness);

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1), width: 1),
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          borderRadius: BorderRadius.circular(20),
          onTap: () {
            // Mark as read or navigate to task
          },
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    shape: BoxShape.circle,
                  ),
                  child: Icon(iconData, color: statusColor, size: 22),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              notification.title,
                              style: TextStyle(
                                fontSize: 15,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textBody.getByBrightness(brightness),
                              ),
                            ),
                          ),
                          if (isUnread)
                            Container(
                              width: 8,
                              height: 8,
                              decoration: BoxDecoration(
                                color: statusColor,
                                shape: BoxShape.circle,
                              ),
                            ),
                        ],
                      ),
                      const SizedBox(height: 6),
                      Text(
                        notification.message,
                        style: TextStyle(
                          fontSize: 13,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                          height: 1.4,
                        ),
                      ),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          Icon(
                            Icons.access_time_rounded,
                            size: 14,
                            color: AppColors.textSubtitle.getByBrightness(brightness).withValues(
                              alpha: 0.5,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            _formatDate(notification.createdAt),
                            style: TextStyle(
                              fontSize: 11,
                              color: AppColors.textSubtitle.getByBrightness(brightness).withValues(
                                alpha: 0.5,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                IconButton(
                  icon: Icon(
                    Icons.close_rounded,
                    size: 18,
                    color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.3),
                  ),
                  onPressed: () =>
                      controller.deleteNotification(notification.id),
                  constraints: const BoxConstraints(),
                  padding: EdgeInsets.zero,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  IconData _getNotificationIcon(String? type) {
    switch (type?.toLowerCase()) {
      case 'task':
        return Icons.assignment_rounded;
      case 'event':
        return Icons.event_rounded;
      case 'payment':
        return Icons.payments_rounded;
      case 'alert':
        return Icons.warning_amber_rounded;
      default:
        return Icons.notifications_rounded;
    }
  }

  Color _getNotificationColor(String? type, Brightness brightness) {
    switch (type?.toLowerCase()) {
      case 'task':
        return AppColors.primary.getByBrightness(brightness);
      case 'event':
        return AppColors.info.getByBrightness(brightness);
      case 'payment':
        return AppColors.success.getByBrightness(brightness);
      case 'alert':
        return AppColors.accent.getByBrightness(brightness);
      default:
        return AppColors.primary.getByBrightness(brightness);
    }
  }

  String _formatDate(String dateStr) {
    try {
      final date = DateTime.parse(dateStr);
      return DateFormat('yyyy/MM/dd - hh:mm a', 'ar').format(date);
    } catch (_) {
      return dateStr;
    }
  }

  Widget _buildEmptyState(Brightness brightness) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.notifications_off_rounded,
              size: 80,
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'لا توجد إشعارات',
            style: TextStyle(
              color: AppColors.textBody.getByBrightness(brightness),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'ستظهر لك التنبيهات الجديدة هنا',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        ],
      ),
    );
  }

  void _showClearAllConfirm(Brightness brightness) {
    Get.defaultDialog(
      title: 'مسح جميع الإشعارات',
      titleStyle: TextStyle(
        color: AppColors.primary.getByBrightness(brightness),
        fontWeight: FontWeight.bold,
      ),
      middleText:
          'هل أنت متأكد من رغبتك في حذف كل الإشعارات؟ لا يمكن التراجع عن هذه الخطوة.',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      radius: 24,
      contentPadding: const EdgeInsets.all(20),
      confirm: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(top: 16),
        child: ElevatedButton(
          onPressed: () {
            Get.back();
            controller.clearAll();
          },
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.accent.getByBrightness(brightness),
            padding: const EdgeInsets.symmetric(vertical: 12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
            ),
          ),
          child: const Text(
            'نعم، امسح الكل',
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
          ),
        ),
      ),
      cancel: TextButton(
        onPressed: () => Get.back(),
        child: Text(
          'إلغاء',
          style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness)),
        ),
      ),
    );
  }
}
