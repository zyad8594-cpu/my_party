import 'package:get/get.dart';
import '../../../core/api/api_provider.dart' show ApiProvider;
import '../../../core/api/api_service.dart' show ApiService;
import '../../../core/api/api_constants.dart' show ApiEndpoints;

class NotificationProvider extends ApiProvider 
{
  NotificationProvider():super(Get.find<ApiService>());

  
  @override
  Future<List> getAll() async 
  {
    final response = await service.get(ApiEndpoints.notifications);
    return List<dynamic>.from(response);
  }
  
  // 
  @override
  Future<Map<String, dynamic>> getById(int id) async
  {
    // final response = await service.get("${Endpoints.notifications}/$id");
    // return Map<String, dynamic>.from(response);
    throw UnimplementedError("getById is not implemented");
  }

  // 
  @override
  Future<Map<String, dynamic>> create(Map<String, dynamic> data) async 
  {
    // final response = await service.post(Endpoints.notifications, data: data);
    // return Map<String, dynamic>.from(response);
    throw UnimplementedError("create is not implemented");
  }

  // 
  @override
  Future<Map<String, dynamic>> update(int id, Map<String, dynamic> data) async
  {
    // final response = await service.put("${Endpoints.notifications}/$id", data: data);
    // return Map<String, dynamic>.from(response);
    throw UnimplementedError("update is not implemented");
  }
  
  @override
  Future delete(int id) async 
  {
    return await service.delete("${ApiEndpoints.notifications}/$id");
  }

  Future clearAll() async 
  {
    return await service.delete(ApiEndpoints.notifications);
  }
  
}