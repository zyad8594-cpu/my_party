import 'package:get/get.dart';
import '../../../features/notifications/data/repository/notification_repository.dart';
import '../../../features/notifications/controller/notification_controller.dart';
import '../../../features/notifications/provider/notification_provider.dart';

// import '../../auth/controller/auth_controller.dart';
// import '../../auth/data/repository/auth_repository.dart';
// import '../../suppliers/controller/supplier_dashboard_controller.dart';

class NotificationBinding extends Bindings 
{
  @override
  void dependencies() 
  {
    Get.lazyPut<NotificationRepository>(() => NotificationRepository());
    Get.lazyPut<NotificationController>(() => NotificationController(), fenix: true,);
    Get.lazyPut<NotificationProvider>(() => NotificationProvider(), fenix: true,);
  }
}
