import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../data/repository/service_repository.dart' show ServiceRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/service.dart' show Service;

class ServiceController extends GetxController 
{
  final ServiceRepository _repository = Get.find<ServiceRepository>();

  final services = <Service>[].obs;
  final selectedService = Rxn<Service>();
  final isLoading = false.obs;

  // Reactive state for Service Add/Edit
  final serviceNameRx = ''.obs;
  final descriptionRx = ''.obs;

  final nameController = TextEditingController();
  final descriptionController = TextEditingController();

  @override
  void onInit() {
    super.onInit();
    nameController.addListener(() {
      serviceNameRx.value = nameController.text;
    });
    descriptionController.addListener(() {
      descriptionRx.value = descriptionController.text;
    });
    fetchServices();
  }

  void clearFields() {
    serviceNameRx.value = '';
    descriptionRx.value = '';

    nameController.clear();
    descriptionController.clear();
  }

  void populateFields(Service service) {
    serviceNameRx.value = service.serviceName;
    descriptionRx.value = service.description ?? '';

    nameController.text = service.serviceName;
    descriptionController.text = service.description ?? '';
  }

  Future<void> fetchServices() async {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => services.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetchService(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (service) => selectedService.value = service,
    );
    isLoading.value = false;
  }

  Future<void> createService() async {
    if (serviceNameRx.value.isEmpty) {
      utils.showSnackbar('تنبيه', 'يرجى إدخال اسم الخدمة', isError: true);
      return;
    }
    isLoading.value = true;
    final data = {
      'service_name': serviceNameRx.value,
      'description': descriptionRx.value,
    };
    final result = await _repository.create(data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (newService) {
        services.add(newService);
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة الخدمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateService(int id) async {
    isLoading.value = true;
    final data = {
      'service_name': serviceNameRx.value,
      'description': descriptionRx.value,
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = services.indexWhere((c) => c.id == id);
        if (index != -1) services[index] = updated;
        selectedService.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث الخدمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteService(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        services.removeWhere((c) => c.id == id);
        if (selectedService.value?.id == id) {
          selectedService.value = null;
        }
        utils.showSnackbar('نجاح', 'تم حذف الخدمة');
      },
    );
  }
}
