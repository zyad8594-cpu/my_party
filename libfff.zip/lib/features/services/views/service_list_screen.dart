import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../features/auth/controller/auth_controller.dart' show AuthController;
import '../data/models/service.dart' show Service;
import '../controller/service_controller.dart' show ServiceController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;

class ServiceListScreen extends StatelessWidget 
{
  ServiceListScreen({super.key});

  final ServiceController controller = Get.find<ServiceController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      appBar: CustomAppBar(
        // authController: authController, 
        title: 'قائمة الخدمات'),
      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: () => Get.toNamed(AppRoutes.serviceAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(Icons.add_rounded, color: Colors.white, size: 30),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: Obx(() {
          if (controller.isLoading.value) {
            return const LoadingWidget();
          }
          if (controller.services.isEmpty) {
            return _buildEmptyState(brightness);
          }
          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: controller.services.length,
            itemBuilder: (context, index) {
              final service = controller.services[index];
              return _buildServiceCard(service, context, brightness);
            },
          );
        }),
      ),
    );
  }

  Widget _buildServiceCard(Service service, BuildContext context, Brightness brightness) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 12.0),
      child: Container(
        decoration: AppFormWidgets.cardDecoration(context),
        padding: const EdgeInsets.all(12),
        child: Row(
          children: [
            Container(
              width: 50,
              height: 50,
              decoration: BoxDecoration(
                color: AppColors.secondary.getByBrightness(brightness).withValues(alpha: 0.1),
                borderRadius: BorderRadius.circular(12),
              ),
              child: Icon(
                Icons.category_outlined,
                color: AppColors.secondary.getByBrightness(brightness),
                size: 24,
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    service.serviceName,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    service.description ?? 'لا يوجد وصف',
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                    ),
                  ),
                ],
              ),
            ),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.edit_rounded,
                      color: AppColors.warning.getByBrightness(brightness),
                      size: 18,
                    ),
                  ),
                  onPressed: () =>
                      Get.toNamed(AppRoutes.serviceAdd, arguments: service),
                ),
                const SizedBox(width: 4),
                IconButton(
                  icon: Container(
                    padding: const EdgeInsets.all(6),
                    decoration: BoxDecoration(
                      color: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(8),
                    ),
                    child: Icon(
                      Icons.delete_rounded,
                      color: AppColors.accent.getByBrightness(brightness),
                      size: 18,
                    ),
                  ),
                  onPressed: () => _delete(service.id, brightness),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyState(Brightness brightness) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.category_outlined,
            size: 80,
            color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5),
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد خدمات مضافة',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 18),
          ),
        ],
      ),
    );
  }

  void _delete(int id, Brightness brightness) async {
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      titleStyle: TextStyle(color: AppColors.primary.getByBrightness(brightness)),
      middleText: 'هل أنت متأكد من حذف هذه الخدمة؟',
      middleTextStyle: const TextStyle(color: Colors.white),
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      textConfirm: 'نعم',
      textCancel: 'لا',
      confirmTextColor: Colors.black,
      cancelTextColor: AppColors.primary.getByBrightness(brightness),
      onConfirm: () {
        Get.back();
        controller.deleteService(id);
      },
    );
  }
}
