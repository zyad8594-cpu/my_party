import 'package:get/get.dart';
import '../../../core/api/api_provider.dart' show ApiProvider;
import '../../../core/api/api_service.dart' show ApiService;
import '../../../core/api/api_constants.dart' show ApiEndpoints;

class ServiceProvider extends ApiProvider 
{
  ServiceProvider():super(Get.find<ApiService>());

  
  @override
  Future<List> getAll() async 
  {
    final response = await service.get(ApiEndpoints.services);
    return List<dynamic>.from(response);
  }
  
  @override
  Future<Map<String, dynamic>> getById(int id) async
  {
    final response = await service.get("${ApiEndpoints.services}/$id");
    return Map<String, dynamic>.from(response);
  }

  @override
  Future<Map<String, dynamic>> create(Map<String, dynamic> data) async 
  {
    final response = await service.post(ApiEndpoints.services, data: data);
    return Map<String, dynamic>.from(response);
  }

  @override
  Future<Map<String, dynamic>> update(int id, Map<String, dynamic> data) async
  {
    final response = await service.put("${ApiEndpoints.services}/$id", data: data);
    return Map<String, dynamic>.from(response);
  }
  
  @override
  Future delete(int id) async 
  {
    return await service.delete("${ApiEndpoints.services}/$id");
  }
  
}