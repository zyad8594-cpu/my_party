import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;

import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../controller/supplier_dashboard_controller.dart' show SupplierDashboardController;
import '../../tasks/data/models/task.dart' show Task;
import 'package:intl/intl.dart' show DateFormat;
import '../../auth/controller/auth_controller.dart' show AuthController;


class SupplierTaskListScreen extends StatelessWidget 
{
  SupplierTaskListScreen({super.key});
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    // We can reuse the same controller or a similar one
    final SupplierDashboardController controller =
        Get.find<SupplierDashboardController>();
    final RxString selectedFilter = 'الكل'.obs;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authController, 
        title: 'مهامي'),

      body: Column(
        children: [
          _buildFilterChips(selectedFilter, brightness),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const LoadingWidget();
              }

              // Actually, let's just use the controller's activeTasks for now or fetch all.
              // For a better implementation, the controller should have a 'allSupplierTasks' list.

              final filteredTasks = controller.activeTasks.where((t) {
                if (selectedFilter.value == 'الكل') return true;
                if (selectedFilter.value == 'بانتظار البدء') {
                  return t.status.isPENDING;
                }
                if (selectedFilter.value == 'قيد التنفيذ') {
                  return t.status.isIN_PROGRESS;
                }
                if (selectedFilter.value == 'مكتملة') {
                  return t.status.isCOMPLETED;
                }
                return true;
              }).toList();

              if (filteredTasks.isEmpty) {
                return _buildEmptyState(brightness);
              }

              return ListView.builder(
                padding: const EdgeInsets.all(20),
                itemCount: filteredTasks.length,
                itemBuilder: (context, index) {
                  return _buildTaskCard(filteredTasks[index], controller, brightness);
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterChips(RxString selectedFilter, Brightness brightness) {
    final filters = ['الكل', 'بانتظار البدء', 'قيد التنفيذ', 'مكتملة'];
    return Container(
      height: 60,
      margin: const EdgeInsets.symmetric(vertical: 10),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: 20),
        itemCount: filters.length,
        itemBuilder: (context, index) {
          return Obx(
            () => Padding(
              padding: const EdgeInsets.only(left: 8),
              child: ChoiceChip(
                label: Text(filters[index]),
                selected: selectedFilter.value == filters[index],
                onSelected: (val) => selectedFilter.value = filters[index],
                selectedColor: AppColors.primary.getByBrightness(brightness),
                labelStyle: TextStyle(
                  color: selectedFilter.value == filters[index]
                      ? Colors.white
                      : AppColors.textBody.getByBrightness(brightness),
                  fontWeight: FontWeight.bold,
                ),
                backgroundColor: Colors.white,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
                showCheckmark: false,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildTaskCard(Task task, SupplierDashboardController controller, Brightness brightness) {
    final bool isPending = task.status.isPENDING;
    final bool isCompleted = task.status.isCOMPLETED;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: InkWell(
        onTap: () => Get.toNamed(AppRoutes.taskDetail, arguments: task),
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      Icons.assignment_rounded,
                      color: AppColors.primary.getByBrightness(brightness),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          task.typeTask!,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.textBody.getByBrightness(brightness),
                          ),
                        ),
                        Text(
                          task.eventName ,
                          style: TextStyle(
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  _buildStatusBadge(task.status, brightness),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Icon(
                    Icons.calendar_today_rounded,
                    size: 14,
                    color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.5),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    'تاريخ التسليم: ${_formatDate(task.dateDue)}',
                    style: TextStyle(
                      fontSize: 12,
                      color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.7),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              if (!isCompleted)
                Row(
                  children: [
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () => controller.updateTaskStatus(
                          task.id,
                          isPending ? 'IN_PROGRESS' : 'COMPLETED',
                        ),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: isPending
                              ? AppColors.primary.getByBrightness(brightness)
                              : AppColors.success.getByBrightness(brightness),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          padding: const EdgeInsets.symmetric(vertical: 12),
                        ),
                        child: Text(
                          isPending ? 'بدء المهمة' : 'إكمال المهمة',
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  ],
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBadge(Status status, Brightness brightness) {
    Color color=status.color(brightness);
    
    

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(10),
      ),
      child: Text(
        status.tryText(),
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }

  String _formatDate(String? dateStr) {
    if (dateStr == null) return 'غير محدد';
    try {
      final date = DateTime.parse(dateStr);
      return DateFormat('yyyy/MM/dd', 'ar').format(date);
    } catch (_) {
      return dateStr;
    }
  }

  Widget _buildEmptyState(Brightness brightness) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(
            Icons.assignment_turned_in_rounded,
            size: 80,
            color: Colors.grey[200],
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد مهام مطابقة للمرشح',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 16),
          ),
        ],
      ),
    );
  }
}
