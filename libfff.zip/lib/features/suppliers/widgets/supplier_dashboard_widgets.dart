import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../controller/supplier_dashboard_controller.dart' show SupplierDashboardController;
import '../../tasks/data/models/task.dart' show Task;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;

class SupplierDashboardWidgets {
  static Widget buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
    BuildContext context,
  ) {
    final brightness = Theme.of(context).brightness;
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: AppFormWidgets.cardDecoration(context),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: color.withValues(alpha: 0.1),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, color: color, size: 20),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: AppColors.textBody.getByBrightness(brightness),
                ),
              ),
              Text(
                title,
                style: TextStyle(
                  fontSize: 11,
                  color: AppColors.textSubtitle.getByBrightness(brightness),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class SupplierGreeting extends StatelessWidget {
  final Map<String, dynamic> authUser;

  const SupplierGreeting({super.key, required this.authUser});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final name = authUser['full_name'] ?? 'شريكنا العزيز';
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'مرحباً بك، $name 👋',
          style: TextStyle(
            color: AppColors.textBody.getByBrightness(brightness),
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'نظرة سريعة على أدائك ومهامك اليوم',
          style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
        ),
      ],
    );
  }
}

class SupplierStatsGrid extends StatelessWidget {
  final SupplierDashboardController controller;

  const SupplierStatsGrid({super.key, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      crossAxisSpacing: 16,
      mainAxisSpacing: 16,
      childAspectRatio: 1.4,
      children: [
        SupplierDashboardWidgets.buildStatCard(
          'إجمالي الأرباح',
          '${controller.totalEarnings.value.toStringAsFixed(0)} ر.س',
          Icons.account_balance_wallet_rounded,
          AppColors.success.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'مهام مكتملة',
          '${controller.completedTasksCount.value}',
          Icons.check_circle_rounded,
          AppColors.primary.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'طلبات معلقة',
          '${controller.pendingTasksCount.value}',
          Icons.pending_actions_rounded,
          AppColors.warning.getByBrightness(brightness),
          context,
        ),
        SupplierDashboardWidgets.buildStatCard(
          'تقييمك الحالي',
          '${controller.rating.value}',
          Icons.star_rounded,
          const Color(0xFFFFC107),
          context
        ),
      ],
    );
  }
}

class SupplierActiveTasksList extends StatelessWidget {
  final SupplierDashboardController controller;

  const SupplierActiveTasksList({super.key, required this.controller});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: controller.activeTasks
          .map((task) => _buildTaskCard(task, context))
          .toList(),
    );
  }

  Widget _buildTaskCard(Task task, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final bool isPending = task.status.isPENDING;
    final bool isInProgress = task.status.isIN_PROGRESS;

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: AppFormWidgets.cardDecoration(context),
      child: InkWell(
        onTap: () => Get.toNamed(AppRoutes.taskDetail, arguments: task),
        borderRadius: BorderRadius.circular(24),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            children: [
              Row(
                children: [
                  Container(
                    width: 50,
                    height: 50,
                    decoration: BoxDecoration(
                      color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(16),
                    ),
                    child: Icon(
                      Icons.assignment_rounded,
                      color: AppColors.primary.getByBrightness(brightness),
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          task.typeTask!,
                          style: TextStyle(
                            fontWeight: FontWeight.bold,
                            color: AppColors.textBody.getByBrightness(brightness),
                          ),
                        ),
                        Text(
                          task.eventName,
                          style: TextStyle(
                            color: AppColors.textSubtitle.getByBrightness(brightness),
                            fontSize: 12,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Container(
                    padding: const EdgeInsets.symmetric(
                      horizontal: 10,
                      vertical: 4,
                    ),
                    decoration: BoxDecoration(
                      color: (isInProgress ? AppColors.info : AppColors.warning).getByBrightness(brightness).withValues(alpha: 0.1),
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: Text(
                      isPending ? 'بانتظارك' : 'قيد التنفيذ',
                      style: TextStyle(
                        color: isInProgress
                            ? AppColors.info.getByBrightness(brightness)
                            : AppColors.warning.getByBrightness(brightness),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () =>
                          Get.toNamed(AppRoutes.taskDetail, arguments: task),
                      style: OutlinedButton.styleFrom(
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        side: BorderSide(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
                      ),
                      child: Text(
                        'التفاصيل',
                        style: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  if (isPending)
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () =>
                            controller.updateTaskStatus(task.id, 'IN_PROGRESS'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.primary.getByBrightness(brightness),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'بدء المهمة',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    )
                  else if (isInProgress)
                    Expanded(
                      child: ElevatedButton(
                        onPressed: () =>
                            controller.updateTaskStatus(task.id, 'COMPLETED'),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: AppColors.success.getByBrightness(brightness),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                        ),
                        child: const Text(
                          'إكمال المهمة',
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SupplierEmptyTasksState extends StatelessWidget {
  const SupplierEmptyTasksState({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Container(
      padding: const EdgeInsets.all(32),
      decoration: AppFormWidgets.cardDecoration(context),
      child: Column(
        children: [
          Icon(
            Icons.assignment_turned_in_rounded,
            size: 60,
            color: Colors.grey[200],
          ),
          const SizedBox(height: 16),
          Text(
            'لا توجد مهام نشطة حالياً',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        ],
      ),
    );
  }
}
