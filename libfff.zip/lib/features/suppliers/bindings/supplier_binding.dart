import 'package:get/get.dart';
import '../data/repository/supplier_repository.dart' show SupplierRepository;
import '../controller/supplier_controller.dart' show SupplierController;
import '../../auth/data/repository/auth_repository.dart' show AuthRepository;
import '../provider/supplier_provider.dart' show SupplierProvider;

class SupplierBinding extends Bindings 
{
  @override
  void dependencies() 
  {
    Get.lazyPut(() => SupplierRepository());
    Get.lazyPut(() => SupplierController());
    Get.lazyPut(() => AuthRepository());
    Get.lazyPut(() => SupplierProvider());
  }
}
