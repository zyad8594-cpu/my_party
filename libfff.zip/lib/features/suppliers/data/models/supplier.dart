import '../../../../core/utils/number_toolse.dart';
import '../../../../core/utils/string_toolse.dart';
import '../../../../data/models/user.dart';
import '../../../services/data/models/service.dart' show Service;
import '../../../tasks/data/models/task.dart';

class Supplier extends User
{
  final String password;
  final String? address;
  final String? notes;
  final List<Service> services;
  final List<Task> tasks;
  

  @override
  String get email => super.email ?? '';

  Supplier({
    required super.id,
    required super.name,
    required String email,
    super.phoneNumber,
    super.imgUrl,
    super.isActive = false,
    super.isDeleted = false,
    super.createdAt = '',
    super.updatedAt = '',
    this.services = const [],
    this.tasks = const [],
    required this.password,
    this.address,
    this.notes,
  }): super(role: 'SUPPLIER', email: email)
  {
    for (var service in this.services) {
      service.suppliers.add(this);
    }
  }

  factory Supplier.fromJson(json) {
    return Supplier(
      id: NumberTools.tryParseInt(json, keys: [
        'id', 'supplier_id', 'user_id',
        'supplierId', 'userId'
      ]),
      imgUrl: StrTools.tryParse(json, keys: [
        'img_url', 'imgUrl', 'user_img', 'supplier_img',
        'userImg', 'supplierImg', 'imgUrl',
        'user_img_url', 'supplier_img_url',
        'userImgUrl', 'supplierImgUrl'
      ]),
      name: StrTools.tryParse(json, keys: [
        'name', 'full_name', 'user_name', 'supplier_name',
        'fullName', 'supplierName', 'userName',
        'userFullName', 'supplierFullName',
        'user_full_name', 'supplier_full_name'
      ]),
      email: StrTools.tryParse(json, keys: [
        'email', 'user_email', 'supplier_email',
        'userEmail', 'supplierEmail', 'email',
      ]),
      password: StrTools.tryParse(json, keys: [
        'password', 'user_password', 'supplier_password',
        'userPassword', 'supplierPassword'
      ]),
      phoneNumber: StrTools.tryParse(json, keys: [
        'phone', 'phone_number', 'user_phone', 'supplier_phone',
        'userPhone', 'supplierPhone', 'phoneNumber',
        'user_phone_number', 'supplier_phone_number',
        'userPhoneNumber', 'supplierPhoneNumber'
      ]),
      address: StrTools.tryParse(json, keys: [
        'address', 'user_address', 'supplier_address',
        'userAddress', 'supplierAddress'
      ]),
      notes: StrTools.tryParse(json, keys: [
        'notes', 'user_notes', 'supplier_notes',
        'userNotes', 'supplierNotes'
      ]),
      createdAt: StrTools.tryParse(json, keys: [
        'created_at', 'createdAt', 'user_created_at', 'supplier_created_at',
        'userCreatedAt', 'supplierCreatedAt'
      ]),
      services: (json['services'] as List?)
          ?.map((e) => Service.fromJson(e))
          .toList() ??
      [],
      tasks: (json['tasks'] as List?)
          ?.map((e) => Task.fromJson(e))
          .toList() ??
      [],
    );
  }

  @override
  toJson() {
    return {
      ...super.toJson(),
      'password': password,
      if(address != null) 'address': address,
      if(notes != null) 'notes': notes,
      'services': services.map((e) => e.toJson()).toList(),
      'tasks': tasks.map((e) => e.toJson()).toList(),
    };
  }

  @override
  Supplier copyWith({
    int? id,
    String? name,
    String? role,
    String? email,
    String? phoneNumber,
    String? imgUrl,
    bool? isActive,
    bool? isDeleted,
    String? createdAt,
    String? updatedAt,
    String? password,
    String? address,
    String? notes,
    List<Service>? services,
    List<Task>? tasks,
  }) {
    return Supplier(
      id: id ?? this.id,
      name: name ?? this.name,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      isActive: isActive ?? this.isActive,
      isDeleted: isDeleted ?? this.isDeleted,
      email: email ?? this.email,
      password: password ?? this.password,
      imgUrl: imgUrl ?? this.imgUrl,
      createdAt: createdAt ?? this.createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      address: address ?? this.address,
      notes: notes ?? this.notes,
      services: services ?? this.services,
      tasks: tasks ?? this.tasks,
    );
  }

  @override
  List<Object?> get props => [
        ...super.props,
        password,
        address,
        notes,
        services,
        tasks,
      ];
}
