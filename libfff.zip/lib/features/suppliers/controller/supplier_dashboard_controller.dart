import 'package:get/get.dart';
import '../../../core/utils/status.dart';
import '../../../core/api/auth_service.dart' show AuthService;
import '../../tasks/controller/task_controller.dart' show TaskController;
import '../../tasks/data/models/task.dart' show Task;

class SupplierDashboardController extends GetxController 
{
  final isLoading = false.obs;

  // Real data from TaskController
  final activeTasks = <Task>[].obs;
  final completedTasksCount = 0.obs;
  final pendingTasksCount = 0.obs;
  final totalEarnings = 0.0.obs;
  final rating = 4.8.obs; // Mock rating since it might not be in the model yet

  // final authUser = AuthService.to.user;

  @override
  void onInit() {
    super.onInit();
    refreshDashboard();
  }

  void refreshDashboard() async {
    isLoading.value = true;
    try {
      // In a real app, we would fetch supplier-specific stats from an API
      // Here we filter the tasks from the general TaskController if available
      if (Get.isRegistered<TaskController>()) {
        final taskController = Get.find<TaskController>();
        await taskController.fetchTasks();

        final supplierId = AuthService.user['id'] ?? AuthService.user['supplier_id'];

        final myTasks = taskController.tasks
            .where((t) => t.assigneeId == supplierId)
            .toList();

        activeTasks.value = myTasks
            .where(
              (t) =>
                  t.status.isIN_PROGRESS ||
                  t.status.isPENDING,
            )
            .toList();

        completedTasksCount.value = myTasks
            .where((t) => t.status.isCOMPLETED)
            .length;

        pendingTasksCount.value = myTasks
            .where((t) => t.status.isPENDING)
            .length;

        totalEarnings.value = myTasks
            .where((t) => t.status.isCOMPLETED)
            .fold(0.0, (sum, item) => sum + (item.cost));
      }
    } catch (e) {
      // print('Dashboard error: $e');
    } finally {
      isLoading.value = false;
    }
  }

  Future<void> updateTaskStatus(int taskId, String newStatus) async {
    try {
      if (Get.isRegistered<TaskController>()) {
        final taskController = Get.find<TaskController>();
        await taskController.updateTaskStatus(taskId, newStatus);
        refreshDashboard();
      }
    } catch (e) {
      Get.snackbar('خطأ', 'فشل تحديث حالة المهمة');
    }
  }
}
