import 'package:get/get.dart';
import '../../services/data/models/service.dart' show Service;
import '../data/repository/supplier_repository.dart' show SupplierRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/supplier.dart' show Supplier;

class SupplierController extends GetxController 
{
  final SupplierRepository _repository = Get.find<SupplierRepository>();

  // Reactive state for Supplier Add/Edit
  final servicesRx = <Service>[].obs;
  final nameRx = ''.obs;
  final phoneRx = ''.obs;
  final emailRx = ''.obs;
  final addressRx = ''.obs;
  final notesRx = ''.obs;

  final suppliers = <Supplier>[].obs;
  final selectedSupplier = Rxn<Supplier>();
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchAll();
  }

  void clearFields() {
    servicesRx.value = [];
    nameRx.value = '';
    phoneRx.value = '';
    emailRx.value = '';
    addressRx.value = '';
    notesRx.value = '';
  }

  void populateFields(Supplier supplier) {
    servicesRx.value = supplier.services;
    nameRx.value = supplier.name;
    phoneRx.value = supplier.phoneNumber??'';
    emailRx.value = supplier.email;
    addressRx.value = supplier.address ?? '';
    notesRx.value = supplier.notes ?? '';
  }

  Future<void> fetchAll() async {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => suppliers.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (supplier) => selectedSupplier.value = supplier,
    );
    isLoading.value = false;
  }

  // Future<void> fetchAllByServiceId(int serviceId) async {
  //   isLoading.value = true;
  //   try {
  //     final list = await _repository.getAllByServiceId(serviceId);
  //     suppliers.value = list;
  //   } catch (e) {
  //     utils.showSnackbar('خطأ', e.toString(), isError: true);
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }
  

  // Future<void> fetchByIdAndServiceId(int id, int serviceId) async {
  //   isLoading.value = true;
  //   try {
  //     final supplier = await _repository.getByIdAndServiceId(id, serviceId);
  //     selectedSupplier.value = supplier;
  //   } catch (e) {
  //     utils.showSnackbar('خطأ', e.toString(), isError: true);
  //   } finally {
  //     isLoading.value = false;
  //   }
  // }
  
  Future<void> createSupplier() async {
    isLoading.value = true;
    final data = {
      'services': servicesRx.map((e) => e.id).toList(),
      'full_name': nameRx.value,
      'phone_number': phoneRx.value,
      'email': emailRx.value,
      'address': addressRx.value,
      'notes': notesRx.value,
      'password': 'password123',
    };
    final result = await _repository.create(data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (newSupplier) {
        suppliers.add(newSupplier);
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة المورد');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateSupplier(int id) async {
    isLoading.value = true;
    final data = {
      'services': servicesRx.map((e) => e.id).toList(),
      'full_name': nameRx.value,
      'phone_number': phoneRx.value,
      'email': emailRx.value,
      'address': addressRx.value,
      'notes': notesRx.value,
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = suppliers.indexWhere((c) => c.id == id);
        if (index != -1) suppliers[index] = updated;
        selectedSupplier.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث المورد');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteSupplier(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        suppliers.removeWhere((c) => c.id == id);
        if (selectedSupplier.value?.id == id) {
          selectedSupplier.value = null;
        }
        utils.showSnackbar('نجاح', 'تم حذف المورد');
      },
    );
  }
}
