import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../../../core/api/auth_service.dart';
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../data/repository/task_repository.dart' show TaskRepository;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/task.dart' show Task;
import '../../suppliers/data/models/supplier.dart' show Supplier;

class TaskController extends GetxController 
{
  final TaskRepository _repository = Get.find<TaskRepository>();
  final AuthController authController = Get.find<AuthController>();

  // Reactive state for Task Add/Edit
  final typeRx = ''.obs;
  final descriptionRx = ''.obs;
  final costRx = 0.0.obs;
  final eventIdRx = 0.obs;
  final assignmentTypeRx = 'COORDINATOR'.obs;
  final assignmentFlowRx = 'myself'.obs;
  final selectedSupplierForNewTaskRx = Rxn<Supplier>();
  final assigneeIdRx = RxnInt();
  final startDateRx = DateTime.now().obs;
  final dueDateRx = DateTime.now().add(const Duration(days: 7)).obs;

  final tasks = <Task>[].obs;
  final searchQuery = ''.obs;
  final selectedStatus = 'الكل'.obs;
  final selectedFilterTab = 'كل المهام'.obs; // 'كل المهام', 'مهامي', 'مهام الموردين'
  final selectedTask = Rxn<Task>();
  final isLoading = false.obs;

  @override
  void onInit() {
    super.onInit();
    fetchTasks();
  }

  void clearFields() {
    typeRx.value = '';
    descriptionRx.value = '';
    costRx.value = 0.0;
    eventIdRx.value = 0;
    assignmentTypeRx.value = 'COORDINATOR';
    assignmentFlowRx.value = 'myself';
    selectedSupplierForNewTaskRx.value = null;
    assigneeIdRx.value = null;
    startDateRx.value = DateTime.now();
    dueDateRx.value = DateTime.now().add(const Duration(days: 7));
  }

  void populateFields(Task task) {
    typeRx.value = task.typeTask!;
    descriptionRx.value = task.taskDescription ?? '';
    costRx.value = task.cost;  
    eventIdRx.value = task.eventId;
    assignmentTypeRx.value = task.assignmentType;
    if (task.assignmentType == 'COORDINATOR') {
      assignmentFlowRx.value = 'myself';
      selectedSupplierForNewTaskRx.value = null;
    } else {
      assignmentFlowRx.value = 'supplier_by_service';
      // If we are editing and have a supplier, we might need to fetch it to show name,
      // but if the task object doesn't have supplier details, that's fine.
    }
    assigneeIdRx.value = task.assigneeId;
    startDateRx.value = task.dateStart != null
        ? DateTime.parse(task.dateStart!)
        : DateTime.now();
    dueDateRx.value = task.dateDue != null
        ? DateTime.parse(task.dateDue!)
        : DateTime.now();
  }

  List<Task> get filteredTasks {
    final role = AuthService.user['role_name']?.toLowerCase() ?? 'coordinator';
    final userId = AuthService.user['user_id'];

    return tasks.where((t) {
      // 0. Role-based global filter: Suppliers only see their own tasks
      if (role == 'supplier' && t.assigneeId != userId) {
        return false;
      }

      // 1. Filter by Search Query
      final matchesSearch =
          t.typeTask!.toLowerCase().contains(searchQuery.value.toLowerCase()) ||
          (t.taskDescription?.toLowerCase().contains(
                searchQuery.value.toLowerCase(),
              ) ??
              false);
      if (!matchesSearch) return false;

      // 2. Filter by Tab (All, My, Vendor)
      bool matchesTab = true;
      if (selectedFilterTab.value == 'مهامي') {
        matchesTab = t.assignmentType.toUpperCase() == 'COORDINATOR' && 
                     t.taskCreatorId == userId;
      } else if (selectedFilterTab.value == 'مهام الموردين') {
        matchesTab = t.assignmentType.toUpperCase() == 'SUPPLIER';
      }
      if (!matchesTab) return false;

      // 3. Filter by Status
      if (selectedStatus.value == 'الكل') return true;

      final taskStatusArabic = t.status.text();
      return taskStatusArabic == selectedStatus.value;
    }).toList();
  }

  Future<void> rateTask(int taskId, int rating, String? comment) async {
    isLoading.value = true;
    final result = await _repository.rate(taskId, rating, comment);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        utils.showSnackbar('نجاح', 'تم تقييم المهمة بنجاح');
        fetchTasks();
      },
    );
    isLoading.value = false;
  }

  Future<void> fetchTasks() async {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => tasks.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetchTask(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (task) => selectedTask.value = task,
    );
    isLoading.value = false;
  }

  Future<void> createTask() async {
    isLoading.value = true;
    final coordinatorId = AuthService.user['user_id'];
    final data = {
      'event_id': eventIdRx.value,
      'coordinator_id': coordinatorId,
      'type_task': typeRx.value,
      'status': 'PENDING',
      'date_start': startDateRx.value.toIso8601String(),
      'date_due': dueDateRx.value.toIso8601String(),
      'notes': '',
      'user_assign_id': (assignmentTypeRx.toUpperCase() == 'COORDINATOR')? coordinatorId : assigneeIdRx.value,
      'description': descriptionRx.value,
      'cost': costRx.value,
      'url_image': '',
    };
    print({...data, 'assignmentTypeRx': assignmentTypeRx.value, 'assignmentFlowRx': assignmentFlowRx.value});
    final result = await _repository.create(data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (newTask) {
        tasks.add(newTask);
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة المهمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateTask(int id, {Status? currentStatus}) async {
    isLoading.value = true;
    final data = {
      'type_task': typeRx.value,
      'status': currentStatus ?? selectedTask.value?.status ?? Status.PENDING,
      'date_start': startDateRx.value.toIso8601String(),
      'date_due': dueDateRx.value.toIso8601String(),
      'assign_description': descriptionRx.value,
      'assign_cost': costRx.value,
      'assign_notes': '',
      'assign_url_image': '',
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = tasks.indexWhere((c) => c.id == id);
        if (index != -1) tasks[index] = updated;
        selectedTask.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث المهمة');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> updateTaskStatus(int id, String status) async {
    isLoading.value = true;
    final data = {'status': status};
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = tasks.indexWhere((c) => c.id == id);
        if (index != -1) tasks[index] = updated;
        if (selectedTask.value?.id == id) {
          selectedTask.value = updated;
        }
        utils.showSnackbar('نجاح', 'تم تحديث حالة المهمة');
      },
    );
    isLoading.value = false;
  }

  Future<void> deleteTask(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        tasks.removeWhere((c) => c.id == id);
        if (selectedTask.value?.id == id) {
          selectedTask.value = null;
        }
        utils.showSnackbar('نجاح', 'تم حذف المنسق');
      },
    );
  }
}
