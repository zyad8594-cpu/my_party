import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../data/models/task.dart' show Task;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/api/auth_service.dart' show AuthService;
import '../controller/task_controller.dart' show TaskController;
import '../widgets/task_detail_widgets.dart' show TaskDetailHeader, TaskDetailGrid, TaskDetailWidgets, TaskProofOfWork, TaskActionButtons;

class TaskDetailScreen extends StatelessWidget 
{
  TaskDetailScreen({super.key});
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final Task task = Get.arguments;
    final taskController = Get.find<TaskController>();
    final role = AuthService.user['role_name'] ?? 'coordinator';

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        showBackButton: true, title: task.typeTask!),
      body: Obx(() {
        // Find the latest task from the controller to ensure reactivity
        final currentTask = taskController.filteredTasks.firstWhere(
          (t) => t.id == task.id,
          orElse: () => task,
        );

        return SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              TaskDetailHeader(task: currentTask),
              const SizedBox(height: 24),
              TaskDetailGrid(task: currentTask),
              const SizedBox(height: 24),
              TaskDetailWidgets.buildInfoCard(
                context,
                title: 'الوصف والملاحظات',
                icon: Icons.description_rounded,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      currentTask.taskDescription ?? 'لا يوجد وصف متاح.',
                      style: TextStyle(
                        color: AppColors.textBody.getByBrightness(brightness),
                        fontSize: 14,
                        height: 1.6,
                      ),
                    ),
                    if (currentTask.notes != null &&
                        currentTask.notes!.isNotEmpty) ...[
                      const Padding(
                        padding: EdgeInsets.symmetric(vertical: 16),
                        child: Divider(height: 1),
                      ),
                      Text(
                        'ملاحظات إضافية:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 14,
                          color: AppColors.primary.getByBrightness(brightness),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        currentTask.notes!,
                        style: TextStyle(
                          color: AppColors.textBody.getByBrightness(brightness),
                          fontSize: 13,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              if (currentTask.status.isCOMPLETED) ...[
                const SizedBox(height: 24),
                TaskProofOfWork(task: currentTask),
              ],
              const SizedBox(height: 32),
              TaskActionButtons(
                task: currentTask,
                role: role,
                controller: taskController,
              ),
            ],
          ),
        );
      }),
    );
  }
}
