import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:my_party/core/utils/status.dart';
import '../data/models/task.dart' show Task;
import '../controller/task_controller.dart' show TaskController;
import '../../../core/components/loading_widget.dart' show LoadingWidget;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/themes/app_colors.dart' show AppColors;

import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;

class TaskListScreen extends StatelessWidget {
  TaskListScreen({super.key});
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    final TaskController controller = Get.find<TaskController>();

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authController, 
        title: 'المهام'),

      floatingActionButton: Container(
        decoration: BoxDecoration(
          gradient: AppColors.primaryGradient.getByBrightness(brightness),
          borderRadius: BorderRadius.circular(16),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.3),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: FloatingActionButton(
          onPressed: () => Get.toNamed(AppRoutes.taskAdd),
          backgroundColor: Colors.transparent,
          elevation: 0,
          child: const Icon(
            Icons.add_task_rounded,
            color: Colors.white,
            size: 30,
          ),
        ),
      ),
      body: Column(
        children: [
          _buildSearchAndFilters(controller, context, brightness),
          Expanded(
            child: Obx(() {
              if (controller.isLoading.value) {
                return const LoadingWidget();
              }
              if (controller.filteredTasks.isEmpty) {
                return _buildEmptyState(brightness);
              }
              return ListView.builder(
                padding: const EdgeInsets.symmetric(horizontal: 20),
                itemCount: controller.filteredTasks.length,
                itemBuilder: (context, index) {
                  final task = controller.filteredTasks[index];
                  return _buildTaskCard(task, brightness);
                },
              );
            }),
          ),
        ],
      ),
    );
  }

  Widget _buildSearchAndFilters(TaskController controller, BuildContext context, Brightness brightness) {
    return Container(
      padding: const EdgeInsets.all(20),
      child: Column(
        children: [
          TextField(
            onChanged: (value) => controller.searchQuery.value = value,
            decoration: AppFormWidgets.searchDecoration('البحث عن مهمة...', context),
          ),
          const SizedBox(height: 16),
          SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              children:
                  [
                    'الكل',
                    'قيد الانتظار',
                    'قيد التنفيذ',
                    'مكتملة',
                    'ملغاة',
                  ].map((status) {
                    return Obx(() {
                      final isSelected =
                          controller.selectedStatus.value == status;
                      return Padding(
                        padding: const EdgeInsets.only(left: 8.0),
                        child: ChoiceChip(
                          label: Text(status),
                          selected: isSelected,
                          onSelected: (selected) {
                            if (selected) {
                              controller.selectedStatus.value = status;
                            }
                          },
                          selectedColor: AppColors.primary.getByBrightness(brightness),
                          labelStyle: TextStyle(
                            color: isSelected
                                ? Colors.white
                                : AppColors.textBody.getByBrightness(brightness),
                            fontWeight: isSelected
                                ? FontWeight.bold
                                : FontWeight.normal,
                          ),
                          backgroundColor: AppColors.surface.getByBrightness(brightness),
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(12),
                          ),
                          showCheckmark: false,
                        ),
                      );
                    });
                  }).toList(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskCard(Task task, Brightness brightness) {
    final statusColor = task.status.tryColor(brightness);
    final statusText = task.status.tryText();

    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: () => Get.toNamed(AppRoutes.taskDetail, arguments: task),
          borderRadius: BorderRadius.circular(24),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  width: 60,
                  height: 60,
                  decoration: BoxDecoration(
                    color: statusColor.withValues(alpha: 0.1),
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Icon(
                    Icons.assignment_rounded,
                    color: statusColor,
                    size: 28,
                  ),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Expanded(
                            child: Text(
                              task.typeTask!,
                              style: TextStyle(
                                fontSize: 16,
                                fontWeight: FontWeight.bold,
                                color: AppColors.textBody.getByBrightness(brightness),
                              ),
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                          _buildStatusBadge(statusText, statusColor),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        task.eventName,
                        style: TextStyle(
                          fontSize: 12,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                        ),
                      ),
                      const SizedBox(height: 4),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Icon(
                                Icons.description_rounded,
                                size: 12,
                                color: AppColors.textSubtitle.getByBrightness(brightness),
                              ),
                              const SizedBox(width: 4),
                              Text(
                                task.taskDescription?.substring(
                                      0,
                                      task.taskDescription!.length > 20
                                          ? 20
                                          : task.taskDescription!.length,
                                    ) ??
                                    '',
                                style: TextStyle(
                                  fontSize: 11,
                                  color: AppColors.textSubtitle.getByBrightness(brightness),
                                ),
                              ),
                            ],
                          ),
                          Row(
                            children: [
                              IconButton(
                                constraints: const BoxConstraints(),
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  Icons.edit_rounded,
                                  size: 18,
                                  color: AppColors.primary.getByBrightness(brightness),
                                ),
                                onPressed: () => Get.toNamed(
                                  AppRoutes.taskAdd,
                                  arguments: task,
                                ),
                              ),
                              const SizedBox(width: 8),
                              IconButton(
                                constraints: const BoxConstraints(),
                                padding: EdgeInsets.zero,
                                icon: Icon(
                                  Icons.delete_rounded,
                                  size: 18,
                                  color: AppColors.accent.getByBrightness(brightness),
                                ),
                                onPressed: () => _delete(task.id, brightness),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStatusBadge(String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.1),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontSize: 10,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }





  Widget _buildEmptyState(Brightness brightness) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.all(24),
            decoration: BoxDecoration(
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.05),
              shape: BoxShape.circle,
            ),
            child: Icon(
              Icons.assignment_turned_in_rounded,
              size: 80,
              color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
            ),
          ),
          const SizedBox(height: 24),
          Text(
            'لا توجد مهام حالياً',
            style: TextStyle(
              color: AppColors.textSubtitle.getByBrightness(brightness),
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
          const SizedBox(height: 8),
          Text(
            'اضغط على زر الإضافة لإضافة مهمة جديدة',
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 14),
          ),
        ],
      ),
    );
  }

  void _delete(int id, Brightness brightness) async {
    final TaskController controller = Get.find<TaskController>();
    Get.defaultDialog(
      title: 'تأكيد الحذف',
      titleStyle: TextStyle(
        color: AppColors.primary.getByBrightness(brightness),
        fontWeight: FontWeight.bold,
      ),
      middleText: 'هل أنت متأكد من حذف هذه المهمة؟',
      middleTextStyle: TextStyle(color: AppColors.textBody.getByBrightness(brightness)),
      backgroundColor: AppColors.surface.getByBrightness(brightness),
      radius: 20,
      confirm: ElevatedButton(
        onPressed: () {
          Get.back();
          controller.deleteTask(id);
        },
        style: ElevatedButton.styleFrom(
          backgroundColor: AppColors.accent.getByBrightness(brightness),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: const Text('نعم، احذف', style: TextStyle(color: Colors.white)),
      ),
      cancel: OutlinedButton(
        onPressed: () => Get.back(),
        style: OutlinedButton.styleFrom(
          side: BorderSide(color: AppColors.primary.getByBrightness(brightness)),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12),
          ),
        ),
        child: Text('إلغاء', style: TextStyle(color: AppColors.primary.getByBrightness(brightness))),
      ),
    );
  }
}
