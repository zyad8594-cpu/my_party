import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../suppliers/controller/supplier_controller.dart' show SupplierController;
import '../../suppliers/data/models/supplier.dart' show Supplier;
import '../controller/task_controller.dart' show TaskController;

class ServiceSuppliersScreen extends StatelessWidget 
{
  final int serviceId;
  final String serviceName;

  const ServiceSuppliersScreen({
    super.key,
    required this.serviceId,
    required this.serviceName,
  });

  @override
  Widget build(BuildContext context) {
    final supplierCtrl = Get.find<SupplierController>();
    final controller = Get.find<TaskController>();
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: AppBar(
        title: Text('موردين - $serviceName'),
        backgroundColor: AppColors.appBarBackground.getByBrightness(brightness),
        elevation: 0,
        centerTitle: true,
      ),
      body: Obx(() {
        if (supplierCtrl.isLoading.value) {
          return const Center(child: CircularProgressIndicator());
        }

        final serviceSuppliers = supplierCtrl.suppliers.where((e) => e.services.any((s) => s.id == serviceId)).toList();

        if (serviceSuppliers.isEmpty) {
          return Center(child: Text('لا يوجد موردين لهذه الخدمة $serviceId'));
        }

        return ListView.builder(
          padding: const EdgeInsets.all(16),
          itemCount: serviceSuppliers.length,
          itemBuilder: (context, index) {
            final supplier = serviceSuppliers[index];
            return Card(
              margin: const EdgeInsets.only(bottom: 12),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: ListTile(
                leading: CircleAvatar(
                  backgroundColor: AppColors.primary.getByBrightness(brightness),
                  child: Icon(Icons.store, color: AppColors.textBasec.getByBrightness(brightness)),
                ),
                title: Text(supplier.name.isEmpty ? 'لا يوجد اسم' : supplier.name, style: TextStyle(color: AppColors.textBasec.getByBrightness(brightness))),
                subtitle: Text(supplier.phoneNumber!.isEmpty ? 'لا يوجد رقم' : supplier.phoneNumber!, style: TextStyle(color: AppColors.textBasec.getByBrightness(brightness))),
                onTap: () {
                  controller.assigneeIdRx.value = supplier.id;
                  Get.back<Supplier>(result: supplier);
                },
              ),
            );
          },
        );
      }),
    );
  }
}
