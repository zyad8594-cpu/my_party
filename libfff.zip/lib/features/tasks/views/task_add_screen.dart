import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/api/auth_service.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../controller/task_controller.dart' show TaskController;
import '../../events/controller/event_controller.dart' show EventController;
import '../../suppliers/controller/supplier_controller.dart' show SupplierController;
import '../../coordinators/controller/coordinator_controller.dart' show CoordinatorController;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../../services/controller/service_controller.dart' show ServiceController;
import 'service_suppliers_screen.dart' show ServiceSuppliersScreen;
import '../data/models/task.dart' show Task;
import '../widgets/task_form_widgets.dart' show TaskDatePicker, TaskSubmitButton;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;

class TaskAddScreen extends StatelessWidget 
{
  TaskAddScreen({super.key});

  final TaskController controller = Get.find<TaskController>();
  final EventController eventCtrl = Get.find<EventController>();
  final SupplierController supplierCtrl = Get.find<SupplierController>();
  final CoordinatorController coordCtrl = Get.find<CoordinatorController>();
  final AuthController authCtrl = Get.find<AuthController>();
  final ServiceController serviceCtrl = Get.find<ServiceController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final Task? task = Get.arguments as Task?;
    final isEditing = task != null;

    if (isEditing) {
      // Use microtask to ensure reactive updates don't clash with build phase
      Future.microtask(() => controller.populateFields(task));
    } else {
      Future.microtask(() {
        controller.clearFields();
        if (eventCtrl.events.isNotEmpty) {
          controller.eventIdRx.value = eventCtrl.events.first.id;
        }
      });
    }

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authCtrl,
        showBackButton: true,
        title: isEditing ? 'تعديل المهمة' : 'إضافة مهمة جديدة',
      ),
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                physics: const BouncingScrollPhysics(),
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildSectionTitle(context, 'المعلومات الأساسية', Icons.info_outline_rounded),
                    const SizedBox(height: 12),
                    _buildGeneralInfoCard(context, brightness),
                    const SizedBox(height: 32),
                    _buildSectionTitle(context, 'إسناد المهمة', Icons.assignment_ind_outlined),
                    const SizedBox(height: 12),
                    _buildAssignmentCard(context, brightness),
                    Obx(() {
                      final bool isMyself = controller.assignmentFlowRx.value == 'myself';
                      final bool hasSupplier = controller.assigneeIdRx.value != null;
                      final bool showRest = isMyself || hasSupplier;

                      return AnimatedSize(
                        duration: const Duration(milliseconds: 400),
                        curve: Curves.easeInOutBack,
                        child: showRest
                            ? Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  const SizedBox(height: 32),
                                  _buildSectionTitle(context, 'الجدولة والتكلفة', Icons.date_range_outlined),
                                  const SizedBox(height: 12),
                                  _buildScheduleAndCostCard(context, brightness),
                                ],
                              )
                            : const SizedBox(width: double.infinity),
                      );
                    }),
                    const SizedBox(height: 40),
                  ],
                ),
              ),
            ),
            _buildBottomBar(context, brightness, isEditing, task),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionTitle(BuildContext context, String title, IconData icon) {
    final brightness = Theme.of(context).brightness;
    final primary = AppColors.primary.getByBrightness(brightness);
    final textTheme = AppColors.textBody.getByBrightness(brightness);

    return Row(
      children: [
        Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: primary.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(icon, size: 20, color: primary),
        ),
        const SizedBox(width: 12),
        Text(
          title,
          style: TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: textTheme,
          ),
        ),
      ],
    );
  }

  Widget _buildCardWrapper({required Widget child, required BuildContext context}) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: AppFormWidgets.cardDecoration(context),
      child: child,
    );
  }

  Widget _buildGeneralInfoCard(BuildContext context, Brightness brightness) {
    return _buildCardWrapper(
      context: context,
      child: Column(
        children: [
          Obx(
            () => DropdownButtonFormField<int>(
              value: controller.eventIdRx.value == 0 ? null : controller.eventIdRx.value,
              decoration: AppFormWidgets.fieldDecoration('المناسبة', Icons.event_rounded, context),
              items: eventCtrl.events.map((e) => DropdownMenuItem(value: e.id, child: Text(e.nameEvent))).toList(),
              onChanged: (val) => controller.eventIdRx.value = val ?? 0,
            ),
          ),
          const SizedBox(height: 20),
          Obx(
            () => TextFormField(
              initialValue: controller.typeRx.value,
              onChanged: (val) => controller.typeRx.value = val,
              decoration: AppFormWidgets.fieldDecoration('عنوان المهمة', Icons.title_rounded, context),
            ),
          ),
          const SizedBox(height: 20),
          Obx(
            () => TextFormField(
              initialValue: controller.descriptionRx.value,
              onChanged: (val) => controller.descriptionRx.value = val,
              maxLines: 3,
              decoration: AppFormWidgets.fieldDecoration('الوصف التفصيلي', Icons.notes_rounded, context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAssignmentCard(BuildContext context, Brightness brightness) {
    return _buildCardWrapper(
      context: context,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Obx(() {
            final flow = controller.assignmentFlowRx.value;
            return DropdownButtonFormField<String>(
              value: flow.isEmpty ? null : flow,
              decoration: AppFormWidgets.fieldDecoration('إضافة مهمة ل', Icons.assignment_ind_rounded, context),
              items: const [
                DropdownMenuItem(value: 'myself', child: Text('نفسي')),
                DropdownMenuItem(value: 'supplier_by_service', child: Text('مورد حسب الخدمات')),
              ],
              onChanged: (val) {
                if (val == 'myself') {
                  controller.assignmentFlowRx.value = 'myself';
                  controller.assignmentTypeRx.value = 'USER';
                  controller.assigneeIdRx.value = AuthService.user['id'];
                  controller.selectedSupplierForNewTaskRx.value = null;
                } else if (val == 'supplier_by_service') {
                  controller.assignmentFlowRx.value = 'supplier_by_service';
                  controller.assignmentTypeRx.value = 'SUPPLIER';
                  controller.assigneeIdRx.value = null;
                  controller.selectedSupplierForNewTaskRx.value = null;
                }
              },
            );
          }),
          Obx(() {
            if (controller.assignmentFlowRx.value == 'supplier_by_service') {
              return AnimatedSize(
                duration: const Duration(milliseconds: 300),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const SizedBox(height: 28),
                    if (controller.selectedSupplierForNewTaskRx.value == null) ...[
                      Text(
                        'اختر نوع الخدمة لتحديد المورد:',
                        style: TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: AppColors.textSubtitle.getByBrightness(brightness),
                        ),
                      ),
                      const SizedBox(height: 16),
                      if (serviceCtrl.services.isEmpty)
                        Container(
                          padding: const EdgeInsets.all(16),
                          decoration: BoxDecoration(
                            color: Colors.red.withOpacity(0.05),
                            borderRadius: BorderRadius.circular(16),
                          ),
                          child: const Center(
                            child: Text(
                              'لا توجد خدمات متاحة حالياً',
                              style: TextStyle(color: Colors.red, fontWeight: FontWeight.bold),
                            ),
                          ),
                        )
                      else
                        Wrap(
                          spacing: 12,
                          runSpacing: 12,
                          children: serviceCtrl.services.map((service) {
                            return _buildServiceChip(context, brightness, service);
                          }).toList(),
                        ),
                    ] else ...[
                      // Selected Supplier View
                      Container(
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: AppColors.primary.getByBrightness(brightness).withOpacity(0.06),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(
                            color: AppColors.primary.getByBrightness(brightness).withOpacity(0.2),
                          ),
                        ),
                        child: Row(
                          children: [
                            Container(
                              padding: const EdgeInsets.all(12),
                              decoration: BoxDecoration(
                                color: AppColors.primary.getByBrightness(brightness).withOpacity(0.12),
                                shape: BoxShape.circle,
                              ),
                              child: Icon(Icons.store_rounded, color: AppColors.primary.getByBrightness(brightness)),
                            ),
                            const SizedBox(width: 16),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Text(
                                    'المورد المحدد',
                                    style: TextStyle(
                                      fontSize: 12,
                                      fontWeight: FontWeight.w600,
                                      color: AppColors.primary.getByBrightness(brightness),
                                    ),
                                  ),
                                  const SizedBox(height: 2),
                                  Text(
                                    controller.selectedSupplierForNewTaskRx.value!.name,
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      fontSize: 16,
                                      color: AppColors.textBody.getByBrightness(brightness),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                            IconButton(
                              icon: const Icon(Icons.edit_rounded, size: 20),
                              color: AppColors.primary.getByBrightness(brightness),
                              style: IconButton.styleFrom(
                                backgroundColor: AppColors.background.getByBrightness(brightness),
                              ),
                              onPressed: () {
                                controller.selectedSupplierForNewTaskRx.value = null;
                                controller.assigneeIdRx.value = null;
                              },
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              );
            }
            return const SizedBox.shrink();
          }),
        ],
      ),
    );
  }

  Widget _buildServiceChip(BuildContext context, Brightness brightness, dynamic service) {
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: () async {
          final result = await Get.to(() => ServiceSuppliersScreen(
                serviceId: service.id,
                serviceName: service.serviceName,
              ));
          if (result != null) {
            controller.selectedSupplierForNewTaskRx.value = result;
            controller.assignmentTypeRx.value = 'SUPPLIER';
            controller.assigneeIdRx.value = result.id;
          }
        },
        borderRadius: BorderRadius.circular(16),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
          decoration: BoxDecoration(
            color: AppColors.background.getByBrightness(brightness),
            border: Border.all(
              color: AppColors.text.getByBrightness(brightness).withOpacity(0.2),
            ),
            borderRadius: BorderRadius.circular(16),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                Icons.miscellaneous_services_rounded,
                color: AppColors.textSubtitle.getByBrightness(brightness),
                size: 18,
              ),
              const SizedBox(width: 8),
              Text(
                service.serviceName,
                style: TextStyle(
                  color: AppColors.textBody.getByBrightness(brightness),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildScheduleAndCostCard(BuildContext context, Brightness brightness) {
    return _buildCardWrapper(
      context: context,
      child: Column(
        children: [
          Row(
            children: [
              Expanded(child: TaskDatePicker(label: 'تاريخ البدء', date: controller.startDateRx)),
              const SizedBox(width: 16),
              Expanded(child: TaskDatePicker(label: 'تاريخ التسليم', date: controller.dueDateRx)),
            ],
          ),
          const SizedBox(height: 20),
          Obx(
            () => TextFormField(
              initialValue: controller.costRx.value == 0.0 ? '' : controller.costRx.value.toString(),
              onChanged: (val) => controller.costRx.value = double.tryParse(val) ?? 0.0,
              keyboardType: TextInputType.number,
              decoration: AppFormWidgets.fieldDecoration('التكلفة الإجمالية', Icons.monetization_on_rounded, context),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildBottomBar(BuildContext context, Brightness brightness, bool isEditing, Task? task) {
    return Container(
      padding: const EdgeInsets.fromLTRB(24, 16, 24, 24),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 15,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: Obx(() {
        final bool showConfirm = controller.assignmentFlowRx.value == 'myself' || controller.assigneeIdRx.value != null;
        return AnimatedOpacity(
          opacity: showConfirm ? 1.0 : 0.5,
          duration: const Duration(milliseconds: 300),
          child: TaskSubmitButton(
            label: isEditing ? 'حفـظ التـعـديـلات' : 'إضـافة المهـمة',
            isLoading: controller.isLoading.value,
            onPressed: (controller.isLoading.value || !showConfirm)
                ? null
                : () {
                    if (isEditing) {
                      controller.updateTask(task!.id, currentStatus: task.status);
                    } else {
                      controller.createTask();
                    }
                  },
          ),
        );
      }),
    );
  }
}
