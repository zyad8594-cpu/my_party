
import '../../../../core/utils/number_toolse.dart';
import '../../../../core/utils/status.dart';
import 'package:equatable/equatable.dart';
import '../../../../core/utils/string_toolse.dart';

class Task extends Equatable {
  final int id;
  final int eventId;
  final String eventName;
  final String? typeTask;
  final Status status; 
  final String? dateStart;
  final String? dateDue;
  final String? dateCompletion;
  final String createdAt;

  final int taskCreatorId;
  final String takCreatorName;
  final int assigneeId;
  final String assignmentType;
  final String? assigneeName;
  final String? taskDescription;
  final double cost;
  final String? notes;
  final String? urlImage;
  final String? reminderType;
  final int? reminderValue;
  final String? reminderUnit;

  Task({
    required this.id,
    required this.eventId,
    required this.eventName,
    this.typeTask,
    this.status = Status.PENDING,
    this.dateStart,
    this.dateDue,
    this.dateCompletion,
    this.createdAt = '',
    required this.taskCreatorId,
    required this.takCreatorName,
    required this.assigneeId,
    required this.assignmentType,
    this.assigneeName,
    this.taskDescription,
    this.cost = 0.0,
    this.notes,
    this.urlImage,
    this.reminderType,
    this.reminderValue,
    this.reminderUnit,
  });
  Task copyWith({
  int? id,
  int? eventId,
  String? eventName,
  int? coordinatorId,
  String? creatorName,
  int? userAssignId,
  String? userAssignType,
  String? userAssignName,
  String? description,
  double? cost,
  String? notes,
  String? urlImage, 
  String? reminderType,
  int? reminderValue,
  String? reminderUnit,
  String? typeTask,
  Status? status, 
  String? dateStart,
  String? dateDue,
  String? dateCompletion,
  String? createdAt,
  }){
    return Task(
      id: id ?? this.id,
      eventId: eventId ?? this.eventId,
      eventName: eventName ?? this.eventName,
      taskCreatorId: coordinatorId ?? this.taskCreatorId,
      takCreatorName: creatorName ?? this.takCreatorName,
      assigneeId: userAssignId ?? this.assigneeId,
      assignmentType: userAssignType ?? this.assignmentType,
      assigneeName: userAssignName ?? this.assigneeName,
      taskDescription: description ?? this.taskDescription,
      cost: cost ?? this.cost,
      notes: notes ?? this.notes,
      urlImage: urlImage ?? this.urlImage,
      reminderType: reminderType ?? this.reminderType,
      reminderValue: reminderValue ?? this.reminderValue,
      reminderUnit: reminderUnit ?? this.reminderUnit,
      typeTask: typeTask ?? this.typeTask,
      status: status ?? this.status, 
      dateStart: dateStart ?? this.dateStart,
      dateDue: dateDue ?? this.dateDue,
      dateCompletion: dateCompletion ?? this.dateCompletion,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  factory Task.fromJson(Map<String, dynamic> json) {
    return Task(
      id: NumberTools.tryParseInt(json, keys: ['task_id', 'id']),
      eventId: NumberTools.tryParseInt(json, keys: ['event_id', 'eventId']),
      eventName: StrTools.tryParse(json, keys: ['event_name', 'eventName']),
      taskCreatorId: NumberTools.tryParseInt(json, keys: ['task_creator_id', 'taskCreatorId']),
      takCreatorName: StrTools.tryParse(json, keys: ['task_creator_name', 'taskCreatorName']),
      assigneeId: NumberTools.tryParseInt(json, keys: ['user_assign_id', 'userAssignId']),
      assignmentType: StrTools.tryParse(json, keys: ['assignment_type', 'assignmentType']),
      assigneeName: StrTools.tryParse(json, keys: ['assignee_name', 'assigneeName']),
      taskDescription: StrTools.tryParse(json, keys: ['description']),
      cost: NumberTools.tryParseDouble(json, keys: ['cost']),
      notes: StrTools.tryParse(json, keys: ['notes']),
      urlImage: StrTools.tryParse(json, keys: ['url_image', 'urlImage']),
      reminderType: StrTools.tryParse(json, keys: ['reminder_type', 'reminderType']),
      reminderValue: NumberTools.tryParseInt(json, keys: ['reminder_value', 'reminderValue']),
      reminderUnit: StrTools.tryParse(json, keys: ['reminder_unit', 'reminderUnit']),
      typeTask: StrTools.tryParse(json, keys: ['type_task', 'typeTask']),
      status: StatusTools.tryParse(json, keys: ['status', 'task_status']),
      dateStart: StrTools.tryParse(json, keys: ['date_start', 'dateStart']),
      dateDue: StrTools.tryParse(json, keys: ['date_due', 'dateDue']),
      dateCompletion: StrTools.tryParse(json, keys: ['date_completion', 'dateCompletion']),
      createdAt: StrTools.tryParse(json, keys: ['created_at', 'createdAt']),
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'event_id': eventId,
      'coordinator_id': taskCreatorId,
      'creator_name': takCreatorName,
      'user_assign_id': assigneeId,
      'user_assign_type': assignmentType,
      if(assigneeName != null) 'user_assign_name': assigneeName,
      if(taskDescription != null) 'description': taskDescription,
      'cost': cost,
      if(notes != null) 'notes': notes,
      if(urlImage != null) 'url_image': urlImage,
      if(reminderType != null) 'reminder_type': reminderType,
      if(reminderValue != null) 'reminder_value': reminderValue,
      if(reminderUnit != null) 'reminder_unit': reminderUnit,
      if(typeTask != null) 'type_task': typeTask,
      'status': status.tryValue(),
      if(dateStart != null) 'date_start': dateStart,
      if(dateDue != null) 'date_due': dateDue,
      if(dateCompletion != null) 'date_completion': dateCompletion,
      'created_at': createdAt,
    };
  }

  @override
  List<Object?> get props => [
        id,
        eventId,
        eventName,
        typeTask,
        status,
        dateStart,
        dateDue,
        dateCompletion,
        createdAt,
        taskCreatorId,
        takCreatorName,
        assigneeId,
        assignmentType,
        assigneeName,
        taskDescription,
        cost,
        notes,
        urlImage,
        reminderType,
        reminderValue,
        reminderUnit,
      ];
}
