import 'package:get/get.dart';
import '../data/repository/task_repository.dart' show TaskRepository;
import '../controller/task_controller.dart' show TaskController;
import '../provider/task_provider.dart' show TaskProvider;

class TaskBinding extends Bindings 
{
  @override
  void dependencies() 
  {
    Get.lazyPut(() => TaskRepository());
    Get.lazyPut(() => TaskController());
    Get.lazyPut(() => TaskProvider());
  }
}
