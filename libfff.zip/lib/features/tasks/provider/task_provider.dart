import 'package:get/get.dart';
import '../../../core/api/api_provider.dart' show ApiProvider;
import '../../../core/api/api_service.dart' show ApiService;
import '../../../core/api/api_constants.dart' show ApiEndpoints;

class TaskProvider extends ApiProvider 
{
  TaskProvider():super(Get.find<ApiService>());

  
  @override
  Future<List> getAll() async 
  {
    final response = await service.get(ApiEndpoints.tasks);
    return List<dynamic>.from(response);
  }
  
  @override
  Future<Map<String, dynamic>> getById(int id) async
  {
    final response = await service.get("${ApiEndpoints.tasks}/$id");
    return Map<String, dynamic>.from(response);
  }

  @override
  Future<Map<String, dynamic>> create(Map<String, dynamic> data) async 
  {
    final response = await service.post(ApiEndpoints.tasks, data: data);
    return Map<String, dynamic>.from(response);
  }

  @override
  Future<Map<String, dynamic>> update(int id, Map<String, dynamic> data) async
  {
    final response = await service.put("${ApiEndpoints.tasks}/$id", data: data);
    return Map<String, dynamic>.from(response);
  }
  
  @override
  Future delete(int id) async 
  {
    return await service.delete("${ApiEndpoints.tasks}/$id");
  }

  Future<Map<String, dynamic>> rate(int id, int value, String? comment) async 
  { 
    return Map<String, dynamic>.from(
      await service.post(
        "${ApiEndpoints.tasks}/$id/rate",
        data: {'value_rating': value, 'comment': comment},
      ),
    ); 
  }
}