import 'package:get/get.dart';
import '../../../core/utils/status.dart';
import '../../../features/events/controller/event_controller.dart';
import '../../../features/tasks/controller/task_controller.dart';
import '../../../features/incomes/controller/income_controller.dart';

class ReportsController extends GetxController {
  final isLoading = false.obs;

  // Mock data for charts
  final RxList<double> monthlyIncome = <double>[
    12000,
    15000,
    18000,
    14000,
    22000,
    25000,
    28000,
    21000,
    24000,
    30000,
    32000,
    35000,
  ].obs;

  final RxMap<String, int> taskStatusStats = <String, int>{
    'pending': 0,
    'in_progress': 0,
    'completed': 0,
    'cancelled': 0,
  }.obs;

  final RxDouble totalRevenue = 0.0.obs;
  final RxDouble totalExpenses = 0.0.obs;
  final RxInt activeEventsCount = 0.obs;

  @override
  void onInit() {
    super.onInit();
    refreshStatistics();
  }

  Future<void> refreshStatistics() async 
  {
    isLoading.value = true;
    
    try {
      final eventCtrl = Get.isRegistered<EventController>() ? Get.find<EventController>() : Get.put(EventController());
      final taskCtrl = Get.isRegistered<TaskController>() ? Get.find<TaskController>() : Get.put(TaskController());
      final incomeCtrl = Get.isRegistered<IncomeController>() ? Get.find<IncomeController>() : Get.put(IncomeController());

      // Fetch fresh data
      await Future.wait([
        eventCtrl.fetchAll(),
        taskCtrl.fetchTasks(),
        incomeCtrl.fetchIncomes(),
      ]);

      // Update Event Stats
      activeEventsCount.value = eventCtrl.events.where((e) => !e.status.isCOMPLETED && !e.status.isCANCELLED).length;

      // Update Task Stats
      final tasks = taskCtrl.tasks;
      taskStatusStats['pending'] = tasks.where((t) => t.status.isPENDING).length;
      taskStatusStats['in_progress'] = tasks.where((t) => t.status.isIN_PROGRESS).length;
      taskStatusStats['completed'] = tasks.where((t) => t.status.isCOMPLETED).length;
      taskStatusStats['cancelled'] = tasks.where((t) => t.status.isCANCELLED).length;

      // Update Income Stats
      final incomes = incomeCtrl.incomes;
      totalRevenue.value = incomes.fold(0, (sum, item) => sum + item.amount);
      
      // Calculate monthly income for chart (last 12 months)
      final now = DateTime.now();
      final List<double> monthlyData = List.filled(12, 0.0);
      
      for (var income in incomes) {
        final date = DateTime.tryParse(income.paymentDate);
        if (date != null) {
          final monthsAgo = (now.year - date.year) * 12 + (now.month - date.month);
          if (monthsAgo >= 0 && monthsAgo < 12) {
            monthlyData[11 - monthsAgo] += income.amount;
          }
        }
      }
      monthlyIncome.value = monthlyData;

      // Mock total expenses for now as there is no expense module yet, or use task costs
      totalExpenses.value = tasks.fold(0, (sum, item) => sum + item.cost);

    } catch (e) {
      print('Error refreshing reports statistics: $e');
    }

    isLoading.value = false;
  }

  void exportReport(String type) {
    // Mock export functionality
    Get.snackbar('تصدير التقرير', 'تم بدء تصدير التقرير بصيغة $type بنجاح');
  }
}
