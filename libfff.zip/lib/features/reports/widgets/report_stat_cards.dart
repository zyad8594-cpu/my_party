import 'package:get/get.dart';
import 'package:flutter/material.dart';
import '../controller/reports_controller.dart' show ReportsController;
import '../../../core/themes/app_colors.dart' show AppColors;

class ReportStatCards extends StatelessWidget 
{
  final ReportsController controller;

  const ReportStatCards({super.key, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: Get.width > 1200 ? 5 : (Get.width > 900 ? 4 : (Get.width > 600 ? 3 : (Get.width > 450 ? 2 : 1))),
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      childAspectRatio: Get.width > 600 ? 1.2 : (Get.width > 450 ? 1.4 : 1.8),
      children: [
        _buildStatCard(
          'إجمالي الدخل',
          '${controller.totalRevenue.value.toStringAsFixed(0)} ر.س',
          Icons.trending_up_rounded,
          AppColors.success.getByBrightness(brightness),
          brightness,
        ),
        _buildStatCard(
          'إجمالي المصاريف',
          '${controller.totalExpenses.value.toStringAsFixed(0)} ر.س',
          Icons.trending_down_rounded,
          AppColors.accent.getByBrightness(brightness),
          brightness,
        ),
        _buildStatCard(
          'المناسبات النشطة',
          '${controller.activeEventsCount.value}',
          Icons.event_available_rounded,
          AppColors.info.getByBrightness(brightness),
          brightness,
        ),
        _buildStatCard(
          'صافي الربح',
          '${(controller.totalRevenue.value - controller.totalExpenses.value).toStringAsFixed(0)} ر.س',
          Icons.account_balance_wallet_rounded,
          AppColors.primary.getByBrightness(brightness),
          brightness,
        ),
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color,
    Brightness brightness,
  ) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: color, size: 24),
          const SizedBox(height: 8),
          Text(
            title,
            style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontSize: 12),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: TextStyle(
              color: AppColors.textBody.getByBrightness(brightness),
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }
}
