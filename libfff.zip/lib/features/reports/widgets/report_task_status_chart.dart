import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import '../controller/reports_controller.dart' show ReportsController;
import '../../../core/themes/app_colors.dart' show AppColors;

class ReportTaskStatusChart extends StatelessWidget {
  final ReportsController controller;

  const ReportTaskStatusChart({super.key, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: BorderRadius.circular(24),
        border: Border.all(color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.1)),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'توزيع حالات المهام',
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: AppColors.textBody.getByBrightness(brightness),
            ),
          ),
          const SizedBox(height: 24),
          Row(
            children: [
              Expanded(
                flex: 2,
                child: SizedBox(
                  height: 180,
                  child: PieChart(
                    PieChartData(
                      sectionsSpace: 2,
                      centerSpaceRadius: 40,
                      sections: [
                        PieChartSectionData(
                          value:
                              controller.taskStatusStats['completed']
                                  ?.toDouble() ??
                              0,
                          title: '',
                          color: AppColors.success.getByBrightness(brightness),
                          radius: 50,
                        ),
                        PieChartSectionData(
                          value:
                              controller.taskStatusStats['in_progress']
                                  ?.toDouble() ??
                              0,
                          title: '',
                          color: AppColors.warning.getByBrightness(brightness),
                          radius: 50,
                        ),
                        PieChartSectionData(
                          value:
                              controller.taskStatusStats['pending']
                                  ?.toDouble() ??
                              0,
                          title: '',
                          color: AppColors.info.getByBrightness(brightness),
                          radius: 50,
                        ),
                        PieChartSectionData(
                          value:
                              controller.taskStatusStats['cancelled']
                                  ?.toDouble() ??
                              0,
                          title: '',
                          color: AppColors.accent.getByBrightness(brightness),
                          radius: 50,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: Column(
                  children: [
                    _buildLegendItem('مكتملة', AppColors.success.getByBrightness(brightness), brightness),
                    _buildLegendItem('قيد التنفيذ', AppColors.warning.getByBrightness(brightness), brightness),
                    _buildLegendItem('قيد الانتظار', AppColors.info.getByBrightness(brightness), brightness),
                    _buildLegendItem('ملغاة', AppColors.accent.getByBrightness(brightness), brightness),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color, Brightness brightness) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Container(
            width: 12,
            height: 12,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 8),
          Text(
            label,
            style: TextStyle(fontSize: 11, color: AppColors.textSubtitle.getByBrightness(brightness)),
          ),
        ],
      ),
    );
  }
}
