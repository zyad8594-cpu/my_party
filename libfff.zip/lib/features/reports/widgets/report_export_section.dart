import 'package:flutter/material.dart';
import '../controller/reports_controller.dart' show ReportsController;
import '../../../core/themes/app_colors.dart' show AppColors;

class ReportExportSection extends StatelessWidget 
{
  final ReportsController controller;

  const ReportExportSection({super.key, required this.controller});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'تصدير التقارير',
          style: TextStyle(
            fontSize: 16,
            fontWeight: FontWeight.bold,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(
              child: _buildExportButton(
                'PDF',
                Icons.picture_as_pdf_rounded,
                Colors.red[400]!,
                () => controller.exportReport('PDF'),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: _buildExportButton(
                'Excel',
                Icons.table_chart_rounded,
                Colors.green[600]!,
                () => controller.exportReport('Excel'),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildExportButton(
    String title,
    IconData icon,
    Color color,
    VoidCallback onTap,
  ) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: color.withValues(alpha: 0.1),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: color.withValues(alpha: 0.2)),
        ),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 20),
            const SizedBox(width: 8),
            Text(
              'تصدير $title',
              style: TextStyle(
                color: color,
                fontWeight: FontWeight.bold,
                fontSize: 13,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
