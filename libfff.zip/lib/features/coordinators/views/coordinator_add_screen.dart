import 'package:flutter/material.dart' show 
  StatelessWidget, BuildContext, Widget, Theme, Scaffold, SingleChildScrollView, 
  Text, TextStyle, TextFormField, Icons, EdgeInsets, BouncingScrollPhysics,
  Column, CrossAxisAlignment, FontWeight, SizedBox, TextInputType, Icon;
  
import 'package:get/get.dart';
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/widgets/app_form_widgets.dart' show AppFormWidgets;
import '../../auth/controller/auth_controller.dart' show AuthController;
import '../controller/coordinator_controller.dart' show CoordinatorController;
import '../data/models/coordinator.dart' show Coordinator;

class CoordinatorAddScreen extends StatelessWidget 
{
  CoordinatorAddScreen({super.key});

  final CoordinatorController controller = Get.find<CoordinatorController>();
  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final Coordinator? coordinator = Get.arguments as Coordinator?;
    final isEditing = coordinator != null;

    if (isEditing) {
      controller.populateFields(coordinator);
    } else {
      controller.clearFields();
    }

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        // authController: authController,
        showBackButton: true,
        title: isEditing ? 'تعديل بيانات المنسق' : 'إضافة منسق جديد',
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        physics: const BouncingScrollPhysics(),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              isEditing ? 'تحديث المعلومات' : 'البيانات الأساسية للمنسق',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
            const SizedBox(height: 16),
            GlassCard(
              padding: const EdgeInsets.all(24),
              child: Column(
                children: [
                  TextFormField(
                    initialValue: isEditing ? coordinator.name : null,
                    onChanged: (val) => controller.fullNameRx.value = val,
                    decoration: AppFormWidgets.fieldDecoration('الاسم الكامل', Icons.person_outline_rounded, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? coordinator.email : null,
                    onChanged: (val) => controller.emailRx.value = val,
                    keyboardType: TextInputType.emailAddress,
                    decoration: AppFormWidgets.fieldDecoration('البريد الإلكتروني', Icons.email_outlined, context),
                  ),
                  const SizedBox(height: 20),
                  TextFormField(
                    initialValue: isEditing ? coordinator.phoneNumber : null,
                    onChanged: (val) => controller.phoneNumberRx.value = val,
                    keyboardType: TextInputType.phone,
                    decoration: AppFormWidgets.fieldDecoration('رقم الهاتف', Icons.phone_outlined, context),
                  ),
                  if (!isEditing) ...[
                    const SizedBox(height: 20),
                    TextFormField(
                      onChanged: (val) => controller.passwordRx.value = val,
                      obscureText: true,
                      decoration: AppFormWidgets.fieldDecoration('كلمة المرور', Icons.lock_outline_rounded, context),
                    ),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 40),
            Obx(
              () => GradientButton(
                text: isEditing ? 'حفظ التعديلات' : 'إضافة منسق',
                isLoading: controller.isLoading.value,
                onPressed: () {
                  if (controller.fullNameRx.value.isEmpty) {
                    Get.snackbar(
                      'تنبيه',
                      'يرجى إدخال اسم المنسق',
                      backgroundColor: AppColors.accent.getByBrightness(brightness).withValues(alpha: 0.1),
                      colorText: AppColors.accent.getByBrightness(brightness),
                      icon: Icon(Icons.warning_amber_rounded, color: AppColors.accent.getByBrightness(brightness)),
                    );
                    return;
                  }
                  if (isEditing) {
                    controller.edit(coordinator.id);
                  } else {
                    controller.create();
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
