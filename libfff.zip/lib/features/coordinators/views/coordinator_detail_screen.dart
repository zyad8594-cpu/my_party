import 'package:flutter/material.dart' show 
  StatelessWidget, BuildContext, Widget, Theme, Scaffold, SingleChildScrollView, 
  Text, TextStyle, Icons, EdgeInsets, Column, CrossAxisAlignment, FontWeight, 
  SizedBox, BoxDecoration, BoxShadow, Icon, ElevatedButton, Row, Expanded, 
  BoxShape, Container, IconData, Center;
  
import 'package:get/get.dart';
import 'package:my_party/features/auth/controller/auth_controller.dart' show AuthController;
import '../data/models/coordinator.dart' show Coordinator;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;

class CoordinatorDetailScreen extends StatelessWidget {
  CoordinatorDetailScreen({super.key});

  final AuthController authController = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    final Coordinator coordinator = Get.arguments;

    return Scaffold(
      appBar: CustomAppBar(
        // authController: authController, 
        showBackButton: true, title: coordinator.name),
      body: Container(
        decoration: BoxDecoration(color: AppColors.background.getByBrightness(brightness)),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 20),
              _buildProfileHeader(coordinator, context),
              const SizedBox(height: 32),
              _buildInfoSection(coordinator, context),
              const SizedBox(height: 40),
              _buildActions(context, coordinator),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildProfileHeader(Coordinator coordinator, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return Column(
      children: [
        Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            gradient: AppColors.primaryGradient.getByBrightness(brightness),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.2),
                blurRadius: 20,
                spreadRadius: 5,
              ),
            ],
          ),
          child: Center(
            child: Text(
              coordinator.name.substring(0, 1).toUpperCase(),
              style: TextStyle(
                fontSize: 48,
                fontWeight: FontWeight.bold,
                color: AppColors.w_b.getByBrightness(brightness),
              ),
            ),
          ),
        ),
        const SizedBox(height: 16),
        Text(
          coordinator.name,
          style: TextStyle(
            fontSize: 24,
            fontWeight: FontWeight.bold,
            color: AppColors.w_b.getByBrightness(brightness),
          ),
        ),
        Text(
          'منسق حفلات معتمد',
          style: TextStyle(color: AppColors.primary.getByBrightness(brightness), fontSize: 16),
        ),
      ],
    );
  }

  Widget _buildInfoSection(Coordinator coordinator, BuildContext context) 
  {
    return Column(
      children: [
        _buildInfoCard(
          Icons.email_outlined,
          'البريد الإلكتروني',
          coordinator.email,
          context,
        ),
        const SizedBox(height: 16),
        _buildInfoCard(
          Icons.phone_outlined,
          'رقم الهاتف',
          coordinator.phoneNumber ?? 'لا يوجد',
          context,
        ),
        const SizedBox(height: 16),
        _buildInfoCard(
          Icons.calendar_today_outlined,
          'تاريخ الانضمام',
          'مارس 2024',
          context,
        ), // Mocked date
      ],
    );
  }

  Widget _buildInfoCard(IconData icon, String label, String value, BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;

    return GlassCard(
      padding: const EdgeInsets.all(16),
      child: Row(
        children: [
          Icon(icon, color: AppColors.primary.getByBrightness(brightness)),
          const SizedBox(width: 16),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                label,
                style: TextStyle(
                  color: AppColors.textSubtitle.getByBrightness(brightness),
                  fontSize: 12,
                ),
              ),
              Text(
                value,
                style: TextStyle(
                  color: AppColors.w_b.getByBrightness(brightness),
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildActions(BuildContext context, Coordinator coordinator) 
  {
    final brightness = Theme.of(context).brightness;
    
    return Row(
      children: [
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.edit, size: 18),
            label: const Text('تعديل'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.surface.getByBrightness(brightness),
              foregroundColor: AppColors.primary.getByBrightness(brightness),
            ),
          ),
        ),
        const SizedBox(width: 16),
        Expanded(
          child: ElevatedButton.icon(
            onPressed: () {},
            icon: const Icon(Icons.message_outlined, size: 18),
            label: const Text('مراسلة'),
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.primary.getByBrightness(brightness),
              foregroundColor: AppColors.w_b.getByBrightness(brightness),
            ),
          ),
        ),
      ],
    );
  }
}
