import 'package:get/get.dart';
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../data/models/coordinator.dart' show Coordinator;
import '../data/repository/coordinator_repository.dart' show CoordinatorRepository;

class CoordinatorController extends GetxController 
{
  final CoordinatorRepository _repository = Get.find<CoordinatorRepository>();

  // Reactive state for Coordinator Add/Edit
  final fullNameRx = ''.obs;
  final emailRx = ''.obs;
  final phoneNumberRx = ''.obs;
  final passwordRx = ''.obs;

  final coordinators = <Coordinator>[].obs;
  final selectedCoordinator = Rxn<Coordinator>();
  final isLoading = false.obs;

  @override
  void onInit() 
  {
    super.onInit();
    fetchAll();
  }

  void clearFields() 
  {
    fullNameRx.value = '';
    emailRx.value = '';
    phoneNumberRx.value = '';
    passwordRx.value = '';
  }

  void populateFields(Coordinator coordinator) 
  {
    fullNameRx.value = coordinator.name;
    emailRx.value = coordinator.email;
    phoneNumberRx.value = coordinator.phoneNumber ?? '';
  }

  Future<void> fetchAll() async 
  {
    isLoading.value = true;
    final result = await _repository.getAll();
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (data) => coordinators.value = data,
    );
    isLoading.value = false;
  }

  Future<void> fetch(int id) async {
    isLoading.value = true;
    final result = await _repository.getById(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (coordinator) => selectedCoordinator.value = coordinator,
    );
    isLoading.value = false;
  }

  Future<void> create() async {
    isLoading.value = true;
    final data = {
      'full_name': fullNameRx.value,
      'email': emailRx.value,
      'phone_number': phoneNumberRx.value,
      if (passwordRx.value.isNotEmpty) 'password': passwordRx.value,
    };
    final result = await _repository.create(data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (newCoordinator) {
        coordinators.add(newCoordinator);
        Get.back();
        utils.showSnackbar('نجاح', 'تم إضافة المنسق');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> edit(int id) async {
    isLoading.value = true;
    final data = {
      'full_name': fullNameRx.value,
      'email': emailRx.value,
      'phone_number': phoneNumberRx.value,
    };
    final result = await _repository.update(id, data);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (updated) {
        final index = coordinators.indexWhere((c) => c.id == id);
        if (index != -1) coordinators[index] = updated;
        selectedCoordinator.value = updated;
        Get.back();
        utils.showSnackbar('نجاح', 'تم تحديث المنسق');
        clearFields();
      },
    );
    isLoading.value = false;
  }

  Future<void> delete(int id) async {
    final result = await _repository.delete(id);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (_) {
        coordinators.removeWhere((c) => c.id == id);
        if (selectedCoordinator.value?.id == id) {
          selectedCoordinator.value = null;
        }
        utils.showSnackbar('نجاح', 'تم حذف المنسق');
      },
    );
  }
}
