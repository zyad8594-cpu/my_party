import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/auth_controller.dart' show AuthController;
import '../../../core/components/custom_app_bar.dart' show CustomAppBar;
import '../../../core/components/glass_card.dart' show GlassCard;
import '../../../core/components/gradient_button.dart' show GradientButton;
import '../../../core/themes/app_colors.dart' show AppColors;
import '../../../core/routes/app_routes.dart' show AppRoutes;

class RegisterScreen extends StatelessWidget {
  RegisterScreen({super.key});

  final AuthController controller = Get.find<AuthController>();

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;

    return Scaffold(
      backgroundColor: AppColors.background.getByBrightness(brightness),
      appBar: CustomAppBar(
        showBackButton: true,
        title: 'إنشاء حساب',
      ),
      body: Stack(
        children: [
          Positioned(
            bottom: -50,
            left: -50,
            child: Container(
              width: 250,
              height: 250,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    AppColors.secondary.getByBrightness(brightness).withValues(alpha: 0.08),
                    AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.03),
                  ],
                ),
              ),
            ),
          ),
          SafeArea(
            child: SingleChildScrollView(
              padding: const EdgeInsets.symmetric(horizontal: 24.0, vertical: 32),
              physics: const BouncingScrollPhysics(),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const SizedBox(height: 16),
                  Center(
                    child: Hero(
                      tag: 'auth_profile_logo',
                      child: Obx(() => InkWell(
                        onTap: controller.pickImage,
                        borderRadius: BorderRadius.circular(60),
                        child: Container(
                          width: 120,
                          height: 120,
                          decoration: BoxDecoration(
                            color: AppColors.surface.getByBrightness(brightness),
                            shape: BoxShape.circle,
                            image: controller.profileImage.value != null 
                              ? DecorationImage(
                                  image: FileImage(controller.profileImage.value!),
                                  fit: BoxFit.cover,
                                )
                              : null,
                            boxShadow: [
                              BoxShadow(
                                color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.1),
                                blurRadius: 20,
                                offset: const Offset(0, 10),
                              ),
                            ],
                          ),
                          child: controller.profileImage.value == null 
                            ? Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                children: [
                                  Icon(
                                    Icons.add_a_photo_outlined,
                                    size: 32,
                                    color: AppColors.primary.getByBrightness(brightness),
                                  ),
                                  const SizedBox(height: 4),
                                  Text(
                                    'صورة',
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppColors.primary.getByBrightness(brightness),
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ],
                              )
                            : Align(
                                alignment: Alignment.bottomRight,
                                child: Container(
                                  padding: const EdgeInsets.all(4),
                                  decoration: BoxDecoration(
                                    color: AppColors.primary.getByBrightness(brightness),
                                    shape: BoxShape.circle,
                                  ),
                                  child: const Icon(
                                    Icons.edit,
                                    size: 16,
                                    color: Colors.white,
                                  ),
                                ),
                              ),
                        ),
                      )),
                    ),
                  ),
                  const SizedBox(height: 32),
                  Text(
                    'انضم إلينا',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color: AppColors.textBody.getByBrightness(brightness),
                      fontWeight: FontWeight.w900,
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'ابدأ بتنظيم مناسباتك بشكل أسهل واحترافي',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: AppColors.textSubtitle.getByBrightness(brightness),
                      fontSize: 15,
                    ),
                  ),
                  const SizedBox(height: 48),
                  GlassCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        TextField(
                          onChanged: (val) => controller.name.value = val,
                          decoration: const InputDecoration(
                            labelText: 'الاسم الكامل',
                            prefixIcon: Icon(Icons.person_outline_rounded),
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          onChanged: (val) => controller.email.value = val,
                          keyboardType: TextInputType.emailAddress,
                          decoration: const InputDecoration(
                            labelText: 'البريد الإلكتروني',
                            hintText: 'example@mail.com',
                            prefixIcon: Icon(Icons.email_outlined),
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          onChanged: (val) => controller.phone.value = val,
                          keyboardType: TextInputType.phone,
                          decoration: const InputDecoration(
                            labelText: 'رقم الهاتف',
                            prefixIcon: Icon(Icons.phone_outlined),
                          ),
                        ),
                        const SizedBox(height: 20),
                        TextField(
                          onChanged: (val) => controller.password.value = val,
                          obscureText: true,
                          decoration: const InputDecoration(
                            labelText: 'كلمة المرور',
                            hintText: '••••••••',
                            prefixIcon: Icon(Icons.lock_outline_rounded),
                          ),
                        ),
                        const SizedBox(height: 20),
                        Obx(
                          () => DropdownButtonFormField<String>(
                            value: controller.selectedRole.value,
                            decoration: const InputDecoration(
                              labelText: 'نوع الحساب',
                              prefixIcon: Icon(Icons.category_outlined),
                            ),
                            items: const [
                              DropdownMenuItem(
                                value: 'coordinator',
                                child: Text('منسق حفلات'),
                              ),
                              DropdownMenuItem(
                                value: 'supplier',
                                child: Text('مزود خدمات'),
                              ),
                            ],
                            onChanged: (value) {
                              if (value != null) controller.selectedRole.value = value;
                            },
                          ),
                        ),
                        const SizedBox(height: 36),
                        Obx(
                          () => GradientButton(
                            text: controller.selectedRole.value == 'supplier' ? 'التالي' : 'إنشاء حساب',
                            isLoading: controller.isLoading.value,
                            onPressed: () {
                              if (controller.selectedRole.value == 'supplier') {
                                if (controller.name.value.isEmpty || controller.email.value.isEmpty || controller.password.value.isEmpty) {
                                  Get.snackbar('تنبيه', 'يرجى ملء جميع البيانات الأساسية أولاً', 
                                    backgroundColor: Colors.red.withOpacity(0.7),
                                    colorText: Colors.white,
                                    snackPosition: SnackPosition.BOTTOM,
                                  );
                                  return;
                                }
                                Get.toNamed(AppRoutes.supplierServiceSelection);
                              } else {
                                controller.register();
                              }
                            },
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 32),
                  TextButton(
                    onPressed: () => Get.back(),
                    child: RichText(
                      text: TextSpan(
                        text: 'لديك حساب بالفعل؟ ',
                        style: TextStyle(color: AppColors.textSubtitle.getByBrightness(brightness), fontFamily: 'Cairo'),
                        children: [
                          TextSpan(
                            text: 'قم بتسجيل الدخول',
                            style: TextStyle(
                              color: AppColors.primary.getByBrightness(brightness),
                              fontWeight: FontWeight.bold,
                              fontFamily: 'Cairo',
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 20),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
