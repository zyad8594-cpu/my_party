import 'package:get/get.dart';
import '../../events/controller/event_controller.dart' show EventController;
import '../../tasks/controller/task_controller.dart' show TaskController;
import '../../clients/controller/client_controller.dart' show ClientController;
import '../../coordinators/controller/coordinator_controller.dart' show CoordinatorController;
import '../../suppliers/controller/supplier_controller.dart' show SupplierController;
import '../../../core/utils/status.dart';

class HomeController extends GetxController {

  // الإحصائيات للصفحة الرئيسية
  final isLoading = false.obs;

  final RxMap<String, int> taskStatusStats = <String, int>{
    'pending': 0,
    'in_progress': 0,
    'completed': 0,
    'cancelled': 0,
  }.obs;
  final RxMap<String, int> eventStatusStats = <String, int>{
    'pending': 0,
    'in_progress': 0,
    'completed': 0,
    'cancelled': 0,
  }.obs;
  
  final totalCoordinators = 0.obs;
  final totalSuppliers = 0.obs;
  final totalEvents = 0.obs;
  final totalTasks = 0.obs;
  final totalClients = 0.obs;

  @override
  void onInit() {
    super.onInit();
    refreshStatistics();
  }

  Future<void> refreshStatistics() async 
  {
    isLoading.value = true;
    
    try {
      // Ensure all required controllers are registered and fetch their data
      final eventCtrl = Get.isRegistered<EventController>() ? Get.find<EventController>() : Get.put(EventController());
      final taskCtrl = Get.isRegistered<TaskController>() ? Get.find<TaskController>() : Get.put(TaskController());
      final clientCtrl = Get.isRegistered<ClientController>() ? Get.find<ClientController>() : Get.put(ClientController());
      final coordCtrl = Get.isRegistered<CoordinatorController>() ? Get.find<CoordinatorController>() : Get.put(CoordinatorController());
      final suppCtrl = Get.isRegistered<SupplierController>() ? Get.find<SupplierController>() : Get.put(SupplierController());

      // Fetch all data in parallel
      await Future.wait([
        eventCtrl.fetchAll(),
        taskCtrl.fetchTasks(),
        clientCtrl.fetchAll(),
        coordCtrl.fetchAll(),
        suppCtrl.fetchAll(),
      ]);

      // Update local stats from fetched data
      totalEvents.value = eventCtrl.events.length;
      eventStatusStats['pending'] = eventCtrl.events.where((e) => e.status.isPENDING).length;
      eventStatusStats['in_progress'] = eventCtrl.events.where((e) => e.status.isIN_PROGRESS).length;
      eventStatusStats['completed'] = eventCtrl.events.where((e) => e.status.isCOMPLETED).length;
      eventStatusStats['cancelled'] = eventCtrl.events.where((e) => e.status.isCANCELLED).length;

      totalTasks.value = taskCtrl.tasks.length;
      taskStatusStats['pending'] = taskCtrl.tasks.where((t) => t.status.isPENDING).length;
      taskStatusStats['in_progress'] = taskCtrl.tasks.where((t) => t.status.isIN_PROGRESS).length;
      taskStatusStats['completed'] = taskCtrl.tasks.where((t) => t.status.isCOMPLETED).length;
      taskStatusStats['cancelled'] = taskCtrl.tasks.where((t) => t.status.isCANCELLED).length;

      totalClients.value = clientCtrl.clients.where((c) => !c.isDeleted).length;
      totalCoordinators.value = coordCtrl.coordinators.length;
      totalSuppliers.value = suppCtrl.suppliers.length;

    } catch (e) {
      print('Error refreshing statistics: $e');
    }

    isLoading.value = false;
  }
}
