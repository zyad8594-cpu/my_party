import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../core/api/auth_service.dart';
import '../../../core/themes/app_colors.dart';
import '../../../core/controllers/main_layout_controller.dart';
import 'home_screen.dart';
import '../../clients/views/client_list_screen.dart';
import '../../events/views/event_list_screen.dart';
import '../../reports/views/reports_screen.dart';
import '../../notifications/views/notification_list_screen.dart';
import '../../suppliers/views/supplier_home_screen.dart';
import '../../tasks/views/role_based_task_list_screen.dart';

class MainLayoutScreen extends StatelessWidget {
  MainLayoutScreen({super.key});

  final MainLayoutController controller = Get.find<MainLayoutController>();

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    
    final role = AuthService.user['role_name'];
    final isSupplier = role == 'supplier';

    final List<Widget> supplierPages = [
      SupplierDashboardScreen(),
      const RoleBasedTaskListScreen(),
      NotificationListScreen(),
    ];

    final List<Widget> adminPages = [
      HomeScreen(),
      ClientListScreen(),
      EventListScreen(),
      ReportsScreen(),
      NotificationListScreen(),
    ];

    final pages = isSupplier ? supplierPages : adminPages;

    final List<BottomNavigationBarItem> supplierItems = const [
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard_rounded),
        label: 'لوحة التحكم',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.assignment_rounded),
        label: 'مهامي',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.notifications_rounded),
        label: 'الإشعارات',
      ),
    ];

    final List<BottomNavigationBarItem> adminItems = const [
      BottomNavigationBarItem(
        icon: Icon(Icons.dashboard_rounded),
        label: 'الرئيسية',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.people_alt_rounded),
        label: 'العملاء',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.calendar_month_rounded),
        label: 'المناسبات',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.bar_chart_rounded),
        label: 'التقارير',
      ),
      BottomNavigationBarItem(
        icon: Icon(Icons.notifications_rounded),
        label: 'الإشعارات',
      ),
    ];

    return Obx(
      () => Scaffold(
        body: IndexedStack(
          index: controller.currentIndex.value,
          children: pages,
        ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withValues(alpha: 0.05),
                blurRadius: 20,
                offset: const Offset(0, -5),
              ),
            ],
            borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
          ),
          child: SafeArea(
            child: BottomNavigationBar(
              currentIndex: controller.currentIndex.value,
              onTap: controller.changePage,
              selectedItemColor: AppColors.primary.getByBrightness(brightness),
              unselectedItemColor: AppColors.textSubtitle.getByBrightness(brightness),
              selectedLabelStyle: const TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
              unselectedLabelStyle: const TextStyle(fontWeight: FontWeight.w500, fontSize: 11),
              showUnselectedLabels: true,
              type: BottomNavigationBarType.fixed,
              backgroundColor: Colors.transparent,
              elevation: 0,
              items: isSupplier ? supplierItems : adminItems,
            ),
          ),
        ),
      ),
    );
  }
}
