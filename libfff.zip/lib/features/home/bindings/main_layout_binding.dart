import 'package:get/get.dart';

import '../../../core/controllers/main_layout_controller.dart' show MainLayoutController;
import 'home_binding.dart' show HomeBinding;
import '../../clients/bindings/client_binding.dart' show ClientBinding;
import '../../events/bindings/event_binding.dart' show EventBinding;
import '../../reports/bindings/report_binding.dart' show ReportBinding;
import '../../notifications/bindings/notification_binding.dart' show NotificationBinding;
import '../../tasks/bindings/task_binding.dart' show TaskBinding;
import '../../suppliers/bindings/supplier_binding.dart' show SupplierBinding;

class MainLayoutBinding extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut<MainLayoutController>(() => MainLayoutController());
    HomeBinding().dependencies();
    ClientBinding().dependencies();
    EventBinding().dependencies();
    ReportBinding().dependencies();
    NotificationBinding().dependencies();
    TaskBinding().dependencies();
    SupplierBinding().dependencies();
  }
}
