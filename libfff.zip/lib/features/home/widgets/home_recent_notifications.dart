import 'package:flutter/material.dart';
import '../../../core/themes/app_colors.dart' show AppColors;

class HomeRecentNotifications extends StatelessWidget 
{
  const HomeRecentNotifications({super.key});

  @override
  Widget build(BuildContext context) 
  {
    final brightness = Theme.of(context).brightness;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              'آخر الإشعارات',
              style: TextStyle(
                fontSize: 18, 
                fontWeight: FontWeight.bold,
                color: AppColors.textBody.getByBrightness(brightness),
              ),
            ),
            TextButton(onPressed: () {}, child: const Text('عرض الكل')),
          ],
        ),
        const SizedBox(height: 16),
        Container(
          decoration: BoxDecoration(
            color: AppColors.surface.getByBrightness(brightness),
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            children: [
              _buildNotificationItem(
                'تم إسناد مهمة جديدة',
                'قام أحمد بإسناد مهمة تنسيق الصوتيات.',
                'قبل 5 دقائق',
                Icons.assignment_turned_in_rounded,
                AppColors.primary.getByBrightness(brightness),
                brightness,
                0,
              ),
              _buildNotificationItem(
                'ميزانية تجوزت الحد',
                'تجاوزت مصروفات حفل التخرج الميزانية المحددة.',
                'قبل ساعة',
                Icons.warning_amber_rounded,
                AppColors.accent.getByBrightness(brightness),
                brightness,
                1,
              ),
              _buildNotificationItem(
                'اكتمل حفل الزفاف',
                'تم إغلاق جميع المهام المتعلقة بحفل زفاف آل عثمان.',
                'منذ ساعتين',
                Icons.done_all_rounded,
                AppColors.success.getByBrightness(brightness),
                brightness,
                2,
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildNotificationItem(
    String title,
    String desc,
    String time,
    IconData icon,
    Color color,
    Brightness brightness,
    int index,
  ) {
    return TweenAnimationBuilder<double>(
      tween: Tween<double>(begin: 0.0, end: 1.0),
      duration: Duration(milliseconds: 800 + (index * 150)),
      curve: Curves.easeOutCubic,
      builder: (context, val, child) => Opacity(
        opacity: val,
        child: Transform.translate(offset: Offset(50 * (1 - val), 0), child: child),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: color.withValues(alpha: 0.1),
            shape: BoxShape.circle,
          ),
          child: Icon(icon, color: color, size: 20),
        ),
        title: Text(
          title,
          style: TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 14,
            color: AppColors.textBody.getByBrightness(brightness),
          ),
        ),
        subtitle: Text(
          desc,
          style: TextStyle(
            fontSize: 12,
            color: AppColors.textSubtitle.getByBrightness(brightness),
          ),
        ),
        trailing: Text(
          time,
          style: TextStyle(fontSize: 10, color: AppColors.text.getByBrightness(brightness)),
        ),
      ),
    );
  }
}
