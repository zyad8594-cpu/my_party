import 'package:flutter/material.dart' show 
  BuildContext, Locale, StatelessWidget, ThemeMode, WidgetsFlutterBinding,
  runApp, Widget;
import 'package:get/get.dart';
import 'package:flutter_localizations/flutter_localizations.dart' show 
  GlobalMaterialLocalizations, GlobalWidgetsLocalizations, GlobalCupertinoLocalizations;
import 'core/routes/app_pages.dart' show AppPages;
import 'core/routes/app_routes.dart' show AppRoutes;
import 'core/api/api_service.dart' show ApiService;
import 'core/api/auth_service.dart' show AuthService;
import 'core/themes/app_theme.dart' show AppTheme;
import 'features/auth/provider/auth_provider.dart' show AuthProvider;
import 'features/auth/data/repository/auth_repository.dart' show AuthRepository;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initServices();
  runApp(const MyApp());
}

Future<void> initServices() async {
  await Get.putAsync(() => AuthService().init());
  await Get.putAsync(() => ApiService().init());
  
  // Global Auth Services
  Get.put(AuthProvider(), permanent: true);
  Get.put(AuthRepository(), permanent: true);
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'نظام إدارة المناسبات',
      theme: AppTheme.lightTheme,
      darkTheme: AppTheme.darkTheme,
      themeMode: ThemeMode.system,
      initialRoute: AppRoutes.login,
      getPages: AppPages.pages,
      locale: const Locale('ar', 'AE'),
      fallbackLocale: const Locale('ar', 'AE'),
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      supportedLocales: const [Locale('ar', 'AE')],
    );
  }
}
