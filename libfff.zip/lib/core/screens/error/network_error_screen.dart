import 'package:flutter/material.dart';
import '../../widgets/error_view.dart';
import 'package:get/get.dart';

class NetworkErrorScreen extends StatelessWidget {
  const NetworkErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('خطأ في الاتصال'),
        centerTitle: true,
      ),
      body: ErrorView(
        icon: Icons.wifi_off_rounded,
        message: 'لا يوجد اتصال بالإنترنت، يرجى التحقق من الشبكة الخاصة بك والمحاولة مرة أخرى.',
        retryText: 'إعادة المحاولة',
        onRetry: () {
          // يمكن اینجا استخدام Get.back() للمحاولة أو استدعاء دالة أخرى
          Get.back();
        },
      ),
    );
  }
}
