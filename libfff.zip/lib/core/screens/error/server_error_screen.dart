import 'package:flutter/material.dart';
import '../../widgets/error_view.dart';
import 'package:get/get.dart';

class ServerErrorScreen extends StatelessWidget {
  const ServerErrorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('خطأ في الخادم'),
        centerTitle: true,
      ),
      body: ErrorView(
        icon: Icons.cloud_off_rounded,
        message: 'حدث خطأ عام في الخادم. فريقنا يعمل على حله الآن. يرجى المحاولة لاحقاً.',
        retryText: 'العودة للخلف',
        onRetry: () {
          Get.back();
        },
      ),
    );
  }
}
