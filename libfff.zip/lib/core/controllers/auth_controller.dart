// ignore_for_file: unused_local_variable

import 'dart:io' show File;
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart' show ImagePicker, ImageSource, XFile;
import 'package:dio/dio.dart' as dio;
import '../../../core/routes/app_routes.dart' show AppRoutes;
import '../../../core/api/auth_service.dart' show AuthService;
import '../../../core/utils/utils.dart' as utils show showSnackbar;
import '../../features/auth/data/repository/auth_repository.dart' show AuthRepository;
import '../api/api_service.dart';

class AuthController extends GetxController 
{
  final AuthRepository _authRepository = Get.find<AuthRepository>();

  final email = ''.obs;
  final password = ''.obs;
  final name = ''.obs;
  final phone = ''.obs;

  final selectedRole = 'coordinator'.obs;
  final profileImage = Rxn<File>();
  final selectedServiceIds = <int>[].obs;

  final isLoading = false.obs;
  final isErrorShow = false.obs;

  final ImagePicker _picker = ImagePicker();

  Future<void> pickImage() async {
    final XFile? image = await _picker.pickImage(source: ImageSource.gallery);
    if (image != null) {
      profileImage.value = File(image.path);
    }
  }



  void login() async {
    if (email.value.isEmpty || password.value.isEmpty) {
      if (!isErrorShow.value) {
        isErrorShow.value = true;
        utils.showSnackbar('خطأ', 'يرجى إدخال البريد وكلمة المرور', isError: true);
        Future.delayed(const Duration(seconds: 3), () {
          isErrorShow.value = false;
        });
      }

      return;
    }

    isLoading.value = true;
    final result = await _authRepository.login(email.value, password.value);
    
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (response) async {
        final token = response['token'];
        final userData = response['user'];
        await AuthService.saveAuthData(token, userData);
        Get.find<ApiService>().setToken(token);

        if (userData['role_name'] == 'SUPPLIER') {
          Get.offAllNamed(AppRoutes.supplierHome);
        } else {
          Get.offAllNamed(AppRoutes.home);
        }

        utils.showSnackbar('نجاح', 'تم تسجيل الدخول بنجاح');
      },
    );
    isLoading.value = false;
  }

  void register() async {
    if (name.value.isEmpty || email.value.isEmpty || password.value.isEmpty) {
      utils.showSnackbar('خطأ', 'يرجى ملء جميع الحقول', isError: true);
      return;
    }
    isLoading.value = true;
    
    // We use FormData to support file uploads
    final Map<String, dynamic> mapData = {
      'full_name': name.value,
      'email': email.value,
      'password': password.value,
      'phone': phone.value,
      'role_name': selectedRole.value.toUpperCase(),
    };

    dynamic finalData;
    
    if (profileImage.value != null || (selectedRole.value == 'supplier' && selectedServiceIds.isNotEmpty)) {
      finalData = dio.FormData.fromMap({
        ...mapData,
        if (selectedRole.value == 'supplier') 'service_ids[]': selectedServiceIds,
        if (profileImage.value != null) 
          'img_url': await dio.MultipartFile.fromFile(
            profileImage.value!.path,
            filename: profileImage.value!.path.split('/').last,
          ),
      });
    } else {
      finalData = mapData;
    }

    final result = await _authRepository.register(finalData);
    result.fold(
      (error) => utils.showSnackbar('خطأ', error.message, isError: true),
      (response) {
        Get.offAllNamed(AppRoutes.login);
        utils.showSnackbar('نجاح', 'تم التسجيل بنجاح، يمكنك تسجيل الدخول الآن');
        // Clear data
        _clearForm();
      },
    );
    isLoading.value = false;
  }

  void _clearForm() {
    name.value = '';
    email.value = '';
    password.value = '';
    phone.value = '';
    profileImage.value = null;
    selectedServiceIds.clear();
  }

  void logout() {
    AuthService.logout();
  }

}
