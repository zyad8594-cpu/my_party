import 'package:get/get.dart' show GetxController;

abstract class Controllers extends GetxController {
  final List<(String, Function)> _actions = [];

  (bool, int) _has(String name) {
    var i = 0;
    for (var element in _actions) {
      if (element.$1 == name) {
        return (true, i);
      }
      i++;
    }
    return (false, -1);
  }

  bool has(String name) {
    return _has(name).$1;
  }

  void set(String name, Function value) {
    final has = this._has(name);
    if (has.$1) {
      _actions[has.$2] = (name, value);
      return;
    }
    _actions.add((name, value));
  }

  void add(String name, Function value) {
    if (has(name)) {
      throw Exception('Action already exists');
    }
    _actions.add((name, value));
  }

  Function? at(String name) {
    for (var element in _actions) {
      if (element.$1 == name) {
        return element.$2;
      }
    }
    return null;
  }

  dynamic executeAction(String name, [dynamic args]) {
    return at(name)!(args);
  }

  Future<dynamic> executeAsyncAction(String name, [dynamic args]) async {
    return (await at(name)!(args));
  }

  void addAll(List<(String, Function)> actions) {
    for (var action in actions) {
      add(action.$1, action.$2);
    }
  }
}
