class StrTools 
{
  static String tryParse<K>(value, {String defaultV = '', K? keys})
  {
    try{ return value as String;}catch(e){}
    if(value is Map || value is List)
    {
      for(var key in ((keys is Iterable))? keys : [keys]){
        try{
          final val = value[key];
          return val as String;
        }catch(e){}
      }
    }
    
    return defaultV;
  }

  static String parse<K>(value, {String? defaultV, K? keys}) 
  {
    try{ return value as String;}catch(e){}
    if(value is Map || value is List)
    {
      for(var key in (keys is Iterable)? keys : [keys]){
        try{
          final val = value[key];
          return val as String;
        }catch(e){}
      }      
    }
    if(defaultV != null) return defaultV;
    throw Exception('Invalid value: $value');
  }
}