class ListTools 
{
  static List<T> tryParse<T, K>(value, {List<T> defaultV = const [], K? keys})
  {
    if((value is Map || value is List) && keys != null)
    {
      for(var key in ((keys is Iterable))? keys : [keys])
      {
        try{ 
          final val = value[key];
          return val as List<T>;
        }catch(e){}
      }
    }
    
    try{ return value as List<T>;}catch(e){}
    return defaultV;
  }

  static List<T> parse<T, K>(value, {List<T>? defaultV, K? keys})
  {
    if((value is Map || value is List) && keys != null)
    {
      for(var key in ((keys is Iterable))? keys : [keys])
      {
        try{ 
          final val = value[key];
          return val as List<T>;
        }catch(e){}
      }
    }
    
    try{ return value as List<T>;}catch(e){}
    if(defaultV != null) return defaultV;
    throw Exception('Invalid value: $value');
  }

  static List<T> map<T>(
    T Function(dynamic) toElement,{
    value, 
    List<T>? defaultV,
    keys
  })
  {
    if(keys != null)
    {
      for(var key in ((keys is Iterable)? keys : [keys]))
      {
        try{ 
          final val = value[key];
          return val.map(toElement).toList();
        }catch(e){}
      }
    }
    
    try{ return value.map(toElement).toList();}catch(e){}
    if(defaultV != null) return defaultV.map(toElement).toList();
    throw Exception('Invalid value: $value');
  }

  static List<T> tryMap<T>(
    T Function(dynamic) toElement,{
    value, 
    List<T> defaultV = const [],
    keys
  })
  {
    if(keys != null)
    {
      for(var key in ((keys is Iterable)? keys : [keys]))
      {
        try{ 
          final val = value[key];
          return val.map(toElement).toList();
        }catch(e){}
      }
    }
    
    try{ return value.map(toElement).toList();}catch(e){}
    return defaultV.map(toElement).toList();
  }

}