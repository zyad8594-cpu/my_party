class MapTools 
{
  static Map<MK, MV> tryParse<MK, MV, K>(value, {Map<MK, MV> defaultV = const {}, K? keys})
  {
    if((value is Map || value is List) && keys != null)
    {
      for(var key in ((keys is Iterable))? keys : [keys])
      {
        try{ 
          final val = value[key];
          return val as Map<MK, MV>;
        }catch(e){}
      }
    }
    
    try{ return value as Map<MK, MV>;}catch(e){}
    return defaultV;
  }

  static Map<MK, MV> parse<MK, MV, K>(value, {Map<MK, MV>? defaultV, K? keys})
  {
    if((value is Map || value is List) && keys != null)
    {
      for(var key in ((keys is Iterable))? keys : [keys])
      {
        try{ 
          final val = value[key];
          return val as Map<MK, MV>;
        }catch(e){}
      }
    }
    
    try{ return value as Map<MK, MV>;}catch(e){}
    if(defaultV != null) return defaultV;
    throw Exception('Invalid value: $value');
  }

}