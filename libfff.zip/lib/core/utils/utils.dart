import 'package:flutter/material.dart' show 
  Colors, EdgeInsets, Center, CircularProgressIndicator;
import 'package:get/get.dart';

void showSnackbar(String title, String message, {bool isError = false, SnackPosition position = SnackPosition.BOTTOM}) 
{
  Get.snackbar(
    title,
    message,
    snackPosition: position,
    backgroundColor: isError ? Colors.red : Colors.green,
    colorText: Colors.white,
    margin: const EdgeInsets.all(8),
  );
}

void showLoading() 
{
  Get.dialog(
    const Center(child: CircularProgressIndicator()),
    barrierDismissible: false,
  );
}

void hideLoading() 
{
  if (Get.isDialogOpen ?? false) Get.back();
}

num toNum(val, [num defaultValue = 0]) 
{
  if (val is num) return val;
  if (val is String) return num.parse(val);
  return defaultValue;
}

String toStr(val, [String defaultValue = '']) 
{
  if (val is String) return val;
  try 
  {
    return val.toString();
  } 
  catch (e) 
  {
    return defaultValue;
  }
}