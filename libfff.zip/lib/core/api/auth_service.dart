import 'dart:convert' show jsonDecode, jsonEncode;

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../routes/app_routes.dart' show AppRoutes;
import 'api_constants.dart';

class AuthService extends GetxService {
  // static AuthService get to => Get.find<AuthService>();

  final RxString _token = ''.obs;
  final RxMap<String, dynamic> _user = RxMap({});
  static RxMap<String, dynamic> get user => Get.find<AuthService>()._user;
  static RxString get token => Get.find<AuthService>()._token;

  static RxBool get userIsSupplier => (Get.find<AuthService>()._user['role_name'] == 'SUPPLIER').obs;
  
  Future<AuthService> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token.value = prefs.getString(ApiKeys.tokenKey) ?? '';
    if (_token.isNotEmpty) {
      _user.value = Map<String, dynamic>.from(jsonDecode(prefs.getString(ApiKeys.userKey) ?? '{}'));
    }
    return this;
  }

  static Future<void> saveAuthData(
    String newToken,
    Map<String, dynamic> userData,
  ) async {
    return await Get.find<AuthService>()._saveAuthData(newToken, userData);
  }
  
  Future<void> _saveAuthData(
    String newToken,
    Map<String, dynamic> userData,
  ) async {
    _token.value = newToken;
    _user.value = userData;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(ApiKeys.tokenKey, newToken);
    await prefs.setString(ApiKeys.userKey, jsonEncode(userData));
  }

  static Future<void> logout() async {
    return await Get.find<AuthService>()._logout();
  }
  Future<void> _logout() async {
    _token.value = '';
    _user.clear();
    final prefs = await SharedPreferences.getInstance();
    await prefs.remove(ApiKeys.tokenKey);
    await prefs.remove(ApiKeys.userKey);
    Get.offAllNamed(AppRoutes.login);
  }

  bool get isLoggedIn => _token.isNotEmpty;
}
