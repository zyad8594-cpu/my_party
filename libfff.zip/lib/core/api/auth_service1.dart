import 'dart:convert' show jsonDecode, jsonEncode;

import 'package:get/get.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../routes/app_routes.dart'  show AppRoutes;
import 'api_constants.dart';

class AuthService extends GetxService {
  static AuthService get to => Get.find();

  final RxString _token = ''.obs;
  final RxMap<String, dynamic> _user = RxMap({});

  Future<AuthService> init() async {
    final prefs = await SharedPreferences.getInstance();
    _token.value = prefs.getString(ApiKeys.tokenKey) ?? '';
    if (_token.isNotEmpty) {
      final userJson = prefs.getString(ApiKeys.userKey);
      if (userJson != null) {
        _user.value = Map<String, dynamic>.from(jsonDecode(userJson));
      }
    }
    return this;
  }

  Future<void> setToken(String newToken, [SharedPreferences? prefs]) async {
    _token.value = newToken;
    prefs ??= await SharedPreferences.getInstance();
    await prefs.setString(ApiKeys.tokenKey, newToken);
  }

  String getToken() => _token.value;

  Future<void> clearToken([SharedPreferences? prefs]) async {
    _token.value = '';
    prefs ??= await SharedPreferences.getInstance();
    await prefs.remove(ApiKeys.tokenKey);
  }

  Future<void> setUser(
    Map<String, dynamic> userData, [
    SharedPreferences? prefs,
  ]) async {
    _user.value = userData;
    prefs ??= await SharedPreferences.getInstance();
    await prefs.setString(ApiKeys.userKey, jsonEncode(userData));
  }

  Map<String, dynamic> getUser() => _user.value;

  Future<void> clearUser([SharedPreferences? prefs]) async {
    _user.value.clear();
    prefs ??= await SharedPreferences.getInstance();
    await prefs.remove(ApiKeys.userKey);
  }

  Future<void> saveAuthData(
    String newToken,
    Map<String, dynamic> userData,
  ) async {
    final prefs = await SharedPreferences.getInstance();
    await setToken(newToken, prefs);
    await setUser(userData, prefs);
  }

  Future<void> logout() async {
    final prefs = await SharedPreferences.getInstance();
    clearToken(prefs);
    clearUser(prefs);
    Get.offAllNamed(AppRoutes.login);
  }

  bool get isLoggedIn => getToken().isNotEmpty;
}
