import 'package:flutter/material.dart' show 
  Brightness, Color, LinearGradient, Alignment, Colors;

class AppColorSet<T> 
{
  final T light;
  final T dark;

  const AppColorSet({required this.light, required this.dark});

  T getByBrightness(Brightness brightness)=> brightness == Brightness.dark? dark: light;
}

class AppColors 
{
  // Primary colors (Midnight Navy in Light, Soft Gold in Dark)
  static const primary = AppColorSet(light: Color(0xFF0F172A), dark: Color(0xFFD4AF37));
  static const secondary = AppColorSet(light: Color(0xFFD4AF37), dark: Color(0xFFF3E5AB)); 
  static const accent = AppColorSet(light: Color(0xFFE11D48), dark: Color(0xFFE11D48)); 

  // Functional colors
  static const success = AppColorSet(light: Color(0xFF10B981), dark: Color(0xFF10B981));
  static const warning = AppColorSet(light: Color(0xFFF59E0B), dark: Color(0xFFF59E0B));
  static const info = AppColorSet(light: Color(0xFF0EA5E9), dark: Color(0xFF0EA5E9));

  // Background & Surface
  static const boxDecoration = AppColorSet(light: Color(0xFFFFFFFF), dark: Color(0xFF1E293B));
  static const background = AppColorSet(light: Color(0xFFF8FAFC), dark: Color(0xFF020617)); // Pearl White & Very Dark Blue
  static const surface = AppColorSet(light: Color(0xFFFFFFFF), dark: Color(0xFF0F172A)); // White & Dark Navy
  static const card = surface;
  static const cardClient = AppColorSet(light: Color(0xFFF1F5F9), dark: Color(0xFF1E293B));
  static const searchBarFillColor = AppColorSet(light: Color(0xFF0F172A), dark: Color(0xFF1E293B));

  // Text colors
  static const textBody = AppColorSet(light: Color(0xFF0F172A), dark: Color(0xFFF1F5F9));
  static const textBasec = AppColorSet(light: Colors.black, dark: Colors.white);
  static const textSubtitle = AppColorSet(light: Color(0xFF64748B), dark: Color(0xFF94A3B8));
  static const text = AppColorSet(light: Color(0xFF94A3B8), dark: Color(0xFF64748B));

  // Special backgrounds (Pastels)
  static const primaryStatusBg = AppColorSet(light: Color(0xFFF1F5F9), dark: Color(0xFF1E293B)); // Slate pastel
  static const successStatusBg = AppColorSet(light: Color(0xFFECFDF5), dark: Color(0xFF064E3B));
  static const warningStatusBg = AppColorSet(light: Color(0xFFFFFBEB), dark: Color(0xFF78350F));
  static const dangerStatusBg = AppColorSet(light: Color(0xFFFEF2F2), dark: Color(0xFF7F1D1D));

  static const transparent = AppColorSet(light: Colors.transparent, dark: Colors.transparent);
  static const appBarBackground = AppColorSet(light: Color(0xFFF8FAFC), dark: Color(0xFF020617));

  static const w_b = AppColorSet(light: Colors.white, dark: Colors.black);

  // Gradients
  static const primaryGradient = AppColorSet(
    light: LinearGradient(
      colors: [Color(0xFF0F172A), Color(0xFF1E293B)], // Midnight Navy to Slate
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
    dark: LinearGradient(
      colors: [Color(0xFFD4AF37), Color(0xFFF3E5AB)], // Gold to Champagne
      begin: Alignment.topLeft,
      end: Alignment.bottomRight,
    ),
  );
}

