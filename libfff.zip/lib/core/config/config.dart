class Config 
{
  static const String 
    APP_NAME = 'my_party_pro',
    APP_VERSION = '1.0.0',
    APP_DESCRIPTION = 'My Party Pro is a party management application',
    APP_AUTHOR = 'Zyad',
    APP_AUTHOR_EMAIL = 'zyad8594@gmail.com',
    APP_AUTHOR_URL = 'https://github.com/zyad-dev'
  ;

}

class Assets
{
  static const String 
    _root = 'assets',
      images = '$_root/images',
        appLogo = '$images/logo.png',
        appIcon = '$images/icon.png',
        appSplash = '$images/splash.png',
        appFavicon = '$images/favicon.png',
        appScreenshot = '$images/screenshot.png',
        appBanner = '$images/banner.png',
        appLogoDark = '$images/logo_dark.png',
        appIconDark = '$images/icon_dark.png',
        appSplashDark = '$images/splash_dark.png',
        appFaviconDark = '$images/favicon_dark.png',
        appScreenshotDark = '$images/screenshot_dark.png',
        appBannerDark = '$images/banner_dark.png',
      icons = '$_root/icons'
  ;
}


