import 'package:get/get.dart';
import 'package:flutter/material.dart' show 
  StatelessWidget, PreferredSizeWidget, Widget, BuildContext, Brightness,
  Theme, Color, AppBar, Text, TextStyle, FontWeight, IconThemeData, IconButton,
  Icon, Icons, CircleAvatar, NetworkImage, Size, kToolbarHeight;
  
import '../api/auth_service.dart';
import '../themes/app_colors.dart' show AppColors;
import '../routes/app_routes.dart' show AppRoutes;

class CustomAppBar extends StatelessWidget implements PreferredSizeWidget 
{
  final String title;
  final List<Widget>? actions;
  final bool showBackButton;

  const CustomAppBar({
    super.key, 
    required this.title, 
    this.actions,
    this.showBackButton = false,
    // required this.authController,
  });

  @override
  Widget build(BuildContext context) {
    Brightness brightness = Theme.of(context).brightness;
    final Color textColor = AppColors.textBasec.getByBrightness(brightness);

    return AppBar(
      title: Text(
        title,
        style: TextStyle(
          color: textColor,
          fontWeight: FontWeight.bold,
          fontSize: 18,
        ),
      ),
      centerTitle: true,
      backgroundColor: AppColors.primary.getByBrightness(brightness),
      elevation: 0,
      scrolledUnderElevation: 0,
      iconTheme: IconThemeData(color: textColor),
      leading: showBackButton
          ? IconButton(
              icon: Icon(Icons.arrow_back_ios_new_rounded, color: textColor),
              onPressed: () => Get.back(),
            )
          : IconButton(
              onPressed: () {
                Get.toNamed(AppRoutes.profile);
              },
              icon: CircleAvatar(
                radius: 18,
                backgroundImage: NetworkImage(
                  AuthService.user['img_url'] ?? '',                ),
              ),
            ),
      actions: actions,
    );
  }

  @override
  Size get preferredSize => const Size.fromHeight(kToolbarHeight);
}
