import 'package:flutter/material.dart' show
  StatelessWidget, Widget, BuildContext, Brightness, 
  Theme, CircularProgressIndicator, Center;
import '../themes/app_colors.dart' show AppColors;

class LoadingWidget extends StatelessWidget {
  const LoadingWidget({super.key});

  @override
  Widget build(BuildContext context) {
    Brightness brightness = Theme.of(context).brightness;
    return Center(
      child: CircularProgressIndicator(
        color: AppColors.primary.getByBrightness(brightness),
        strokeWidth: 3,
      ),
    );
  }
}