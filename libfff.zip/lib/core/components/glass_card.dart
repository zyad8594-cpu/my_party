import 'package:flutter/material.dart' show 
  StatelessWidget, Widget, BuildContext, Theme, BoxDecoration, 
  EdgeInsetsGeometry, BorderRadius, Offset, Border, BoxShadow, Container,
  EdgeInsets;
import '../themes/app_colors.dart' show AppColors;

class GlassCard extends StatelessWidget 
{
  final Widget child;
  final EdgeInsetsGeometry? padding;
  final double? width;
  final double? height;
  final BorderRadius? borderRadius;

  const GlassCard({
    super.key,
    required this.child,
    this.padding,
    this.width,
    this.height,
    this.borderRadius,
  });

  @override
  Widget build(BuildContext context) {
    final brightness = Theme.of(context).brightness;
    return Container(
      width: width,
      height: height,
      padding: padding ?? const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: AppColors.surface.getByBrightness(brightness),
        borderRadius: borderRadius ?? BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.primary.getByBrightness(brightness).withValues(alpha: 0.04),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
        border: Border.all(
          color: AppColors.textSubtitle.getByBrightness(brightness).withValues(alpha: 0.05),
          width: 1,
        ),
      ),
      child: child,
    );
  }
}
