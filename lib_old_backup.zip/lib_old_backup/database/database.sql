
-- حذف قاعدة البيانات إذا كانت موجودة وإنشاء قاعدة جديدة
DROP DATABASE IF EXISTS `my_party_1`;

CREATE DATABASE IF NOT EXISTS `my_party_1` 
    DEFAULT CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;
USE `my_party_1`;


-- 1. إنشاء الجداول (Tables) 



-- 1.1 جدول الأدوار (Roles)
CREATE TABLE IF NOT EXISTS `Roles` (
    `role_id` INT PRIMARY KEY AUTO_INCREMENT,
    `role_name` VARCHAR(50) UNIQUE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


-- 1.2 جدول الصلاحيات (Permissions)
CREATE TABLE IF NOT EXISTS `Permissions` (
    `permission_id` INT PRIMARY KEY AUTO_INCREMENT,
    `permission_name` VARCHAR(100) UNIQUE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.3 جدول صلاحيات الأدوار (Role_Permissions)
CREATE TABLE IF NOT EXISTS `Role_Permissions` (
    `role_id` INT NOT NULL,
    `permission_id` INT NOT NULL,
    PRIMARY KEY (`role_id`, `permission_id`),
    FOREIGN KEY (`role_id`) REFERENCES `Roles`(`role_id`) ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `Permissions`(`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.4 جدول المستخدمين (Users) – نظام الدخول الموحد
CREATE TABLE IF NOT EXISTS `Users` (
    `user_id` INT PRIMARY KEY AUTO_INCREMENT,
    `email` VARCHAR(100) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role_id` INT NOT NULL,
    `is_active` BOOLEAN DEFAULT TRUE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`role_id`) REFERENCES `Roles`(`role_id`),
    UNIQUE KEY `unique_email_role` (`email`, `role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.5 جدول الخدمات (Services)
CREATE TABLE IF NOT EXISTS `Services` (
    `service_id` INT PRIMARY KEY AUTO_INCREMENT,
    `service_name` VARCHAR(100) NOT NULL,
    `description` TEXT NULL, 
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.6 جدول الموردين (Suppliers)
CREATE TABLE IF NOT EXISTS `Suppliers` (
    `supplier_id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT UNIQUE NOT NULL,
    `name` VARCHAR(100) NOT NULL,
    `phone` VARCHAR(20) NOT NULL,
    `address` VARCHAR(255) NULL,
    `notes` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.6.1 جدول خدمات الموردين (Supplier_Services) - العلاقة المتعددة المتعدد
CREATE TABLE IF NOT EXISTS `Supplier_Services` (
    `supplier_id` INT NOT NULL,
    `service_id` INT NOT NULL,
    PRIMARY KEY (`supplier_id`, `service_id`),
    FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers`(`supplier_id`) ON DELETE CASCADE,
    FOREIGN KEY (`service_id`) REFERENCES `Services`(`service_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.7 جدول المنسقين (Coordinators)
CREATE TABLE IF NOT EXISTS `Coordinators` (
    `coordinator_id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT UNIQUE NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `phone_number` VARCHAR(20) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.8 جدول العملاء (Clients)
CREATE TABLE IF NOT EXISTS `Clients` (
    `client_id` INT PRIMARY KEY AUTO_INCREMENT,
    `full_name` VARCHAR(100) NOT NULL,
    `phone_number` VARCHAR(20) NOT NULL,
    `email` VARCHAR(100) NULL,
    `address` VARCHAR(255) NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.9 جدول المناسبات (Events)
CREATE TABLE IF NOT EXISTS `Events` (
    `event_id` INT PRIMARY KEY AUTO_INCREMENT,
    `client_id` INT NOT NULL,
    `coordinator_id` INT NOT NULL,
    `name_event` VARCHAR(100) NOT NULL,
    `description` TEXT NULL,
    `event_date` DATE NOT NULL,
    `location` VARCHAR(255) NULL,
    `budget` DECIMAL(10,2) DEFAULT 0.00,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    `status` ENUM('not_started', 'in_progress', 'completed', 'cancelled') DEFAULT 'not_started',
    FOREIGN KEY (`client_id`) REFERENCES `Clients`(`client_id`) ON DELETE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Coordinators`(`coordinator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.10 جدول المهام (Tasks)
CREATE TABLE IF NOT EXISTS `Tasks` (
    `task_id` INT PRIMARY KEY AUTO_INCREMENT,
    `event_id` INT NOT NULL,
    `assignment_type` ENUM('SUPPLIER', 'USER') NOT NULL,
    `assigned_user_id` INT NULL, -- يشير إلى coordinator_id
    `assigned_supplier_id` INT NULL, -- يشير إلى supplier_id
    `type_task` VARCHAR(100) NOT NULL,
    `description` TEXT NULL,
    `cost` DECIMAL(10,2) DEFAULT 0.00,
    `status` ENUM('PENDING','IN_PROGRESS','UNDER_REVIEW','COMPLETED','CANCELLED') DEFAULT 'PENDING',
    `notes` TEXT NULL,
    `url_image` VARCHAR(255) NULL,
    `date_start` DATE NULL,
    `date_due` DATE NULL,
    `date_completion` TIMESTAMP NULL,
    `reminder_type` ENUM('INTERVAL','BEFORE_DUE') NULL,
    `reminder_value` INT NULL,
    `reminder_unit` ENUM('MINUTE','HOUR','DAY') NULL,
    `completion_at` TIMESTAMP NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE,
    FOREIGN KEY (`assigned_user_id`) REFERENCES `Coordinators`(`coordinator_id`) ON DELETE SET NULL,
    FOREIGN KEY (`assigned_supplier_id`) REFERENCES `Suppliers`(`supplier_id`) ON DELETE SET NULL, 
    
    CONSTRAINT chk_only_one_assign CHECK ((
        `assignment_type` = 'USER' AND 
        `assigned_user_id` IS NOT NULL AND 
        `assigned_supplier_id` IS NULL
    ) OR (
        `assignment_type` = 'SUPPLIER' AND 
        `assigned_user_id` IS NULL AND 
        `assigned_supplier_id` IS NOT NULL
    ))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.11 جدول تقييم المهام (Ratings_Task)
CREATE TABLE IF NOT EXISTS `Ratings_Task` (
    `rating_id` INT PRIMARY KEY AUTO_INCREMENT,
    `task_id` INT NOT NULL UNIQUE,
    `coordinator_id` INT NOT NULL,
    `value_rating` INT NOT NULL CHECK (value_rating BETWEEN 1 AND 5),
    `comment` TEXT NULL,
    `rated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`task_id`) REFERENCES `Tasks`(`task_id`) ON DELETE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Coordinators`(`coordinator_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.12 جدول الإشعارات (Notifications)
CREATE TABLE IF NOT EXISTS `Notifications` (
    `notification_id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT NULL, -- للمنسقين
    `supplier_id` INT NULL, -- للموردين
    `task_id` INT NOT NULL,
    `type` VARCHAR(255) NOT NULL,
    `title` VARCHAR(255) NOT NULL,
    `message` TEXT NOT NULL,
    `is_read` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`task_id`) REFERENCES `Tasks`(`task_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.13 جدول الدخل (Income)
CREATE TABLE IF NOT EXISTS `Income` (
    `income_id` INT PRIMARY KEY AUTO_INCREMENT,
    `event_id` INT NOT NULL,
    `amount` DECIMAL(10,2) NOT NULL,
    `payment_method` VARCHAR(50) NULL,
    `payment_date` DATE NOT NULL,
    `url_image` VARCHAR(255) NULL,
    `description` TEXT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 1.14 جدول سجل التدقيق (Audit_Log) – لإضفاء الاحترافية وتتبع التغييرات
CREATE TABLE IF NOT EXISTS `Audit_Log` (
    `log_id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `table_name` VARCHAR(50) NOT NULL,
    `action` ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    `record_id` INT NOT NULL,
    `old_data` JSON NULL,
    `new_data` JSON NULL,
    `changed_by` INT NULL, -- user_id (يمكن ربطه إذا كان متاحًا)
    `changed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_record (`table_name`, `record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;



-- 2. إنشاء VIEWS (المشاهدات) – تقارير شاملة 


CREATE OR REPLACE VIEW `v_events_detailed` AS
SELECT 
    e.`event_id`,
    e.`name_event` AS `event_name`,
    e.`description`,
    e.`event_date`,
    e.`location`,
    e.`budget` AS `planned_budget`,
    e.`status` AS `event_status`,
    c.`full_name` AS `client_name`,
    c.`phone_number` AS `client_phone`,
    coord.`full_name` AS `coordinator_name`,
    coord.`phone_number` AS `coordinator_phone`,
    COALESCE(SUM(DISTINCT inc.`amount`), 0) AS `total_income`,
    COALESCE(SUM(DISTINCT t.`cost`), 0) AS `total_expenses`,
    COALESCE(SUM(DISTINCT inc.`amount`), 0) - COALESCE(SUM(DISTINCT t.`cost`), 0) AS `net_profit`,
    COUNT(DISTINCT t.`task_id`) AS `total_tasks`,
    SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) AS `completed_tasks`,
    CONCAT(ROUND(100 * SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) / NULLIF(COUNT(t.`task_id`), 0), 2), '%') AS `completion_percentage`
FROM `Events` e
LEFT JOIN `Clients` c ON e.`client_id` = c.`client_id`
LEFT JOIN `Coordinators` coord ON e.`coordinator_id` = coord.`coordinator_id`
LEFT JOIN `Income` inc ON e.`event_id` = inc.`event_id`
LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id`
GROUP BY e.`event_id`;


-- 2.2 عرض المهام مع معلومات الجهة المنفذة وتقييمها
CREATE OR REPLACE VIEW `v_tasks_full` AS
SELECT 
    t.`task_id`,
    t.`event_id`,
    e.`name_event` AS `event_name`,
    t.`assignment_type`,
    CASE 
        WHEN t.`assignment_type` = 'USER' THEN coord.`full_name`
        WHEN t.`assignment_type` = 'SUPPLIER' THEN s.`name`
    END AS `assignee_name`,
    t.`type_task`,
    t.`description`,
    t.`cost`,
    t.`status`,
    t.`date_start`,
    t.`date_due`,
    t.`date_completion`,
    t.`notes`,
    t.`url_image`,
    r.`value_rating` AS `rating_value`,
    r.`comment` AS `rating_comment`
FROM `Tasks` t
LEFT JOIN `Events` e ON t.`event_id` = e.`event_id`
LEFT JOIN `Coordinators` coord ON t.`assigned_user_id` = coord.`coordinator_id`
LEFT JOIN `Suppliers` s ON t.`assigned_supplier_id` = s.`supplier_id`
LEFT JOIN `Ratings_Task` r ON t.`task_id` = r.`task_id`;


-- 2.3 عرض تقييمات الموردين (متوسط التقييم، عدد المهام المنفذة)
CREATE OR REPLACE VIEW `v_supplier_performance` AS
SELECT 
    s.`supplier_id`,
    s.`name` AS `supplier_name`,
    (SELECT GROUP_CONCAT(sv.`service_name` SEPARATOR ', ') FROM `Supplier_Services` ss JOIN `Services` sv ON ss.`service_id` = sv.`service_id` WHERE ss.`supplier_id` = s.`supplier_id`) AS `services_provided`,
    COUNT(DISTINCT t.`task_id`) AS `tasks_completed`,
    ROUND(AVG(r.`value_rating`), 2) AS `avg_rating`,
    COUNT(r.`rating_id`) AS `total_ratings`
FROM `Suppliers` s
LEFT JOIN `Tasks` t ON s.`supplier_id` = t.`assigned_supplier_id` AND t.`status` = 'COMPLETED'
LEFT JOIN `Ratings_Task` r ON t.`task_id` = r.`task_id`
GROUP BY s.`supplier_id`;


-- 2.4 عرض أداء المنسقين (عدد الأحداث التي يديرونها، المهام المنجزة)
CREATE OR REPLACE VIEW `v_coordinator_performance` AS
SELECT 
    coord.`coordinator_id`,
    coord.`full_name` AS `coordinator_name`,
    COUNT(DISTINCT e.`event_id`) AS `events_managed`,
    COUNT(DISTINCT t.`task_id`) AS `total_tasks_assigned`,
    SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) AS `tasks_completed`,
    ROUND(AVG(r.`value_rating`), 2) AS `avg_rating_given`
FROM `Coordinators` coord
LEFT JOIN `Events` e ON coord.`coordinator_id` = e.`coordinator_id`
LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id`
LEFT JOIN `Ratings_Task` r ON coord.`coordinator_id` = r.`coordinator_id`
GROUP BY coord.`coordinator_id`;


-- 2.5 عرض الإشعارات مع تفاصيل المستلم
CREATE OR REPLACE VIEW `v_notifications` AS
SELECT 
    n.`notification_id`,
    n.`task_id`,
    t.`type_task` AS `task_type`,
    n.`type` AS `notification_type`,
    n.`title`,
    n.`message`,
    n.`is_read`,
    n.`created_at`,
    CASE 
        WHEN n.`user_id` IS NOT NULL THEN 'Coordinator'
        WHEN n.`supplier_id` IS NOT NULL THEN 'Supplier'
    END AS `recipient_type`,
    COALESCE(coord.`full_name`, s.`name`) AS `recipient_name`
FROM `Notifications` n
LEFT JOIN `Tasks` t ON n.`task_id` = t.`task_id`
LEFT JOIN `Coordinators` coord ON n.`user_id` = coord.`user_id`
LEFT JOIN `Suppliers` s ON n.`supplier_id` = s.`supplier_id`;



-- 3. إنشاء FUNCTIONS (الدوال) – عمليات حسابية ومنطقية متقدمة 


DELIMITER $$


CREATE FUNCTION `fn_role_get_name_by_id`(
    `p_role_id` INT
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret VARCHAR(50) CHARSET utf8mb4;
    SELECT `role_name` INTO ret FROM `Roles` WHERE `role_id` = p_role_id;
    RETURN ret;
END$$



CREATE FUNCTION `fn_role_get_id_by_name`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret INT;
    SELECT `role_id` INTO ret FROM `Roles` WHERE `role_name` = p_role_name;
    RETURN ret;
END$$




CREATE FUNCTION `fn_role_has_permission`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4, 
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;

    SELECT COUNT(*) INTO v_count
    FROM `Role_Permissions` rp
    JOIN `Roles` r ON rp.`role_id` = r.`role_id`
    JOIN `Permissions` p ON rp.`permission_id` = p.`permission_id`
    WHERE r.`role_name` = p_role_name AND p.`permission_name` = p_permission_name;
    RETURN v_count > 0;
END$$



CREATE FUNCTION `fn_permission_get_id_by_name`(
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret INT;
    SELECT `permission_id` INTO ret FROM `Permissions` WHERE `permission_name` = p_permission_name;
    RETURN ret;
END$$



CREATE FUNCTION `fn_permission_get_name_by_id`(
    `p_permission_id` INT
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret VARCHAR(50) CHARSET utf8mb4;
    SELECT `permission_name` INTO ret FROM `Permissions` WHERE `permission_id` = p_permission_id;
    RETURN ret;
END$$



CREATE FUNCTION `fn_table_exists`(
    `p_table_name` VARCHAR(255) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC
BEGIN
    DECLARE table_count INT;
    
    SELECT COUNT(*) INTO table_count
        FROM information_schema.tables 
        WHERE `table_schema` = DATABASE() -- يبحث في قاعدة البيانات الحالية
        AND `table_name` = p_table_name;
    
    RETURN table_count > 0;
END$$



CREATE FUNCTION `uc_first`(
    `str` VARCHAR(255) CHARSET utf8mb4) RETURNS VARCHAR(255) CHARSET utf8mb4 DETERMINISTIC
BEGIN
    RETURN CONCAT(UPPER(LEFT(str, 1)), LOWER(SUBSTRING(str, 2)));
END$$



-- 3.1 دالة لحساب إجمالي الدخل لحدث
CREATE FUNCTION `fn_event_total_income`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(10,2);
    SELECT IFNULL(SUM(`amount`), 0) INTO v_total
    FROM `Income` WHERE `event_id` = p_event_id;
    RETURN v_total;
END$$



-- 3.2 دالة لحساب إجمالي مصروفات حدث
CREATE FUNCTION `fn_event_total_expenses`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(10,2);
    SELECT IFNULL(SUM(`cost`), 0) INTO v_total
    FROM `Tasks` WHERE `event_id` = p_event_id;
    RETURN v_total;
END$$



-- 3.3 دالة لحساب صافي الربح لحدث
CREATE FUNCTION `fn_event_net_profit`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
BEGIN
    RETURN fn_event_total_income(p_event_id) - fn_event_total_expenses(p_event_id);
END$$



-- 3.4 دالة للتحقق من وجود صلاحية لمستخدم (بناءً على role_id)
CREATE FUNCTION `fn_user_has_permission`(
    `p_user_id` INT, 
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM `Users` u
    JOIN `Role_Permissions` rp ON u.`role_id` = rp.`role_id`
    JOIN `Permissions` p ON rp.`permission_id` = p.`permission_id`
    WHERE u.`user_id` = p_user_id AND p.`permission_name` = p_permission_name;
    RETURN v_count > 0;
END$$



-- 3.5 دالة لحساب متوسط التقييم لمورد معين
CREATE FUNCTION `fn_supplier_avg_rating`(
    `p_supplier_id` INT
    ) RETURNS DECIMAL(3,2) DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_avg DECIMAL(3,2);
    SELECT ROUND(AVG(r.`value_rating`), 2) INTO v_avg
    FROM `Ratings_Task` r
    JOIN `Tasks` t ON r.`task_id` = t.`task_id`
    WHERE t.`assigned_supplier_id` = p_supplier_id;
    RETURN IFNULL(v_avg, 0);
END$$



-- 3.6 دالة لحساب عدد المهام المتأخرة لحدث
CREATE FUNCTION `fn_event_overdue_tasks`(
    `p_event_id` INT
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM `Tasks`
    WHERE `event_id` = p_event_id 
      AND `status` NOT IN ('COMPLETED', 'CANCELLED')
      AND `date_due` < CURDATE();
    RETURN v_count;
END$$



-- 4. إنشاء STORED PROCEDURES (الإجراءات المخزنة) – العمليات الرئيسية 


-- 4.1 إجراء تسجيل الدخول والتحقق من المستخدم
CREATE PROCEDURE `sp_user_login`(
    IN `p_email` VARCHAR(100) CHARSET utf8mb4, 
    IN `p_password` VARCHAR(255) CHARSET utf8mb4
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_password_hash VARCHAR(255);
    
    -- البحث عن المستخدم
    SELECT `user_id`, `password` INTO v_user_id, v_password_hash
        FROM `Users` WHERE `email` = p_email AND `is_active` = TRUE;
    
    -- التحقق من كلمة المرور (يفترض استخدام hashing)
    IF v_user_id IS NOT NULL AND v_password_hash = p_password THEN
        -- إرجاع بيانات المستخدم
        SELECT u.`user_id`, u.`email`, u.`role_id`, r.`role_name`,
               COALESCE(coord.`coordinator_id`, supp.`supplier_id`) AS `profile_id`,
               CASE WHEN coord.`coordinator_id` IS NOT NULL THEN 'coordinator'
                    WHEN supp.`supplier_id` IS NOT NULL THEN 'supplier'
                    ELSE 'admin' END AS `user_type`
            FROM `Users` u
            JOIN `Roles` r ON u.`role_id` = r.`role_id`
            LEFT JOIN `Coordinators` coord ON u.`user_id` = coord.`user_id`
            LEFT JOIN `Suppliers` supp ON u.`user_id` = supp.`user_id`
            WHERE u.`user_id` = v_user_id;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    END IF;
END$$


-- 4.2 إجراء إنشاء حدث جديد مع مهامه (باستخدام JSON)
CREATE PROCEDURE `sp_create_event_full`(
    IN `p_client_id` INT,
    IN `p_coordinator_id` INT,
    IN `p_name_event` VARCHAR(100) CHARSET utf8mb4,
    IN `p_description` TEXT,
    IN `p_event_date` DATE,
    IN `p_location` VARCHAR(255) CHARSET utf8mb4,
    IN `p_budget` DECIMAL(10,2),
    IN `p_status` ENUM('not_started','in_progress','completed','cancelled') CHARSET utf8mb4,
    IN `p_tasks_json` JSON  -- مصفوفة من المهام: [{"type_task":"...","assignment_type":"...", ...}]
)
BEGIN
    DECLARE v_event_id INT;
    DECLARE v_counter INT DEFAULT 0;
    DECLARE v_total INT;
    DECLARE v_task JSON;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- إدراج الحدث
    INSERT INTO `Events` (`client_id`, `coordinator_id`, `name_event`, `description`, 
                          `event_date`, `location`, `budget`, `status`)
        VALUES (p_client_id, p_coordinator_id, p_name_event, p_description,
            p_event_date, p_location, p_budget, p_status);
    SET v_event_id = LAST_INSERT_ID();
    
    -- إدراج المهام إذا وجدت
    IF p_tasks_json IS NOT NULL THEN
        SET v_total = JSON_LENGTH(p_tasks_json);
        WHILE v_counter < v_total DO
            SET v_task = JSON_EXTRACT(p_tasks_json, CONCAT('$[', v_counter, ']'));
            
            INSERT INTO `Tasks` (
                `event_id`, `assignment_type`, `assigned_user_id`, `assigned_supplier_id`,
                `type_task`, `description`, `cost`, `status`, `notes`, `url_image`,
                `date_start`, `date_due`, `reminder_type`, `reminder_value`, `reminder_unit`
            ) VALUES (
                v_event_id,
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.assignment_type')),
                JSON_EXTRACT(v_task, '$.assigned_user_id'),
                JSON_EXTRACT(v_task, '$.assigned_supplier_id'),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.type_task')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.description')),
                IFNULL(JSON_EXTRACT(v_task, '$.cost'), 0),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.status')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.notes')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.url_image')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.date_start')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.date_due')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.reminder_type')),
                JSON_EXTRACT(v_task, '$.reminder_value'),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.reminder_unit'))
            );
            
            SET v_counter = v_counter + 1;
        END WHILE;
    END IF;
    
    COMMIT;
    
    -- إرجاع معرف الحدث
    SELECT v_event_id AS `event_id`;
END$$



-- 4.3 إجراء تحديث حالة مهمة مع إنشاء إشعار تلقائي
CREATE PROCEDURE `sp_update_task_status`(
    IN `p_task_id` INT,
    IN `p_new_status` ENUM(
        'PENDING',
        'IN_PROGRESS',
        'UNDER_REVIEW',
        'COMPLETED',
        'CANCELLED'
    ) CHARSET utf8mb4,
    IN `p_notes` TEXT CHARSET utf8mb4
)
BEGIN
    DECLARE v_old_status VARCHAR(20);
    DECLARE v_assigned_user INT;
    DECLARE v_assigned_supplier INT;
    DECLARE v_event_id INT;
    
    SELECT `status`, `assigned_user_id`, `assigned_supplier_id`, `event_id`
        INTO v_old_status, v_assigned_user, v_assigned_supplier, v_event_id
        FROM `Tasks` WHERE `task_id` = p_task_id;
    
    -- تحديث المهمة
    UPDATE `Tasks`
        SET `status` = p_new_status,
            `notes` = IF(p_notes IS NOT NULL, CONCAT(IFNULL(`notes`, ''), '\n', p_notes), `notes`),
            `date_completion` = IF(p_new_status = 'COMPLETED', NOW(), `date_completion`),
            `completion_at` = IF(p_new_status = 'COMPLETED', NOW(), `completion_at`)
        WHERE `task_id` = p_task_id;
    
    -- إنشاء إشعار حسب الحالة الجديدة
    IF p_new_status = 'COMPLETED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
        SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_COMPLETED', 'تم إكمال مهمة',
               CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' قد اكتملت.')
            FROM `Tasks` t
            JOIN `Events` e ON t.`event_id` = e.`event_id`
            WHERE t.`task_id` = p_task_id;
        
    ELSEIF p_new_status = 'CANCELLED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
            SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_CANCELLED', 'تم إلغاء مهمة',
                CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' تم إلغاؤها.')
                FROM `Tasks` t
                JOIN `Events` e ON t.`event_id` = e.`event_id`
                WHERE t.`task_id` = p_task_id;
    END IF;
    
END$$



-- 4.4 إجراء إضافة تقييم لمهمة مع التحقق
CREATE PROCEDURE `sp_add_task_rating`(
    IN `p_task_id` INT,
    IN `p_coordinator_id` INT,
    IN `p_value_rating` INT,
    IN `p_comment` TEXT CHARSET utf8mb4
)
BEGIN
    -- التحقق من اكتمال المهمة
    IF NOT EXISTS(SELECT 1 FROM `Tasks` WHERE `task_id` = p_task_id AND `status` = 'COMPLETED') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تقييم مهمة غير مكتملة.';
    END IF;
    
    -- التحقق من أن المنسق هو المسؤول عن حدث المهمة
    IF NOT EXISTS(
        SELECT 1 FROM `Tasks` t
        JOIN `Events` e ON t.`event_id` = e.`event_id`
        WHERE t.`task_id` = p_task_id AND e.`coordinator_id` = p_coordinator_id
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية تقييم هذه المهمة.';
    END IF;
    
    -- إدراج التقييم
    INSERT INTO `Ratings_Task` (`task_id`, `coordinator_id`, `value_rating`, `comment`)
    VALUES (p_task_id, p_coordinator_id, p_value_rating, p_comment);
    
    -- إشعار للمورد بالتقييم الجديد
    INSERT INTO `Notifications` (`supplier_id`, `task_id`, `type`, `title`, `message`)
    SELECT t.`assigned_supplier_id`, p_task_id, 'NEW_RATING', 'تقييم جديد',
           CONCAT('تم تقييم مهمتك بـ ', p_value_rating, ' نجوم.')
    FROM `Tasks` t
    WHERE t.`task_id` = p_task_id AND t.`assigned_supplier_id` IS NOT NULL;
    
END$$



-- 4.5 إجراء إنشاء إشعارات تذكير للمهام القريبة
CREATE PROCEDURE `sp_generate_reminders`()
BEGIN
    -- إشعارات للمهام التي تاريخ استحقاقها خلال 3 أيام ولم تكتمل
    INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
    SELECT 
        CASE WHEN t.`assignment_type` = 'USER' THEN t.`assigned_user_id` ELSE NULL END,
        CASE WHEN t.`assignment_type` = 'SUPPLIER' THEN t.`assigned_supplier_id` ELSE NULL END,
        t.`task_id`,
        'TASK_REMINDER',
        'تذكير بمهمة',
        CONCAT('مهمة "', t.`type_task`, '" مستحقة في ', t.`date_due`)
    FROM `Tasks` t
    WHERE t.`status` NOT IN ('COMPLETED', 'CANCELLED')
      AND t.`date_due` BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
      AND NOT EXISTS (
          SELECT 1 FROM `Notifications` n
          WHERE n.`task_id` = t.`task_id` AND n.`type` = 'TASK_REMINDER' AND DATE(n.`created_at`) = CURDATE()
      );
END$$



-- 4.6 إجراء تقرير مالي لفترة زمنية
CREATE PROCEDURE `sp_financial_report`(
    IN `p_start_date` DATE,
    IN `p_end_date` DATE
)
BEGIN
    -- إجمالي الدخل حسب الحدث في الفترة
    SELECT 
        e.`event_id`,
        e.`name_event`,
        e.`event_date`,
        IFNULL(SUM(i.`amount`), 0) AS `total_income`,
        IFNULL(SUM(t.`cost`), 0) AS `total_expenses`,
        IFNULL(SUM(i.`amount`), 0) - IFNULL(SUM(t.`cost`), 0) AS `profit`
    FROM `Events` e
    LEFT JOIN `Income` i ON e.`event_id` = i.`event_id` AND i.`payment_date` BETWEEN p_start_date AND p_end_date
    LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id` AND t.`date_completion` BETWEEN p_start_date AND p_end_date
    WHERE e.`event_date` BETWEEN p_start_date AND p_end_date
    GROUP BY e.`event_id`;
    
    -- إجمالي عام
    SELECT 
        IFNULL(SUM(i.`amount`), 0) AS `grand_total_income`,
        IFNULL(SUM(t.`cost`), 0) AS `grand_total_expenses`,
        IFNULL(SUM(i.`amount`), 0) - IFNULL(SUM(t.`cost`), 0) AS `grand_profit`
    FROM `Events` e
    LEFT JOIN `Income` i ON e.`event_id` = i.`event_id` AND i.`payment_date` BETWEEN p_start_date AND p_end_date
    LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id` AND t.`date_completion` BETWEEN p_start_date AND p_end_date
    WHERE e.`event_date` BETWEEN p_start_date AND p_end_date;
END$$



-- 4.7 إجراء إعادة تعيين كلمة المرور (تحديث)
CREATE PROCEDURE `sp_change_password`(
    IN `p_user_id` INT,
    IN `p_old_password` VARCHAR(255) CHARSET utf8mb4,
    IN `p_new_password` VARCHAR(255) CHARSET utf8mb4
)
BEGIN
    DECLARE v_current_password VARCHAR(255);
    
    SELECT `password` INTO v_current_password
    FROM `Users` WHERE `user_id` = p_user_id;
    
    IF v_current_password = p_old_password THEN
        UPDATE `Users` SET `password` = p_new_password, `updated_at` = NOW()
        WHERE `user_id` = p_user_id;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'كلمة المرور القديمة غير صحيحة.';
    END IF;
END$$



-- 4.8 إجراء إلغاء حدث (مع تحديث حالة المهام المرتبطة)
CREATE PROCEDURE `sp_cancel_event`(
    IN `p_event_id` INT,
    IN `p_reason` TEXT CHARSET utf8mb4
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- تحديث حالة الحدث
    UPDATE `Events` SET `status` = 'cancelled', `description` = CONCAT(`description`, '\nالإلغاء: ', p_reason)
    WHERE `event_id` = p_event_id;
    
    -- إلغاء جميع المهام غير المنجزة
    UPDATE `Tasks` SET `status` = 'CANCELLED', `notes` = CONCAT(IFNULL(`notes`, ''), '\nألغيت بسبب إلغاء الحدث: ', p_reason)
    WHERE `event_id` = p_event_id AND `status` NOT IN ('COMPLETED', 'CANCELLED');
    
    -- إشعار للمنسق
    INSERT INTO `Notifications` (`user_id`, `task_id`, `type`, `title`, `message`)
    SELECT e.`coordinator_id`, NULL, 'EVENT_CANCELLED', 'تم إلغاء حدث',
           CONCAT('الحدث ', e.`name_event`, ' تم إلغاؤه. السبب: ', p_reason)
    FROM `Events` e
    WHERE e.`event_id` = p_event_id;
    
    COMMIT;
END$$



-- 5.1 Trigger لتحديث حقل updated_at تلقائياً في جدول Events
CREATE TRIGGER `trg_events_before_update`
    BEFORE UPDATE ON `Events`
    FOR EACH ROW
BEGIN
    SET NEW.`updated_at` = CURRENT_TIMESTAMP;
END$$


-- 5.2 Trigger للتحقق من صحة البيانات قبل إدراج مهمة
CREATE TRIGGER `trg_tasks_before_insert`
    BEFORE INSERT ON `Tasks`
    FOR EACH ROW
BEGIN
    -- التحقق من نوع الإسناد
    IF NEW.`assignment_type` = 'USER' AND NEW.`assigned_user_id` IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تحديد منسق للمهمة عندما يكون النوع USER.';
    END IF;
    IF NEW.`assignment_type` = 'SUPPLIER' AND NEW.`assigned_supplier_id` IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تحديد مورد للمهمة عندما يكون النوع SUPPLIER.';
    END IF;
    IF NEW.`assignment_type` NOT IN ('USER', 'SUPPLIER') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'نوع الإسناد غير صحيح.';
    END IF;
    
    -- التحقق من وجود المنسق أو المورد
    IF NEW.`assigned_user_id` IS NOT NULL AND NOT EXISTS(SELECT 1 FROM `Coordinators` WHERE `coordinator_id` = NEW.`assigned_user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المنسق المحدد غير موجود.';
    END IF;
    IF NEW.`assigned_supplier_id` IS NOT NULL AND NOT EXISTS(SELECT 1 FROM `Suppliers` WHERE `supplier_id` = NEW.`assigned_supplier_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المورد المحدد غير موجود.';
    END IF;
    
    -- التحقق من تاريخ البدء لا يتجاوز تاريخ الاستحقاق
    IF NEW.`date_start` IS NOT NULL AND NEW.`date_due` IS NOT NULL AND NEW.`date_start` > NEW.`date_due` THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'تاريخ البدء لا يمكن أن يكون بعد تاريخ الاستحقاق.';
    END IF;
END$$
    

-- 5.3 Trigger لتسجيل التغييرات في جدول Audit_Log (لجدول Events)
CREATE TRIGGER `trg_events_after_insert`
    AFTER INSERT ON `Events`
    FOR EACH ROW
BEGIN
    INSERT INTO `Audit_Log` (`table_name`, `action`, `record_id`, `new_data`, `changed_at`)
    VALUES ('Events', 'INSERT', NEW.`event_id`, JSON_OBJECT(
        'client_id', NEW.`client_id`,
        'coordinator_id', NEW.`coordinator_id`,
        'name_event', NEW.`name_event`,
        'event_date', NEW.`event_date`,
        'budget', NEW.`budget`,
        'status', NEW.`status`
    ), NOW());
END$$
    


CREATE TRIGGER `trg_events_after_update`
    AFTER UPDATE ON `Events`
    FOR EACH ROW
BEGIN
    INSERT INTO `Audit_Log` (`table_name`, `action`, `record_id`, `old_data`, `new_data`, `changed_at`)
    VALUES ('Events', 'UPDATE', NEW.`event_id`,
        JSON_OBJECT(
            'client_id', OLD.`client_id`,
            'coordinator_id', OLD.`coordinator_id`,
            'name_event', OLD.`name_event`,
            'event_date', OLD.`event_date`,
            'budget', OLD.`budget`,
            'status', OLD.`status`
        ),
        JSON_OBJECT(
            'client_id', NEW.`client_id`,
            'coordinator_id', NEW.`coordinator_id`,
            'name_event', NEW.`name_event`,
            'event_date', NEW.`event_date`,
            'budget', NEW.`budget`,
            'status', NEW.`status`
        ), NOW());
END$$
    

-- 5.4 Trigger لإنشاء إشعار تلقائي عند إسناد مهمة جديدة
CREATE TRIGGER `trg_tasks_after_insert`
    AFTER INSERT ON `Tasks`
    FOR EACH ROW
BEGIN
    DECLARE v_title VARCHAR(255);
    DECLARE v_message TEXT;
    
    SET v_title = 'مهمة جديدة';
    SET v_message = CONCAT('تم إسناد مهمة جديدة إليك: ', NEW.`type_task`);
    
    IF NEW.`assignment_type` = 'USER' AND NEW.`assigned_user_id` IS NOT NULL THEN
        INSERT INTO `Notifications` (`user_id`, `task_id`, `type`, `title`, `message`)
        VALUES (NEW.`assigned_user_id`, NEW.`task_id`, 'TASK_ASSIGNED', v_title, v_message);
    ELSEIF NEW.`assignment_type` = 'SUPPLIER' AND NEW.`assigned_supplier_id` IS NOT NULL THEN
        INSERT INTO `Notifications` (`supplier_id`, `task_id`, `type`, `title`, `message`)
        VALUES (NEW.`assigned_supplier_id`, NEW.`task_id`, 'TASK_ASSIGNED', v_title, v_message);
    END IF;
END$$
    

-- 5.5 Trigger لمنع حذف مستخدم إذا كان مرتبطاً بمنسق أو مورد
CREATE TRIGGER `trg_users_before_delete`
    BEFORE DELETE ON `Users`
    FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM `Coordinators` WHERE `user_id` = OLD.`user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن حذف مستخدم مرتبط بمنسق. احذف المنسق أولاً.';
    END IF;
    IF EXISTS (SELECT 1 FROM `Suppliers` WHERE `user_id` = OLD.`user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن حذف مستخدم مرتبط بمورد. احذف المورد أولاً.';
    END IF;
END$$
    

-- 5.6 Trigger لمنع إضافة تقييم لمهمة لم تكتمل (حماية إضافية)
CREATE TRIGGER `trg_ratings_before_insert`
    BEFORE INSERT ON `Ratings_Task`
    FOR EACH ROW
BEGIN
    DECLARE v_task_status VARCHAR(20);
    SELECT `status` INTO v_task_status FROM `Tasks` WHERE `task_id` = NEW.`task_id`;
    
    IF v_task_status != 'COMPLETED' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تقييم مهمة غير مكتملة.';
    END IF;
    
    -- منع التقييم المكرر
    IF EXISTS (SELECT 1 FROM `Ratings_Task` WHERE `task_id` = NEW.`task_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إضافة أكثر من تقييم لنفس المهمة.';
    END IF;
END$$
    

-- 5.7 Trigger لمنع تعديل أو حذف الإشعارات المقروءة (اختياري)
CREATE TRIGGER `trg_notifications_before_update`
    BEFORE UPDATE ON `Notifications`
    FOR EACH ROW
BEGIN
    IF OLD.`is_read` = TRUE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تعديل إشعار مقروء.';
    END IF;
END$$
    

-- 5.8 Trigger للتحقق من صحة تاريخ الدخل (لا يمكن أن يكون في المستقبل)
CREATE TRIGGER `trg_income_before_insert`
    BEFORE INSERT ON `Income`
    FOR EACH ROW
BEGIN
    IF NEW.`payment_date` > CURDATE() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'تاريخ الدفع لا يمكن أن يكون في المستقبل.';
    END IF;
END$$


DELIMITER ;


-- 6. إنشاء EVENT (حدث مجدول) لتنفيذ التذكيرات بشكل دوري 


-- تأكد من تمكين جدولة الأحداث: SET GLOBAL event_scheduler = ON;
CREATE EVENT IF NOT EXISTS `event_generate_reminders`
        ON SCHEDULE EVERY 1 DAY
        STARTS CURRENT_DATE + INTERVAL 1 DAY
    DO CALL sp_generate_reminders();
    


-- 7. إنشاء الفهارس (Indexes) لتحسين الأداء 


CREATE INDEX idx_tasks_event_id ON `Tasks`(`event_id`);

CREATE INDEX idx_tasks_assigned_user ON `Tasks`(`assigned_user_id`);

CREATE INDEX idx_tasks_assigned_supplier ON `Tasks`(`assigned_supplier_id`);

CREATE INDEX idx_notifications_user ON `Notifications`(`user_id`, `is_read`);

CREATE INDEX idx_notifications_supplier ON `Notifications`(`supplier_id`, `is_read`);

CREATE INDEX idx_income_event_id ON `Income`(`event_id`);

CREATE INDEX idx_ratings_task_id ON `Ratings_Task`(`task_id`);


-- 8. إدراج البيانات الأساسية (الأدوار، الصلاحيات، إلخ) 


-- إدراج الأدوار الأساسية
INSERT IGNORE INTO `Roles` (`role_name`) VALUES 
    ('admin'), ('coordinator'), ('supplier');

-- إدراج الصلاحيات الأساسية
INSERT IGNORE INTO `Permissions` (`permission_name`) VALUES 
    ('create_event'), ('edit_event'), ('delete_event'), 
    ('assign_task'), ('rate_task'), ('view_reports');

-- ربط الصلاحيات بالأدوار (مثال: admin يملك كل الصلاحيات)
INSERT IGNORE INTO `Role_Permissions` (`role_id`, `permission_id`)
    SELECT r.`role_id`, p.`permission_id`
    FROM `Roles` r CROSS JOIN `Permissions` p
    WHERE r.`role_name` = 'admin';

-- إضافة مستخدم admin افتراضي (كلمة المرور: admin123، يمكن تغييرها لاحقاً)
-- ملاحظة: في الإنتاج يجب استخدام hashing آمن مثل bcrypt وليس نص عادي.
INSERT IGNORE INTO `Users` (`email`, `password`, `role_id`, `is_active`)
    SELECT 'admin@myparty.com', 'admin123', `role_id`, TRUE
    FROM `Roles` WHERE `role_name` = 'admin';

