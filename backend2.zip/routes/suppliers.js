const express = require('express');
const router = express.Router();
const suppliersController = require('../controllers/suppliersController');
const { authorizeRole, authenticateToken } = require('../config/constents');


router.use(authenticateToken);

router.get('/', authorizeRole.fullAdmin(), suppliersController.getAllSuppliers);
router.get('/rated-by-coordinator/:coordinatorId', authorizeRole.fullAdmin(), suppliersController.getSuppliersWithCoordinatorRating);
router.get('/:id', authorizeRole.fullAdmin(), suppliersController.getSupplierById);

router.get('/:id/services/:serviceId', authorizeRole.onlyAdminAnd('supplier'), suppliersController.getByIdAndServiceId);
router.get('/services/:serviceId', authorizeRole.onlyAdminAnd('supplier'), suppliersController.getAllByServiceId);

router.get('/:id/notifications', authorizeRole.onlyAdminAnd('supplier'), suppliersController.getNotifications);
router.get('/:id/notifications/:notificationId', authorizeRole.onlyAdminAnd('supplier'), suppliersController.getNotification);




router.post('/', authorizeRole.subAdmin(), suppliersController.createSupplier);
router.post('/assign-service', authorizeRole.fullAdmin(), suppliersController.assignServiceToSupplier);
router.post('/remove-service', authorizeRole.fullAdmin(), suppliersController.removeServiceFromSupplier);




router.put('/:id', authorizeRole.subAdmin(), suppliersController.updateSupplier);




router.delete('/:id', authorizeRole.subAdmin(), suppliersController.deleteSupplier);
// router.delete('/:id/services/:serviceId', authorizeRole.onlyAdminAnd('supplier'), suppliersController.deleteService);
router.delete('/:id/services', authorizeRole.onlyAdminAnd('supplier'), suppliersController.clearAllServices);
router.delete('/:id/notifications/:notificationId', authorizeRole.onlyAdminAnd('supplier'), suppliersController.deleteNotification);
router.delete('/:id/notifications', authorizeRole.onlyAdminAnd('supplier'), suppliersController.clearAllNotifications);


module.exports = router;
