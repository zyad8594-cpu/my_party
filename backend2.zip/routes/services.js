const express = require('express');
const router = express.Router();
const servicesController = require('../controllers/servicesController');
const { authorizeRole, authenticateToken } = require('../config/constents');


router.use(authenticateToken);

router.get('/', authorizeRole.fullAdmin(), servicesController.getAllServices);
router.get('/:id', authorizeRole.fullAdmin(), servicesController.getServiceById);
router.post('/', authorizeRole.onlyAdmin(), servicesController.createService);
router.put('/:id', authorizeRole.onlyAdmin(), servicesController.updateService);
router.delete('/:id', authorizeRole.onlyAdmin(), servicesController.deleteService);

module.exports = router;
