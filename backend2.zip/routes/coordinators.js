const express = require('express');
const router = express.Router();
const coordinatorsController = require('../controllers/coordinatorsController');
const { authorizeRole, authenticateToken } = require('../config/constents');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken);


router.get('/', authorizeRole.fullAdmin(), coordinatorsController.getAllCoordinators);
router.get('/:id', authorizeRole.fullAdmin(), coordinatorsController.getCoordinatorById);
router.post('/', authorizeRole.onlyAdmin(), upload.single('img_url'), coordinatorsController.createCoordinator);
router.put('/:id', authorizeRole.subAdmin(), coordinatorsController.updateCoordinator);
router.delete('/:id', authorizeRole.onlyAdmin(), coordinatorsController.deleteCoordinator);


module.exports = router;