const express = require('express');
const router = express.Router();
const incomeController = require('../controllers/incomeController');
const { authorizeRole, authenticateToken } = require('../config/constents');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken);

router.get('/', authorizeRole.subAdmin(), incomeController.getAllIncomes);
router.get('/:id',authorizeRole.subAdmin(), incomeController.getIncomeById);
router.post('/', authorizeRole.subAdmin(), upload.single('img_url'), incomeController.createIncome);
router.put('/:id', authorizeRole.subAdmin(), upload.single('img_url'), incomeController.updateIncome);
router.delete('/:id', authorizeRole.subAdmin(), incomeController.deleteIncome);

module.exports = router;