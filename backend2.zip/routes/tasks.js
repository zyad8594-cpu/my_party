const express = require('express');
const router = express.Router();
const tasksController = require('../controllers/tasksController');
const { authorizeRole, authenticateToken } = require('../config/constents');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken);

router.get('/', authorizeRole.fullAdmin(), tasksController.getAllTasks);
router.get('/:id', authorizeRole.fullAdmin(), tasksController.getTaskById);
router.get('/event/:eventId',authorizeRole.subAdmin(), tasksController.getTasksByEventId);

router.post('/', authorizeRole.subAdmin(), tasksController.createTask);
router.post('/:id/rating', authorizeRole.subAdmin(), tasksController.addTaskRating);

router.put('/:id', authorizeRole.fullAdmin(), tasksController.updateTask);
router.put('/:id/status', authorizeRole.fullAdmin(), upload.single('url_image'), tasksController.updateTaskStatus);

router.delete('/:id', authorizeRole.fullAdmin(), tasksController.deleteTask);


module.exports = router;
