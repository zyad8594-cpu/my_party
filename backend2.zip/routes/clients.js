const express = require('express');
const router = express.Router();
const clientController = require('../controllers/clientController');
const { authorizeRole, authenticateToken } = require('../config/constents');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken);

router.get('/', authorizeRole.fullAdmin(),  clientController.getAllClients);
router.get('/:id', authorizeRole.fullAdmin(), clientController.getClientById);
router.post('/', authorizeRole.subAdmin(), upload.single('img_url'), clientController.createClient);
router.put('/:id',  authorizeRole.subAdmin(), upload.single('img_url'), clientController.updateClient);
router.delete('/:id',  authorizeRole.subAdmin(), clientController.deleteClient);
router.put('/:id/restore',  authorizeRole.subAdmin(), clientController.restoreClient);

module.exports = router;