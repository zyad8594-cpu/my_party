const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + req.body.email + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});
router.post('/login', authController.login);
router.post('/register', upload.single('img_url'), authController.register);

module.exports = router;
