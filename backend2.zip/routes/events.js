const express = require('express');
const router = express.Router();
const eventsController = require('../controllers/eventsController');
const { authorizeRole, authenticateToken } = require('../config/constents');

const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + 
        (req.body.event_name || '') + '-' + 
        (req.body.client_id || '') + '-' + 
        Math.round(Math.random() * 1E9) + '-' +
         path.extname(file.originalname) 
    );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken); // Protect all event routes

router.get('/', authorizeRole.fullAdmin(), eventsController.getAllEvents);
router.get('/:id',authorizeRole.fullAdmin(), eventsController.getEventById);

router.post('/', authorizeRole.subAdmin(), upload.single('img_url'), eventsController.createEvent);
router.post('/:id/cancel', authorizeRole.subAdmin(), eventsController.cancelEvent);

router.put('/:id', authorizeRole.subAdmin(), upload.single('img_url'), eventsController.updateEvent);
router.put('/:id/status', authorizeRole.subAdmin(), eventsController.updateEventStatus);

router.delete('/:id', authorizeRole.subAdmin(), eventsController.deleteEvent);


module.exports = router;
