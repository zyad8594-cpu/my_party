const express = require('express');
const router = express.Router();
const clientController = require('../controllers/userController');
const { authorizeRole, authenticateToken } = require('../config/constents');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: function(req, file, cb){
        cb(null, 'uploads/');
    },
    filename: function(req, file, cb){
        cb(null, Date.now()  + '-' + Math.round(Math.random() * 1E9) + '-' + path.extname(file.originalname) );
    }
});

const upload = multer({storage: storage});

router.use(authenticateToken);

router.get('/', authorizeRole.fullAdmin(), clientController.getAllUsers);
router.get('/:id', authorizeRole.fullAdmin(), clientController.getUserById);

router.post('/', authorizeRole.onlyAdmin(), upload.single('img_url'), clientController.create);

router.put('/:id', authorizeRole.full(), upload.single('img_url'), clientController.update);
router.put('/:id/set_active', authorizeRole.onlyAdmin(), clientController.set_active);
router.put('/change-password/:userId', authorizeRole.full(), clientController.changePassword);

router.delete('/:id', authorizeRole.onlyAdmin(), clientController.delete);


module.exports = router;