const express = require('express');
const router = express.Router();
const ServiceRequestsController = require('../controllers/ServiceRequestsController');
const { authorizeRole, authenticateToken } = require('../config/constents');


router.use(authenticateToken);

router.post('/', authorizeRole.select(['supplier']), ServiceRequestsController.createRequest);
router.get('/mine', authorizeRole.select(['supplier']), ServiceRequestsController.getMyRequests);
router.delete('/:id', authorizeRole.select(['supplier']), ServiceRequestsController.withdrawRequest);

router.get('/', authorizeRole.onlyAdmin(),  ServiceRequestsController.getAllRequests);
router.put('/:id',  authorizeRole.onlyAdmin(), ServiceRequestsController.updateStatus);

module.exports = router;