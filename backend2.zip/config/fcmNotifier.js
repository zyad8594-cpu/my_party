// fcmNotifier.js
var admin = require('firebase-admin');

var serviceAccount = require('./path/to/your/firebase-adminsdk.json');

admin.initializeApp({
  credential: admin.credential.cert(serviceAccount)
});

async function sendPushNotification(deviceToken, notificationData) {
    const message = {
        notification: {
            title: 'إشعار جديد',
            body: notificationData.content // محتوى الإشعار من قاعدة البيانات
        },
        data: {
            id: notificationData.id.toString(),
            type: notificationData.type
        },
        token: deviceToken, // رمز جهاز المستخدم المستهدف
    };

    try {
        const response = await admin.messaging().send(message);
        console.log('✅ تم إرسال الإشعار بنجاح:', response);
    } catch (error) {
        console.error('❌ فشل إرسال الإشعار:', error);
    }
}

// قم باستدعاء هذه الدالة من مراقب قاعدة البيانات
// ستحتاج إلى الحصول على deviceToken لكل مستخدم وتخزينه في قاعدة البيانات.