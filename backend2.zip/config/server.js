// server.js
const http = require('http');
const { Server } = require('socket.io');

const server = http.createServer(app); // إذا كنت تستخدم express
const io = new Server(server, {
  cors: { origin: "*" } // اضبط هذا لاحقًا ليناسب نطاق تطبيقك فقط
});

io.on('connection', (socket) => {
    console.log('📱 جهاز جديد متصل:', socket.id);

    socket.on('disconnect', () => {
        console.log('📱 جهاز غير متصل:', socket.id);
    });
});

// هذه الدالة سيتم استدعاؤها من مراقب قاعدة البيانات
function sendNotificationToClients(notificationData) {
    console.log('📤 جاري إرسال الإشعار عبر WebSocket:', notificationData);
    // إرسال الإشعار إلى جميع الأجهزة المتصلة
    io.emit('new-notification', notificationData);
}