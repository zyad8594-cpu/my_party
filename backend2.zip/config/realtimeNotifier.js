// realtimeNotifier.js
const MySQLEvents = require('@rodrigogs/mysql-events');

const connectionConfig = {
    host: process.env.DB_HOST || 'localhost',
    user: process.env.DB_USER || 'root',
    password: process.env.DB_PASSWORD || '',
};

const instance = new MySQLEvents(connectionConfig, {
    startAtEnd: true, // البدء من آخر الأحداث وليس من البداية
    excludedSchemas: { mysql: true }, // تجاهل تغييرات النظام
});

await instance.start();

// الاستماع لأحداث INSERT على جدول notifications
const watcher = await instance.addTrigger({
    name: 'monitor-notifications',
    expression: `${process.env.DB_NAME || 'my_party_4'}.Notifications`, // استبدل باسم قاعدة البيانات والجدول
    statement: MySQLEvents.STATEMENTS.INSERT, // راقب عمليات الإدراج فقط
    onEvent: (event) => {
        const newNotification = event.affectedRows[0].after;
        console.log('✅ تم اكتشاف إشعار جديد:', newNotification);

        // هنا سترسل الإشعار عبر WebSockets و/أو FCM
        sendNotificationToClients(newNotification);
    },
});