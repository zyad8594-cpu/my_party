DELIMITER $$
CREATE TRIGGER `trg_users_before_insert` BEFORE INSERT ON `Users`
    FOR EACH ROW 
    BEGIN
        IF EXISTS (SELECT 1 FROM `Users` WHERE `email` = NEW.`email`) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Email already exists for another user';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_users_before_update` BEFORE UPDATE ON `Users`
    FOR EACH ROW
    BEGIN
        IF NEW.`email` != OLD.`email` THEN
            IF EXISTS (SELECT 1 FROM `Users` WHERE `email` = NEW.`email` AND `user_id` != NEW.`user_id`) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Email already exists for another user';
            END IF;
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_clientss_before_update` BEFORE UPDATE ON `Clients`
    FOR EACH ROW
    BEGIN
        IF NEW.`email` != OLD.`email` THEN
            IF EXISTS (SELECT 1 FROM `clients` WHERE `email` = NEW.`email` AND `client_id` != NEW.`client_id`) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Email already exists for another user';
            END IF;
        END IF;
        IF NEW.`phone_number` != OLD.`phone_number` THEN
            IF EXISTS (SELECT 1 FROM `clients` WHERE `phone_number` = NEW.`phone_number` AND `client_id` != NEW.`client_id`) THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'phone_number already exists for another client';
            END IF;
        END IF;
    END $$
DELIMITER ;


DELIMITER $$ 
CREATE TRIGGER `trg_supplier_services_before_insert` BEFORE INSERT ON `Supplier_Services`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`supplier_id`, 'supplier') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User is not a supplier';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_supplier_services_before_update` BEFORE UPDATE ON `Supplier_Services`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`supplier_id`, 'supplier') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User is not a supplier';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_task_assigns_before_insert` BEFORE INSERT ON `Task_Assigns`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`coordinator_id`, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إنشاء المهام من قبل غير المنسقين';
        END IF;
        IF NEW.`user_assign_id` IS NOT NULL AND NOT (fn_user_has_role(NEW.`user_assign_id`, 'coordinator') OR fn_user_has_role(NEW.`user_assign_id`, 'supplier')) THEN
            SET @msg_error = CONCAT('لا يمكن تعيين المهام لغير المنسقين أو الموردين رقم المستخدم هو ', IFNULL(NEW.`user_assign_id`, 'NULL'));
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = @msg_error;
        END IF;
        IF NEW.`date_start` IS NOT NULL AND NEW.`date_start` < CURDATE() THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إنشاء المهام في الماضي';
        END IF;
        IF NEW.`date_due` IS NOT NULL AND NEW.`date_start` IS NOT NULL AND NEW.`date_due` <= NEW.`date_start` THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن أن يكون تاريخ الانتهاء قبل تاريخ البدء';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_task_assigns_before_update` BEFORE UPDATE ON `Task_Assigns`
    FOR EACH ROW
    BEGIN
        IF NEW.`date_start` IS NOT NULL AND NEW.`date_start` < CURDATE() THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تحديث المهام في الماضي';
        END IF;
        IF NEW.`date_due` IS NOT NULL AND NEW.`date_start` IS NOT NULL AND NEW.`date_due` <= NEW.`date_start` THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن أن يكون تاريخ الانتهاء قبل تاريخ البدء';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_ratings_task_assign_before_insert` BEFORE INSERT ON `Ratings_Task_Assign`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`coordinator_id`, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Rater must be a coordinator';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_ratings_task_assign_before_update` BEFORE UPDATE ON `Ratings_Task_Assign`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`coordinator_id`, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Rater must be a coordinator';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$
CREATE TRIGGER `trg_events_before_insert` BEFORE INSERT ON `Events`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`coordinator_id`, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Coordinator must have coordinator role';
        END IF;
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE TRIGGER `trg_events_before_update` BEFORE UPDATE ON `Events`
    FOR EACH ROW
    BEGIN
        IF NOT fn_user_has_role(NEW.`coordinator_id`, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Coordinator must have coordinator role';
        END IF;
    END $$
DELIMITER ;


