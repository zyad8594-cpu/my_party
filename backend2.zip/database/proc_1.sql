DELIMITER $$
CREATE PROCEDURE `sp_throw_if_not_admin`(IN `p_user_id` INT)
BEGIN
    DECLARE v_role VARCHAR(50);
    SELECT `role_name` INTO v_role FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NULL;
    IF v_role IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم غير موجود';
    END IF;
    IF v_role != 'admin' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذه العملية تتطلب صلاحيات مدير';
    END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_user`(
    IN `p_executor_user_id` INT,
    IN `p_user_id` INT
)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
BEGIN
    DECLARE v_user_email VARCHAR(255);
    DECLARE v_user_name VARCHAR(255);
    DECLARE v_role_name VARCHAR(50);
    
    -- التحقق من صلاحية المدير
    CALL sp_throw_if_not_admin(p_executor_user_id);
    
    SELECT `email`, `full_name`, `role_name` INTO v_user_email, v_user_name, v_role_name
    FROM `Users` WHERE `user_id` = p_user_id;
    
    IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
    END IF;
    IF fn_user_is_deleted(p_user_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الحساب محذوف بالفعل';
    END IF;
    
    UPDATE `Users` SET `deleted_at` = NOW() WHERE `user_id` = p_user_id;
    
    -- إشعار للمدير المنفذ
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_executor_user_id,
        'delete_user',
        'حذف حساب',
        CONCAT('تم حذف حساب المستخدم: ', v_user_name, ' (', v_user_email, ') - الدور: ', v_role_name)
    );
    
    -- إشعار للمستخدم نفسه
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_user_id,
        'delete_user',
        'تم حذف حسابك',
        CONCAT('تم حذف حسابك بتاريخ ', NOW(), '. إذا كان هذا خطأ، يرجى التواصل مع المدير.')
    );
    
    SELECT p_user_id AS user_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_restore_user`(
    IN `p_executor_user_id` INT,
    IN `p_user_id` INT
)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_user_email VARCHAR(255);
    DECLARE v_user_name VARCHAR(255);
    DECLARE v_role_name VARCHAR(50);
    
    CALL sp_throw_if_not_admin(p_executor_user_id);
    
    SELECT `email`, `full_name`, `role_name` INTO v_user_email, v_user_name, v_role_name
    FROM `Users` WHERE `user_id` = p_user_id;
    
    IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
    END IF;
    IF NOT fn_user_is_deleted(p_user_id) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الحساب ليس محذوفاً';
    END IF;
    
    UPDATE `Users` SET `deleted_at` = NULL WHERE `user_id` = p_user_id;
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_executor_user_id,
        'restore_user',
        'استعادة حساب',
        CONCAT('تم استعادة حساب المستخدم: ', v_user_name, ' (', v_user_email, ') - الدور: ', v_role_name)
    );
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_user_id,
        'restore_user',
        'تم استعادة حسابك',
        CONCAT('تم استعادة حسابك بتاريخ ', NOW(), '. يمكنك الآن تسجيل الدخول.')
    );
    
    SELECT p_user_id AS user_id;
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_set_user_active`(
    IN `p_executor_user_id` INT,
    IN `p_user_id` INT, 
    IN `p_active` BOOLEAN, 
    IN `p_with_out` BOOLEAN
)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_error_msg TEXT;
    DECLARE v_user_name VARCHAR(255);
    DECLARE v_user_email VARCHAR(255);
    
    CALL sp_throw_if_not_admin(p_executor_user_id);
    
    SELECT `full_name`, `email` INTO v_user_name, v_user_email
    FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NULL;
    
    IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
    END IF;
    IF EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `is_active` = p_active) THEN
        SET v_error_msg = IF(p_active = TRUE, 'هذا الحساب مفعل بالفعل', 'هذا الحساب غير مفعل بالفعل');
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_msg;
    END IF;
    
    UPDATE `Users` SET `is_active` = p_active WHERE `user_id` = p_user_id;
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_executor_user_id,
        IF(p_active, 'activate_user', 'deactivate_user'),
        IF(p_active, 'تفعيل حساب', 'تعطيل حساب'),
        CONCAT('تم ', IF(p_active, 'تفعيل', 'تعطيل'), ' حساب المستخدم: ', v_user_name, ' (', v_user_email, ')')
    );
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_user_id,
        IF(p_active, 'activate_user', 'deactivate_user'),
        IF(p_active, 'تم تفعيل حسابك', 'تم تعطيل حسابك'),
        CONCAT('تم ', IF(p_active, 'تفعيل', 'تعطيل'), ' حسابك بتاريخ ', NOW(), '.')
    );
    
    IF p_with_out THEN SELECT p_user_id AS user_id; END IF;
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_add_permission_to_role`(
    IN `p_executor_user_id` INT,
    IN `p_role_name` VARCHAR(50), 
    IN `p_permission_name` VARCHAR(100)
)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
BEGIN
    CALL sp_throw_if_not_admin(p_executor_user_id);
    
    IF NOT EXISTS (SELECT 1 FROM `Roles` WHERE `role_name` = p_role_name AND `deleted_at` IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الدور غير موجود';
    END IF;
    IF NOT EXISTS (SELECT 1 FROM `Permissions` WHERE `permission_name` = p_permission_name AND `deleted_at` IS NULL) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الصلاحية غير موجودة';
    END IF;
    
    INSERT INTO `Role_Permissions` (`role_name`, `permission_name`, `deleted_at`)
    VALUES (p_role_name, p_permission_name, NULL)
    ON DUPLICATE KEY UPDATE `deleted_at` = NULL;
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_executor_user_id,
        'permission_added',
        'إضافة صلاحية لدور',
        CONCAT('تم إضافة الصلاحية "', p_permission_name, '" إلى دور "', p_role_name, '"')
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_remove_permission_from_role`(
    IN `p_executor_user_id` INT,
    IN `p_role_name` VARCHAR(50), 
    IN `p_permission_name` VARCHAR(100)
)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
BEGIN
    CALL sp_throw_if_not_admin(p_executor_user_id);
    
    UPDATE `Role_Permissions` 
    SET `deleted_at` = NOW()
    WHERE `role_name` = p_role_name AND `permission_name` = p_permission_name;
    
    INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
    VALUES (p_executor_user_id,
        'permission_removed',
        'إزالة صلاحية من دور',
        CONCAT('تم إزالة الصلاحية "', p_permission_name, '" من دور "', p_role_name, '"')
    );
END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_event`(
    IN `p_executor_user_id` INT,
    IN `p_event_id` INT,
    IN `p_event_name` VARCHAR(255),
    IN `p_description` TEXT,
    IN `p_event_date` DATE,
    IN `p_location` VARCHAR(255),
    IN `p_budget` DECIMAL(10,2),
    IN `p_status` ENUM('PENDING','IN_PROGRESS','COMPLETED','CANCELLED')
)
BEGIN
    DECLARE v_coordinator_id INT;
    DECLARE v_old_name VARCHAR(255);
    DECLARE v_executor_role VARCHAR(50);
    
    -- التحقق من وجود الحدث
    SELECT `coordinator_id`, `event_name` INTO v_coordinator_id, v_old_name
    FROM `Events` WHERE `event_id` = p_event_id AND `deleted_at` IS NULL;
    
    IF v_coordinator_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحدث غير موجود';
    END IF;
    
    -- التحقق من صلاحية المنفذ: إما مدير أو المنسق نفسه
    SELECT `role_name` INTO v_executor_role FROM `Users` WHERE `user_id` = p_executor_user_id AND `deleted_at` IS NULL;
    IF v_executor_role IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم المنفذ غير موجود';
    END IF;
    
    IF v_executor_role != 'admin' AND p_executor_user_id != v_coordinator_id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية تحديث هذا الحدث';
    END IF;
    
    UPDATE `Events`
        SET `event_name` = IFNULL(p_event_name, `event_name`),
            `description` = IFNULL(p_description, `description`),
            `event_date` = IFNULL(p_event_date, `event_date`),
            `location` = IFNULL(p_location, `location`),
            `budget` = IFNULL(p_budget, `budget`),
            `status` = IFNULL(p_status, `status`),
            `updated_at` = NOW()
        WHERE `event_id` = p_event_id;
    
    -- إشعار للمنسق (إذا لم يكن هو المنفذ)
    IF v_coordinator_id != p_executor_user_id THEN
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'update_event',
            'تحديث حدث',
            CONCAT('تم تحديث بيانات الحدث "', IFNULL(p_event_name, v_old_name), '" (رقم ', p_event_id, ') بواسطة المستخدم ', p_executor_user_id)
        );
    END IF;
    
    -- إشعار للمدير إذا لم يكن هو المنفذ
    IF v_executor_role != 'admin' THEN
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_event',
            'تحديث حدث',
            CONCAT('تم تحديث بيانات الحدث "', IFNULL(p_event_name, v_old_name), '" (رقم ', p_event_id, ') بواسطة المنسق رقم ', v_coordinator_id)
        );
    END IF;
    
    SELECT * FROM `Events` WHERE `event_id` = p_event_id;
END$$
DELIMITER ;

DELIMITER $$

CREATE PROCEDURE `sp_delete_event`(
    IN `p_executor_user_id` INT,
    IN `p_event_id` INT
)
BEGIN
    DECLARE v_coordinator_id INT;
    DECLARE v_event_name VARCHAR(255);
    DECLARE v_executor_role VARCHAR(50);
    
    SELECT `coordinator_id`, `event_name` INTO v_coordinator_id, v_event_name
    FROM `Events` WHERE `event_id` = p_event_id AND `deleted_at` IS NULL;
    
    IF v_coordinator_id IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحدث غير موجود';
    END IF;
    
    SELECT `role_name` INTO v_executor_role FROM `Users` WHERE `user_id` = p_executor_user_id AND `deleted_at` IS NULL;
    IF v_executor_role IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم المنفذ غير موجود';
    END IF;
    
    IF v_executor_role != 'admin' AND p_executor_user_id != v_coordinator_id THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية حذف هذا الحدث';
    END IF;
    
    UPDATE `Events` SET `deleted_at` = NOW() WHERE `event_id` = p_event_id;
    
    -- إشعار للمنسق (إذا لم يكن هو المنفذ)
    IF v_coordinator_id != p_executor_user_id THEN
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'delete_event',
            'حذف حدث',
            CONCAT('تم حذف الحدث "', v_event_name, '" (رقم ', p_event_id, ') بواسطة المستخدم ', p_executor_user_id)
        );
    END IF;
    
    -- إشعار للمدير إذا لم يكن هو المنفذ
    IF v_executor_role != 'admin' THEN
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_event',
            'حذف حدث',
            CONCAT('تم حذف الحدث "', v_event_name, '" (رقم ', p_event_id, ') بواسطة المنسق رقم ', v_coordinator_id)
        );
    END IF;
    
    SELECT p_event_id AS event_id;
END$$

DELIMITER ;