USE my_party_3;

-- ============================================================
-- تعطيل المحفزات (Triggers) مؤقتًا لتجنب أخطاء التحقق من التواريخ
-- ============================================================
SET @OLD_SQL_MODE = @@SQL_MODE;
SET SQL_MODE = '';

-- ============================================================
-- 1. إضافة مستخدمين إضافيين (أكثر من 30 لكل دور)
-- ============================================================

-- جدول مؤقت للأسماء العربية
DROP TEMPORARY TABLE IF EXISTS temp_arabic_names;
CREATE TEMPORARY TABLE temp_arabic_names (full_name VARCHAR(255), phone_prefix VARCHAR(20));
INSERT INTO temp_arabic_names (full_name, phone_prefix) VALUES
('أحمد محمد عبدالله', '77'), ('فاطمة علي حسن', '78'), ('عبدالله ناصر صالح', '77'), ('زينب عبده محمد', '78'),
('محمد حسين علي', '77'), ('نورة سعيد عمر', '78'), ('خالد عبدالرحمن', '77'), ('منى طارق احمد', '78'),
('سعيد احمد محمد', '77'), ('هناء يحيى علي', '78'), ('عمر صالح ناصر', '77'), ('ريم محمد عبدالله', '78'),
('يوسف علي حسين', '77'), ('سامية ناصر عبدالله', '78'), ('ابراهيم محمد علي', '77'), ('هدى عبده محمد', '78'),
('محمود عبدالله ناصر', '77'), ('ايمان علي احمد', '78'), ('حسن محمد حسين', '77'), ('نادية صالح عمر', '78'),
('علي احمد محمد', '77'), ('سعاد ناصر علي', '78'), ('نبيل محمد عبدالله', '77'), ('خديجة عبده علي', '78'),
('رامي علي صالح', '77'), ('اماني محمد ناصر', '78'), ('طلال عبدالله احمد', '77'), ('بشرى علي عبده', '78'),
('ماجد ناصر محمد', '77'), ('فاطمة احمد علي', '78'), ('وائل محمد صالح', '77'), ('سوسن عبدالله ناصر', '78'),
('زياد علي محمد', '77'), ('نوال عبده علي', '78'), ('هشام احمد محمد', '77'), ('غادة ناصر عبدالله', '78'),
('تامر محمد علي', '77'), ('رانيا صالح ناصر', '78'), ('رامز احمد عبدالله', '77'), ('شيماء محمد علي', '78');

-- إضافة منسقين (coordinators) - 15 منسق
INSERT IGNORE INTO Users (role_name, full_name, phone_number, img_url, email, password, is_active)
SELECT 
    'coordinator',
    full_name,
    CONCAT("74", LPAD(ABS(RAND() * 10000000), 7, '0')) AS phone,
    CONCAT('https://i.pravatar.cc/150?u=coord_', FLOOR(RAND() * 1000)) AS img_url,
    LOWER(REPLACE(REPLACE(full_name, ' ', '.'), 'amsde', 'h')) AS email_domain,
    '123456' AS password,
    IF(RAND() > 0.2, 1, 0) AS is_active
FROM temp_arabic_names
LIMIT 15;

-- إضافة موردين (suppliers) - 15 مورد
INSERT IGNORE INTO Users (role_name, full_name, phone_number, img_url, email, password, is_active)
SELECT 
    'supplier',
    full_name,
    CONCAT('70', LPAD(ABS(RAND() * 10000000), 7, '0')) AS phone,
    CONCAT('https://i.pravatar.cc/150?u=supp_', FLOOR(RAND() * 1000)) AS img_url,
    LOWER(REPLACE(REPLACE(full_name, ' ', '.'), 'ffdrf', 'h')) AS email_domain,
    '123456' AS password,
    IF(RAND() > 0.2, 1, 0) AS is_active
FROM temp_arabic_names
LIMIT 15;

-- إضافة عملاء (clients) - 15 عميل
INSERT IGNORE INTO Users (role_name, full_name, phone_number, img_url, email, is_active)
SELECT 
    'client',
    full_name,
    CONCAT('72', LPAD(ABS(RAND() * 10000000), 7, '0')) AS phone,
    CONCAT('https://i.pravatar.cc/150?u=client_', FLOOR(RAND() * 1000)) AS img_url,
    LOWER(REPLACE(REPLACE(full_name, ' ', '.'), 'kjhgb', 'h')) AS email_domain,
    IF(RAND() > 0.2, 1, 0) AS is_active
FROM temp_arabic_names
LIMIT 15;

-- ============================================================
-- 2. إضافة تفاصيل للمستخدمين (عناوين وملاحظات)
-- ============================================================

-- جدول مؤقت للعناوين
DROP TEMPORARY TABLE IF EXISTS temp_addresses;
CREATE TEMPORARY TABLE temp_addresses (addr VARCHAR(255));
INSERT INTO temp_addresses (addr) VALUES
('صنعاء - حدة'), ('صنعاء - شعوب'), ('صنعاء - السبعين'), ('عدن - خور مكسر'), ('عدن - المنصورة'),
('تعز - صالة'), ('تعز - الروضة'), ('إب - مدينة إب'), ('إب - الرضمة'), ('الحديدة - المنظر'),
('الحديدة - الحوك'), ('المكلا'), ('سيئون'), ('ذمار'), ('عمران'), ('صعدة'), ('حجة'), ('المحويت');

-- إضافة عنوان لكل مستخدم ليس لديه عنوان
INSERT IGNORE INTO User_Detail_Values (user_id, role_name, detail_name, detail_value)
SELECT u.user_id, u.role_name, 'address', 
       (SELECT addr FROM temp_addresses ORDER BY RAND() LIMIT 1)
FROM Users u
WHERE u.role_name IN ('coordinator', 'supplier', 'client')
  AND NOT EXISTS (SELECT 1 FROM User_Detail_Values ud WHERE ud.user_id = u.user_id AND ud.detail_name = 'address')
  AND u.user_id > 10; -- للمستخدمين الجدد فقط

-- إضافة ملاحظات للموردين
INSERT IGNORE INTO User_Detail_Values (user_id, role_name, detail_name, detail_value)
SELECT u.user_id, u.role_name, 'notes', 
       CONCAT('ملاحظات عن المورد: ', u.full_name, ' - متخصص في ', 
              CASE FLOOR(1 + RAND()*5)
                  WHEN 1 THEN 'الخدمات الغذائية'
                  WHEN 2 THEN 'خدمات الديكور'
                  WHEN 3 THEN 'خدمات الصوتيات'
                  WHEN 4 THEN 'خدمات التصوير'
                  ELSE 'خدمات متكاملة'
              END)
FROM Users u
WHERE u.role_name = 'supplier'
  AND NOT EXISTS (SELECT 1 FROM User_Detail_Values ud WHERE ud.user_id = u.user_id AND ud.detail_name = 'notes')
  AND u.user_id > 10;

-- ============================================================
-- 3. إضافة خدمات إضافية (30 خدمة)
-- ============================================================

-- إضافة 20 خدمة جديدة ليصبح المجموع أكثر من 30
INSERT IGNORE INTO Services (service_name, description)
SELECT 
    CONCAT('خدمة ', n) AS service_name,
    CONCAT('وصف خدمة رقم ', n, ' - مقدمة من فريق متخصص') AS description
FROM (
    SELECT 1 n UNION SELECT 2 UNION SELECT 3 UNION SELECT 4 UNION SELECT 5 
    UNION SELECT 6 UNION SELECT 7 UNION SELECT 8 UNION SELECT 9 UNION SELECT 10
    UNION SELECT 11 UNION SELECT 12 UNION SELECT 13 UNION SELECT 14 UNION SELECT 15
    UNION SELECT 16 UNION SELECT 17 UNION SELECT 18 UNION SELECT 19 UNION SELECT 20
) nums
WHERE (SELECT COUNT(*) FROM Services) < 30;

-- ============================================================
-- 4. ربط الموردين بالخدمات (30+ سجل)
-- ============================================================

-- لكل مورد، نربطه بـ 2-5 خدمات عشوائية
INSERT IGNORE INTO Supplier_Services (supplier_id, service_id)
SELECT u.user_id, s.service_id
FROM Users u
CROSS JOIN Services s
WHERE u.role_name = 'supplier'
  AND u.user_id > 3
  AND RAND() < 0.3
  AND NOT EXISTS (
      SELECT 1 FROM Supplier_Services ss 
      WHERE ss.supplier_id = u.user_id AND ss.service_id = s.service_id
  )
LIMIT 200;

-- ============================================================
-- 5. إضافة أحداث (30+ حدث)
-- ============================================================

-- جدول مؤقت للأحداث
DROP TEMPORARY TABLE IF EXISTS temp_events_data;
CREATE TEMPORARY TABLE temp_events_data (
    event_name VARCHAR(255), 
    description TEXT, 
    location VARCHAR(255), 
    budget DECIMAL(10,2), 
    event_date DATE, 
    status VARCHAR(20)
);

INSERT INTO temp_events_data (event_name, description, location, budget, event_date, status) VALUES
('حفل زفاف العائلة', 'حفل زفاف ابني', 'صالة الملكة أروى', 3000.00, DATE_ADD(CURDATE(), INTERVAL 30 DAY), 'PENDING'),
('حفل تخرج دفعة 2026', 'حفل تخرج طلاب الجامعة', 'قاعة المؤتمرات', 5000.00, DATE_ADD(CURDATE(), INTERVAL 45 DAY), 'PENDING'),
('مؤتمر التقنية', 'مؤتمر الذكاء الاصطناعي', 'فندق موفنبيك', 8000.00, DATE_ADD(CURDATE(), INTERVAL 60 DAY), 'PENDING'),
('معرض فني', 'معرض الفن التشكيلي', 'جاليري الفن', 1200.00, DATE_ADD(CURDATE(), INTERVAL 15 DAY), 'IN_PROGRESS'),
('ندوة صحية', 'التغذية السليمة', 'مركز المجتمع', 500.00, DATE_ADD(CURDATE(), INTERVAL 10 DAY), 'IN_PROGRESS'),
('حفل عشاء عمل', 'عشاء شركاء النجاح', 'مطعم الفردوس', 2000.00, DATE_ADD(CURDATE(), INTERVAL 25 DAY), 'PENDING'),
('مهرجان موسيقي', 'حفل غنائي', 'المسرح الروماني', 4000.00, DATE_ADD(CURDATE(), INTERVAL 50 DAY), 'PENDING'),
('دورة تدريبية', 'دورة تطوير الذات', 'مركز تدريب', 800.00, DATE_ADD(CURDATE(), INTERVAL 5 DAY), 'COMPLETED'),
('افتتاح مشروع', 'افتتاح فرع جديد', 'مقر الشركة', 6000.00, DATE_ADD(CURDATE(), INTERVAL 40 DAY), 'PENDING'),
('حفلة عيد ميلاد', 'عيد ميلاد 40', 'منزل العائلة', 600.00, DATE_ADD(CURDATE(), INTERVAL 20 DAY), 'PENDING'),
('مسابقة رياضية', 'ماراثون خيري', 'شارع الرئيسي', 1500.00, DATE_ADD(CURDATE(), INTERVAL 35 DAY), 'PENDING'),
('معرض كتاب', 'معرض الكتاب السنوي', 'قاعة المعارض', 2000.00, DATE_ADD(CURDATE(), INTERVAL 55 DAY), 'PENDING'),
('حفل خطوبة', 'حفل خطوبة', 'صالة الزفاف', 1000.00, DATE_ADD(CURDATE(), INTERVAL 18 DAY), 'IN_PROGRESS'),
('مؤتمر طبي', 'مؤتمر الجراحة الحديثة', 'فندق شيراتون', 7000.00, DATE_ADD(CURDATE(), INTERVAL 70 DAY), 'PENDING'),
('عرض أزياء', 'عرض أزياء خيري', 'فندق ماريوت', 2500.00, DATE_ADD(CURDATE(), INTERVAL 28 DAY), 'PENDING'),
('مهرجان طعام', 'مهرجان الأكلات الشعبية', 'حديقة السبعين', 1800.00, DATE_ADD(CURDATE(), INTERVAL 32 DAY), 'PENDING'),
('ورشة عمل', 'ريادة الأعمال', 'مركز الابتكار', 900.00, DATE_ADD(CURDATE(), INTERVAL 22 DAY), 'PENDING'),
('تخرج مدرسي', 'حفل تخرج طلاب', 'قاعة المدرسة', 400.00, DATE_ADD(CURDATE(), INTERVAL 12 DAY), 'IN_PROGRESS'),
('مهرجان ثقافي', 'فعاليات ثقافية', 'مكتبة البلدية', 600.00, DATE_ADD(CURDATE(), INTERVAL 42 DAY), 'PENDING'),
('عرض مسرحي', 'مسرحية كوميدية', 'المسرح القومي', 1000.00, DATE_ADD(CURDATE(), INTERVAL 38 DAY), 'PENDING'),
('مؤتمر استثماري', 'فرص استثمارية', 'فندق هوليدي إن', 4500.00, DATE_ADD(CURDATE(), INTERVAL 65 DAY), 'PENDING'),
('حفلة أطفال', 'يوم المرح', 'مدينة الملاهي', 800.00, DATE_ADD(CURDATE(), INTERVAL 26 DAY), 'PENDING'),
('معرض تكنولوجيا', 'أحدث الابتكارات', 'مركز المعارض', 3500.00, DATE_ADD(CURDATE(), INTERVAL 48 DAY), 'PENDING'),
('دورة برمجة', 'Flutter و Dart', 'أونلاين', 400.00, DATE_ADD(CURDATE(), INTERVAL 8 DAY), 'COMPLETED'),
('جلسة تصوير', 'جلسة تصوير عائلية', 'استوديو', 300.00, DATE_ADD(CURDATE(), INTERVAL 14 DAY), 'COMPLETED'),
('رحلة ترفيهية', 'رحلة إلى الشاطئ', 'الشاطئ', 2000.00, DATE_ADD(CURDATE(), INTERVAL 52 DAY), 'PENDING'),
('حفل تكريم', 'تكريم المتفوقين', 'قاعة الاحتفالات', 1200.00, DATE_ADD(CURDATE(), INTERVAL 33 DAY), 'PENDING'),
('معرض وظائف', 'توظيف خريجين', 'مركز المعارض', 1500.00, DATE_ADD(CURDATE(), INTERVAL 44 DAY), 'PENDING'),
('ندوة قانونية', 'القوانين الجديدة', 'قاعة المؤتمرات', 700.00, DATE_ADD(CURDATE(), INTERVAL 19 DAY), 'IN_PROGRESS'),
('حفل زفاف', 'زفاف صديق', 'صالة النخبة', 2800.00, DATE_ADD(CURDATE(), INTERVAL 36 DAY), 'PENDING'),
('حفل تخرج', 'تخرج من الجامعة', 'قاعة التاج', 3500.00, DATE_ADD(CURDATE(), INTERVAL 58 DAY), 'PENDING');

-- إضافة الأحداث مع اختيار عشوائي للعملاء والمنسقين
INSERT INTO Events (event_name, description, location, budget, event_date, client_id, coordinator_id, status)
SELECT 
    e.event_name,
    e.description,
    e.location,
    e.budget,
    e.event_date,
    (SELECT user_id FROM Users WHERE role_name = 'client' AND deleted_at IS NULL ORDER BY RAND() LIMIT 1) AS client_id,
    (SELECT user_id FROM Users WHERE role_name = 'coordinator' AND deleted_at IS NULL ORDER BY RAND() LIMIT 1) AS coordinator_id,
    e.status
FROM temp_events_data e
WHERE NOT EXISTS (SELECT 1 FROM Events LIMIT 1); -- تأكد من عدم وجود أحداث (يمكن تعديل الشرط)

DROP TEMPORARY TABLE temp_events_data;

-- ============================================================
-- 6. إضافة مهام كثيرة (لكل حدث 3-5 مهام)
-- ============================================================

-- جدول مؤقت لأنواع المهام
DROP TEMPORARY TABLE IF EXISTS temp_task_types;
CREATE TEMPORARY TABLE temp_task_types (type_task VARCHAR(255));
INSERT INTO temp_task_types (type_task) VALUES
('تأمين قاعة'), ('تجهيز ديكور'), ('تنسيق الزهور'), ('تصوير وفيديو'), ('تجهيز الصوتيات'),
('توفير وجبات'), ('تنسيق الإضاءة'), ('تأمين نقل'), ('طباعة دعوات'), ('تنظيف الموقع'),
('استقبال الضيوف'), ('تجهيز الكوشة'), ('توفير هدايا'), ('تأمين الأمن'), ('تسجيل الحضور'),
('ترتيب الجلسات'), ('تجهيز المنصة'), ('إدارة الكراسي'), ('توزيع الهدايا'), ('تنسيق البوفيه');

-- إضافة مهام لكل حدث (باستخدام تواريخ مستقبلية لتجنب أخطاء Trigger)
INSERT INTO Tasks (event_id, coordinator_id, status, type_task, date_start, date_due)
SELECT 
    e.event_id,
    e.coordinator_id,
    CASE FLOOR(1 + RAND()*5)
        WHEN 1 THEN 'PENDING'
        WHEN 2 THEN 'IN_PROGRESS'
        WHEN 3 THEN 'COMPLETED'
        WHEN 4 THEN 'UNDER_REVIEW'
        ELSE 'PENDING'
    END AS status,
    tt.type_task,
    DATE_ADD(e.event_date, INTERVAL -FLOOR(1 + RAND()*10) DAY) AS date_start,
    DATE_ADD(e.event_date, INTERVAL -FLOOR(1 + RAND()*5) DAY) AS date_due
FROM Events e
CROSS JOIN temp_task_types tt
WHERE RAND() < 0.35  -- احتمالية 35% لإضافة المهمة
  AND NOT EXISTS (
      SELECT 1 FROM Tasks t 
      WHERE t.event_id = e.event_id AND t.type_task = tt.type_task
  )
  AND DATE_ADD(e.event_date, INTERVAL -FLOOR(1 + RAND()*10) DAY) > CURDATE() - INTERVAL 30 DAY
LIMIT 800;

DROP TEMPORARY TABLE temp_task_types;

-- ============================================================
-- 7. تعيين المهام (Task_Assigns) لكل مهمة
-- ============================================================

-- جدول مؤقت للمستخدمين القابلين للتعيين (منسقين وموردين)
DROP TEMPORARY TABLE IF EXISTS temp_assignable_users;
CREATE TEMPORARY TABLE temp_assignable_users (user_id INT);
INSERT INTO temp_assignable_users 
SELECT user_id FROM Users 
WHERE role_name IN ('coordinator', 'supplier') 
  AND deleted_at IS NULL 
  AND is_active = 1;

-- تعيين كل مهمة لمستخدم
INSERT INTO Task_Assigns (task_id, coordinator_id, user_assign_id, description, cost, notes, url_image, reminder_type, reminder_value, reminder_unit)
SELECT 
    t.task_id,
    t.coordinator_id,
    (SELECT user_id FROM temp_assignable_users ORDER BY RAND() LIMIT 1) AS assign_user,
    CONCAT('تعيين مهمة: ', t.type_task, ' للحدث رقم ', e.event_id) AS description,
    ROUND(100 + RAND() * 2000, 2) AS cost,
    CASE WHEN RAND() > 0.7 THEN CONCAT('ملاحظة: ', t.type_task, ' تحتاج إلى اهتمام خاص') ELSE NULL END AS notes,
    CASE WHEN RAND() > 0.8 THEN 'https://example.com/task_image.jpg' ELSE NULL END AS url_image,
    CASE FLOOR(1 + RAND()*2) 
        WHEN 1 THEN 'INTERVAL' 
        WHEN 2 THEN 'BEFORE_DUE' 
        ELSE NULL 
    END AS reminder_type,
    FLOOR(1 + RAND()*30) AS reminder_value,
    CASE FLOOR(1 + RAND()*3) 
        WHEN 1 THEN 'MINUTE' 
        WHEN 2 THEN 'HOUR' 
        ELSE 'DAY' 
    END AS reminder_unit
FROM Tasks t
JOIN Events e ON t.event_id = e.event_id
WHERE NOT EXISTS (SELECT 1 FROM Task_Assigns ta WHERE ta.task_id = t.task_id)
  AND EXISTS (SELECT 1 FROM temp_assignable_users)
LIMIT 800;

DROP TEMPORARY TABLE temp_assignable_users;

-- ============================================================
-- 8. إضافة تقييمات للمهام المكتملة (30+)
-- ============================================================

INSERT INTO Ratings_Task (task_id, coordinator_id, value_rating, comment, rated_at)
SELECT 
    ta.task_assign_id,
    t.coordinator_id,
    FLOOR(1 + RAND()*5) AS rating,
    CASE FLOOR(1 + RAND()*5)
        WHEN 1 THEN 'عمل ممتاز ومتقن'
        WHEN 2 THEN 'جيد جداً، نرجو الاستمرار'
        WHEN 3 THEN 'مرضٍ مع بعض الملاحظات'
        WHEN 4 THEN 'مقبول يحتاج تحسين'
        ELSE 'ممتاز، شكراً لجهودكم'
    END AS comment,
    NOW() - INTERVAL FLOOR(RAND()*30) DAY AS rated_at
FROM Tasks t
JOIN Task_Assigns ta ON t.task_id = ta.task_id
WHERE t.status = 'COMPLETED'
  AND NOT EXISTS (SELECT 1 FROM Ratings_Task r WHERE r.task_id = ta.task_assign_id)
  AND RAND() < 0.5
LIMIT 100;

-- ============================================================
-- 9. إضافة إشعارات كثيرة (30+)
-- ============================================================

-- إشعارات للمستخدمين (عشوائية)
INSERT INTO Notifications (user_id, task_id, type, title, message, is_read)
SELECT 
    u.user_id,
    NULL AS task_id,
    CASE FLOOR(1 + RAND()*3)
        WHEN 1 THEN 'SYSTEM'
        WHEN 2 THEN 'REMINDER'
        ELSE 'INFO'
    END AS type,
    CASE FLOOR(1 + RAND()*4)
        WHEN 1 THEN 'تحديث النظام'
        WHEN 2 THEN 'تذكير بمهمة'
        WHEN 3 THEN 'تنبيه هام'
        ELSE 'إشعار جديد'
    END AS title,
    CASE FLOOR(1 + RAND()*4)
        WHEN 1 THEN CONCAT('مرحباً ', u.full_name, '، تم تحديث النظام بإضافة ميزات جديدة')
        WHEN 2 THEN CONCAT('تذكير: هناك مهام مستحقة للحدث القادم')
        WHEN 3 THEN CONCAT('تنبيه: يرجى مراجعة المهام المعلقة')
        ELSE CONCAT('تم إضافة حدث جديد في المنصة')
    END AS message,
    IF(RAND() > 0.3, 1, 0) AS is_read
FROM Users u
WHERE u.deleted_at IS NULL
  AND u.user_id NOT IN (SELECT user_id FROM Notifications WHERE type = 'SYSTEM' LIMIT 50)
  AND RAND() < 0.3
LIMIT 100;

-- إشعارات متعلقة بالمهام
INSERT INTO Notifications (user_id, task_id, type, title, message, is_read)
SELECT 
    ta.user_assign_id,
    ta.task_assign_id,
    'TASK_ASSIGNED',
    'مهمة جديدة',
    CONCAT('تم تعيين مهمة جديدة: ', t.type_task, ' في حدث ', e.event_name, ' بتاريخ ', t.date_due),
    0
FROM Task_Assigns ta
JOIN Tasks t ON ta.task_id = t.task_id
JOIN Events e ON t.event_id = e.event_id
WHERE NOT EXISTS (SELECT 1 FROM Notifications n WHERE n.task_id = ta.task_assign_id)
  AND RAND() < 0.4
LIMIT 150;

-- ============================================================
-- 10. إضافة إيرادات للأحداث (30+)
-- ============================================================

-- إضافة إيرادات لكل حدث
INSERT INTO Incomes (event_id, amount, payment_method, payment_date, description, url_image)
SELECT 
    e.event_id,
    ROUND(500 + RAND() * 5000, 2) AS amount,
    CASE FLOOR(1 + RAND()*4)
        WHEN 1 THEN 'نقدي'
        WHEN 2 THEN 'تحويل بنكي'
        WHEN 3 THEN 'شيك'
        ELSE 'بطاقة ائتمان'
    END AS payment_method,
    DATE_ADD(e.event_date, INTERVAL -FLOOR(RAND()*20) DAY) AS payment_date,
    CONCAT('دفعة للحدث: ', e.event_name) AS description,
    CASE WHEN RAND() > 0.8 THEN CONCAT('https://example.com/receipt_', e.event_id, '.jpg') ELSE NULL END AS url_image
FROM Events e
WHERE NOT EXISTS (SELECT 1 FROM Incomes i WHERE i.event_id = e.event_id)
  AND DATE_ADD(e.event_date, INTERVAL -FLOOR(RAND()*20) DAY) > CURDATE() - INTERVAL 60 DAY
LIMIT 80;

-- ============================================================
-- 11. إضافة إيرادات إضافية لبعض الأحداث (إيرادات متعددة)
-- ============================================================

-- إضافة إيراد ثانٍ لبعض الأحداث
INSERT INTO Incomes (event_id, amount, payment_method, payment_date, description, url_image)
SELECT 
    e.event_id,
    ROUND(300 + RAND() * 2000, 2) AS amount,
    CASE FLOOR(1 + RAND()*3)
        WHEN 1 THEN 'نقدي'
        WHEN 2 THEN 'تحويل بنكي'
        ELSE 'بطاقة ائتمان'
    END AS payment_method,
    DATE_ADD(e.event_date, INTERVAL -FLOOR(RAND()*10) DAY) AS payment_date,
    CONCAT('دفعة إضافية للحدث: ', e.event_name) AS description,
    NULL AS url_image
FROM Events e
WHERE (SELECT COUNT(*) FROM Incomes i WHERE i.event_id = e.event_id) < 2
  AND RAND() < 0.4
  AND DATE_ADD(e.event_date, INTERVAL -FLOOR(RAND()*10) DAY) > CURDATE() - INTERVAL 30 DAY
LIMIT 40;

-- ============================================================
-- 12. تحديث حالة بعض المهام لتكون مكتملة
-- ============================================================

UPDATE Tasks 
SET status = 'COMPLETED', 
    date_completion = DATE_ADD(date_due, INTERVAL FLOOR(RAND()*3) DAY),
    updated_at = NOW()
WHERE task_id IN (
    SELECT task_id FROM (
        SELECT task_id FROM Tasks 
        WHERE status = 'PENDING' 
          AND date_due < CURDATE() + INTERVAL 30 DAY
        ORDER BY RAND() 
        LIMIT 50
    ) tmp
);

-- ============================================================
-- 13. إضافة بعض المهام التي تم إلغاؤها
-- ============================================================

UPDATE Tasks 
SET status = 'CANCELLED',
    notes = CONCAT(IFNULL(notes, ''), ' تم إلغاء المهمة بسبب تغيير الخطة'),
    updated_at = NOW()
WHERE task_id IN (
    SELECT task_id FROM (
        SELECT task_id FROM Tasks 
        WHERE status = 'PENDING' 
        ORDER BY RAND() 
        LIMIT 20
    ) tmp
);

-- ============================================================
-- 14. تحديث حالة بعض الأحداث لتكون مكتملة أو قيد التنفيذ
-- ============================================================

UPDATE Events 
SET status = 'COMPLETED', 
    updated_at = NOW()
WHERE event_id IN (
    SELECT event_id FROM (
        SELECT event_id FROM Events 
        WHERE status = 'PENDING' 
          AND event_date < CURDATE() + INTERVAL 15 DAY
        ORDER BY RAND() 
        LIMIT 8
    ) tmp
);

UPDATE Events 
SET status = 'IN_PROGRESS', 
    updated_at = NOW()
WHERE event_id IN (
    SELECT event_id FROM (
        SELECT event_id FROM Events 
        WHERE status = 'PENDING' 
          AND event_date BETWEEN CURDATE() AND CURDATE() + INTERVAL 20 DAY
        ORDER BY RAND() 
        LIMIT 12
    ) tmp
);

-- ============================================================
-- 15. إضافة تعليقات للمهام المكتملة
-- ============================================================

UPDATE Tasks 
SET notes = CONCAT(IFNULL(notes, ''), ' تم إنجاز المهمة بنجاح في الوقت المحدد')
WHERE status = 'COMPLETED' 
  AND notes NOT LIKE '%تم إنجاز%'
  AND RAND() < 0.5
LIMIT 60;

-- ============================================================
-- استعادة إعدادات SQL
-- ============================================================
SET SQL_MODE = @OLD_SQL_MODE;

-- ============================================================
-- التحقق من عدد السجلات (استعلام عرض)
-- ============================================================
SELECT 'Users' AS TableName, COUNT(*) AS RecordCount FROM Users
UNION ALL
SELECT 'User_Detail_Values', COUNT(*) FROM User_Detail_Values
UNION ALL
SELECT 'Events', COUNT(*) FROM Events
UNION ALL
SELECT 'Services', COUNT(*) FROM Services
UNION ALL
SELECT 'Supplier_Services', COUNT(*) FROM Supplier_Services
UNION ALL
SELECT 'Tasks', COUNT(*) FROM Tasks
UNION ALL
SELECT 'Task_Assigns', COUNT(*) FROM Task_Assigns
UNION ALL
SELECT 'Ratings_Task', COUNT(*) FROM Ratings_Task
UNION ALL
SELECT 'Notifications', COUNT(*) FROM Notifications
UNION ALL
SELECT 'Incomes', COUNT(*) FROM Incomes;

-- ============================================================
-- عرض عينة من البيانات (اختياري)
-- ============================================================
SELECT 'عينة من المستخدمين' AS Info;
SELECT user_id, role_name, full_name, email, is_active FROM Users LIMIT 10;

SELECT 'عينة من الأحداث' AS Info;
SELECT event_id, event_name, event_date, status, budget FROM Events LIMIT 10;

SELECT 'عينة من المهام' AS Info;
SELECT task_id, event_id, type_task, status, date_due FROM Tasks LIMIT 10;

SELECT 'إحصائيات سريعة' AS Info;
SELECT 
    (SELECT COUNT(*) FROM Events) AS total_events,
    (SELECT COUNT(*) FROM Tasks) AS total_tasks,
    (SELECT COUNT(*) FROM Task_Assigns) AS total_assignments,
    (SELECT COUNT(*) FROM Incomes) AS total_incomes,
    (SELECT ROUND(SUM(amount), 2) FROM Incomes) AS total_amount;