
-- عرض المشرفين
CREATE OR REPLACE VIEW `vw_get_all_admins` AS
    SELECT 
        `u`.*,
        (`u`.`deleted_at` IS NOT NULL) AS `is_deleted`
    FROM `Users` `u` WHERE `u`.`role_name` = 'admin';

-- عرض المنسقين
CREATE OR REPLACE VIEW `vw_get_all_coordinators` AS
    SELECT 
        `u`.*,
        (`u`.`deleted_at` IS NOT NULL) AS `is_deleted`
    FROM `Users` `u` WHERE `u`.`role_name` = 'coordinator';

-- عرض الموردين
CREATE OR REPLACE VIEW `vw_get_all_suppliers` AS
    SELECT 
        `u`.*,
        (`u`.`deleted_at` IS NOT NULL) AS `is_deleted`,
        `fn_user_get_detail`(`u`.`user_id`,'address') AS `address`
        FROM `Users` `u` WHERE `u`.`role_name` = 'supplier';


-- عرض الأحداث مع التفاصيل (استخدام الأعمدة المباشرة)
CREATE OR REPLACE VIEW `vw_events_detailed` AS
    SELECT 
        e.*,
        (e.`deleted_at` IS NOT NULL) AS `is_deleted`,
        fn_event_get_status(e.`event_id`) AS `status`,
        c.`full_name` AS `client_name`,
        c.`phone_number` AS `client_phone`,
        c.`phone_number` AS `client_email`,

        co.`full_name` AS `coordinator_name`,
        co.`phone_number` AS `coordinator_phone`,
        co.`email` AS `coordinator_email`,

        COALESCE((SELECT SUM(inc.`amount`) FROM `Incomes` inc WHERE inc.`event_id` = e.`event_id` AND inc.`deleted_at` IS NULL), 0) AS `total_income`,
        COALESCE((SELECT SUM(ta.`cost`) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`deleted_at` IS NULL), 0) AS `total_expenses`,
        (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`deleted_at` IS NULL) AS `total_tasks`,
        (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`status` = 'COMPLETED' AND ta.`deleted_at` IS NULL) AS `completed_tasks`,
        CONCAT(
            ROUND(
                100 * (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`status` = 'COMPLETED' AND ta.`deleted_at` IS NULL) 
                / NULLIF((SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`deleted_at` IS NULL), 0), 
            2), '%'
        ) AS `completion_percentage`
    FROM `Events` e
    LEFT JOIN `Users` co ON e.`coordinator_id` = co.`user_id`
    LEFT JOIN `Clients` c ON e.`client_id` = c.`client_id`;
    
-- عرض المهام الكامل (استخدام الأعمدة المباشرة)
CREATE OR REPLACE VIEW `vw_tasks_full` AS
    SELECT 
        ta.*,
        e.`event_name`,
        creator.`full_name` AS `task_creator_name`,
        CASE 
            WHEN fn_user_has_role(ta.`user_assign_id`, 'coordinator') THEN 'coordinator'
            WHEN fn_user_has_role(ta.`user_assign_id`, 'supplier') THEN 'supplier'
            ELSE 'unknown'
        END AS `assignment_type`,
        assignee.`full_name` AS `assigne_name`,
        r.`rating_value`,
        r.`rating_comment`,
        r.`rated_at`
    FROM `Task_Assigns` ta
    LEFT JOIN `Events` e ON ta.`event_id` = e.`event_id`
    LEFT JOIN `Users` creator ON ta.`coordinator_id` = creator.`user_id`
    LEFT JOIN `Users` assignee ON ta.`user_assign_id` = assignee.`user_id`
    LEFT JOIN `Ratings_Task_Assign` r ON ta.`task_assign_id` = r.`task_assign_id`;

-- عرض الإشعارات (استخدام الأعمدة المباشرة)
CREATE OR REPLACE VIEW `vw_notifications` AS
    SELECT 
        n.*,
        CASE 
            WHEN fn_user_has_role(n.`user_id`, 'coordinator') THEN 'Coordinator'
            WHEN fn_user_has_role(n.`user_id`, 'supplier') THEN 'Supplier'
            ELSE 'admin'
        END AS `recipient_type`,
        u.`full_name` AS `recipient_name`
    FROM `Notifications` n
    LEFT JOIN `Users` u ON n.`user_id` = u.`user_id`;
    