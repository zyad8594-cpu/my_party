DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fun_role_has_detail`(
        `p_detail_name` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        `p_role_name` VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN 
        RETURN EXISTS (
            SELECT 1 FROM `Role_Details` 
            WHERE `detail_name` = p_detail_name AND `role_name` = p_role_name
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_role_has_permission`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci, 
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
    BEGIN
        RETURN EXISTS(
            SELECT 1 FROM `Role_Permissions` rp
            WHERE rp.`role_name` = p_role_name AND rp.`permission_name` = p_permission_name
        );
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_role_exists`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN EXISTS(
            SELECT 1 FROM `Roles` WHERE `role_name` = p_role_name AND `deleted_at` IS NULL
        );
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_has_role`(
    `p_user_id` INT,
    `p_role_name` VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci 
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
    BEGIN
        RETURN EXISTS(
            SELECT 1 FROM `Users` 
            WHERE `user_id` = p_user_id AND `role_name` = p_role_name AND `deleted_at` IS NULL
        );
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_get_rolename`(
        `p_user_conditions` JSON
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC READS SQL DATA
    BEGIN
        DECLARE v_user_id INT ;
        DECLARE v_full_name VARCHAR(255);
        DECLARE v_phone VARCHAR(20);
        DECLARE v_email VARCHAR(255);
        DECLARE v_password VARCHAR(255);
        DECLARE v_img_url TEXT;
        DECLARE v_role_name VARCHAR(50);
        DECLARE v_deleted_at TIMESTAMP;
        DECLARE is_all_null BOOLEAN;

        SET v_user_id = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.user_id')); 
        SET v_full_name = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.full_name')); 
        SET v_phone = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.phone_number')); 
        SET v_email = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.email')); 
        SET v_password = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.password')); 
        SET v_img_url = JSON_UNQUOTE(JSON_EXTRACT(p_user_conditions, '$.img_url')); 
    
        SET is_all_null =  v_user_id IS NULL AND 
                            v_full_name IS NULL AND 
                            v_phone IS NULL AND 
                            v_email IS NULL AND 
                            v_password IS NULL AND 
                            v_img_url IS NULL;
                            
        SELECT `role_name`, `deleted_at` INTO v_role_name, v_deleted_at FROM `Users` 
            WHERE NOT is_all_null AND (
                (v_user_id IS NULL OR `user_id` = v_user_id) AND 
                (v_full_name IS NULL OR `full_name` = v_full_name) AND 
                (v_phone IS NULL OR `phone_number` = v_phone) AND 
                (v_email IS NULL OR `email` = v_email) AND 
                (v_password IS NULL OR `password` = v_password) AND 
                (v_img_url IS NULL OR `img_url` = v_img_url)
            )
            LIMIT 1;

        IF v_deleted_at IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'User is deleted';
        END IF;
        RETURN v_role_name;
    END $$
DELIMITER ;


DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_has_detail`(
    `p_user_conditions` JSON,
    `p_detail_name` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci 
    ) RETURNS BOOLEAN NOT DETERMINISTIC READS SQL DATA
    BEGIN
        DECLARE v_role_name VARCHAR(50);

        SET v_role_name = fn_user_get_rolename(p_user_conditions);

        IF v_role_name IS NULL THEN
            RETURN FALSE;
        END IF;

        RETURN EXISTS(
            SELECT 1 FROM `Role_Details` rd
            WHERE rd.`role_name` = v_role_name 
            AND rd.`detail_name` = p_detail_name
            AND rd.`deleted_at` IS NULL
        );
    END $$
DELIMITER ;


DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_detail_exists`(
    `p_user_id` INT,
    `p_detail_name` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN 
        RETURN EXISTS (
            SELECT 1 FROM `User_Detail_Values` 
            WHERE `user_id` = p_user_id AND `detail_name` = p_detail_name
        );
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost'  FUNCTION `fn_user_get_detail`(
    `p_user_id` INT, 
    `p_detail_name` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN (
            SELECT `detail_value` FROM `User_Detail_Values`
            WHERE `user_id` = p_user_id AND `detail_name` = p_detail_name LIMIT 1
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_is_actived`(
    `p_user_id` INT
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN EXISTS (
            SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `is_active` = TRUE AND `deleted_at` IS NULL
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_user_is_deleted`(
    `p_user_id` INT
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN EXISTS (
            SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NOT NULL
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_total_income`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN (
            SELECT IFNULL(SUM(`amount`), 0) 
            FROM `Incomes` WHERE `event_id` = p_event_id AND `deleted_at` IS NULL
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_total_expenses`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
    BEGIN
        -- تصحيح: استخدام الجدول الصحيح Task_Assigns بدلاً من Tasks
        RETURN (
            SELECT IFNULL(SUM(`cost`), 0) 
            FROM `Task_Assigns` 
            WHERE `event_id` = p_event_id AND `deleted_at` IS NULL
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_net_profit`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN IFNULL(fn_event_total_income(p_event_id), 0) - IFNULL(fn_event_total_expenses(p_event_id), 0);
    END $$
DELIMITER ;

DELIMITER $$
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_overdue_tasks`(
    `p_event_id` INT
    ) RETURNS INT DETERMINISTIC READS SQL DATA
    BEGIN
        -- تصحيح: استخدام الجدول الصحيح Task_Assigns
        RETURN (
            SELECT COUNT(*) 
            FROM `Task_Assigns`
            WHERE `event_id` = p_event_id 
            AND `status` NOT IN ('COMPLETED', 'CANCELLED')
            AND `date_due` < CURDATE()
            AND `deleted_at` IS NULL
        );
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_getKeyOrIndex_array`(
    `p_index` INT, 
    `p_key` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci, 
    `p_keyOrIndex` ENUM('index','key') CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC NO SQL
    BEGIN 
        IF p_keyOrIndex = 'index' THEN 
            RETURN CONCAT('$[', p_index, ']'); 
        ELSEIF p_keyOrIndex = 'key' THEN 
            RETURN CONCAT('$.', p_key); 
        END IF; 
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Invalid key or index'; 
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost'  FUNCTION `fn_array_at`(`p_keys` JSON, `p_index` INT ) 
    RETURNS VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN JSON_UNQUOTE(JSON_EXTRACT(p_keys, CONCAT('$[', p_index, ']')));
    END $$
DELIMITER ;

DELIMITER $$ 
CREATE DEFINER = 'root'@'localhost'  FUNCTION `fn_json_get`(`p_details` JSON, `p_key` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci)
     RETURNS TEXT CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC READS SQL DATA
    BEGIN
        RETURN JSON_UNQUOTE(JSON_EXTRACT(p_details, CONCAT('$.', p_key)));
    END $$
DELIMITER ;



DELIMITER $$ 

CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_get_end_date`(
        `p_event_date` DATE,
        `p_event_duration` INT,
        `p_event_duration_unit` ENUM('DAY', 'WEEK', 'MONTH') CHARSET utf8mb4 COLLATE utf8mb4_general_ci
    ) RETURNS DATE DETERMINISTIC READS SQL DATA
    BEGIN

        IF p_event_duration_unit = 'DAY' THEN RETURN DATE_ADD(p_event_date , INTERVAL P_event_duration DAY);
        ELSEIF p_event_duration_unit = 'WEEK'THEN RETURN DATE_ADD(p_event_date , INTERVAL P_event_duration WEEK);
        ELSE RETURN DATE_ADD(p_event_date , INTERVAL P_event_duration MONTH); END IF;
    END $$

CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_status_is`(
        `p_event_status` ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED') CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        `p_event_id` INT
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA
    BEGIN 
        DECLARE v_event_date DATE;
        DECLARE v_event_end_date DATE;
        DECLARE v_deleted_at TIMESTAMP;

        SELECT `event_date`, fn_event_get_end_date(`event_date`, `event_duration`, `event_duration_unit`), `deleted_at` INTO
            v_event_date, v_event_end_date, v_deleted_at FROM `Events` 
            WHERE `event_id` = p_event_id;

        IF p_event_status = 'PENDING' THEN
            RETURN v_event_date > CURDATE();
        ELSEIF p_event_status = 'IN_PROGRESS' THEN
            RETURN v_event_date BETWEEN CURDATE() AND v_event_end_date;
        ELSEIF p_event_status = 'COMPLETED' THEN
            RETURN v_event_end_date < CURDATE();
        ELSE
            RETURN v_deleted_at IS NOT NULL;
        END IF;
    END $$

CREATE DEFINER = 'root'@'localhost' FUNCTION `fn_event_get_status`(
        `p_event_id` INT
    ) RETURNS ENUM('PENDING', 'IN_PROGRESS', 'COMPLETED', 'CANCELLED', 'OTHER') CHARSET utf8mb4 COLLATE utf8mb4_general_ci DETERMINISTIC READS SQL DATA
    BEGIN 
        DECLARE v_event_date DATE;
        DECLARE v_event_end_date DATE;
        DECLARE v_deleted_at TIMESTAMP;

        SELECT `event_date`, fn_event_get_end_date(`event_date`, `event_duration`, `event_duration_unit`), `deleted_at` INTO
            v_event_date, v_event_end_date, v_deleted_at FROM `Events` 
            WHERE `event_id` = p_event_id;

        IF v_deleted_at IS NOT NULL  THEN
            RETURN 'CANCELLED';
        ELSEIF v_event_date > CURDATE()  THEN
            RETURN 'PENDING';
        ELSEIF v_event_date BETWEEN CURDATE() AND v_event_end_date THEN
            RETURN 'IN_PROGRESS';
        ELSEIF v_event_end_date < CURDATE()  THEN
            RETURN 'COMPLETED';
        ELSE
            RETURN 'OTHER';
        END IF;
    END $$
DELIMITER ;