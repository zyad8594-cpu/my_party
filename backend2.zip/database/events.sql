-- تفعيل المجدول إذا كان مغلقاً
SET GLOBAL event_scheduler = ON;

-- مراقبة المناسبات (انتهاء أو اقتراب الانتهاء)
DELIMITER $$
CREATE PROCEDURE Check_Events_Status()
BEGIN
    -- إشعارات للمناسبات التي ستنتهي خلال 7 أيام (يوشك على الانتهاء)
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        e.coordinator_id,
        'EVENT_UPCOMING_END',
        CONCAT('حدث: ', e.event_name, ' على وشك الانتهاء'),
        CONCAT('سينتهي الحدث "', e.event_name, '" في ', 
               DATE_ADD(e.event_date, INTERVAL e.event_duration DAY), 
               '. يرجى مراجعة المهام والميزانية.')
    FROM Events e
    WHERE e.deleted_at IS NULL
      AND e.event_duration IS NOT NULL
      AND DATE_ADD(e.event_date, INTERVAL e.event_duration DAY) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
      AND NOT EXISTS (
          SELECT 1 FROM Notifications n
          WHERE n.user_id = e.coordinator_id
            AND n.type = 'EVENT_UPCOMING_END'
            AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            AND n.message LIKE CONCAT('%', e.event_name, '%')
      );

    -- إشعارات للمناسبات التي انتهت بالفعل
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        e.coordinator_id,
        'EVENT_EXPIRED',
        CONCAT('حدث: ', e.event_name, ' انتهى وقته'),
        CONCAT('الحدث "', e.event_name, '" قد انتهى في ', 
               DATE_ADD(e.event_date, INTERVAL e.event_duration DAY), 
               '. يرجى مراجعة التقارير النهائية.')
    FROM Events e
    WHERE e.deleted_at IS NULL
      AND e.event_duration IS NOT NULL
      AND DATE_ADD(e.event_date, INTERVAL e.event_duration DAY) < CURDATE()
      AND NOT EXISTS (
          SELECT 1 FROM Notifications n
          WHERE n.user_id = e.coordinator_id
            AND n.type = 'EVENT_EXPIRED'
            AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            AND n.message LIKE CONCAT('%', e.event_name, '%')
      );
END$$
DELIMITER ;




-- مراقبة الميزانية والدفعات
DELIMITER $$
CREATE PROCEDURE Check_Budget_And_Payments()
BEGIN
    -- لكل حدث: حساب إجمالي التكاليف (cost) وإجمالي الدفعات (Incomes)
    -- إشعار إذا تجاوزت التكاليف الميزانية
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        e.coordinator_id,
        'BUDGET_OVERSPENT',
        CONCAT('تجاوز الميزانية في حدث: ', e.event_name),
        CONCAT('الميزانية المحددة: ', e.budget, ', إجمالي التكاليف: ', COALESCE(SUM(ta.cost), 0), 
               '. الرجاء التدخل.')
    FROM Events e
    LEFT JOIN Task_Assigns ta ON e.event_id = ta.event_id AND ta.deleted_at IS NULL
    WHERE e.deleted_at IS NULL
    GROUP BY e.event_id, e.coordinator_id, e.event_name, e.budget
    HAVING COALESCE(SUM(ta.cost), 0) > e.budget
       AND NOT EXISTS (
           SELECT 1 FROM Notifications n
           WHERE n.user_id = e.coordinator_id
             AND n.type = 'BUDGET_OVERSPENT'
             AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
             AND n.message LIKE CONCAT('%', e.event_name, '%')
       );

    -- إشعار إذا كانت الدفعات أقل من التكاليف والحدث على وشك الانتهاء (خلال 7 أيام)
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        e.coordinator_id,
        'PAYMENT_INCOMPLETE',
        CONCAT('دفعات غير مكتملة لحدث: ', e.event_name),
        CONCAT('إجمالي التكاليف: ', COALESCE(SUM(ta.cost), 0), 
               ', إجمالي الدفعات: ', COALESCE(SUM(inc.amount), 0),
               '. الحدث ينتهي قريباً (', DATE_ADD(e.event_date, INTERVAL e.event_duration DAY), ').')
    FROM Events e
    LEFT JOIN Task_Assigns ta ON e.event_id = ta.event_id AND ta.deleted_at IS NULL
    LEFT JOIN Incomes inc ON e.event_id = inc.event_id AND inc.deleted_at IS NULL
    WHERE e.deleted_at IS NULL
      AND e.event_duration IS NOT NULL
      AND DATE_ADD(e.event_date, INTERVAL e.event_duration DAY) BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 7 DAY)
    GROUP BY e.event_id, e.coordinator_id, e.event_name, e.budget, e.event_date, e.event_duration
    HAVING COALESCE(SUM(inc.amount), 0) < COALESCE(SUM(ta.cost), 0)
       AND NOT EXISTS (
           SELECT 1 FROM Notifications n
           WHERE n.user_id = e.coordinator_id
             AND n.type = 'PAYMENT_INCOMPLETE'
             AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
             AND n.message LIKE CONCAT('%', e.event_name, '%')
       );
END$$
DELIMITER ;



-- مراقبة المهام (المواعيد النهائية والتأخير)
DELIMITER $$
CREATE PROCEDURE Check_Tasks_Deadlines()
BEGIN
    -- المهام المستحقة خلال 3 أيام (للموردين والمنسقين)
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        ta.user_assign_id,
        'TASK_UPCOMING',
        CONCAT('مهمة: ', ta.description, ' تستحق قريباً'),
        CONCAT('المهمة المطلوبة للحدث رقم ', ta.event_id, ' تستحق في ', ta.date_due, '. يرجى الإنجاز.')
    FROM Task_Assigns ta
    WHERE ta.deleted_at IS NULL
      AND ta.status NOT IN ('COMPLETED', 'CANCELLED')
      AND ta.date_due BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
      AND ta.user_assign_id IS NOT NULL
      AND NOT EXISTS (
          SELECT 1 FROM Notifications n
          WHERE n.user_id = ta.user_assign_id
            AND n.type = 'TASK_UPCOMING'
            AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            AND n.message LIKE CONCAT('%', ta.task_assign_id, '%')
      );

    -- المهام المتأخرة (للمنسقين)
    INSERT INTO Notifications (`user_id`, `type`, `title`, `message`)
    SELECT 
        ta.coordinator_id,
        'TASK_OVERDUE',
        CONCAT('مهمة متأخرة: ', ta.description),
        CONCAT('المهمة رقم ', ta.task_assign_id, ' كان موعدها ', ta.date_due, ' ولم تكتمل بعد.')
    FROM Task_Assigns ta
    WHERE ta.deleted_at IS NULL
      AND ta.status NOT IN ('COMPLETED', 'CANCELLED')
      AND ta.date_due < CURDATE()
      AND NOT EXISTS (
          SELECT 1 FROM Notifications n
          WHERE n.user_id = ta.coordinator_id
            AND n.type = 'TASK_OVERDUE'
            AND n.created_at > DATE_SUB(NOW(), INTERVAL 1 DAY)
            AND n.message LIKE CONCAT('%', ta.task_assign_id, '%')
      );
END$$
DELIMITER ;


-- إجراء شامل لاستدعاء جميع عمليات المراقبة
DELIMITER $$
CREATE PROCEDURE Run_Monitoring()
BEGIN
    CALL Check_Events_Status();
    CALL Check_Tasks_Deadlines();
    CALL Check_Budget_And_Payments();
END$$
DELIMITER ;





-- سنقوم بتشغيل الفحص كل 6 ساعات (يمكن تعديل الفاصل حسب الحاجة).
CREATE EVENT IF NOT EXISTS Event_Monitoring
ON SCHEDULE EVERY 6 HOUR
STARTS CURRENT_TIMESTAMP
DO
    CALL Run_Monitoring();






-- إنشاء حدث لتشغيل التذكيرات كل ساعة
DROP EVENT IF EXISTS `event_generate_reminders_hourly`;
CREATE EVENT `event_generate_reminders_hourly`
    ON SCHEDULE EVERY 1 HOUR
    STARTS CURRENT_TIMESTAMP
    DO CALL sp_generate_task_reminders();













sp_delete_user

sp_restore_user

sp_set_user_active

sp_add_permission_to_role

sp_remove_permission_from_role

sp_update_event

sp_delete_event

sp_update_service

sp_delete_service

sp_update_income

sp_delete_income

sp_update_task

sp_delete_task

sp_assign_service_to_supplier

sp_remove_service_from_supplier

sp_change_password (هذا يمكن أن يتحقق من أن المستخدم المنفذ هو نفسه صاحب الحساب، أو مدير)