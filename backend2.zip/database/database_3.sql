DROP DATABASE IF EXISTS `my_party_3`;

CREATE DATABASE IF NOT EXISTS `my_party_3` 
    DEFAULT CHARACTER SET utf8mb4 -- نوع الترميز
    COLLATE utf8mb4_general_ci; -- نوع الترتيب
USE `my_party_3`;

-- =====================================================
-- إنشاء الجداول الأساسية
-- =====================================================

-- جدول الأدوار (تم إضافة عمود deleted_at)
CREATE TABLE IF NOT EXISTS `Roles` (
    `role_name` VARCHAR(50) NOT NULL PRIMARY KEY, -- اسم الدور
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الدور
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الدور
    `deleted_at` TIMESTAMP NULL DEFAULT NULL -- تاريخ حذف الدور
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- إضافة الأدوار
INSERT IGNORE INTO `Roles` (`role_name`) VALUES 
    ('admin'), ('coordinator'), ('supplier');

-- جدول تفاصيل الأدوار (الحقول المسموح بها لكل دور)
CREATE TABLE IF NOT EXISTS `Role_Details` (
    `detail_name` VARCHAR(255) NOT NULL, -- اسم التفصيل
    `role_name` VARCHAR(50) NOT NULL, -- اسم الدور
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء التفصيل
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث التفصيل
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`detail_name`, `role_name`), -- مفتاح أساسي
    FOREIGN KEY (`role_name`) REFERENCES `Roles`(`role_name`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف الدور يتم حذف التفاصيل
    INDEX `idx_role_name` (`role_name`) -- فهرس على اسم الدور
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- إضافة التفاصيل لكل دور
INSERT IGNORE INTO `Role_Details` (`detail_name`, `role_name`) VALUES 
    ('address', 'supplier'), ('notes', 'supplier');

-- جدول الصلاحيات
CREATE TABLE IF NOT EXISTS `Permissions` (
    `permission_name` VARCHAR(100) NOT NULL PRIMARY KEY, -- اسم الصلاحية
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الصلاحية
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الصلاحية
    `deleted_at` TIMESTAMP NULL DEFAULT NULL -- تاريخ حذف الصلاحية
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- إضافة الصلاحيات
INSERT IGNORE INTO `Permissions` (`permission_name`) VALUES 
    ('view_admin_user'), ('create_admin_user'), ('edit_admin_user'), ('delete_admin_user'), 
    ('view_coordinator_user'), ('create_coordinator_user'), ('edit_coordinator_user'), ('delete_coordinator_user'), 
    ('view_supplier_user'), ('create_supplier_user'), ('edit_supplier_user'), ('delete_supplier_user'), 
    ('view_service'), ('create_service'), ('edit_service'), ('delete_service'), 

    ('view_client'), ('create_client'), ('edit_client'), ('delete_client'), 
    ('view_task'), ('create_task'), ('edit_task'), ('delete_task'), ('assign_task'), ('rate_task'),
    ('view_event'), ('create_event'), ('edit_event'), ('delete_event'), 
    ('view_income'), ('create_income'), ('edit_income'), ('delete_income'), 
     ('view_reports');

-- جدول صلاحيات الأدوار
CREATE TABLE IF NOT EXISTS `Role_Permissions` (
    `role_name` VARCHAR(50) NOT NULL, -- اسم الدور
    `permission_name` VARCHAR(100) NOT NULL, -- اسم الصلاحية
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الصلاحية
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الصلاحية
    `deleted_at` TIMESTAMP NULL DEFAULT NULL, 
    PRIMARY KEY (`role_name`, `permission_name`), -- مفتاح أساسي
    FOREIGN KEY (`role_name`) REFERENCES `Roles`(`role_name`) ON DELETE CASCADE ON UPDATE CASCADE, -- مفتاح خارجي عند حذف الدور يتم حذف الصلاحيات
    FOREIGN KEY (`permission_name`) REFERENCES `Permissions`(`permission_name`) ON DELETE CASCADE ON UPDATE CASCADE, -- مفتاح خارجي عند حذف الصلاحية يتم حذف الصلاحيات
    INDEX `idx_permission_name` (`permission_name`) -- فهرس على اسم الصلاحية
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- إضافة كل الصلاحيات للادمن
INSERT IGNORE INTO `Role_Permissions` (`role_name`, `permission_name`)
    SELECT r.`role_name`, p.`permission_name`
        FROM `Roles` r CROSS JOIN `Permissions` p
        WHERE r.`role_name` = 'admin' AND p.`deleted_at` IS NULL;

-- إضافة الصلاحيات لكل دور
INSERT IGNORE INTO `Role_Permissions` (`role_name`, `permission_name`)
    VALUES 
        
        ('coordinator', 'create_client'), ('coordinator', 'edit_client'), ('coordinator', 'delete_client'),
        ('coordinator', 'create_event'), ('coordinator', 'edit_event'), ('coordinator', 'delete_event'),
        ('coordinator', 'assign_task'), ('coordinator', 'rate_task'), ('coordinator', 'view_reports'),

        ('supplier', 'create_supplier_user'), ('supplier', 'edit_supplier_user'), ('supplier', 'delete_supplier_user');

-- جدول المستخدمين الأساسي
CREATE TABLE IF NOT EXISTS `Users` (
    `user_id` INT PRIMARY KEY AUTO_INCREMENT, -- رقم المستخدم
    `role_name` VARCHAR(50) NOT NULL, -- اسم الدور

    `full_name` VARCHAR(255) NOT NULL, -- اسم المستخدم
    `phone_number` VARCHAR(20) NULL UNIQUE DEFAULT NULL, -- رقم الهاتف
    `img_url` TEXT NULL DEFAULT NULL, -- رابط الصورة
    `email` VARCHAR(255) NOT NULL UNIQUE, -- البريد الإلكتروني
    `password` VARCHAR(255) NOT NULL, -- كلمة المرور

    `is_active` BOOLEAN DEFAULT FALSE, -- هل المستخدم نشط
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء المستخدم
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث المستخدم
    `deleted_at` TIMESTAMP NULL DEFAULT NULL, -- تاريخ حذف المستخدم
    FOREIGN KEY (`role_name`) REFERENCES `Roles`(`role_name`), -- مفتاح خارجي عند حذف الدور يتم حذف المستخدمين
    INDEX `idx_role_name` (`role_name`), -- فهرس على اسم الدور
    INDEX `idx_is_active` (`is_active`) -- فهرس على حالة المستخدم
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول صلاحيات المستخدم
CREATE TABLE IF NOT EXISTS `User_Permissions`(
        `user_id` INT NOT NULL,
        `permission_name` VARCHAR(100) NOT NULL,
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
        `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, 
        `deleted_at` TIMESTAMP NULL DEFAULT NULL, 
        
        PRIMARY KEY (`user_id`, `permission_name`),
        FOREIGN KEY(`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
        FOREIGN KEY(`permission_name`) REFERENCES `Permissions`(`permission_name`) ON DELETE CASCADE ON UPDATE CASCADE
    )
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول قيم تفاصيل المستخدم
CREATE TABLE IF NOT EXISTS `User_Detail_Values` (
    `user_id` INT NOT NULL, -- معرف المستخدم
    `detail_name` VARCHAR(255) NOT NULL, -- اسم التفصيل
    `detail_value` TEXT NULL, -- قيمة التفصيل

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء التفصيل
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث التفصيل
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,

    PRIMARY KEY (`user_id`, `detail_name`), -- مفتاح أساسي
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف المستخدم يتم حذف التفاصيل
    FOREIGN KEY (`detail_name`) REFERENCES `Role_Details`(`detail_name`) ON DELETE CASCADE,
    INDEX `idx_detail_name` (`detail_name`), -- فهرس على اسم التفصيل
    INDEX `idx_user_id` (`user_id`) -- فهرس على معرف المستخدم
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول المستخدمين الأساسي
CREATE TABLE IF NOT EXISTS `Clients` (
    `client_id` INT PRIMARY KEY AUTO_INCREMENT, -- رقم العميل
    `coordinator_id` INT NOT NULL,
    `creator_user_role` VARCHAR(50) NOT NULL CHECK(`creator_user_role` IN ('coordinator', 'admin')),
    `full_name` VARCHAR(255) NOT NULL, -- اسم العميل
    `phone_number` VARCHAR(20) NOT NULL, -- رقم الهاتف
    `img_url` TEXT NULL DEFAULT NULL, -- رابط الصورة
    `email` VARCHAR(255) NULL DEFAULT NULL, -- البريد الإلكتروني
    `address` TEXT NULL DEFAULT NULL,

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء العميل
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث العميل
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,

    FOREIGN KEY(`coordinator_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    CONSTRAINT `uc_client_phone_in_coordinator_creator` UNIQUE(`coordinator_id`, `phone_number`),
    CONSTRAINT `uc_client_email_in_coordinator_creator` UNIQUE(`coordinator_id`, `email`)
    
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول الأحداث (Events)
CREATE TABLE IF NOT EXISTS `Events` (
    `event_id` INT PRIMARY KEY AUTO_INCREMENT, -- معرف الحدث
    `coordinator_id` INT NOT NULL, -- معرف المنسق  
    `client_id` INT NOT NULL, -- معرف العميل

    `event_name` VARCHAR(255) NOT NULL, -- اسم الحدث
    `description` TEXT NULL, -- وصف الحدث
    `location` VARCHAR(255) NULL, -- موقع الحدث
    `img_url` TEXT NULL DEFAULT NULL,
    `budget` DECIMAL(10,2) DEFAULT 0.00, -- ميزانية الحدث
    `event_date` DATE NOT NULL, -- تاريخ الحدث
    `event_duration` INT NULL DEFAULT NULL,
    `event_duration_unit` ENUM('DAY', 'WEEK', 'MONTH') DEFAULT 'WEEK',

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الحدث
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الحدث
    `deleted_at` TIMESTAMP NULL, -- تاريخ حذف الحدث
    FOREIGN KEY (`client_id`) REFERENCES `Clients`(`client_id`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف العميل يتم حذف الحدث
    FOREIGN KEY (`coordinator_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE -- مفتاح خارجي عند حذف المنسق يتم حذف الحدث
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول الإيرادات
CREATE TABLE IF NOT EXISTS `Incomes` (
    `income_id` INT PRIMARY KEY AUTO_INCREMENT, -- معرف الإيراد
    `event_id` INT NOT NULL, -- معرف الحدث
    `amount` DECIMAL(10,2) NOT NULL, -- قيمة الإيراد
    `payment_method` VARCHAR(50) NULL, -- طريقة الدفع
    `payment_date` DATE NOT NULL, -- تاريخ الدفع
    `url_image` VARCHAR(255) NULL, -- رابط الصورة
    `description` TEXT NULL, -- وصف الإيراد
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الإيراد
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الإيراد
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE -- مفتاح خارجي عند حذف الحدث يتم حذف الإيراد
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول الخدمات
CREATE TABLE IF NOT EXISTS `Services` (
    `service_id` INT PRIMARY KEY AUTO_INCREMENT, -- معرف الخدمة
    `service_name` VARCHAR(100) NOT NULL, -- اسم الخدمة
    `description` TEXT NULL, -- وصف الخدمة
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الخدمة
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الخدمة
    `deleted_at` TIMESTAMP NULL DEFAULT NULL
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول خدمات الموردين
CREATE TABLE IF NOT EXISTS `Supplier_Services` (
    `supplier_id` INT NOT NULL, -- معرف المورد
    `service_id` INT NOT NULL, -- معرف الخدمة
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, 
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, 
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    PRIMARY KEY (`supplier_id`, `service_id`), -- مفتاح أساسي
    FOREIGN KEY (`supplier_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف المورد يتم حذف الخدمة
    FOREIGN KEY (`service_id`) REFERENCES `Services`(`service_id`) ON DELETE CASCADE -- مفتاح خارجي عند حذف الخدمة يتم حذف الخدمة
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول المهام 
CREATE TABLE IF NOT EXISTS `Task_Assigns` (
    `task_assign_id` INT PRIMARY KEY AUTO_INCREMENT,
    `event_id` INT NOT NULL, -- نقلت من جدول Tasks
    `type_task` VARCHAR(255), -- نقلت من جدول Tasks
    `notes` TEXT NULL, -- نقلت من جدول Tasks

    `service_id` INT NULL DEFAULT NULL,
    `user_assign_id` INT NULL DEFAULT NULL,
    `coordinator_id` INT NOT NULL, -- المنسق الذي قام بالتعيين

    `status` ENUM('PENDING', 'IN_PROGRESS', 'UNDER_REVIEW', 'COMPLETED', 'CANCELLED') DEFAULT 'PENDING',
    `description` TEXT NULL,
    `cost` DECIMAL(10,2) DEFAULT 0.00,
    `url_image` VARCHAR(255) NULL,
    `date_start` DATE NULL,
    `date_due` DATE NULL,
    `date_completion` TIMESTAMP NULL,

    `reminder_type` ENUM('INTERVAL', 'BEFORE_DUE') NULL DEFAULT 'BEFORE_DUE',
    `reminder_value` INT NULL,
    `reminder_unit` ENUM('MINUTE', 'HOUR', 'DAY') NULL DEFAULT 'DAY',

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,

    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`service_id`) REFERENCES `Supplier_Services`(`service_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`user_assign_id`) REFERENCES `Supplier_Services`(`supplier_id`) ON DELETE CASCADE ON UPDATE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,

    INDEX `idx_event_id` (`event_id`),
    INDEX `idx_user_assign_id` (`user_assign_id`),
    INDEX `idx_coordinator_id` (`coordinator_id`),
    INDEX `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- جدول تقييم المهام
CREATE TABLE IF NOT EXISTS `Ratings_Task_Assign` (
    `rating_id` INT PRIMARY KEY AUTO_INCREMENT, -- معرف التقييم
    `task_assign_id` INT NOT NULL, -- معرف المهمة (مرتبط بـ Task_Assigns)
    `coordinator_id` INT NOT NULL, -- معرف المنسق
    `user_assign_id` INT NOT NULL,
    
    `rating_value` INT NOT NULL CHECK (`rating_value` BETWEEN 1 AND 5), -- قيمة التقييم
    `rating_comment` TEXT NULL DEFAULT NULL, -- تعليق التقييم
    `rated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ التقييم

    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء التقييم
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث التقييم
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (`task_assign_id`) REFERENCES `Task_Assigns`(`task_assign_id`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف تعيين المهمة يتم حذف التقييم
    FOREIGN KEY (`coordinator_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE, -- مفتاح خارجي عند حذف المنسق يتم حذف التقييم

    CONSTRAINT `uc_coordinator_rate` UNIQUE(`coordinator_id`, `task_assign_id`),
    CONSTRAINT `check_different_users` CHECK (`user_assign_id` != `coordinator_id`)
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب

-- جدول الإشعارات
CREATE TABLE IF NOT EXISTS `Notifications` (
    `notification_id` INT PRIMARY KEY AUTO_INCREMENT, -- معرف الإشعار
     `user_id` INT NOT NULL, -- معرف المستخدم
    `type` VARCHAR(255) NOT NULL, -- نوع الإشعار
    `title` VARCHAR(255) NOT NULL, -- عنوان الإشعار
    `message` TEXT NOT NULL, -- رسالة الإشعار
    `is_read` BOOLEAN DEFAULT FALSE, -- حالة قراءة الإشعار
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP, -- تاريخ إنشاء الإشعار
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP, -- تاريخ تحديث الإشعار
    `deleted_at` TIMESTAMP NULL DEFAULT NULL,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE -- مفتاح خارجي عند حذف المستخدم يتم حذف الإشعار
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب



CREATE TABLE IF NOT EXISTS `Service_Requests` (
        `id` INT AUTO_INCREMENT PRIMARY KEY,
        `supplier_id` INT NOT NULL,
        `service_name` VARCHAR(100) NOT NULL,
        `description` TEXT,
        `status` ENUM('PENDING', 'APPROVED', 'REJECTED') DEFAULT 'PENDING',
        `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        `updated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        `deleted_at` TIMESTAMP NULL DEFAULT NULL,
        FOREIGN KEY (`supplier_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE
    ) 
    ENGINE=InnoDB -- نوع المحرك
    DEFAULT -- الافتراضي
    CHARSET=utf8mb4 -- نوع الترميز
    COLLATE=utf8mb4_general_ci; -- نوع الترتيب


-- =====================================================
-- إنشاء الدوال (Functions)
-- =====================================================



-- =====================================================
-- إنشاء طرق العرض (Views)
-- =====================================================


-- =====================================================
-- إنشاء الإجراءات المخزنة (Stored Procedures)
-- =====================================================



-- =====================================================
-- إنشاء المحفزات (Triggers)
-- =====================================================


