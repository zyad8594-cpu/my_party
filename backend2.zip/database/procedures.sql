DELIMITER $$
CREATE PROCEDURE `sp_get_user_by_id`(IN `p_user_id` INT)
    BEGIN 
        DECLARE v_role_name VARCHAR(50);
        
        SELECT `role_name` INTO v_role_name 
        FROM `Users` 
        WHERE `user_id` = p_user_id AND `deleted_at` IS NULL;
        
        IF v_role_name IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم غير موجود';
        END IF;
        
        CASE v_role_name
            WHEN 'admin' THEN
                SELECT * FROM `vw_get_all_admins` WHERE `user_id` = p_user_id;
            WHEN 'coordinator' THEN
                SELECT * FROM `vw_get_all_coordinators` WHERE `user_id` = p_user_id;
            WHEN 'supplier' THEN
                SELECT * FROM `vw_get_all_suppliers` WHERE `user_id` = p_user_id;
            ELSE
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'دور المستخدم غير معروف';
        END CASE;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_get_user_by_email`(IN `p_email` VARCHAR(255))
    BEGIN 
        DECLARE v_user_id INT;
        
        SELECT `user_id` INTO v_user_id 
        FROM `Users` 
        WHERE `email` = p_email AND `deleted_at` IS NULL;
        
        IF v_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم غير موجود';
        END IF;
        
        CALL sp_get_user_by_id(v_user_id);
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_login_user`(IN `p_email` VARCHAR(255))
    BEGIN 
        DECLARE v_user_id INT;
        DECLARE v_user_is_active BOOLEAN;
        DECLARE v_user_deleted_at TIMESTAMP;
        DECLARE v_user_password_hash VARCHAR(255);
        
        SELECT `user_id`, `is_active`, `deleted_at`, `password` 
        INTO v_user_id, v_user_is_active, v_user_deleted_at, v_user_password_hash 
        FROM `Users` WHERE `email` = p_email;
        
        IF v_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'البريد الإلكتروني غير مسجل';
        END IF;
        
        IF v_user_deleted_at IS NOT NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحساب محذوف';
        END IF;
        
        IF NOT v_user_is_active THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحساب غير مفعل';
        END IF;

        CALL sp_get_user_by_id(v_user_id);
    END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE `sp_throw_if_account_not_admin`(
        IN `p_user_creator_email` VARCHAR(255),
        IN `p_user_creator_pass` VARCHAR(255),
        IN `p_permission_role` ENUM('admin', 'coordinator', 'supplier')
    )
    BEGIN
        DECLARE v_user_id INT;
        -- DECLARE v_permission_name VARCHAR(100);
        -- DECLARE v_error_msg TEXT;
        
        -- الحصول على معرف المستخدم المدير
        SELECT `user_id` INTO v_user_id 
            FROM `Users` 
            WHERE `email` = p_user_creator_email 
            AND `password` = p_user_creator_pass 
            AND `role_name` = 'admin'
            AND `deleted_at` IS NULL;
        
        IF v_user_id IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن الإنشاء إلا عن طريق حساب مدير';
        END IF;
        
        -- -- اسم الصلاحية المطلوبة: create_{role}_user
        -- SET v_permission_name = CONCAT('create_', p_permission_role, '_user');
        
        -- -- التحقق من أن دور 'admin' لديه هذه الصلاحية
        -- IF NOT EXISTS (
        --     SELECT 1 FROM `Role_Permissions` rp
        --     WHERE rp.`role_name` = 'admin' 
        --     AND rp.`permission_name` = v_permission_name
        --     AND rp.`deleted_at` IS NULL
        -- ) THEN
        --     SET v_error_msg = CONCAT('حساب المدير ليس لديه صلاحية ', v_permission_name);
        --     SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_msg;
        -- END IF;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_user`(
        IN `p_user_creator_email` VARCHAR(255),
        IN `p_user_creator_pass` VARCHAR(255),
        IN `p_role_name` VARCHAR(50),
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_is_active` BOOLEAN,
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_details` JSON,
        OUT `p_user_id` INT,
        IN `p_with_out` BOOLEAN
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_detail_name VARCHAR(255);
        DECLARE v_detail_value TEXT;
        DECLARE v_i INT DEFAULT 0;
        DECLARE v_keys JSON;
        DECLARE v_total INT DEFAULT 0;
        DECLARE v_error_msg TEXT;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        -- التحقق من صلاحية المدير
        CALL sp_throw_if_account_not_admin(p_user_creator_email, p_user_creator_pass, p_role_name);
        
        START TRANSACTION;
        
        -- التحقق من عدم تكرار البريد أو الهاتف
        IF EXISTS(SELECT 1 FROM `Users` WHERE `email` = p_email AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا البريد موجود مسبقا';
        END IF;
        IF EXISTS(SELECT 1 FROM `Users` WHERE `phone_number` = p_phone_number AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الهاتف موجود مسبقا';
        END IF;
        
        -- إدراج المستخدم
        INSERT INTO `Users` (`role_name`, `full_name`, `phone_number`, `is_active`, `img_url`, `email`, `password`, `is_active`)
        VALUES (p_role_name, p_full_name, p_phone_number, p_is_active, p_img_url, p_email, p_password, FALSE);
        SET p_user_id = LAST_INSERT_ID();
        
        -- معالجة التفاصيل الإضافية
        IF p_details IS NOT NULL AND JSON_VALID(p_details) THEN
            SET v_keys = JSON_KEYS(p_details);
            SET v_total = JSON_LENGTH(v_keys);
            
            WHILE v_i < v_total DO
                SET v_detail_name = JSON_UNQUOTE(JSON_EXTRACT(v_keys, CONCAT('$[', v_i, ']')));
                SET v_detail_value = JSON_UNQUOTE(JSON_EXTRACT(p_details, CONCAT('$.', v_detail_name)));
                
                IF NOT fun_role_has_detail(v_detail_name, p_role_name) THEN  
                    SET v_error_msg = CONCAT('الحقل "', v_detail_name, ' => ', v_detail_value, '" غير مسموح به في دور هذا الحساب');
                    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_msg;
                END IF;
                
                INSERT INTO `User_Detail_Values` (`user_id`, `detail_name`, `detail_value`)
                    VALUES (p_user_id, v_detail_name, v_detail_value)
                    ON DUPLICATE KEY UPDATE
                    `user_id` = VALUES(`user_id`),
                    `detail_name` = VALUES(`detail_name`),
                    `detail_value` = VALUES(`detail_value`);
                SET v_i = v_i + 1;
            END WHILE;
        END IF;
        
        -- إشعار للمدير (user_id = 1)
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            CONCAT('create_', p_role_name, '_user'), 
            CONCAT('إشتراك ', 
                CASE p_role_name
                    WHEN 'coordinator' THEN 'منسق'
                    WHEN 'supplier' THEN 'مورد'
                    ELSE p_role_name
                END, 
                ' جديد'
            ), 
            CONCAT(
                'تمت عملية إشتراك بحساب ', 
                CASE p_role_name
                    WHEN 'coordinator' THEN 'منسق'
                    WHEN 'supplier' THEN 'مورد'
                    ELSE p_role_name
                END, 
                ' جديد\n',
                'رقم الحساب: ', p_user_id, '\n',
                'الإسم: ', p_full_name, '\n',
                'رقم الهاتف: ', p_phone_number, '\n',
                'البريد: ', p_email, 
                IF(p_is_active, '', '\nيرجى الموافقة عليه لتفعيله')
            )
        );
        
        COMMIT;
        IF p_with_out THEN CALL sp_get_user_by_id(p_user_id); END IF;
    END$$

CREATE PROCEDURE `sp_register`(
        IN `p_role_name` VARCHAR(50),
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_details` JSON,
        IN `p_with_out` BOOLEAN
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_user_id INT;
        DECLARE v_user_creator_email VARCHAR(255);
        DECLARE v_user_creator_pass VARCHAR(255);
        SELECT `email`, `password` INTO v_user_creator_email, v_user_creator_pass 
        FROM `Users` WHERE `user_id` = 1 AND `deleted_at` IS NULL;
        CALL sp_create_user(
            v_user_creator_email,
            v_user_creator_pass,
            p_role_name, p_full_name, p_phone_number, FALSE, p_img_url, 
            p_email, p_password, p_details, v_user_id, p_with_out
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_coordinator`(
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_is_active` BOOLEAN,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_with_out` BOOLEAN
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_user_id INT;
        DECLARE v_user_creator_email VARCHAR(255);
        DECLARE v_user_creator_pass VARCHAR(255);
        SELECT `email`, `password` INTO v_user_creator_email, v_user_creator_pass 
        FROM `Users` WHERE `user_id` = 1 AND `deleted_at` IS NULL;
        
        CALL sp_create_user(
            v_user_creator_email, v_user_creator_pass, 'coordinator', p_full_name,
            p_phone_number, p_is_active, p_img_url, p_email, p_password, '{}', v_user_id, p_with_out
        );
    END$$

CREATE PROCEDURE `sp_create_supplier`(
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_is_active` BOOLEAN,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_address` TEXT,
        IN `p_notes` TEXT,
        IN `p_services` JSON,
        IN `p_with_out` BOOLEAN
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_user_id INT;
        DECLARE v_service_id INT;
        DECLARE v_user_creator_email VARCHAR(255);
        DECLARE v_user_creator_pass VARCHAR(255);
        DECLARE v_total INT DEFAULT 0;
        DECLARE v_i INT DEFAULT 0;
        DECLARE v_details JSON;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

        SELECT `email`, `password` INTO v_user_creator_email, v_user_creator_pass 
        FROM `Users` WHERE `user_id` = 1 AND `deleted_at` IS NULL;
        
        -- بناء JSON للتفاصيل
        SET v_details = JSON_OBJECT();
        IF p_address IS NOT NULL THEN
            SET v_details = JSON_SET(v_details, '$.address', p_address);
        END IF;
        IF p_notes IS NOT NULL THEN
            SET v_details = JSON_SET(v_details, '$.notes', p_notes);
        END IF;
        
        START TRANSACTION;

        CALL sp_create_user(
            v_user_creator_email, v_user_creator_pass, 'supplier', p_full_name,
            p_phone_number, p_is_active, p_img_url, p_email, p_password, v_details, v_user_id, p_with_out
        );

        IF p_services IS NOT NULL THEN
            SET v_total = JSON_LENGTH(p_services);
            
            WHILE v_i < v_total DO
                SET v_service_id = JSON_UNQUOTE(JSON_EXTRACT(p_services, CONCAT('$[', v_i, ']')));
                IF v_service_id IS NOT NULL THEN 
                    INSERT INTO `Supplier_Services` (`supplier_id`, `service_id`) VALUES (v_user_id, v_service_id);
                END IF;
                SET v_i = v_i + 1;
            END WHILE; 
        END IF;
        COMMIT;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_client`(
        IN `p_coordinator_id` INT,
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_address` TEXT,
        IN `p_with_out` BOOLEAN
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_creator_user_role VARCHAR(50);
        DECLARE v_creator_name VARCHAR(255);
        DECLARE v_creator_email VARCHAR(255);
        DECLARE v_client_id INT;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        -- الحصول على بيانات المنسق
        SELECT `role_name`, `full_name`, `email`
        INTO v_creator_user_role, v_creator_name, v_creator_email
        FROM `Users` 
        WHERE `user_id` = p_coordinator_id 
        AND `role_name` IN ('coordinator', 'admin')
        AND `deleted_at` IS NULL; 
        
        IF v_creator_user_role IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إنشاء العميل إلا عن طريق حساب منسق أو مدير';
        END IF;
        
        -- التحقق من عدم وجود عميل بنفس البريد أو الهاتف لنفس المنسق
        IF EXISTS(
            SELECT 1 FROM `Clients` 
            WHERE `coordinator_id` = p_coordinator_id 
            AND (`email` = p_email OR `phone_number` = p_phone_number)
            AND `deleted_at` IS NULL
        ) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا العميل موجود مسبقا لهذا المنسق';
        END IF;
        
        
        START TRANSACTION;
        
        INSERT INTO `Clients`(`coordinator_id`, `creator_user_role`, `full_name`, `phone_number`, `img_url`, `email`, `address`)
        VALUES (p_coordinator_id, v_creator_user_role, p_full_name, p_phone_number, p_img_url, p_email, p_address);
        SET v_client_id = LAST_INSERT_ID();
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_coordinator_id,
            'create_client', 
            'عميل جديد', 
            CONCAT(
                'لقد قمت بإضافة عميل جديد\n', 
                'رقم العميل: ', v_client_id, '\n',
                'إسم العميل: ', p_full_name, '\n',
                'رقم هاتفه: ', p_phone_number, '\n',
                IF(p_email IS NULL OR p_email = '', '', CONCAT('البريد: ', p_email, '\n')),
                IF(p_address IS NULL OR p_address = '', '', CONCAT('العنوان: ', p_address))
            )
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'create_client', 
            'عميل جديد', 
            CONCAT(
                'لقد قام ', IF(v_creator_user_role = 'admin', 'المدير ', 'المنسق '),
                v_creator_name, ' "', v_creator_email, '" بإضافة عميل جديد\n\n',
                'رقم العميل: ', v_client_id, '\n',
                'إسم العميل: ', p_full_name, '\n',
                'رقم هاتفه: ', p_phone_number, '\n',
                IF(p_email IS NULL OR p_email = '', '', CONCAT('البريد: ', p_email, '\n')),
                IF(p_address IS NULL OR p_address = '', '', CONCAT('العنوان: ', p_address))
            )
        );
        
        COMMIT;
        IF p_with_out THEN SELECT * FROM `Clients` WHERE `client_id` = v_client_id; END IF;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_client`(
        IN `p_coordinator_id` INT,
        IN `p_client_id` INT,
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_address` TEXT
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_creator_user_role VARCHAR(50);
        DECLARE v_creator_name VARCHAR(255);
        DECLARE v_creator_email VARCHAR(255);
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        -- الحصول على بيانات المنسق
        SELECT `role_name`, `full_name`, `email`
            INTO v_creator_user_role, v_creator_name, v_creator_email
                FROM `Users` 
                    WHERE `user_id` = p_coordinator_id 
                        AND `role_name` IN ('coordinator', 'admin')
                        AND `deleted_at` IS NULL; 
        
        IF v_creator_user_role IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تعديل بيانات العميل إلا عن طريق حساب منسق أو مدير';
        END IF;
        
        
        START TRANSACTION;
        
        UPDATE `Clients` SET 
            `full_name` = IFNULL(p_full_name, `full_name`), 
            `phone_number` = IFNULL(p_phone_number, `phone_number`), 
            `img_url` = IFNULL(p_img_url, `img_url`), 
            `email` = IFNULL(p_email, `email`), 
            `address` = IFNULL(p_address, `address`),
            `updated_at` = NOW()
        WHERE `client_id` = p_client_id;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_coordinator_id,
            'update_client', 
            'تحديث بيانات عميل', 
            CONCAT(
                'لقد قمت بتحديث بيانات العميل\n', 
                'إسم العميل: ', p_full_name, '\n',
                'رقم هاتفه: ', p_phone_number, '\n',
                IF(p_email IS NULL OR p_email = '', '', CONCAT('البريد: ', p_email, '\n')),
                IF(p_address IS NULL OR p_address = '', '', CONCAT('العنوان: ', p_address))
            )
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_client', 
            'تحديث بيانات عميل', 
            CONCAT(
                'لقد قام ', IF(v_creator_user_role = 'admin', 'المدير ', 'المنسق '),
                v_creator_name, ' "', v_creator_email, '" بتحديث بيانات العميل\n\n',
                'رقم العميل: ', p_client_id, '\n',
                'إسم العميل: ', p_full_name, '\n',
                'رقم هاتفه: ', p_phone_number, '\n',
                IF(p_email IS NULL OR p_email = '', '', CONCAT('البريد: ', p_email, '\n')),
                IF(p_address IS NULL OR p_address = '', '', CONCAT('العنوان: ', p_address))
            )
        );
        
        COMMIT;
        SELECT * FROM `Clients` WHERE `client_id` = p_client_id;
    END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE `sp_update_user`(
        IN `p_user_creator_email` VARCHAR(255),
        IN `p_user_creator_pass` VARCHAR(255),
        IN `p_user_id` INT,
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_details` JSON
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        DECLARE v_role_name VARCHAR(50);
        DECLARE v_detail_name VARCHAR(255);
        DECLARE v_detail_value TEXT;
        DECLARE v_i INT DEFAULT 0;
        DECLARE v_keys JSON;
        DECLARE v_total INT DEFAULT 0;
        DECLARE v_error_msg TEXT;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        -- الحصول على دور المستخدم قبل التحديث
        SELECT `role_name` INTO v_role_name 
        FROM `Users` 
        WHERE `user_id` = p_user_id AND `deleted_at` IS NULL;
        
        IF v_role_name IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم غير موجود';
        END IF;
        
        -- التحقق من صلاحية المدير لتحديث هذا الدور
        CALL sp_throw_if_account_not_admin(p_user_creator_email, p_user_creator_pass, v_role_name);
        
        -- التحقق من عدم تكرار البريد أو الهاتف مع مستخدم آخر
        IF EXISTS(SELECT 1 FROM `Users` WHERE `user_id` != p_user_id AND `email` = p_email AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا البريد موجود مسبقا';
        END IF;
        IF EXISTS(SELECT 1 FROM `Users` WHERE `user_id` != p_user_id AND `phone_number` = p_phone_number AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الهاتف يمتلكه شخص آخر';
        END IF;
        
        START TRANSACTION;
        
        -- تحديث بيانات المستخدم الأساسية
        UPDATE `Users` SET 
            `full_name` = COALESCE(p_full_name, `full_name`),
            `phone_number` = COALESCE(p_phone_number, `phone_number`),
            `img_url` = COALESCE(p_img_url, `img_url`),
            `email` = COALESCE(p_email, `email`),
            `password` = COALESCE(p_password, `password`),
            `updated_at` = NOW()
        WHERE `user_id` = p_user_id;
        
        -- معالجة التفاصيل الإضافية
        IF p_details IS NOT NULL AND JSON_VALID(p_details) THEN
            SET v_keys = JSON_KEYS(p_details);
            SET v_total = JSON_LENGTH(v_keys);
            
            WHILE v_i < v_total DO
                SET v_detail_name = JSON_UNQUOTE(JSON_EXTRACT(v_keys, CONCAT('$[', v_i, ']')));
                SET v_detail_value = JSON_UNQUOTE(JSON_EXTRACT(p_details, CONCAT('$.', v_detail_name)));
                
                IF NOT fn_user_detail_exists(p_user_id, v_detail_name) THEN
                    IF NOT fun_role_has_detail(v_detail_name, v_role_name) THEN 
                        SET v_error_msg = CONCAT('الحقل "', v_detail_name, '" غير مسموح به في دور هذا الحساب');
                        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_msg;
                    END IF;
                    INSERT INTO `User_Detail_Values` (`user_id`, `detail_name`, `detail_value`)
                    VALUES (p_user_id, v_detail_name, v_detail_value);
                ELSE
                    UPDATE `User_Detail_Values`
                    SET `detail_value` = v_detail_value, `updated_at` = NOW()
                    WHERE `user_id` = p_user_id AND `detail_name` = v_detail_name;
                END IF;
                SET v_i = v_i + 1;
            END WHILE;
        END IF;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            CONCAT('update_', v_role_name, '_user'), 
            CONCAT('تحديث حساب ', 
                CASE v_role_name
                    WHEN 'coordinator' THEN 'منسق'
                    WHEN 'supplier' THEN 'مورد'
                    ELSE v_role_name
                END
            ), 
            CONCAT(
                'تمت عملية تحديث حساب ', 
                CASE v_role_name
                    WHEN 'coordinator' THEN 'المنسق'
                    WHEN 'supplier' THEN 'المورد'
                    ELSE v_role_name
                END,
                '\nرقم الحساب: ', p_user_id, '\n',
                'الإسم: ', COALESCE(p_full_name, (SELECT `full_name` FROM `Users` WHERE `user_id` = p_user_id)), '\n',
                'رقم الهاتف: ', COALESCE(p_phone_number, (SELECT `phone_number` FROM `Users` WHERE `user_id` = p_user_id)), '\n',
                'البريد: ', COALESCE(p_email, (SELECT `email` FROM `Users` WHERE `user_id` = p_user_id))
            )
        );
        
        -- إشعار للمستخدم نفسه
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_user_id,
            CONCAT('update_', v_role_name, '_user'), 
            'تم تحديث حسابك', 
            CONCAT(
                'تمت عملية تحديث حسابك بنجاح \n', 
                'الإسم: ', COALESCE(p_full_name, (SELECT `full_name` FROM `Users` WHERE `user_id` = p_user_id)), '\n',
                'رقم الهاتف: ', COALESCE(p_phone_number, (SELECT `phone_number` FROM `Users` WHERE `user_id` = p_user_id)), '\n',
                'البريد: ', COALESCE(p_email, (SELECT `email` FROM `Users` WHERE `user_id` = p_user_id))
            )
        );
        
        COMMIT;
        CALL sp_get_user_by_id(p_user_id);
    END$$

CREATE PROCEDURE `sp_update_user_byadmin`(
        IN `p_user_id` INT,
        IN `p_full_name` VARCHAR(255),
        IN `p_phone_number` VARCHAR(20),
        IN `p_img_url` TEXT,
        IN `p_email` VARCHAR(255),
        IN `p_password` VARCHAR(255),
        IN `p_details` JSON
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        DECLARE v_email VARCHAR(255);
        DECLARE v_pass VARCHAR(255);
        SELECT `email`, `password` INTO v_email, v_pass FROM `Users` WHERE `user_id` = 1;
        CALL sp_update_user(
            v_email, v_pass, p_user_id, p_full_name, p_phone_number, p_img_url, p_email, p_password, p_details
        );
    END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_user`(IN `p_user_id` INT)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN
        DECLARE v_user_email VARCHAR(255);
        DECLARE v_user_name VARCHAR(255);
        DECLARE v_role_name VARCHAR(50);
        
        SELECT `email`, `full_name`, `role_name` INTO v_user_email, v_user_name, v_role_name
        FROM `Users` WHERE `user_id` = p_user_id;
        
        IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
        END IF;
        IF fn_user_is_deleted(p_user_id) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الحساب محذوف بالفعل';
        END IF;
        
        UPDATE `Users` SET `deleted_at` = NOW() WHERE `user_id` = p_user_id;
        
        -- إشعار للمدير (user_id = 1)
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_user',
            'حذف حساب',
            CONCAT('تم حذف حساب المستخدم: ', v_user_name, ' (', v_user_email, ') - الدور: ', v_role_name)
        );
        
        -- إشعار للمستخدم نفسه (حتى لو كان محذوفاً يمكن إدراج إشعار)
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_user_id,
            'delete_user',
            'تم حذف حسابك',
            CONCAT('تم حذف حسابك بتاريخ ', NOW(), '. إذا كان هذا خطأ، يرجى التواصل مع المدير.')
        );
        
        SELECT p_user_id AS user_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_restore_user`(IN `p_user_id` INT)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        DECLARE v_user_email VARCHAR(255);
        DECLARE v_user_name VARCHAR(255);
        DECLARE v_role_name VARCHAR(50);
        
        SELECT `email`, `full_name`, `role_name` INTO v_user_email, v_user_name, v_role_name
        FROM `Users` WHERE `user_id` = p_user_id;
        
        IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
        END IF;
        IF NOT fn_user_is_deleted(p_user_id) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'هذا الحساب ليس محذوفاً';
        END IF;
        
        UPDATE `Users` SET `deleted_at` = NULL WHERE `user_id` = p_user_id;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'restore_user',
            'استعادة حساب',
            CONCAT('تم استعادة حساب المستخدم: ', v_user_name, ' (', v_user_email, ') - الدور: ', v_role_name)
        );
        
        -- إشعار للمستخدم
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_user_id,
            'restore_user',
            'تم استعادة حسابك',
            CONCAT('تم استعادة حسابك بتاريخ ', NOW(), '. يمكنك الآن تسجيل الدخول.')
        );
        
        SELECT p_user_id AS user_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_set_user_active`(IN `p_user_id` INT, IN `p_active` BOOLEAN, IN `p_with_out` BOOLEAN)
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        DECLARE v_error_msg TEXT;
        DECLARE v_user_name VARCHAR(255);
        DECLARE v_user_email VARCHAR(255);
        
        SELECT `full_name`, `email` INTO v_user_name, v_user_email
        FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NULL;
        
        IF NOT EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'حساب غير موجود';
        END IF;
        IF EXISTS (SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `is_active` = p_active) THEN
            SET v_error_msg = IF(p_active = TRUE, 'هذا الحساب مفعل بالفعل', 'هذا الحساب غير مفعل بالفعل');
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = v_error_msg;
        END IF;
        
        UPDATE `Users` SET `is_active` = p_active WHERE `user_id` = p_user_id;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            IF(p_active, 'activate_user', 'deactivate_user'),
            IF(p_active, 'تفعيل حساب', 'تعطيل حساب'),
            CONCAT('تم ', IF(p_active, 'تفعيل', 'تعطيل'), ' حساب المستخدم: ', v_user_name, ' (', v_user_email, ')')
        );
        
        -- إشعار للمستخدم نفسه
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_user_id,
            IF(p_active, 'activate_user', 'deactivate_user'),
            IF(p_active, 'تم تفعيل حسابك', 'تم تعطيل حسابك'),
            CONCAT('تم ', IF(p_active, 'تفعيل', 'تعطيل'), ' حسابك بتاريخ ', NOW(), '.')
        );
        
        IF p_with_out THEN SELECT p_user_id AS user_id; END IF;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_add_permission_to_role`(
        IN `p_role_name` VARCHAR(50), 
        IN `p_permission_name` VARCHAR(100)
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        IF NOT EXISTS (SELECT 1 FROM `Roles` WHERE `role_name` = p_role_name AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الدور غير موجود';
        END IF;
        IF NOT EXISTS (SELECT 1 FROM `Permissions` WHERE `permission_name` = p_permission_name AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الصلاحية غير موجودة';
        END IF;
        
        -- إدراج أو استعادة إذا كانت محذوفة
        INSERT INTO `Role_Permissions` (`role_name`, `permission_name`, `deleted_at`)
        VALUES (p_role_name, p_permission_name, NULL)
        ON DUPLICATE KEY UPDATE `deleted_at` = NULL;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'permission_added',
            'إضافة صلاحية لدور',
            CONCAT('تم إضافة الصلاحية "', p_permission_name, '" إلى دور "', p_role_name, '"')
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_remove_permission_from_role`(
        IN `p_role_name` VARCHAR(50), 
        IN `p_permission_name` VARCHAR(100)
    )
    DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER
    BEGIN
        UPDATE `Role_Permissions` 
        SET `deleted_at` = NOW()
        WHERE `role_name` = p_role_name AND `permission_name` = p_permission_name;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'permission_removed',
            'إزالة صلاحية من دور',
            CONCAT('تم إزالة الصلاحية "', p_permission_name, '" من دور "', p_role_name, '"')
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_task`(
        IN `p_event_id` INT,
        IN `p_service_id` INT,
        IN `p_type_task` VARCHAR(255),
        IN `p_status` VARCHAR(20),
        IN `p_date_start` DATE,
        IN `p_date_due` DATE,
        IN `p_user_assign_id` INT,
        IN `p_description` TEXT,
        IN `p_cost` DECIMAL(10,2),
        IN `p_notes` TEXT,
        IN `p_url_image` VARCHAR(255),
        IN `p_reminder_type` VARCHAR(20),
        IN `p_reminder_value` INT,
        IN `p_reminder_unit` VARCHAR(20),
        INOUT `p_task_assign_id` INT
    )
    BEGIN 
        DECLARE v_coordinator_id INT;
        DECLARE v_coordinator_name VARCHAR(255);
        DECLARE v_coordinator_phone VARCHAR(20);
        DECLARE v_coordinator_email VARCHAR(255);
        DECLARE v_event_name VARCHAR(255);
        DECLARE v_assign_name VARCHAR(255);
        DECLARE v_assign_email VARCHAR(255);

        DECLARE v_budget DECIMAL(10, 2);
        DECLARE v_total_expenses DECIMAL(10, 2);

        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

        -- الحصول على بيانات الحدث والمنسق
        SELECT `coordinator_id`, `coordinator_name`, `coordinator_phone`, `coordinator_email`, `event_name`,
                `budget`, `total_expenses`
            INTO v_coordinator_id, v_coordinator_name, v_coordinator_phone, v_coordinator_email, v_event_name,
                    v_budget, v_total_expenses 
        FROM `vw_events_detailed` 
        WHERE `event_id` = p_event_id AND `deleted_at` IS NULL;

        -- الحصول على بيانات المستخدم المكلف
        SELECT `full_name`, `email` INTO v_assign_name, v_assign_email 
        FROM `Users` WHERE `user_id` = p_user_assign_id AND `deleted_at` IS NULL;

        
        -- START TRANSACTION;

        -- التحقق من الصلاحيات
        IF p_user_assign_id IS NOT NULL AND NOT (fn_user_has_role(p_user_assign_id, 'coordinator') OR fn_user_has_role(p_user_assign_id, 'supplier')) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إسناد المهام إلا لموردين أو منسقين';
        END IF;
        IF v_coordinator_id IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحدث غير موجود أو لا يملك منسق';
        END IF;
        IF v_assign_email IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المستخدم المكلف غير موجود';
        END IF;

        -- إدراج المهمة
        INSERT INTO `Task_Assigns` (
            `event_id`, `service_id`, `coordinator_id`, `type_task`, `status`,
            `date_start`, `date_due`, `user_assign_id`, `description`,
            `cost`, `notes`, `url_image`, `reminder_type`, `reminder_value`, `reminder_unit` 
        ) VALUES (
            p_event_id, p_service_id, v_coordinator_id, p_type_task, IFNULL(p_status, 'PENDING'),
            p_date_start, p_date_due, IF(p_user_assign_id = v_coordinator_id, NULL, p_user_assign_id), p_description,
            p_cost, p_notes, p_url_image, p_reminder_type, p_reminder_value, p_reminder_unit
        );
        SET p_task_assign_id = LAST_INSERT_ID();

        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'create_task_assign', 
            'مهمة جديدة', 
            CONCAT(
                'لقد قام المنسق ', v_coordinator_name, ' "', v_coordinator_email, '" بإسناد مهمة جديدة ',
                IF(p_user_assign_id = v_coordinator_id, 'لنفسه\n', CONCAT('للمورد ', v_assign_name, ' "', v_assign_email, '"\n')),
                'في مناسبة ', v_event_name, '\n',
                'نوع المهمة: ', p_type_task, 
                IF(p_service_id IS NULL, '', 
                    CONCAT(' في خدمة "', (SELECT IFNULL( `service_name`, '') FROM `Services` WHERE `service_id` = p_service_id), '"')
                )
            )
        );

        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'create_task_assign', 
            'مهمة جديدة', 
            CONCAT(
                'لقد قمت بإسناد مهمة جديدة ',
                IF(p_user_assign_id = v_coordinator_id, 'لنفسك\n', CONCAT('للمورد ', v_assign_name, ' "', v_assign_email, '"\n')),
                'في مناسبة ', v_event_name, '\n',
                'نوع المهمة: ', p_type_task,
                IF(p_service_id IS NULL, '', 
                    CONCAT(' في خدمة "', (SELECT IFNULL( `service_name`, '') FROM `Services` WHERE `service_id` = p_service_id), '"')
                )
            )
        );

        -- إشعار للمكلف إذا لم يكن هو المنسق نفسه
        IF p_user_assign_id != v_coordinator_id THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) VALUES 
            (p_user_assign_id,
                'create_task_assign', 
                'مهمة جديدة', 
                CONCAT(
                    'تم تعيينك لمهمة جديدة من قبل المنسق ', v_coordinator_name, ' "', v_coordinator_email, '"\n',
                    'في مناسبة ', v_event_name, '\n',
                    'نوع المهمة: ', p_type_task,
                    IF(p_service_id IS NULL, '', 
                    CONCAT(' في خدمة "', (SELECT IFNULL( `service_name`, '') FROM `Services` WHERE `service_id` = p_service_id), '"')
                )
                )
            );
        END IF;

         -- إشعار للمكلف إذا لم يكن هو المنسق نفسه
        IF v_total_expenses + p_cost > v_budget THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) VALUES 
            (v_coordinator_id,
                'alert', 
                'ميزانية تجاوزت الحد', 
                CONCAT(
                    'تجاوزت مصروفات ', v_event_name, ' الميزانية المحددة'
                )
            );
        END IF;

        -- COMMIT;
    END$$

CREATE PROCEDURE `sp_create_task_from_json`(
        IN `p_event_id` INT,
        IN `p_task_json` JSON,
        INOUT `p_task_assign_id` INT
    )
    BEGIN 
        CALL sp_create_task(
            p_event_id, 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.service_id')),
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.type_task')),
            IFNULL(JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.status')), 'PENDING'),
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.date_start')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.date_due')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.user_assign_id')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.description')),
            IFNULL(JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.cost')), 0), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.notes')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.url_image')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.reminder_type')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.reminder_value')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_task_json, '$.reminder_unit')),
            p_task_assign_id
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_income`(
        IN `p_event_id` INT,
        IN `p_amount` DECIMAL(10,2),
        IN `p_description` TEXT,
        IN `p_payment_date` DATE,
        IN `p_payment_method` VARCHAR(50) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        IN `p_url_image` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        IN `with_out` BOOLEAN
    )
    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;

        INSERT INTO `Incomes` (`event_id`, `amount`, `description`, `payment_date`, `payment_method`, `url_image`)
            VALUES (p_event_id, p_amount, p_description, p_payment_date, p_payment_method, p_url_image);
        IF with_out = TRUE THEN
            SELECT * FROM `Incomes` WHERE `income_id` = LAST_INSERT_ID();
        END IF;
        
    END$$

CREATE PROCEDURE `sp_create_income_from_json`(
        IN `p_event_id` INT,
        IN `p_income_json` JSON
    )
    BEGIN
        CALL sp_create_income(
            p_event_id, 
            JSON_UNQUOTE(JSON_EXTRACT(p_income_json, '$.amount')),
            JSON_UNQUOTE(JSON_EXTRACT(p_income_json, '$.description')),
            JSON_UNQUOTE(JSON_EXTRACT(p_income_json, '$.payment_date')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_income_json, '$.payment_method')), 
            JSON_UNQUOTE(JSON_EXTRACT(p_income_json, '$.url_image')), 
            FALSE
        );
       
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_event`(
        IN `p_client_id` INT,
        IN `p_coordinator_id` INT,
        IN `p_event_name` VARCHAR(255),
        IN `p_description` TEXT,
        IN `p_img_url` TEXT,
        IN `p_event_date` DATE,
        IN `p_location` VARCHAR(255),
        IN `p_budget` DECIMAL(10,2),
        IN `p_event_duration` INT,
        IN `p_event_duration_unit` ENUM('DAY', 'WEEK', 'MONTH')
    )
    BEGIN
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        -- التحقق من وجود العميل والمنسق
        IF NOT EXISTS (SELECT 1 FROM `Clients` WHERE `client_id` = p_client_id AND `deleted_at` IS NULL) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'العميل غير موجود';
        END IF;
        IF NOT fn_user_has_role(p_coordinator_id, 'coordinator') THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب أن يكون المنسق من دور coordinator';
        END IF;
        
        
        -- START TRANSACTION;
        
        INSERT INTO `Events` (
            `client_id`, `coordinator_id`, `event_name`, `description`, `img_url`, 
            `event_date`, `location`, `budget`, `event_duration`, `event_duration_unit`
        ) VALUES (
            p_client_id, p_coordinator_id, p_event_name, p_description, p_img_url,
            p_event_date, p_location, p_budget, p_event_duration, p_event_duration_unit
        );
        
        
        -- COMMIT;
    END$$

CREATE PROCEDURE `sp_create_event_full`(
        IN `p_client_id` INT,
        IN `p_coordinator_id` INT,
        IN `p_event_name` VARCHAR(255),
        IN `p_description` TEXT,
        IN `p_img_url` TEXT,
        IN `p_event_date` DATE,
        IN `p_location` VARCHAR(255),
        IN `p_budget` DECIMAL(10,2),
        IN `p_event_duration` INT,
        IN `p_event_duration_unit` ENUM('DAY', 'WEEK', 'MONTH'),
        IN `p_options` JSON
    )
    BEGIN
        DECLARE v_event_id INT;
        DECLARE v_counter INT DEFAULT 0;
        DECLARE v_total INT;
        DECLARE v_tasks_json JSON;
        DECLARE v_incomes_json JSON;
        DECLARE v_val_js JSON;
        DECLARE v_last_task_assign_id INT;
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        IF p_options IS NOT NULL AND JSON_VALID(p_options) THEN
            SET v_tasks_json = JSON_EXTRACT(p_options, '$.tasks');
            SET v_incomes_json = JSON_EXTRACT(p_options, '$.incomes');
        END IF;
        
        

        START TRANSACTION;
        
        CALL sp_create_event(p_client_id, p_coordinator_id, p_event_name, 
            p_description, p_img_url, p_event_date, p_location, p_budget, 
            p_event_duration, p_event_duration_unit);
            SET v_event_id = LAST_INSERT_ID();
        
        IF v_tasks_json IS NOT NULL AND JSON_VALID(v_tasks_json) THEN
            SET v_total = JSON_LENGTH(v_tasks_json);
            WHILE v_counter < v_total DO
                SET v_val_js = JSON_EXTRACT(v_tasks_json, CONCAT('$[', v_counter, ']'));
                CALL sp_create_task_from_json(v_event_id, v_val_js, v_last_task_assign_id);
                SET v_counter = v_counter + 1;
            END WHILE;
        END IF;
        
        IF v_incomes_json IS NOT NULL AND JSON_VALID(v_incomes_json) THEN
            SET v_counter = 0;
            SET v_total = JSON_LENGTH(v_incomes_json);
            WHILE v_counter < v_total DO
                SET v_val_js = JSON_EXTRACT(v_incomes_json, CONCAT('$[', v_counter, ']'));
                CALL sp_create_income_from_json(v_event_id, v_val_js);
                SET v_counter = v_counter + 1;
            END WHILE;
        END IF;
        
        COMMIT;
        
        SELECT * FROM `vw_events_detailed` WHERE `event_id` = v_event_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_task_status`(
        IN `p_user_update_id` INT,
        IN `p_task_assign_id` INT,
        IN `p_new_status` ENUM('PENDING','IN_PROGRESS','UNDER_REVIEW','COMPLETED','CANCELLED'),
        IN `p_notes` TEXT,
        IN `p_url_image` TEXT
    )
    BEGIN
        DECLARE v_old_status VARCHAR(20);
        DECLARE v_event_id INT;
        DECLARE v_coordinator_id INT;
        DECLARE v_user_assign_id INT;
        DECLARE v_event_name VARCHAR(255);
        DECLARE v_user_name VARCHAR(255);
        
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        -- جلب البيانات الحالية للمهمة
        SELECT `status`, `event_id`, `coordinator_id`, `user_assign_id`
        INTO v_old_status, v_event_id, v_coordinator_id, v_user_assign_id
        FROM `Task_Assigns` 
        WHERE `task_assign_id` = p_task_assign_id AND `deleted_at` IS NULL;
        
        IF v_old_status IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المهمة غير موجودة';
        END IF;
        
        -- جلب اسم الحدث
        SELECT `event_name` INTO v_event_name FROM `Events` WHERE `event_id` = v_event_id;
        
        -- جلب اسم المستخدم الذي يقوم بالتحديث
        SELECT `full_name` INTO v_user_name FROM `Users` WHERE `user_id` = p_user_update_id;
        
        -- التحقق من صلاحية المستخدم
        IF p_user_update_id = v_coordinator_id THEN
            -- المنسق يمكنه تحديث الحالة فقط إذا كان المكلف هو نفسه (أي المهمة خاصة به)
            IF v_user_assign_id != v_coordinator_id AND v_old_status != 'UNDER_REVIEW' AND p_new_status != 'COMPLETED' THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن للمنسق تحديث حالة مهمة مكلف بها مورد';
            END IF;
            -- لا يمكن تغيير حالة مكتملة أو ملغية
            IF v_old_status IN ('COMPLETED', 'CANCELLED') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تغيير حالة مهمة مكتملة أو ملغية';
            END IF;
        ELSEIF p_user_update_id = v_user_assign_id THEN
            -- المكلف يمكنه تغيير الحالة وفق تسلسل معين
            IF v_old_status = 'PENDING' AND p_new_status != 'IN_PROGRESS' THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تغيير الحالة من PENDING إلى IN_PROGRESS';
            ELSEIF v_old_status = 'IN_PROGRESS' AND p_new_status NOT IN ('UNDER_REVIEW', 'COMPLETED') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تغيير الحالة من IN_PROGRESS إلى UNDER_REVIEW أو COMPLETED';
            ELSEIF v_old_status = 'UNDER_REVIEW' AND p_new_status NOT IN ('IN_PROGRESS', 'COMPLETED') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تغيير الحالة من UNDER_REVIEW إلى IN_PROGRESS أو COMPLETED';
            ELSEIF v_old_status IN ('COMPLETED', 'CANCELLED') THEN
                SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تغيير حالة مهمة مكتملة أو ملغية';
            END IF;
        ELSE
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية لتحديث حالة هذه المهمة';
        END IF;
        
        -- إذا لم يتغير الحالة فلا داعي للمتابعة
        IF v_old_status = p_new_status THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'الحالة الجديدة هي نفس الحالة القديمة';
        END IF;
        
        START TRANSACTION;
        
        -- تحديث المهمة
        UPDATE `Task_Assigns`
        SET `status` = p_new_status,
            `notes` = IF(p_notes IS NOT NULL, CONCAT(IFNULL(`notes`, ''), '\n', p_notes), `notes`),
            `date_completion` = IF(p_new_status = 'COMPLETED', NOW(), `date_completion`),
            `updated_at` = NOW(),
            `url_image` = IFNULL(p_url_image, `url_image`)
        WHERE `task_assign_id` = p_task_assign_id;
        
        -- ============================================================
        -- إشعارات عند تغيير الحالة (لجميع الحالات)
        -- ============================================================
        
        -- نص وصفي لتغيير الحالة
        SET @status_ar = CASE p_new_status
            WHEN 'PENDING' THEN 'معلقة'
            WHEN 'IN_PROGRESS' THEN 'قيد التنفيذ'
            WHEN 'UNDER_REVIEW' THEN 'قيد المراجعة'
            WHEN 'COMPLETED' THEN 'مكتملة'
            WHEN 'CANCELLED' THEN 'ملغية'
        END;
        
        SET @old_status_ar = CASE v_old_status
            WHEN 'PENDING' THEN 'معلقة'
            WHEN 'IN_PROGRESS' THEN 'قيد التنفيذ'
            WHEN 'UNDER_REVIEW' THEN 'قيد المراجعة'
            WHEN 'COMPLETED' THEN 'مكتملة'
            WHEN 'CANCELLED' THEN 'ملغية'
        END;
        
        SET @message_text = CONCAT(
            'تم تغيير حالة المهمة رقم ', p_task_assign_id, 
            ' في الحدث "', v_event_name, '" من "', @old_status_ar, '" إلى "', @status_ar, '"',
            IF(p_notes IS NOT NULL, CONCAT('\nملاحظات: ', p_notes), ''),
            IF(p_url_image IS NOT NULL, '\nتم إضافة صورة جديدة للمهمة.', '')
        );
        
        -- 1. إشعار للمستخدم الذي قام بالتحديث (نفسه)
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
        VALUES (p_user_update_id, 
                CONCAT('TASK_STATUS_', p_new_status),
                CONCAT('تحديث حالة مهمة #', p_task_assign_id),
                CONCAT('لقد قمت بتغيير حالة المهمة إلى "', @status_ar, '".\n', @message_text));
        
        -- 2. إشعار للمنسق (إذا لم يكن هو من قام بالتحديث)
        IF v_coordinator_id != p_user_update_id THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
            VALUES (v_coordinator_id, 
                    CONCAT('TASK_STATUS_', p_new_status),
                    CONCAT('تحديث حالة مهمة #', p_task_assign_id),
                    CONCAT('قام ', v_user_name, ' بتغيير حالة المهمة إلى "', @status_ar, '".\n', @message_text));
        END IF;
        
        -- 3. إشعار للمكلف (إذا كان موجوداً ولم يقم هو بالتحديث)
        IF v_user_assign_id IS NOT NULL AND v_user_assign_id != p_user_update_id THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
            VALUES (v_user_assign_id, 
                    CONCAT('TASK_STATUS_', p_new_status),
                    CONCAT('تحديث حالة مهمة #', p_task_assign_id),
                    CONCAT('تم تغيير حالة مهمتك إلى "', @status_ar, '" بواسطة ', v_user_name, '.\n', @message_text));
        END IF;
        
        -- 4. إشعار للمدير (user_id = 1) دائماً
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
        VALUES (1, 
                CONCAT('TASK_STATUS_', p_new_status),
                CONCAT('تحديث حالة مهمة #', p_task_assign_id),
                CONCAT('قام ', v_user_name, ' (رقم ', p_user_update_id, ') بتغيير حالة المهمة رقم ', p_task_assign_id, 
                       ' في الحدث "', v_event_name, '" من "', @old_status_ar, '" إلى "', @status_ar, '"'));
        
        -- إشعارات خاصة عند الإكمال أو الإلغاء (بالإضافة إلى الإشعارات أعلاه)
        IF p_new_status IN ('COMPLETED', 'CANCELLED') THEN
            SET @status_text = IF(p_new_status = 'COMPLETED', 'إكمال', 'إلغاء');
            
            -- إشعار إضافي للمنسق (بنص مختلف)
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
            VALUES (v_coordinator_id, 
                    CONCAT('TASK_', p_new_status),
                    CONCAT('تم ', @status_text, ' مهمة'),
                    CONCAT('المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '" قد ', IF(p_new_status='COMPLETED', 'اكتملت', 'ألغيت'), '.'));
            
            -- إشعار إضافي للمكلف إذا لم يكن هو المنسق
            IF v_user_assign_id IS NOT NULL AND v_user_assign_id != v_coordinator_id THEN
                INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
                VALUES (v_user_assign_id, 
                        CONCAT('TASK_', p_new_status),
                        CONCAT('تم ', @status_text, ' مهمة'),
                        CONCAT('المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '" قد ', IF(p_new_status='COMPLETED', 'اكتملت', 'ألغيت'), '.'));
            END IF;
        END IF;
        
        COMMIT;
    END$$

DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_add_task_rating`(
        IN `p_task_assign_id` INT,
        IN `p_coordinator_id` INT,
        IN `p_rating_value` INT,
        IN `p_comment` TEXT
    )
    BEGIN
        DECLARE v_event_id INT;
        DECLARE v_assigned_user_id INT;
        DECLARE v_task_status VARCHAR(20);
        
        -- الحصول على بيانات المهمة
        SELECT ta.`event_id`, ta.`user_assign_id`, ta.`status`
        INTO v_event_id, v_assigned_user_id, v_task_status
        FROM `Task_Assigns` ta
        WHERE ta.`task_assign_id` = p_task_assign_id
        AND ta.`deleted_at` IS NULL;
        
        IF v_task_status IS NULL THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المهمة غير موجودة';
        END IF;
        
        IF v_task_status != 'COMPLETED' THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تقييم مهمة غير مكتملة';
        END IF;
        
        -- التحقق من أن المنسق هو منسق الحدث
        IF NOT EXISTS (
            SELECT 1 FROM `Events` e
            WHERE e.`event_id` = v_event_id 
            AND e.`coordinator_id` = p_coordinator_id
            AND e.`deleted_at` IS NULL
        ) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية تقييم هذه المهمة';
        END IF;
        
        -- إدراج التقييم
        INSERT INTO `Ratings_Task_Assign` (`task_assign_id`, `coordinator_id`, `rating_value`, `rating_comment`)
        VALUES (p_task_assign_id, p_coordinator_id, p_rating_value, p_comment);
        
        -- إشعار للمكلف
        IF v_assigned_user_id IS NOT NULL THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`)
            VALUES (
                v_assigned_user_id,
                'NEW_RATING',
                'تقييم جديد',
                CONCAT('تم تقييم مهمتك بـ ', p_rating_value, ' نجوم.')
            );
        END IF;
    END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE `sp_change_password`(
        IN `p_user_id` INT,
        IN `p_old_password` VARCHAR(255),
        IN `p_new_password` VARCHAR(255)
    )
    BEGIN
        IF EXISTS(
            SELECT 1 FROM `Users` WHERE `user_id` = p_user_id AND `password` = p_old_password
        ) THEN
            UPDATE `Users` SET `password` = p_new_password, `updated_at` = NOW()
                WHERE `user_id` = p_user_id;
                
            -- إشعار للمستخدم
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
            VALUES (p_user_id,
                'change_password',
                'تغيير كلمة المرور',
                CONCAT('تم تغيير كلمة المرور الخاصة بحسابك بتاريخ ', NOW())
            );
            
            -- إشعار للمدير (اختياري، يمكن إضافته)
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
            VALUES (1,
                'change_password',
                'تغيير كلمة مرور',
                CONCAT('قام المستخدم رقم ', p_user_id, ' بتغيير كلمة المرور الخاصة به')
            );

            CALL sp_get_user_by_id(p_user_id);
        ELSE
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'كلمة المرور القديمة غير صحيحة.';
        END IF;
    END$$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE `sp_update_event`(
        IN `p_event_id` INT,
        IN `p_event_name` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        IN `p_description` TEXT,
        IN `p_img_url` TEXT,
        IN `p_event_date` DATE,
        IN `p_location` VARCHAR(255) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        IN `p_budget` DECIMAL(10,2),
        IN `p_event_duration` INT,
        IN `p_event_duration_unit` ENUM('DAY', 'WEEK', 'MONTH')
    )
    BEGIN
        DECLARE v_coordinator_id INT;
        DECLARE v_old_name VARCHAR(255);
        
        SELECT `coordinator_id`, `event_name` INTO v_coordinator_id, v_old_name
        FROM `Events` WHERE `event_id` = p_event_id;

        UPDATE `Events`
            SET `event_name` = IFNULL(p_event_name, `event_name`),
                `description` = IFNULL(p_description, `description`),
                `event_date` = IFNULL(p_event_date, `event_date`),
                `location` = IFNULL(p_location, `location`),
                `budget` = IFNULL(p_budget, `budget`),
                `event_duration` = IFNULL(p_event_duration, `event_duration`),
                `event_duration_unit` = IFNULL(p_event_duration_unit, `event_duration_unit`),
                `img_url` = IFNULL(p_img_url, `img_url`),
                `updated_at` = NOW()
            WHERE `event_id` = p_event_id;
        
         -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'update_event',
            'تحديث حدث',
            CONCAT('تم تحديث بيانات الحدث "', IFNULL(p_event_name, v_old_name), '" (رقم ', p_event_id, ')')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_event',
            'تحديث حدث',
            CONCAT('تم تحديث بيانات الحدث "', IFNULL(p_event_name, v_old_name), '" (رقم ', p_event_id, ') بواسطة المنسق رقم ', v_coordinator_id)
        );
        SELECT * FROM `Events` WHERE `event_id` = p_event_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_event`(IN `p_event_id` INT)
    BEGIN
        DECLARE v_coordinator_id INT;
        DECLARE v_event_name VARCHAR(255);
        
        SELECT `coordinator_id`, `event_name` INTO v_coordinator_id, v_event_name
        FROM `Events` WHERE `event_id` = p_event_id;
        
        UPDATE `Events` SET `deleted_at` = NOW() WHERE `event_id` = p_event_id;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'delete_event',
            'حذف حدث',
            CONCAT('تم حذف الحدث "', v_event_name, '" (رقم ', p_event_id, ')')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_event',
            'حذف حدث',
            CONCAT('تم حذف الحدث "', v_event_name, '" (رقم ', p_event_id, ') بواسطة المنسق رقم ', v_coordinator_id)
        );
        
        SELECT p_event_id AS event_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_create_service`(
        IN `p_user_creator_email` VARCHAR(255),
        IN `p_user_creator_pass` VARCHAR(255),
        IN `p_service_name` VARCHAR(100) CHARSET utf8mb4 COLLATE utf8mb4_general_ci,
        IN `p_description` TEXT,
        IN `p_with_out` BOOLEAN
    ) DETERMINISTIC MODIFIES SQL DATA SQL SECURITY DEFINER 
    BEGIN 
        DECLARE v_service_id INT;
        DECLARE EXIT HANDLER FOR SQLEXCEPTION BEGIN ROLLBACK; RESIGNAL; END;
        
        -- التحقق من صلاحية المدير
        CALL sp_throw_if_account_not_admin(p_user_creator_email, p_user_creator_pass, 'admin');
        
        START TRANSACTION;

        INSERT INTO `Services` (`service_name`, `description`) 
            VALUES (p_service_name, p_description);
        SET v_service_id = LAST_INSERT_ID();
        

        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'create_service', 
            'خدمة جديدة', 
            CONCAT(
                'لقد قام المدير "', p_user_creator_email, '" بإضافة خدمة جديدة\n' , 
                'رقم الخدمة: ', v_service_id, '\n',
                'إسم الخدمة: ', p_service_name, '\n',
                'الوصف: ', p_description
            )
        );

        IF p_with_out IS NULL OR p_with_out = TRUE THEN
            SELECT * FROM `Services` WHERE `service_id` = v_service_id;
        END IF;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_service`(
        IN `p_service_id` INT,
        IN `p_service_name` VARCHAR(100),
        IN `p_description` TEXT
    )
    BEGIN
        DECLARE v_old_name VARCHAR(100);
        SELECT `service_name` INTO v_old_name FROM `Services` WHERE `service_id` = p_service_id;
        
        UPDATE `Services`
            SET `service_name` = IFNULL(p_service_name, `service_name`),
                `description` = IFNULL(p_description, `description`),
                `updated_at` = NOW()
            WHERE `service_id` = p_service_id;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_service',
            'تحديث خدمة',
            CONCAT('تم تحديث بيانات الخدمة "', IFNULL(p_service_name, v_old_name), '" (رقم ', p_service_id, ')')
        );
        
        SELECT * FROM `Services` WHERE `service_id` = p_service_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_service`(IN `p_service_id` INT)
    BEGIN
        DECLARE v_service_name VARCHAR(100);
        SELECT `service_name` INTO v_service_name FROM `Services` WHERE `service_id` = p_service_id;
        
        UPDATE `Services` SET `deleted_at` = CURRENT_TIMESTAMP WHERE `service_id` = p_service_id;
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_service',
            'حذف خدمة',
            CONCAT('تم حذف الخدمة "', v_service_name, '" (رقم ', p_service_id, ')')
        );
        
        SELECT p_service_id AS service_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_income`(
        IN `p_income_id` INT,
        IN `p_amount` DECIMAL(10,2),
        IN `p_description` TEXT,
        IN `p_payment_date` DATE,
        IN `p_payment_method` VARCHAR(50),
        IN `p_url_image` VARCHAR(255)
    )
    BEGIN
        DECLARE v_event_id INT;
        DECLARE v_coordinator_id INT;
        DECLARE v_event_name VARCHAR(255);
        
        SELECT e.`event_id`, e.`coordinator_id`, e.`event_name` 
        INTO v_event_id, v_coordinator_id, v_event_name
        FROM `Incomes` i JOIN `Events` e ON i.`event_id` = e.`event_id`
        WHERE i.`income_id` = p_income_id;
        
        UPDATE `Incomes`
            SET `amount` = IFNULL(p_amount, `amount`),
                `description` = IFNULL(p_description, `description`),
                `payment_date` = IFNULL(p_payment_date, `payment_date`),
                `payment_method` = IFNULL(p_payment_method, `payment_method`),
                `url_image` = IFNULL(p_url_image, `url_image`),
                `updated_at` = NOW()
            WHERE `income_id` = p_income_id;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'update_income',
            'تحديث دفعة',
            CONCAT('تم تحديث بيانات الدفعة رقم ', p_income_id, ' للحدث "', v_event_name, '"')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_income',
            'تحديث دفعة',
            CONCAT('تم تحديث بيانات الدفعة رقم ', p_income_id, ' للحدث "', v_event_name, '" بواسطة المنسق ', v_coordinator_id)
        );
        
        SELECT * FROM `Incomes` WHERE `income_id` = p_income_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_income`(IN `p_income_id` INT)
    BEGIN
        DECLARE v_event_id INT;
        DECLARE v_coordinator_id INT;
        DECLARE v_event_name VARCHAR(255);
        
        SELECT e.`event_id`, e.`coordinator_id`, e.`event_name` 
        INTO v_event_id, v_coordinator_id, v_event_name
        FROM `Incomes` i JOIN `Events` e ON i.`event_id` = e.`event_id`
        WHERE i.`income_id` = p_income_id;
        
        UPDATE `Incomes` SET `deleted_at` = CURRENT_TIMESTAMP WHERE `income_id` = p_income_id;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'delete_income',
            'حذف دفعة',
            CONCAT('تم حذف الدفعة رقم ', p_income_id, ' للحدث "', v_event_name, '"')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_income',
            'حذف دفعة',
            CONCAT('تم حذف الدفعة رقم ', p_income_id, ' للحدث "', v_event_name, '" بواسطة المنسق ', v_coordinator_id)
        );
        
        SELECT p_income_id AS income_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_update_task`( 
    IN `p_task_assign_id` INT,
    IN `p_type_task` VARCHAR(255),
    IN `p_status` ENUM('PENDING', 'IN_PROGRESS', 'UNDER_REVIEW', 'COMPLETED', 'CANCELLED'),
    IN `p_date_start` DATE,
    IN `p_date_due` DATE,
    IN `p_description` TEXT,
    IN `p_cost` DECIMAL(10,2),
    IN `p_notes` TEXT,
    IN `p_url_image` VARCHAR(255)
    )
    BEGIN
        DECLARE v_user_assign_id INT;
        DECLARE v_coordinator_id INT;
        DECLARE v_event_id INT;
        DECLARE v_event_name VARCHAR(255);
        
        SELECT `user_assign_id`, `coordinator_id`, `event_id` 
        INTO v_user_assign_id, v_coordinator_id, v_event_id
        FROM `Task_Assigns` WHERE `task_assign_id` = p_task_assign_id;
        
        SELECT `event_name` INTO v_event_name FROM `Events` WHERE `event_id` = v_event_id;
        
        START TRANSACTION;
        
        UPDATE `Task_Assigns`
            `task_assign_id` = `task_assign_id`,
            SET `type_task` = IFNULL(p_type_task, `type_task`),
                `status` = IFNULL(p_status, `status`),
                `date_start` = IFNULL(p_date_start, `date_start`),
                `date_due` = IFNULL(p_date_due, `date_due`),
                `description` = IFNULL(p_description, `description`),
                `cost` = IFNULL(p_cost, `cost`),
                `notes` = IFNULL(p_notes, `notes`),
                `url_image` = IFNULL(p_url_image, `url_image`),
                `updated_at` = NOW()
            WHERE `task_assign_id` = p_task_assign_id;
            
        -- إشعار للمكلف
        IF v_user_assign_id IS NOT NULL THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
            VALUES (v_user_assign_id,
                'update_task',
                'تحديث مهمة',
                CONCAT('تم تحديث بيانات المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '"')
            );
        END IF;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'update_task',
            'تحديث مهمة',
            CONCAT('تم تحديث بيانات المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '"')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'update_task',
            'تحديث مهمة',
            CONCAT('تم تحديث بيانات المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '" بواسطة المنسق ', v_coordinator_id)
        );
            
        COMMIT;
        
        SELECT * FROM `vw_tasks_full` WHERE `task_assign_id` = p_task_assign_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_delete_task`(IN `p_task_assign_id` INT)
    BEGIN
        DECLARE v_user_assign_id INT;
        DECLARE v_coordinator_id INT;
        DECLARE v_event_name VARCHAR(255);
        
        SELECT ta.`user_assign_id`, ta.`coordinator_id`, e.`event_name`
        INTO v_user_assign_id, v_coordinator_id, v_event_name
        FROM `Task_Assigns` ta JOIN `Events` e ON ta.`event_id` = e.`event_id`
        WHERE ta.`task_assign_id` = p_task_assign_id;
        
        UPDATE `Task_Assigns` SET `deleted_at` = CURRENT_TIMESTAMP WHERE `task_assign_id` = p_task_assign_id;
        
        -- إشعار للمكلف
        IF v_user_assign_id IS NOT NULL THEN
            INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
            VALUES (v_user_assign_id,
                'delete_task',
                'حذف مهمة',
                CONCAT('تم حذف المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '"')
            );
        END IF;
        
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (v_coordinator_id,
            'delete_task',
            'حذف مهمة',
            CONCAT('تم حذف المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '"')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'delete_task',
            'حذف مهمة',
            CONCAT('تم حذف المهمة رقم ', p_task_assign_id, ' في الحدث "', v_event_name, '" بواسطة المنسق ', v_coordinator_id)
        );
        
        SELECT p_task_assign_id AS task_assign_id;
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_assign_service_to_supplier`(
        IN `p_supplier_id` INT,
        IN `p_service_id` INT
    )
    BEGIN
        DECLARE v_supplier_name VARCHAR(255);
        DECLARE v_service_name VARCHAR(100);
        
        SELECT `full_name` INTO v_supplier_name FROM `Users` WHERE `user_id` = p_supplier_id;
        SELECT `service_name` INTO v_service_name FROM `Services` WHERE `service_id` = p_service_id;
        
        INSERT IGNORE INTO `Supplier_Services` (`supplier_id`, `service_id`)
        VALUES (p_supplier_id, p_service_id);
        
        -- إشعار للمورد
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_supplier_id,
            'assign_service',
            'إسناد خدمة',
            CONCAT('تم إسناد الخدمة "', v_service_name, '" إليك')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'assign_service',
            'إسناد خدمة لمورد',
            CONCAT('تم إسناد الخدمة "', v_service_name, '" إلى المورد "', v_supplier_name, '" (رقم ', p_supplier_id, ')')
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_remove_service_from_supplier`(
    IN `p_supplier_id` INT,
    IN `p_service_id` INT
    )
    BEGIN
        DECLARE v_supplier_name VARCHAR(255);
        DECLARE v_service_name VARCHAR(100);
        
        SELECT `full_name` INTO v_supplier_name FROM `Users` WHERE `user_id` = p_supplier_id;
        SELECT `service_name` INTO v_service_name FROM `Services` WHERE `service_id` = p_service_id;
        
        UPDATE `Supplier_Services` SET `deleted_at` = CURRENT_TIMESTAMP 
        WHERE `supplier_id` = p_supplier_id AND `service_id` = p_service_id;
        
        -- إشعار للمورد
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (p_supplier_id,
            'remove_service',
            'إزالة خدمة',
            CONCAT('تم إزالة الخدمة "', v_service_name, '" من خدماتك')
        );
        
        -- إشعار للمدير
        INSERT INTO `Notifications` (`user_id`, `type`, `title`, `message`) 
        VALUES (1,
            'remove_service',
            'إزالة خدمة من مورد',
            CONCAT('تم إزالة الخدمة "', v_service_name, '" من المورد "', v_supplier_name, '" (رقم ', p_supplier_id, ')')
        );
    END$$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_events_detailed` (
        IN `p_coordinator_id` INT
    )
    BEGIN 
        SELECT 
            e.*,
            (e.`deleted_at` IS NOT NULL) AS `is_deleted`,
            fn_event_get_status(e.`event_id`) AS `status`,
            c.`full_name` AS `client_name`,
            c.`phone_number` AS `client_phone`,
            c.`phone_number` AS `client_email`,

            co.`full_name` AS `coordinator_name`,
            co.`phone_number` AS `coordinator_phone`,
            co.`email` AS `coordinator_email`,

            COALESCE((SELECT SUM(inc.`amount`) FROM `Incomes` inc WHERE inc.`event_id` = e.`event_id` AND inc.`deleted_at` IS NULL), 0) AS `total_income`,
            COALESCE((SELECT SUM(ta.`cost`) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`deleted_at` IS NULL), 0) AS `total_expenses`,
            (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`coordinator_id` = p_coordinator_id AND ta.`deleted_at` IS NULL) AS `total_tasks`,
            (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`coordinator_id` = p_coordinator_id AND ta.`status` = 'COMPLETED' AND ta.`deleted_at` IS NULL) AS `completed_tasks`,
            CONCAT(
                ROUND(
                    100 * (SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`status` = 'COMPLETED' AND ta.`deleted_at` IS NULL) 
                    / NULLIF((SELECT COUNT(*) FROM `Task_Assigns` ta WHERE ta.`event_id` = e.`event_id` AND ta.`deleted_at` IS NULL), 0), 
                2), '%'
            ) AS `completion_percentage`
        FROM `Events` e
        LEFT JOIN `Users` co ON e.`coordinator_id` = co.`user_id`
        LEFT JOIN `Clients` c ON e.`client_id` = c.`client_id`
        WHERE e.`coordinator_id` = p_coordinator_id AND c.`coordinator_id` = p_coordinator_id;
    END $$
DELIMITER ;

DELIMITER $$
CREATE PROCEDURE `sp_home_stats_coordinator`(
    IN `p_coordinator_id` INT
    )
    BEGIN
        
        SELECT
            (SELECT COUNT(*) FROM `Events` WHERE `deleted_at` IS NULL AND `coordinator_id` = p_coordinator_id) AS total_events,
            (SELECT COUNT(*) FROM `Events` WHERE fn_event_status_is('PENDING', `event_id`) AND `deleted_at` IS NULL AND `coordinator_id` = p_coordinator_id) AS pending_events,
            (SELECT COUNT(*) FROM `Events` WHERE fn_event_status_is('IN_PROGRESS', `event_id`) AND `deleted_at` IS NULL AND `coordinator_id` = p_coordinator_id) AS in_progress_events,
            (SELECT COUNT(*) FROM `Events` WHERE fn_event_status_is('COMLETED', `event_id`) AND `deleted_at` IS NULL AND `coordinator_id` = p_coordinator_id) AS completed_events,
            (SELECT COUNT(*) FROM `Events` WHERE `deleted_at` IS NOT NULL AND `coordinator_id` = p_coordinator_id) AS cancelled_events,

            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `coordinator_id` = p_coordinator_id) AS total_tasks,
            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `status` = 'PENDING'  AND `coordinator_id` = p_coordinator_id) AS pending_tasks,
            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `status` = 'IN_PROGRESS' AND `coordinator_id` = p_coordinator_id) AS in_progress_tasks,
            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `status` = 'COMPLETED'  AND `coordinator_id` = p_coordinator_id) AS completed_tasks,
            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `status` = 'UNDER_REVIEW'  AND `coordinator_id` = p_coordinator_id) AS under_review_tasks,
            (SELECT COUNT(*) FROM `Task_Assigns` WHERE `status` = 'CANCELLED'  AND `coordinator_id` = p_coordinator_id) AS cancelled_tasks,

            (SELECT COUNT(*) FROM `Clients` WHERE  `deleted_at` IS NULL AND `coordinator_id` = p_coordinator_id) AS total_clients
            -- (SELECT COUNT(*) FROM `Users` WHERE `role_name` = 'supplier' AND `deleted_at` IS NULL) AS total_suppliers
            ;
            
    END$$

CREATE PROCEDURE  `sp_report_stats`(
        IN `p_coordinator_id` INT
    ) 
    BEGIN
        SELECT
            (SELECT COUNT(*) FROM `Events` WHERE 
                NOT fn_event_status_is('COMLETED', `event_id`) AND 
                `deleted_at` IS NULL AND 
                `coordinator_id` = p_coordinator_id
            ) AS active_events,
            (SELECT IFNULL(SUM(inc.`amount`), 0) FROM `Incomes` inc JOIN `Events` e ON inc.`event_id` = e.`event_id` WHERE e.`coordinator_id` = p_coordinator_id) AS total_revenue,
            (SELECT IFNULL(SUM(`cost`), 0) FROM `Task_Assigns` WHERE `coordinator_id` = p_coordinator_id) AS total_expenses;
    END $$

CREATE PROCEDURE `sp_monthly_income`(
        IN `p_coordinator_id` INT,
        IN `p_limit` INT
    )
    BEGIN
        SET p_limit = IFNULL(p_limit, 12);
        SELECT
            DATE_FORMAT(inc.`payment_date`, '%Y-%m') AS `month`,
            SUM(inc.`amount`) AS total_income
            FROM `Incomes` inc JOIN `Events` e ON inc.`event_id` = e.`event_id` WHERE e.`coordinator_id` = p_coordinator_id 
            GROUP BY DATE_FORMAT(inc.`payment_date`, '%Y-%m')
            ORDER BY month DESC
        LIMIT p_limit;
    END $$
DELIMITER ;


DELIMITER $$
CREATE PROCEDURE `sp_generate_task_reminders`()
    READS SQL DATA
    MODIFIES SQL DATA
    COMMENT 'يقوم بإنشاء تذكيرات للمهام بناءً على إعدادات التذكير في جدول Task_Assigns'
    BEGIN
        DECLARE v_task_assign_id INT;
        DECLARE v_user_assign_id INT;
        DECLARE v_event_id INT;
        DECLARE v_event_name VARCHAR(255);
        DECLARE v_date_due DATE;
        DECLARE v_reminder_type ENUM('INTERVAL', 'BEFORE_DUE');
        DECLARE v_reminder_value INT;
        DECLARE v_reminder_unit ENUM('MINUTE', 'HOUR', 'DAY');
        DECLARE v_reminder_datetime DATETIME;
        DECLARE v_title VARCHAR(255);
        DECLARE v_message TEXT;
        DECLARE v_done BOOLEAN DEFAULT FALSE;
        
        -- مؤشر لتمرير المهام التي تحتاج إلى تذكيرات
        DECLARE task_cursor CURSOR FOR
            SELECT 
                ta.`task_assign_id`,
                ta.`user_assign_id`,
                ta.`event_id`,
                e.`event_name`,
                ta.`date_due`,
                ta.`reminder_type`,
                ta.`reminder_value`,
                ta.`reminder_unit`
            FROM `Task_Assigns` ta
            INNER JOIN `Events` e ON ta.`event_id` = e.`event_id`
            WHERE ta.`status` NOT IN ('COMPLETED', 'CANCELLED')
                AND ta.`deleted_at` IS NULL
                AND e.`deleted_at` IS NULL
                AND ta.`reminder_type` IS NOT NULL
                AND ta.`reminder_value` IS NOT NULL
                AND ta.`reminder_unit` IS NOT NULL
                AND ta.`date_due` IS NOT NULL;
        
        DECLARE CONTINUE HANDLER FOR NOT FOUND SET v_done = TRUE;
        
        OPEN task_cursor;
        
        task_loop: LOOP
            FETCH task_cursor INTO v_task_assign_id, v_user_assign_id, v_event_id, v_event_name, 
                                   v_date_due, v_reminder_type, v_reminder_value, v_reminder_unit;
            
            IF v_done THEN
                LEAVE task_loop;
            END IF;
            
            -- حساب وقت التذكير بناءً على نوع التذكير
            IF v_reminder_type = 'BEFORE_DUE' THEN
                -- تذكير قبل الموعد المحدد
                SET v_reminder_datetime = CASE v_reminder_unit
                    WHEN 'MINUTE' THEN DATE_SUB(CONCAT(v_date_due, ' 00:00:00'), INTERVAL v_reminder_value MINUTE)
                    WHEN 'HOUR' THEN DATE_SUB(CONCAT(v_date_due, ' 00:00:00'), INTERVAL v_reminder_value HOUR)
                    WHEN 'DAY' THEN DATE_SUB(v_date_due, INTERVAL v_reminder_value DAY)
                END;
            ELSE -- INTERVAL
                -- تذكير متكرر بفاصل زمني (يتم إنشاء تذكير واحد فقط لكل جلسة)
                SET v_reminder_datetime = CASE v_reminder_unit
                    WHEN 'MINUTE' THEN DATE_SUB(NOW(), INTERVAL v_reminder_value MINUTE)
                    WHEN 'HOUR' THEN DATE_SUB(NOW(), INTERVAL v_reminder_value HOUR)
                    WHEN 'DAY' THEN DATE_SUB(NOW(), INTERVAL v_reminder_value DAY)
                END;
            END IF;
            
            -- إنشاء عنوان التذكير
            SET v_title = CONCAT('تذكير بالمهمة #', v_task_assign_id);
            
            -- إنشاء رسالة التذكير
            SET v_message = CONCAT(
                'المهمة: ', 
                IFNULL((SELECT `description` FROM `Task_Assigns` WHERE `task_assign_id` = v_task_assign_id), 'غير محددة'),
                '\nالحدث: ', v_event_name,
                '\nتاريخ الاستحقاق: ', DATE_FORMAT(v_date_due, '%Y-%m-%d'),
                '\nنوع التذكير: ', IF(v_reminder_type = 'BEFORE_DUE', 'قبل الموعد', 'دوري'),
                '\nتم التذكير في: ', DATE_FORMAT(NOW(), '%Y-%m-%d %H:%i:%s')
            );
            
            -- إدراج التذكير في جدول الإشعارات (إذا لم يكن موجوداً بالفعل)
            IF v_reminder_type = 'BEFORE_DUE' THEN
                -- تذكير قبل الموعد: يتم إنشاؤه مرة واحدة فقط
                INSERT INTO `Notifications` (
                    `user_id`, 
                    `type`, 
                    `title`, 
                    `message`, 
                    `created_at`
                )
                SELECT 
                    v_user_assign_id,
                    'TASK_REMINDER_BEFORE_DUE',
                    v_title,
                    v_message,
                    NOW()
                WHERE NOT EXISTS (
                    SELECT 1 FROM `Notifications` n
                    WHERE n.`user_id` = v_user_assign_id
                        AND n.`type` = 'TASK_REMINDER_BEFORE_DUE'
                        AND n.`title` = v_title
                        AND DATE(n.`created_at`) = CURDATE()
                )
                AND NOW() >= v_reminder_datetime;
                
            ELSE -- INTERVAL
                -- تذكير دوري: يتم إنشاؤه في كل جلسة إذا كان الوقت مناسباً
                INSERT INTO `Notifications` (
                    `user_id`, 
                    `type`, 
                    `title`, 
                    `message`, 
                    `created_at`
                )
                SELECT 
                    v_user_assign_id,
                    'TASK_REMINDER_INTERVAL',
                    v_title,
                    v_message,
                    NOW()
                WHERE NOT EXISTS (
                    SELECT 1 FROM `Notifications` n
                    WHERE n.`user_id` = v_user_assign_id
                        AND n.`type` = 'TASK_REMINDER_INTERVAL'
                        AND n.`task_assign_id` = v_task_assign_id
                        AND DATE(n.`created_at`) = CURDATE()
                )
                AND NOW() >= v_reminder_datetime;
            END IF;
            
        END LOOP task_loop;
        
        CLOSE task_cursor;
        
    END$$
DELIMITER ;




