const express = require('express');
const cors = require('cors');
// require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
const path = require('path');
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));


// Use Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/events', require('./routes/events'));
app.use('/api/tasks', require('./routes/tasks'));
app.use('/api/suppliers', require('./routes/suppliers'));
app.use('/api/services', require('./routes/services'));
app.use('/api/coordinators', require('./routes/coordinators'));
app.use('/api/notifications', require('./routes/notifications'));
app.use('/api/clients', require('./routes/clients'));
app.use('/api/incomes', require('./routes/incomes'));
app.use('/api/users', require('./routes/users'));
app.use('/api/dashboard', require('./routes/dashboard'));
app.use('/api/service_requests', require('./routes/serviceRequests'));
app.use('/api/roles', require('./routes/roles'));
app.use('/api/system_users', require('./routes/systemUsers'));

// Base route for testing
app.get('/', (req, res) => {
    res.json({ message: 'Welcome to My Party Pro API' });
});

// Error handling middlewware
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ message: 'Something went wrong!', error: err.message });
});

app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
