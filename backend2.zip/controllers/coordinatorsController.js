const pool = require('../config/db');
/**
* eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJ1c2VyX2lkIjoyLCJyb2xlX25hbWUiOiJjb29yZGluYXRvciIsImlzX2FjdGl2ZSI6MSwiaXNfZGVsZXRlZCI6MCwiZW1haWwiOiJhaG1lZEBteXBhcnR5LmNvbSIsImltZ191cmwiOiJodHRwczovL2kucHJhdmF0YXIuY2MvMTUwP3U9Y29vcmRpbmF0b3IiLCJwYXNzd29yZCI6IjEyMzQ1NiIsImZ1bGxfbmFtZSI6Itin2K3ZhdivIiwicGhvbmVfbnVtYmVyIjoiNzczOTM2NDgxIiwiY3JlYXRlZF9hdCI6IjIwMjYtMDMtMjBUMDA6MjM6MDkuMDAwWiIsInVwZGF0ZWRfYXQiOm51bGwsImFkZHJlc3MiOiIiLCJpYXQiOjE3NzQxNzU2OTEsImV4cCI6MTc3NDI2MjA5MX0.l8er67EeGwvtU9rH1jFoOf8WVrguxGzboIiEeHa4M_4
*/



exports.getAllCoordinators = async (req, res) => {
   try {
       const [coordinators] = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE is_deleted = 0');
      
       res.json(coordinators);
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: err.message, error: err });
   }
};


exports.getCoordinatorById = async (req, res) => {
   try {
       const [coordinator] = await pool.execute('SELECT * FROM vw_get_all_coordinators WHERE user_id = ? AND is_deleted = 0', [req.params.id]);
       if (coordinator.length === 0) return res.status(404).json({ message: 'Coordinator not found' });
       res.json(coordinator[0]);
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error retrieving Coordinator' });
   }
};


exports.createCoordinator = async (req, res) => {

    console.log("start create Coordinator");
   const { full_name, phone_number, is_active, email, password } = req.body;
    let img_url = null;
    if(req.file)
    {
        url_image =  serverBasecPath + '/uploads/' + req.file.filename;
    }

   try {
       const [result] = await pool.execute('CALL sp_create_coordinator(?, ?, ?, ?, ?, ?)', [full_name, phone_number, img_url, is_active, email, password]);
       const new_user = result[0] && result[0][0];


       if (!new_user) return res.status(400).json({ message: 'Invalid role' });
       const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
       res.status(201).json({ message: 'User registered successfully', user_id });
       console.log("end create Coordinator");
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Registration failed', error: err.message });
   }
};


exports.updateCoordinator = async (req, res) => {
    console.log("start update Coordinator");
   const { full_name, phone_number, img_url, email } = req.body;


   try {
       const [result] = await pool.execute('SELECT `email`, `password` INTO @email, @pass FROM `Users WHERE `user_id` = 1; CALL sp_update_user(@email, @pass, ?, ?, ?, ?, ?, ?)', [req.user.user_id, full_name, phone_number, img_url, email, '{}']);


       const user = result[0] && result[0][0];
       res.status(201).json({ message: 'coordinator updated successfully', user });
       console.log("end update Coordinator");
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'coordinator update failed', error: err.message });
   }
};






exports.deleteCoordinator = async (req, res) => {
   try {
       const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
       const deleted_user = result[0] && result[0][0];
       if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
       res.status(200).json({ message: 'User deleted successfully', deleted_user });
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Delete failed', error: err.message });
   }
};
