const pool = require('../config/db');


// List all users globally
exports.getAllUsers = async (req, res) => {
   try {
       const [users] = await pool.execute(`
           SELECT u.*,
           FROM Users u
       `);


       // Format user records explicitly
       const mappedUsers = users.map(user => {
           return {
               user_id: user.user_id,
               email: user.email,
               role: user.role_name,
               full_name: user.full_name,
               is_active: user.is_active,
               created_at: user.created_at
           };
       });

       console.log({mappedUsers});
       res.json(mappedUsers);
   } catch (err) {
       console.error('Error fetching system users:', err);
       res.status(500).json({ message: 'Error retrieving system users' });
   }
};


// Toggle user activation status (Suspend / Activate)
exports.toggleUserStatus = async (req, res) => {
   const userId = req.params.id;
   const { is_active } = req.body; // Expecting boolean


   if (typeof is_active !== 'boolean') {
       return res.status(400).json({ message: 'is_active must be a boolean value' });
   }


   try {
       const [result] = await pool.execute('UPDATE Users SET is_active = ? WHERE user_id = ?', [is_active, userId]);
       if (result.affectedRows === 0) {
           return res.status(404).json({ message: 'User not found' });
       }
       res.json({ message: `User successfully ${is_active ? 'activated' : 'suspended'}` });
   } catch (err) {
       console.error('Error changing user status:', err);
       res.status(500).json({ message: 'Error updating user status' });
   }
};


// Reassign user role
exports.changeUserRole = async (req, res) => {
   const userId = req.params.id;
   const { role_id } = req.body;


   if (!role_id) {
       return res.status(400).json({ message: 'role_id is required' });
   }


   try {
       const [result] = await pool.execute('UPDATE Users SET role_id = ? WHERE user_id = ?', [role_id, userId]);
       if (result.affectedRows === 0) {
           return res.status(404).json({ message: 'User not found' });
       }
       res.json({ message: 'User role successfully updated' });
   } catch (err) {
       console.error('Error updating user role:', err);
       res.status(500).json({ message: 'Error updating user role' });
   }
};





