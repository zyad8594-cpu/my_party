const pool = require('../config/db');
const { serverBasecPath } = require('../config/constents');
const jwt = require('jsonwebtoken');

exports.getAllUsers = async (req, res) => {
    const [users] = await pool.execute("SELECT * FROM Users");
    res.json(users);
};

exports.getUserById = async (req, res) => {
    const [user] = await pool.execute("SELECT * FROM Users WHERE user_id = ?", [req.params.id]);
    res.json(user);
};

exports.create = async (req, res) => {
    // user_creator_email` VARCHAR(255),
    //    user_creator_pass` VARCHAR(255),
    //    role_name` VARCHAR(50),
    //    full_name` VARCHAR(255),
    //    phone_number` VARCHAR(20),
    //    is_active` BOOLEAN,
    //    img_url` TEXT,
    //    email` VARCHAR(255),
    //    password` VARCHAR(255),
    //    details` JSON,
    //    user_id` INT,
    //    with_out` BOOLEAN
    const { role_name, full_name, phone_number, email, is_active, password, details } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute('CALL sp_register(?, ?, ?, ?, ?, ?, ?, TRUE)', 
            [role_name, full_name, phone_number, img_url, email, password, details]);

        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
        res.status(201).json({ message: 'User registered successfully', user_id });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Registration failed', error: err.message });
    }
};

exports.update = async (req, res) => {
    const user_id = req.params.id;
    const { full_name, phone_number, email, password, details } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute('CALL sp_update_user_byadmin(?, ?, ?, ?, ?, ?, ?)', 
            [user_id || null, 
                full_name || null, 
                phone_number || null, 
                img_url || null, 
                email || null, 
                null,
                details? JSON.stringify(details) : '{}'
            ]);

        const updated_user = result[0] && result[0][0];
        console.log({updated_user});
        if (!updated_user) return res.status(400).json({ message: 'Invalid user' });

        const token = jwt.sign(updated_user, process.env.JWT_SECRET || 'your_super_secret_key', { expiresIn: '1d' });
        
        res.status(200).json({ message: 'User details updated successfully', token: token, user: updated_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Update failed', error: err.message });
    }
};

exports.changePassword = async (req, res) => {
    const { old_password, new_password } = req.body;
    try {
        const [result] = await pool.execute('CALL sp_change_password(?, ?, ?)', 
            [req.params.id || req.params.userId || null, old_password || null, new_password || null]);
        const change_pass_user = result[0] && result[0][0];
        console.log({change_pass_user});

        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });

        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
    
}
exports.delete = async (req, res) => {

    try {
        const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
        const deleted_user = result[0] && result[0][0];
        if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User deleted successfully', deleted_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Delete failed', error: err.message });
    }
};

exports.set_active = async (req, res) => {
    const user_id = req.params.id;
    const { is_active } = req.body;

    try {
        const [result] = await pool.execute('CALL sp_set_user_active(?, ?)', [user_id, is_active]);
        const updated_user = result[0] && result[0][0];
        if (!updated_user) return res.status(400).json({ message: 'Invalid user' });
        res.status(200).json({ message: 'User active status updated successfully', updated_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Update failed', error: err.message });
    }
};
