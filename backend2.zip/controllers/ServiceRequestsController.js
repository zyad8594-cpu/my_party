const pool = require('../config/db');


exports.createRequest = async (req, res) => {
   const { supplier_id, service_name, description } = req.body;
  
   if(!supplier_id || !service_name) {
       return res.status(400).json({ message: 'supplier_id and service_name are required' });
   }


   try {
       const [result] = await pool.execute(
           'INSERT INTO Service_Requests (supplier_id, service_name, description) VALUES (?, ?, ?)',
           [supplier_id, service_name, description]
       );
       res.status(201).json({ message: 'Service request created successfully', requestId: result.insertId });
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error creating service request' });
   }
};


exports.getAllRequests = async (req, res) => {
   try {
       const [rows] = await pool.execute(`
           SELECT sr.*, u.full_name as supplier_name
           FROM Service_Requests sr
           JOIN Users u ON sr.supplier_id = u.user_id
           WHERE sr.deleted_at IS NULL
           ORDER BY sr.created_at DESC
       `);
       res.json(rows);
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error retrieving service requests' });
   }
};


exports.updateStatus = async (req, res) => {
   const { id } = req.params;
   const { status } = req.body;
   if(!['PENDING', 'APPROVED', 'REJECTED'].includes(status)) {
       return res.status(400).json({ message: 'Invalid status' });
   }
  
   try {
       await pool.execute(
           'UPDATE Service_Requests SET status = ? WHERE id = ?',
           [status, id]
       );
      
       // If approved, we might want to also add it to the Services list automatically. Let's just update the status for now as admin will handle it manually or through another flow.
       res.json({ message: 'Service request status updated' });
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error updating status' });
   }
};


exports.getMyRequests = async (req, res) => {
   try {
       const [rows] = await pool.execute(`
           SELECT sr.*, u.full_name as supplier_name
           FROM Service_Requests sr
           JOIN Users u ON sr.supplier_id = u.user_id
           WHERE sr.supplier_id = ? AND sr.deleted_at IS NULL
           ORDER BY sr.created_at DESC
       `, [req.user.user_id]);
       console.log({rows, user_id: req.user.user_id});
       res.json(rows);
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error retrieving service requests' });
   }
};


exports.withdrawRequest = async (req, res) => {
   const { id } = req.params;
   try {
       const [result] = await pool.execute(
           'UPDATE Service_Requests SET deleted_at = NOW() WHERE id = ? AND supplier_id = ? AND status = "PENDING"',
           [id, req.user.user_id]
       );
       if (result.affectedRows === 0) {
          return res.status(400).json({ message: 'Cannot withdraw this request' });
       }
       res.json({ message: 'Service request withdrawn successfully' });
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error withdrawing request' });
   }
};


