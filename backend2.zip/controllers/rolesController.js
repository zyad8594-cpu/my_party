const pool = require('../config/db');


// List all roles and their mapped permissions
exports.getRoles = async (req, res) => {
   try {
       const [roles] = await pool.execute('SELECT * FROM Roles');
      
       // Fetch permissions for each role
       for (let role of roles) {
           const [permissions] = await pool.execute(`
               SELECT p.*
               FROM Permissions p
               JOIN Role_Permissions rp ON p.permission_id = rp.permission_id
               WHERE rp.role_id = ?
           `, [role.role_id]);
           role.permissions = permissions;
       }


       res.json(roles);
   } catch (err) {
       console.error('Error fetching roles:', err);
       res.status(500).json({ message: 'Error retrieving roles' });
   }
};


// Create a new custom role
exports.createRole = async (req, res) => {
   const { role_name } = req.body;
   if (!role_name) return res.status(400).json({ message: 'Role name is required' });


   try {
       const [result] = await pool.execute('INSERT INTO Roles (role_name) VALUES (?)', [role_name]);
       res.status(201).json({ message: 'Role created successfully', role_id: result.insertId });
   } catch (err) {
       console.error('Error creating role:', err);
       if (err.code === 'ER_DUP_ENTRY') {
           return res.status(400).json({ message: 'Role already exists' });
       }
       res.status(500).json({ message: 'Error creating role' });
   }
};


// Assign permissions to a role
exports.assignPermissionsToRole = async (req, res) => {
   const roleId = req.params.id;
   const { permission_ids } = req.body; // Expecting an array of permission IDs


   if (!Array.isArray(permission_ids)) {
       return res.status(400).json({ message: 'permission_ids must be an array' });
   }


   const connection = await pool.getConnection();
   try {
       await connection.beginTransaction();


       // 1. Delete existing allocations
       await connection.execute('DELETE FROM Role_Permissions WHERE role_id = ?', [roleId]);


       // 2. Insert new allocations
       if (permission_ids.length > 0) {
           const values = permission_ids.map(pid => [roleId, pid]);
           await connection.query('INSERT INTO Role_Permissions (role_id, permission_id) VALUES ?', [values]);
       }


       await connection.commit();
       res.json({ message: 'Permissions successfully assigned to role' });
   } catch (err) {
       await connection.rollback();
       console.error('Error assigning permissions:', err);
       res.status(500).json({ message: 'Error assigning permissions to role' });
   } finally {
       connection.release();
   }
};


// Delete a role
exports.deleteRole = async (req, res) => {
   const roleId = req.params.id;
   try {
       await pool.execute('DELETE FROM Roles WHERE role_id = ?', [roleId]);
       res.json({ message: 'Role successfully deleted' });
   } catch (err) {
       console.error('Error deleting role:', err);
       if (err.code === 'ER_ROW_IS_REFERENCED_2') {
           return res.status(400).json({ message: 'Cannot delete role because it is assigned to existing users' });
       }
       res.status(500).json({ message: 'Error deleting role' });
   }
};


// List all possible permissions inside the system
exports.getAllPermissions = async (req, res) => {
   try {
       const [permissions] = await pool.execute('SELECT * FROM Permissions');
       res.json(permissions);
   } catch (err) {
       console.error('Error fetching permissions:', err);
       res.status(500).json({ message: 'Error retrieving permissions' });
   }
};





