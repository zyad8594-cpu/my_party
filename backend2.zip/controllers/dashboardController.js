const pool = require('../config/db');


exports.getAdminStats = async (req, res) => {
   try {
       // We will execute a batch of highly optimized analytical queries in parallel.
       const [usersSummary] = await pool.execute(`
           SELECT role_name, COUNT(*) as count
           FROM Users
           GROUP BY role_name
       `);


       const [eventsSummary] = await pool.execute(`
           SELECT status, COUNT(*) as count
           FROM vw_events_detailed
           GROUP BY status
       `);


       const [tasksSummary] = await pool.execute(`
           SELECT status, COUNT(*) as count
           FROM Task_Assigns
           GROUP BY status
       `);


       // Financials (Total collected / expected income)
       const [incomeSummary] = await pool.execute(`
           SELECT SUM(amount) as total_income
           FROM Incomes
       `);


       const [proposalsSummary] = await pool.execute(`
           SELECT COUNT(*) as pending_requests
           FROM Service_Requests
           WHERE status = 'PENDING' AND deleted_at IS NULL
       `);


       // Transforming usersSummary to standard mapped object
       const usersCount = { ALL: 0, CLIENT: 0, SUPPLIER: 0, ADMIN: 0, COORDINATOR: 0 };
       for (let row of usersSummary) {
           let role = (row.role_name || '').toUpperCase();
           usersCount[role] = row.count;
           usersCount.ALL += row.count;
       }


       const eventsCount = { ALL: 0, SCHEDULED: 0, IN_PROGRESS: 0, COMPLETED: 0, CANCELLED: 0 };
       for (let row of eventsSummary) {
           let st = (row.status || '').toUpperCase();
           eventsCount[st] = row.count;
           eventsCount.ALL += row.count;
       }


       const tasksCount = { ALL: 0, PENDING: 0, IN_PROGRESS: 0, COMPLETED: 0 };
       for (let row of tasksSummary) {
           let st = (row.status || '').toUpperCase();
           tasksCount[st] = row.count;
           tasksCount.ALL += row.count;
       }


       res.json({
           users: usersCount,
           events: eventsCount,
           tasks: tasksCount,
           financials: {
               total_income: incomeSummary[0].total_income || 0,
           },
           proposals: {
               pending: proposalsSummary[0].pending_requests || 0,
           }
       });


   } catch (err) {
       console.error('Error fetching admin stats:', err);
       res.status(500).json({ message: 'Error retrieving dashboard insights' });
   }
};





exports.getHomeStats = async (req, res) => {
   try {
       const [stats] = await pool.execute("CALL sp_home_stats_coordinator(?)", [req.user['user_id']]);
       if (!stats[0] || !stats[0][0] || stats[0][0].length === 0) {
           return res.status(404).json({ message: 'No home stats found' });
       }
       res.json(stats[0][0]);
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Failed to fetch home stats', error: err.message });
   }
};


exports.getReportStats = async (req, res) => {
   try {
       const [stats] = await pool.execute("CALL sp_report_stats(?)", [req.user['user_id']]);
       if (!stats[0] || !stats[0][0] || stats[0][0].length === 0) {
           return res.status(404).json({ message: 'No home stats found' });
       }
       const [monthlyIncome] = await pool.execute("CALL sp_monthly_income(?, ?)", [req.user['user_id'], 12]);

       res.json({
           ...stats[0][0],
           monthlyIncome: monthlyIncome[0][0] || []
       });

   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Failed to fetch report stats', error: err.message });
   }
};



