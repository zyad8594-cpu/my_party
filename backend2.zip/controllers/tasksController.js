const pool = require('../config/db');
const { serverBasecPath } = require('../config/constents');

exports.getAllTasks = async (req, res) => {
    try {
        const typ = req.user.role_name == 'coordinator'? 
                `coordinator_id` : 
                `user_assign_id`;
        const [tasks] = await pool.execute(`SELECT * FROM vw_tasks_full WHERE ${typ} = ?`,
            [req.user.user_id]
        );
       
        res.json(tasks);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Tasks' });
    }
};

exports.getTaskById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_tasks_full WHERE task_assign_id = ? AND ?', 
            [
                req.params.id,
                req.user.role_name == 'coordinator'? 
                    `coordinator_id = ${req.user.user_id}` : 
                    `user_assign_id = ${req.user.user_id}`
            ]
        );
         if(rows.length == 0){ return res.status(404).json({message: 'Task not found'}); }
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving tasks' });
    }
};

exports.getTasksByEventId = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM vw_tasks_full WHERE event_id = ? AND ?', 
            [
                req.params.eventId,
                req.user.role_name == 'coordinator'? 
                    `coordinator_id = ${req.user.user_id}` : 
                    `user_assign_id = ${req.user.user_id}`
            ]
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving tasks' });
    }
};

exports.createTask = async (req, res) => {
    const { event_id, service_id, type_task, status, date_start, date_due, 
        user_assign_id, description, cost, notes, url_image, reminder_type, reminder_value, reminder_unit} = req.body;
    try {
        const [result] = await pool.execute(
            'CALL sp_create_task(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, @last_insert_task_assign_id)',
            [
                event_id || null, 
                service_id || null, 
                type_task || null, 
                status || null, 
                date_start || null, 
                date_due || null, 
                user_assign_id || null, 
                description || null, 
                cost || null, 
                notes || null, 
                url_image || null,
                reminder_type || null, 
                reminder_value || null, 
                reminder_unit || null
            ]
        );
        res.status(201).json({ message: 'Task created successfully', result: result || {} });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message, error: err });
    }
};

exports.updateTask = async (req, res) => {
    const { type_task, status, date_start, date_due, description, cost, notes, url_image } = req.body;
    try {
        console.log({ params: Number.parseInt(req.params.id), type_task, status, date_start, date_due, description, cost, notes, url_image });
        const [result] = await pool.execute(
            'CALL sp_update_task(?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                Number.parseInt(req.params.id), 
                type_task || null, 
                status || null, 
                date_start || null, 
                date_due || null, 
                description || null, 
                cost || null, 
                notes || null, 
                url_image || null
            ]
        );
        console.log({result: result[0][0]});
        res.json({ message: 'Task updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        
        res.status(500).json({ message: 'Error updating task', error: err.message });
    }
};

exports.deleteTask = async (req, res) => {
    try {
        await pool.execute('CALL sp_delete_task(?)', [req.params.id]);
        res.json({ message: 'Task deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting task' });
    }
};

exports.updateTaskStatus = async (req, res) => {
    const { status, notes } = req.body;
    let url_image = null;
    if(req.file)
    {
        url_image =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        await pool.execute('CALL sp_update_task_status(?, ?, ?, ?, ?)', [req.user.user_id, req.params.id, status, notes || null, url_image || null]);
        res.json({ message: 'Task status updated successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message:  err.message});
    }
};

exports.addTaskRating = async (req, res) => {
    const { value_rating, comment } = req.body;
    try {
        // const coordinator_id = req.user.profile_id; // Assume user is a coordinator
         pool.execute('CALL sp_add_task_rating(?, ?, ?, ?)', [req.params.id, req.user.user_id, value_rating, comment || null]);
        
        res.status(201).json({ message: 'Rating added successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message, error: err });
    }
}
