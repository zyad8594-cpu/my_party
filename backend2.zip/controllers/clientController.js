const pool = require('../config/db');
const { serverBasecPath } = require('../config/constents');


exports.getAllClients = async (req, res) => {
    try {
        // const [clients] = await pool.execute('CALL sp_get_all_clintes_for_coordinator(?)', [req.user['email']]);
        const [clients] = await pool.execute('SELECT * FROM `Clients` WHERE `coordinator_id` = ?', [req.user['user_id']]);
        // res.json(clients[0]);
        res.json(clients);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Clients' });
    }
};

exports.getClientById = async (req, res) => {
    try {
        const [client] = await pool.execute('SELECT * FROM `Clients` WHERE  `client_id` = ? LIMIT 1', [req.params.id]);

        res.json(client[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Client'});
    }
};

exports.createClient = async (req, res) => {
    const { full_name, phone_number, email, address } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute(
            `CALL sp_create_client(?, ?, ?, ?, ?, ?, ?)`, 
            [req.user.user_id, full_name, phone_number, img_url, email, address, true]);
        const new_user = result[0] && result[0][0];

        if (!new_user) return res.status(400).json({ message: 'Invalid role' });
        res.status(201).json({ message: 'User registered successfully', user: new_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message , error: err });
    }
};

exports.updateClient = async (req, res) => {
    const {full_name , phone_number, email, address, coordinator_email } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute(
            `CALL sp_update_client(?, ?, ?, ?, ?, ?, ?)`, 
            [
                req.user.user_id,
                req.params.id, 
                full_name || null, 
                phone_number || null, 
                img_url || null, 
                email || null, 
                address || null
            ]);

        const client = result[0] && result[0][0];
        res.status(201).json({ message: 'client updated successfully', user: client });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message, error: err });
    }
};

exports.deleteClient = async (req, res) => {
    // try {
    //     const [result] = await pool.execute('CALL sp_delete_user(?)', [req.params.id]);
    //     const deleted_user = result[0] && result[0][0];
    //     if (!deleted_user) return res.status(400).json({ message: 'Invalid user' });
    //     res.status(200).json({ message: 'User deleted successfully', deleted_user });
    // } catch (err) {
    //     console.error(err);
    //     res.status(500).json({ message: 'Delete failed', error: err.message });
    // }
};

exports.restoreClient = async (req, res) => {
    // try {
    //     const [result] = await pool.execute('CALL sp_restore_user(?)', [req.params.id]);
    //     const restored_user = result[0] && result[0][0];
    //     if (!restored_user) return res.status(400).json({ message: 'Invalid user' });
    //     res.status(200).json({ message: 'User restored successfully', restored_user });
    // } catch (err) {
    //     console.error(err);
    //     res.status(500).json({ message: 'Restore failed', error: err.message });
    // }
};