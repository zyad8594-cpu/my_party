const pool = require('../config/db');
const path = require('path');

exports.getNotifications = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT * FROM Notifications WHERE `user_id` = ? AND `deleted_at` IS NULL',
            [req.user.user_id]
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Notifications' });
    }
};

exports.getLastNotifications = async (req, res) => {
    try {
        
        const [yss] = await pool.execute("SELECT 1 FROM Notifications WHERE `user_id` = ? AND `created_at` > ? AND `deleted_at` IS NULL LIMIT 1", 
            [req.user.user_id, req.params.date]);
        console.log({yss});
        const [rows] = await pool.execute("SELECT 1 FROM Notifications WHERE `user_id` = ? AND `created_at` > ? AND `deleted_at` IS NULL", 
            [req.user.user_id, req.params.date]);
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Notifications' });
    }
};

exports.deleteNotification = async (req, res) => {
    const { id } = req.params;
    try {
        await pool.execute('DELETE FROM Notifications WHERE id = ?', [id]);
        res.json({ message: 'Notification deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting notification' });
    }
};

exports.clearAllNotifications = async (req, res) => {
    try {
        await pool.execute('DELETE FROM Notifications');
        res.json({ message: 'All Notifications cleared successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error clearing Notifications' });
    }
};

exports.markAsRead = async (req, res) => {
   const { id } = req.params;
   try {
       await pool.execute('UPDATE Notifications SET is_read = 1 WHERE notification_id = ?', [id]);
       res.json({ message: 'Notification marked as read' });
   } catch (err) {
       console.error(err);
       res.status(500).json({ message: 'Error marking notification as read' });
   }
};



