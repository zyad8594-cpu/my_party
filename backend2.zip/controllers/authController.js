const pool = require('../config/db');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { serverBasecPath } = require('../config/constents');

exports.login = async (req, res) => {
    const { email, password } = req.body;
    
    try {
        // Find user by email 
        
        let [users] = await pool.execute('CALL sp_login_user(?)', [email]);
        // throw { message: { ...user } };
        if (!users || !users[0] || !users[0][0] || !users[0][0].user_id) {
            return res.status(400).json({ message: 'Invalid email or password' });
        }

        const user = users[0][0];

        // Check password
        // const isMatch = await bcrypt.compare(password, user.password);
        const isMatch = password == user.password;
        if (!isMatch) {

            return res.status(400).json({ message: 'Invalid email or password', isMatch: isMatch, password: password, user_password: user.password });
        }


        // user.full_name = user.full_name || '';
        // user.phone_number = user.phone_number || '';
        // user.address = user.address || '';
        // user.img_url = user.img_url || '';
        // Generate JWT token

        const token = jwt.sign(user, process.env.JWT_SECRET || 'your_super_secret_key', { expiresIn: '1d' });

        res.json({ token: token, user: user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'خطاء في الخادم: ' + err.message, error: err.message });
    }
};

exports.register = async (req, res) => {
    const { role_name, full_name, phone_number, email, password, details } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        if ((role_name || '') == 'admin') {
            return res.status(500).json({ message: 'Registration failed', error: 'err.message' });
        }
        const [result] = await pool.execute('CALL sp_register(?, ?, ?, ?, ?, ?, ?, TRUE)', 
            [
                role_name, full_name, phone_number, img_url, email, password , JSON.stringify(details || {})
            ]
        );

        const new_user = result[0] && result[0][0];
        if (!new_user) return res.status(400).json({ message: 'Invalid role' });

        // const user_id = new_user.user_id || new_user.id || Object.values(new_user)[0];
        res.status(201).json({ message: 'User registered successfully', new_user });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message, error: err });
    }
};
