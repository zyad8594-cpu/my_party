const pool = require('../config/db');
const { serverBasecPath } = require('../config/constents');

exports.getAllEvents = async (req, res) => {
    try {
        const [events] = await pool.execute('CALL sp_events_detailed(?)', [req.user.user_id]);
        if (!events[0]) {
           return res.status(404).json({ message: 'No home events found' });
       }
       res.json(events[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Events' });
    }
};

exports.getEventById = async (req, res) => {
    try {
        const [event] = await pool.execute('SELECT * FROM vw_events_detailed WHERE event_id = ? LIMIT 1', [req.params.id]);
        if (event.length === 0) return res.status(404).json({ message: 'Event not found' });

        res.json(event[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving event' });
    }
};

exports.createEvent = async (req, res) => {

    const { client_id, event_name, description, event_date, location, budget, event_duration, event_duration_unit, options } = req.body;
    let img_url = req.body.img_url || null;
    if(req.file)
    {
        img_url =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute(
            'CALL sp_create_event_full(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [
                client_id, 
                req.user.user_id, 
                event_name, 
                description || null, 
                img_url || null, 
                event_date, 
                location || null, 
                budget || 0.0, 
                event_duration || 1, 
                event_duration_unit || null,
                options || null
            ]
        );

        res.status(201).json({ message: 'Event created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message, error: err });
    }
};

exports.updateEvent = async (req, res) => {
    try {
        const { event_name, description, event_date, location, budget, event_duration, event_duration_unit } = req.body;
        let img_url = req.body.img_url || null;
        if(req.file)
        {
            img_url =  serverBasecPath + '/uploads/' + req.file.filename;
        }
        const [result] = await pool.execute(
            'CALL sp_update_event(?, ?, ?, ?, ?, ?, ?, ?, ?)',
            [req.params.id, 
                event_name || null, 
                description || null, 
                img_url, 
                event_date || null, 
                location || null, 
                budget || null, 
                event_duration || null, 
                event_duration_unit || null 
        ]
        );
        res.json({ message: 'Event updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: err.message });
    }
};

exports.deleteEvent = async (req, res) => {
    try {
        const [result] = await pool.execute('CALL sp_delete_event(?)', [req.params.id]);
        res.json({ message: 'Event deleted (soft delete) successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting event' });
    }
};

exports.updateEventStatus = async (req, res) => {
    try {
        const { status } = req.body;
        const [result] = await pool.execute('UPDATE Events SET deleted_at = NULL WHERE event_id = ?', [req.params.id]);
        if (result.affectedRows === 0) return res.status(404).json({ message: 'Event not found' });

        res.json({ message: 'Event status updated' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating event status' });
    }
};

exports.cancelEvent = async (req, res) => {
    try {
        const { reason } = req.body;
        await pool.execute('CALL sp_cancel_event(?, ?)', [req.params.id, reason || 'Cancelled by coordinator']);
        res.json({ message: 'Event cancelled successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error cancelling event' });
    }
}
