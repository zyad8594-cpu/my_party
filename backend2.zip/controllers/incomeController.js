const pool = require('../config/db');
const { serverBasecPath } = require('../config/constents');

exports.getAllIncomes = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT i.*, e.`event_name` FROM `Incomes` i JOIN `Events` e ON i.`event_id` = e.`event_id` WHERE e.`coordinator_id` = ?',
            [req.user.user_id]
        );
        res.json(rows);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Income' });
    }
};

exports.getIncomeById = async (req, res) => {
    try {
        const [rows] = await pool.execute('SELECT i.*, e.`event_name` FROM `Incomes` i JOIN `Events` e ON i.`event_id` = e.`event_id` WHERE e.`coordinator_id` = ? AND i.`income_id` = ?', 
            [req.user.user_id, req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: 'Income not found' });
        res.json(rows[0]);
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error retrieving Income' });
    }
};

exports.createIncome = async (req, res) => {
    const { event_id, amount, description, payment_date, payment_method } = req.body;
    let url_image = req.body.url_image || null;
    if(req.file)
    {
        url_image =  serverBasecPath + '/uploads/' + req.file.filename;
    }
    try {
        const [result] = await pool.execute(
            'CALL sp_create_income(?, ?, ?, ?, ?, ?, ?)',
            [event_id, amount, description, payment_date, payment_method, url_image || null, true]
        );

        res.status(201).json({ message: 'Income created successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error creating income', error: err.message });
    }
};

exports.updateIncome = async (req, res) => {
    try {
        const { amount, description, payment_date, payment_method } = req.body;
        let url_image = req.body.url_image || null;
        if(req.file)
        {
            url_image =  serverBasecPath + '/uploads/' + req.file.filename;
        }
        const [result] = await pool.execute(
            'CALL sp_update_income(?, ?, ?, ?, ?, ?)', 
            [req.params.id, amount || null, description || null, payment_date || null, payment_method || null, url_image || null]
        );
        res.json({ message: 'Income updated successfully', result: result[0][0] });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error updating income' });
    }
};

exports.deleteIncome = async (req, res) => {
    try {
        await pool.execute('CALL sp_delete_income(?)', [req.params.id]);
        res.json({ message: 'Income deleted successfully' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ message: 'Error deleting income' });
    }
};