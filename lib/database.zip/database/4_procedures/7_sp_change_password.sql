-- 4.7 إجراء إعادة تعيين كلمة المرور (تحديث)
CREATE PROCEDURE `sp_change_password`(
    IN `p_user_id` INT,
    IN `p_old_password` VARCHAR(255) CHARSET utf8mb4,
    IN `p_new_password` VARCHAR(255) CHARSET utf8mb4
)
BEGIN
    DECLARE v_current_password VARCHAR(255);
    
    SELECT `password` INTO v_current_password
    FROM `Users` WHERE `user_id` = p_user_id;
    
    IF v_current_password = p_old_password THEN
        UPDATE `Users` SET `password` = p_new_password, `updated_at` = NOW()
        WHERE `user_id` = p_user_id;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'كلمة المرور القديمة غير صحيحة.';
    END IF;
END$$
