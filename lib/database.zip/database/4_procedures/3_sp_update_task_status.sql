-- 4.3 إجراء تحديث حالة مهمة مع إنشاء إشعار تلقائي
CREATE PROCEDURE `sp_update_task_status`(
    IN `p_task_id` INT,
    IN `p_new_status` ENUM(
        'PENDING',
        'IN_PROGRESS',
        'UNDER_REVIEW',
        'COMPLETED',
        'CANCELLED'
    ) CHARSET utf8mb4,
    IN `p_notes` TEXT CHARSET utf8mb4
)
BEGIN
    DECLARE v_old_status VARCHAR(20);
    DECLARE v_assigned_user INT;
    DECLARE v_assigned_supplier INT;
    DECLARE v_event_id INT;
    
    SELECT `status`, `assigned_user_id`, `assigned_supplier_id`, `event_id`
        INTO v_old_status, v_assigned_user, v_assigned_supplier, v_event_id
        FROM `Tasks` WHERE `task_id` = p_task_id;
    
    -- تحديث المهمة
    UPDATE `Tasks`
        SET `status` = p_new_status,
            `notes` = IF(p_notes IS NOT NULL, CONCAT(IFNULL(`notes`, ''), '\n', p_notes), `notes`),
            `date_completion` = IF(p_new_status = 'COMPLETED', NOW(), `date_completion`),
            `completion_at` = IF(p_new_status = 'COMPLETED', NOW(), `completion_at`)
        WHERE `task_id` = p_task_id;
    
    -- إنشاء إشعار حسب الحالة الجديدة
    IF p_new_status = 'COMPLETED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
        SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_COMPLETED', 'تم إكمال مهمة',
               CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' قد اكتملت.')
            FROM `Tasks` t
            JOIN `Events` e ON t.`event_id` = e.`event_id`
            WHERE t.`task_id` = p_task_id;
        
    ELSEIF p_new_status = 'CANCELLED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
            SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_CANCELLED', 'تم إلغاء مهمة',
                CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' تم إلغاؤها.')
                FROM `Tasks` t
                JOIN `Events` e ON t.`event_id` = e.`event_id`
                WHERE t.`task_id` = p_task_id;
    END IF;
    
END$$
