-- 4.2 إجراء إنشاء حدث جديد مع مهامه (باستخدام JSON)
CREATE PROCEDURE `sp_create_event_full`(
    IN `p_client_id` INT,
    IN `p_coordinator_id` INT,
    IN `p_name_event` VARCHAR(100) CHARSET utf8mb4,
    IN `p_description` TEXT,
    IN `p_event_date` DATE,
    IN `p_location` VARCHAR(255) CHARSET utf8mb4,
    IN `p_budget` DECIMAL(10,2),
    IN `p_status` ENUM('not_started','in_progress','completed','cancelled') CHARSET utf8mb4,
    IN `p_tasks_json` JSON  -- مصفوفة من المهام: [{"type_task":"...","assignment_type":"...", ...}]
)
BEGIN
    DECLARE v_event_id INT;
    DECLARE v_counter INT DEFAULT 0;
    DECLARE v_total INT;
    DECLARE v_task JSON;
    
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- إدراج الحدث
    INSERT INTO `Events` (`client_id`, `coordinator_id`, `name_event`, `description`, 
                          `event_date`, `location`, `budget`, `status`)
        VALUES (p_client_id, p_coordinator_id, p_name_event, p_description,
            p_event_date, p_location, p_budget, p_status);
    SET v_event_id = LAST_INSERT_ID();
    
    -- إدراج المهام إذا وجدت
    IF p_tasks_json IS NOT NULL THEN
        SET v_total = JSON_LENGTH(p_tasks_json);
        WHILE v_counter < v_total DO
            SET v_task = JSON_EXTRACT(p_tasks_json, CONCAT('$[', v_counter, ']'));
            
            INSERT INTO `Tasks` (
                `event_id`, `assignment_type`, `assigned_user_id`, `assigned_supplier_id`,
                `type_task`, `description`, `cost`, `status`, `notes`, `url_image`,
                `date_start`, `date_due`, `reminder_type`, `reminder_value`, `reminder_unit`
            ) VALUES (
                v_event_id,
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.assignment_type')),
                JSON_EXTRACT(v_task, '$.assigned_user_id'),
                JSON_EXTRACT(v_task, '$.assigned_supplier_id'),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.type_task')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.description')),
                IFNULL(JSON_EXTRACT(v_task, '$.cost'), 0),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.status')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.notes')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.url_image')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.date_start')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.date_due')),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.reminder_type')),
                JSON_EXTRACT(v_task, '$.reminder_value'),
                JSON_UNQUOTE(JSON_EXTRACT(v_task, '$.reminder_unit'))
            );
            
            SET v_counter = v_counter + 1;
        END WHILE;
    END IF;
    
    COMMIT;
    
    -- إرجاع معرف الحدث
    SELECT v_event_id AS `event_id`;
END$$
