-- 4.1 إجراء تسجيل الدخول والتحقق من المستخدم
CREATE PROCEDURE `sp_user_login`(
    IN `p_email` VARCHAR(100) CHARSET utf8mb4, 
    IN `p_password` VARCHAR(255) CHARSET utf8mb4
)
BEGIN
    DECLARE v_user_id INT;
    DECLARE v_password_hash VARCHAR(255);
    
    -- البحث عن المستخدم
    SELECT `user_id`, `password` INTO v_user_id, v_password_hash
        FROM `Users` WHERE `email` = p_email AND `is_active` = TRUE;
    
    -- التحقق من كلمة المرور (يفترض استخدام hashing)
    IF v_user_id IS NOT NULL AND v_password_hash = p_password THEN
        -- إرجاع بيانات المستخدم
        SELECT u.`user_id`, u.`email`, u.`role_id`, r.`role_name`,
               COALESCE(coord.`coordinator_id`, supp.`supplier_id`) AS `profile_id`,
               CASE WHEN coord.`coordinator_id` IS NOT NULL THEN 'coordinator'
                    WHEN supp.`supplier_id` IS NOT NULL THEN 'supplier'
                    ELSE 'admin' END AS `user_type`
            FROM `Users` u
            JOIN `Roles` r ON u.`role_id` = r.`role_id`
            LEFT JOIN `Coordinators` coord ON u.`user_id` = coord.`user_id`
            LEFT JOIN `Suppliers` supp ON u.`user_id` = supp.`user_id`
            WHERE u.`user_id` = v_user_id;
    ELSE
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'البريد الإلكتروني أو كلمة المرور غير صحيحة';
    END IF;
END$$
