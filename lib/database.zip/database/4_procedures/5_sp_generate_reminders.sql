-- 4.5 إجراء إنشاء إشعارات تذكير للمهام القريبة
CREATE PROCEDURE `sp_generate_reminders`()
BEGIN
    -- إشعارات للمهام التي تاريخ استحقاقها خلال 3 أيام ولم تكتمل
    INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
    SELECT 
        CASE WHEN t.`assignment_type` = 'USER' THEN t.`assigned_user_id` ELSE NULL END,
        CASE WHEN t.`assignment_type` = 'SUPPLIER' THEN t.`assigned_supplier_id` ELSE NULL END,
        t.`task_id`,
        'TASK_REMINDER',
        'تذكير بمهمة',
        CONCAT('مهمة "', t.`type_task`, '" مستحقة في ', t.`date_due`)
    FROM `Tasks` t
    WHERE t.`status` NOT IN ('COMPLETED', 'CANCELLED')
      AND t.`date_due` BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 3 DAY)
      AND NOT EXISTS (
          SELECT 1 FROM `Notifications` n
          WHERE n.`task_id` = t.`task_id` AND n.`type` = 'TASK_REMINDER' AND DATE(n.`created_at`) = CURDATE()
      );
END$$
