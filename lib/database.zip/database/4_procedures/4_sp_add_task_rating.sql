-- 4.4 إجراء إضافة تقييم لمهمة مع التحقق
CREATE PROCEDURE `sp_add_task_rating`(
    IN `p_task_id` INT,
    IN `p_coordinator_id` INT,
    IN `p_value_rating` INT,
    IN `p_comment` TEXT CHARSET utf8mb4
)
BEGIN
    -- التحقق من اكتمال المهمة
    IF NOT EXISTS(SELECT 1 FROM `Tasks` WHERE `task_id` = p_task_id AND `status` = 'COMPLETED') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تقييم مهمة غير مكتملة.';
    END IF;
    
    -- التحقق من أن المنسق هو المسؤول عن حدث المهمة
    IF NOT EXISTS(
        SELECT 1 FROM `Tasks` t
        JOIN `Events` e ON t.`event_id` = e.`event_id`
        WHERE t.`task_id` = p_task_id AND e.`coordinator_id` = p_coordinator_id
    ) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'ليس لديك صلاحية تقييم هذه المهمة.';
    END IF;
    
    -- إدراج التقييم
    INSERT INTO `Ratings_Task` (`task_id`, `coordinator_id`, `value_rating`, `comment`)
    VALUES (p_task_id, p_coordinator_id, p_value_rating, p_comment);
    
    -- إشعار للمورد بالتقييم الجديد
    INSERT INTO `Notifications` (`supplier_id`, `task_id`, `type`, `title`, `message`)
    SELECT t.`assigned_supplier_id`, p_task_id, 'NEW_RATING', 'تقييم جديد',
           CONCAT('تم تقييم مهمتك بـ ', p_value_rating, ' نجوم.')
    FROM `Tasks` t
    WHERE t.`task_id` = p_task_id AND t.`assigned_supplier_id` IS NOT NULL;
    
END$$
