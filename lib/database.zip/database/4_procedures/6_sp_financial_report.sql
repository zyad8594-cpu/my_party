-- 4.6 إجراء تقرير مالي لفترة زمنية
CREATE PROCEDURE `sp_financial_report`(
    IN `p_start_date` DATE,
    IN `p_end_date` DATE
)
BEGIN
    -- إجمالي الدخل حسب الحدث في الفترة
    SELECT 
        e.`event_id`,
        e.`name_event`,
        e.`event_date`,
        IFNULL(SUM(i.`amount`), 0) AS `total_income`,
        IFNULL(SUM(t.`cost`), 0) AS `total_expenses`,
        IFNULL(SUM(i.`amount`), 0) - IFNULL(SUM(t.`cost`), 0) AS `profit`
    FROM `Events` e
    LEFT JOIN `Income` i ON e.`event_id` = i.`event_id` AND i.`payment_date` BETWEEN p_start_date AND p_end_date
    LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id` AND t.`date_completion` BETWEEN p_start_date AND p_end_date
    WHERE e.`event_date` BETWEEN p_start_date AND p_end_date
    GROUP BY e.`event_id`;
    
    -- إجمالي عام
    SELECT 
        IFNULL(SUM(i.`amount`), 0) AS `grand_total_income`,
        IFNULL(SUM(t.`cost`), 0) AS `grand_total_expenses`,
        IFNULL(SUM(i.`amount`), 0) - IFNULL(SUM(t.`cost`), 0) AS `grand_profit`
    FROM `Events` e
    LEFT JOIN `Income` i ON e.`event_id` = i.`event_id` AND i.`payment_date` BETWEEN p_start_date AND p_end_date
    LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id` AND t.`date_completion` BETWEEN p_start_date AND p_end_date
    WHERE e.`event_date` BETWEEN p_start_date AND p_end_date;
END$$
