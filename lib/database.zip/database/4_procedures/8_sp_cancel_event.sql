-- 4.8 إجراء إلغاء حدث (مع تحديث حالة المهام المرتبطة)
CREATE PROCEDURE `sp_cancel_event`(
    IN `p_event_id` INT,
    IN `p_reason` TEXT CHARSET utf8mb4
)
BEGIN
    DECLARE EXIT HANDLER FOR SQLEXCEPTION
    BEGIN
        ROLLBACK;
        RESIGNAL;
    END;
    
    START TRANSACTION;
    
    -- تحديث حالة الحدث
    UPDATE `Events` SET `status` = 'cancelled', `description` = CONCAT(`description`, '\nالإلغاء: ', p_reason)
    WHERE `event_id` = p_event_id;
    
    -- إلغاء جميع المهام غير المنجزة
    UPDATE `Tasks` SET `status` = 'CANCELLED', `notes` = CONCAT(IFNULL(`notes`, ''), '\nألغيت بسبب إلغاء الحدث: ', p_reason)
    WHERE `event_id` = p_event_id AND `status` NOT IN ('COMPLETED', 'CANCELLED');
    
    -- إشعار للمنسق
    INSERT INTO `Notifications` (`user_id`, `task_id`, `type`, `title`, `message`)
    SELECT e.`coordinator_id`, NULL, 'EVENT_CANCELLED', 'تم إلغاء حدث',
           CONCAT('الحدث ', e.`name_event`, ' تم إلغاؤه. السبب: ', p_reason)
    FROM `Events` e
    WHERE e.`event_id` = p_event_id;
    
    COMMIT;
END$$
