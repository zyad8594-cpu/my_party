-- تأكد من تمكين جدولة الأحداث: SET GLOBAL event_scheduler = ON;
CREATE EVENT IF NOT EXISTS `event_generate_reminders`
        ON SCHEDULE EVERY 1 DAY
        STARTS CURRENT_DATE + INTERVAL 1 DAY
    DO CALL sp_generate_reminders();

