-- 2.3 عرض تقييمات الموردين (متوسط التقييم، عدد المهام المنفذة)
CREATE OR REPLACE VIEW `v_supplier_performance` AS
SELECT 
    s.`supplier_id`,
    s.`name` AS `supplier_name`,
    (SELECT GROUP_CONCAT(sv.`service_name` SEPARATOR ', ') FROM `Supplier_Services` ss JOIN `Services` sv ON ss.`service_id` = sv.`service_id` WHERE ss.`supplier_id` = s.`supplier_id`) AS `services_provided`,
    COUNT(DISTINCT t.`task_id`) AS `tasks_completed`,
    ROUND(AVG(r.`value_rating`), 2) AS `avg_rating`,
    COUNT(r.`rating_id`) AS `total_ratings`
FROM `Suppliers` s
LEFT JOIN `Tasks` t ON s.`supplier_id` = t.`assigned_supplier_id` AND t.`status` = 'COMPLETED'
LEFT JOIN `Ratings_Task` r ON t.`task_id` = r.`task_id`
GROUP BY s.`supplier_id`;
