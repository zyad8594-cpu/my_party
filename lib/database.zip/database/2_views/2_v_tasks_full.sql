-- 2.2 عرض المهام مع معلومات الجهة المنفذة وتقييمها
CREATE OR REPLACE VIEW `v_tasks_full` AS
SELECT 
    t.`task_id`,
    t.`event_id`,
    e.`name_event` AS `event_name`,
    t.`assignment_type`,
    CASE 
        WHEN t.`assignment_type` = 'USER' THEN coord.`full_name`
        WHEN t.`assignment_type` = 'SUPPLIER' THEN s.`name`
    END AS `assignee_name`,
    t.`type_task`,
    t.`description`,
    t.`cost`,
    t.`status`,
    t.`date_start`,
    t.`date_due`,
    t.`date_completion`,
    t.`notes`,
    t.`url_image`,
    r.`value_rating` AS `rating_value`,
    r.`comment` AS `rating_comment`
FROM `Tasks` t
LEFT JOIN `Events` e ON t.`event_id` = e.`event_id`
LEFT JOIN `Coordinators` coord ON t.`assigned_user_id` = coord.`coordinator_id`
LEFT JOIN `Suppliers` s ON t.`assigned_supplier_id` = s.`supplier_id`
LEFT JOIN `Ratings_Task` r ON t.`task_id` = r.`task_id`;
