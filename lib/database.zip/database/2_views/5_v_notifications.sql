-- 2.5 عرض الإشعارات مع تفاصيل المستلم
CREATE OR REPLACE VIEW `v_notifications` AS
SELECT 
    n.`notification_id`,
    n.`task_id`,
    t.`type_task` AS `task_type`,
    n.`type` AS `notification_type`,
    n.`title`,
    n.`message`,
    n.`is_read`,
    n.`created_at`,
    CASE 
        WHEN n.`user_id` IS NOT NULL THEN 'Coordinator'
        WHEN n.`supplier_id` IS NOT NULL THEN 'Supplier'
    END AS `recipient_type`,
    COALESCE(coord.`full_name`, s.`name`) AS `recipient_name`
FROM `Notifications` n
LEFT JOIN `Tasks` t ON n.`task_id` = t.`task_id`
LEFT JOIN `Coordinators` coord ON n.`user_id` = coord.`user_id`
LEFT JOIN `Suppliers` s ON n.`supplier_id` = s.`supplier_id`;
