-- 2.4 عرض أداء المنسقين (عدد الأحداث التي يديرونها، المهام المنجزة)
CREATE OR REPLACE VIEW `v_coordinator_performance` AS
SELECT 
    coord.`coordinator_id`,
    coord.`full_name` AS `coordinator_name`,
    COUNT(DISTINCT e.`event_id`) AS `events_managed`,
    COUNT(DISTINCT t.`task_id`) AS `total_tasks_assigned`,
    SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) AS `tasks_completed`,
    ROUND(AVG(r.`value_rating`), 2) AS `avg_rating_given`
FROM `Coordinators` coord
LEFT JOIN `Events` e ON coord.`coordinator_id` = e.`coordinator_id`
LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id`
LEFT JOIN `Ratings_Task` r ON coord.`coordinator_id` = r.`coordinator_id`
GROUP BY coord.`coordinator_id`;
