-- 2. إنشاء VIEWS (المشاهدات) – تقارير شاملة 
CREATE OR REPLACE VIEW `v_events_detailed` AS
SELECT 
    e.`event_id`,
    e.`name_event` AS `event_name`,
    e.`description`,
    e.`event_date`,
    e.`location`,
    e.`budget` AS `planned_budget`,
    e.`status` AS `event_status`,
    c.`full_name` AS `client_name`,
    c.`phone_number` AS `client_phone`,
    coord.`full_name` AS `coordinator_name`,
    coord.`phone_number` AS `coordinator_phone`,
    COALESCE(SUM(DISTINCT inc.`amount`), 0) AS `total_income`,
    COALESCE(SUM(DISTINCT t.`cost`), 0) AS `total_expenses`,
    COALESCE(SUM(DISTINCT inc.`amount`), 0) - COALESCE(SUM(DISTINCT t.`cost`), 0) AS `net_profit`,
    COUNT(DISTINCT t.`task_id`) AS `total_tasks`,
    SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) AS `completed_tasks`,
    CONCAT(ROUND(100 * SUM(CASE WHEN t.`status` = 'COMPLETED' THEN 1 ELSE 0 END) / NULLIF(COUNT(t.`task_id`), 0), 2), '%') AS `completion_percentage`
FROM `Events` e
LEFT JOIN `Clients` c ON e.`client_id` = c.`client_id`
LEFT JOIN `Coordinators` coord ON e.`coordinator_id` = coord.`coordinator_id`
LEFT JOIN `Income` inc ON e.`event_id` = inc.`event_id`
LEFT JOIN `Tasks` t ON e.`event_id` = t.`event_id`
GROUP BY e.`event_id`;

