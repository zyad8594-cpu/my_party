
-- حذف قاعدة البيانات إذا كانت موجودة وإنشاء قاعدة جديدة
DROP DATABASE IF EXISTS `my_party_1`;

CREATE DATABASE IF NOT EXISTS `my_party_1` 
    DEFAULT CHARACTER SET utf8mb4 
    COLLATE utf8mb4_unicode_ci;
USE `my_party_1`;
