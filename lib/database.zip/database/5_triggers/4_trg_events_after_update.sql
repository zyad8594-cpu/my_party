CREATE TRIGGER `trg_events_after_update`
    AFTER UPDATE ON `Events`
    FOR EACH ROW
BEGIN
    INSERT INTO `Audit_Log` (`table_name`, `action`, `record_id`, `old_data`, `new_data`, `changed_at`)
    VALUES ('Events', 'UPDATE', NEW.`event_id`,
        JSON_OBJECT(
            'client_id', OLD.`client_id`,
            'coordinator_id', OLD.`coordinator_id`,
            'name_event', OLD.`name_event`,
            'event_date', OLD.`event_date`,
            'budget', OLD.`budget`,
            'status', OLD.`status`
        ),
        JSON_OBJECT(
            'client_id', NEW.`client_id`,
            'coordinator_id', NEW.`coordinator_id`,
            'name_event', NEW.`name_event`,
            'event_date', NEW.`event_date`,
            'budget', NEW.`budget`,
            'status', NEW.`status`
        ), NOW());
END$$
