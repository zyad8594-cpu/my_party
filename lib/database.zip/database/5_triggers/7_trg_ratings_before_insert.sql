-- 5.6 Trigger لمنع إضافة تقييم لمهمة لم تكتمل (حماية إضافية)
CREATE TRIGGER `trg_ratings_before_insert`
    BEFORE INSERT ON `Ratings_Task`
    FOR EACH ROW
BEGIN
    DECLARE v_task_status VARCHAR(20);
    SELECT `status` INTO v_task_status FROM `Tasks` WHERE `task_id` = NEW.`task_id`;
    
    IF v_task_status != 'COMPLETED' THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تقييم مهمة غير مكتملة.';
    END IF;
    
    -- منع التقييم المكرر
    IF EXISTS (SELECT 1 FROM `Ratings_Task` WHERE `task_id` = NEW.`task_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن إضافة أكثر من تقييم لنفس المهمة.';
    END IF;
END$$
