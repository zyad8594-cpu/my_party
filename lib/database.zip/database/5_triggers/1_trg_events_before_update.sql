-- 5.1 Trigger لتحديث حقل updated_at تلقائياً في جدول Events
CREATE TRIGGER `trg_events_before_update`
    BEFORE UPDATE ON `Events`
    FOR EACH ROW
BEGIN
    SET NEW.`updated_at` = CURRENT_TIMESTAMP;
END$$
