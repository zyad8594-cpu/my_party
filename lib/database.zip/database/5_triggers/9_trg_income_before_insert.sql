-- 5.8 Trigger للتحقق من صحة تاريخ الدخل (لا يمكن أن يكون في المستقبل)
CREATE TRIGGER `trg_income_before_insert`
    BEFORE INSERT ON `Income`
    FOR EACH ROW
BEGIN
    IF NEW.`payment_date` > CURDATE() THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'تاريخ الدفع لا يمكن أن يكون في المستقبل.';
    END IF;
END$$


DELIMITER ;
