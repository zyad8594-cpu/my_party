-- 5.5 Trigger لمنع حذف مستخدم إذا كان مرتبطاً بمنسق أو مورد
CREATE TRIGGER `trg_users_before_delete`
    BEFORE DELETE ON `Users`
    FOR EACH ROW
BEGIN
    IF EXISTS (SELECT 1 FROM `Coordinators` WHERE `user_id` = OLD.`user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن حذف مستخدم مرتبط بمنسق. احذف المنسق أولاً.';
    END IF;
    IF EXISTS (SELECT 1 FROM `Suppliers` WHERE `user_id` = OLD.`user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن حذف مستخدم مرتبط بمورد. احذف المورد أولاً.';
    END IF;
END$$
