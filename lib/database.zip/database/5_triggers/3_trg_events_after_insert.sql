-- 5.3 Trigger لتسجيل التغييرات في جدول Audit_Log (لجدول Events)
CREATE TRIGGER `trg_events_after_insert`
    AFTER INSERT ON `Events`
    FOR EACH ROW
BEGIN
    INSERT INTO `Audit_Log` (`table_name`, `action`, `record_id`, `new_data`, `changed_at`)
    VALUES ('Events', 'INSERT', NEW.`event_id`, JSON_OBJECT(
        'client_id', NEW.`client_id`,
        'coordinator_id', NEW.`coordinator_id`,
        'name_event', NEW.`name_event`,
        'event_date', NEW.`event_date`,
        'budget', NEW.`budget`,
        'status', NEW.`status`
    ), NOW());
END$$
