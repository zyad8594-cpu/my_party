-- 5.4 Trigger لإنشاء إشعار تلقائي عند إسناد مهمة جديدة
CREATE TRIGGER `trg_tasks_after_insert`
    AFTER INSERT ON `Tasks`
    FOR EACH ROW
BEGIN
    DECLARE v_title VARCHAR(255);
    DECLARE v_message TEXT;
    
    SET v_title = 'مهمة جديدة';
    SET v_message = CONCAT('تم إسناد مهمة جديدة إليك: ', NEW.`type_task`);
    
    IF NEW.`assignment_type` = 'USER' AND NEW.`assigned_user_id` IS NOT NULL THEN
        INSERT INTO `Notifications` (`user_id`, `task_id`, `type`, `title`, `message`)
        VALUES (NEW.`assigned_user_id`, NEW.`task_id`, 'TASK_ASSIGNED', v_title, v_message);
    ELSEIF NEW.`assignment_type` = 'SUPPLIER' AND NEW.`assigned_supplier_id` IS NOT NULL THEN
        INSERT INTO `Notifications` (`supplier_id`, `task_id`, `type`, `title`, `message`)
        VALUES (NEW.`assigned_supplier_id`, NEW.`task_id`, 'TASK_ASSIGNED', v_title, v_message);
    END IF;
END$$
