-- 5.2 Trigger للتحقق من صحة البيانات قبل إدراج مهمة
CREATE TRIGGER `trg_tasks_before_insert`
    BEFORE INSERT ON `Tasks`
    FOR EACH ROW
BEGIN
    -- التحقق من نوع الإسناد
    IF NEW.`assignment_type` = 'USER' AND NEW.`assigned_user_id` IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تحديد منسق للمهمة عندما يكون النوع USER.';
    END IF;
    IF NEW.`assignment_type` = 'SUPPLIER' AND NEW.`assigned_supplier_id` IS NULL THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'يجب تحديد مورد للمهمة عندما يكون النوع SUPPLIER.';
    END IF;
    IF NEW.`assignment_type` NOT IN ('USER', 'SUPPLIER') THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'نوع الإسناد غير صحيح.';
    END IF;
    
    -- التحقق من وجود المنسق أو المورد
    IF NEW.`assigned_user_id` IS NOT NULL AND NOT EXISTS(SELECT 1 FROM `Coordinators` WHERE `coordinator_id` = NEW.`assigned_user_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المنسق المحدد غير موجود.';
    END IF;
    IF NEW.`assigned_supplier_id` IS NOT NULL AND NOT EXISTS(SELECT 1 FROM `Suppliers` WHERE `supplier_id` = NEW.`assigned_supplier_id`) THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'المورد المحدد غير موجود.';
    END IF;
    
    -- التحقق من تاريخ البدء لا يتجاوز تاريخ الاستحقاق
    IF NEW.`date_start` IS NOT NULL AND NEW.`date_due` IS NOT NULL AND NEW.`date_start` > NEW.`date_due` THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'تاريخ البدء لا يمكن أن يكون بعد تاريخ الاستحقاق.';
    END IF;
END$$
