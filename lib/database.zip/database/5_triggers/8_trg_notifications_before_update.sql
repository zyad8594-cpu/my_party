-- 5.7 Trigger لمنع تعديل أو حذف الإشعارات المقروءة (اختياري)
CREATE TRIGGER `trg_notifications_before_update`
    BEFORE UPDATE ON `Notifications`
    FOR EACH ROW
BEGIN
    IF OLD.`is_read` = TRUE THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'لا يمكن تعديل إشعار مقروء.';
    END IF;
END$$
