use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_user_has_role`(
    `p_user_id` INT, 
    `p_role_name` VARCHAR(50) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count FROM `Roles` u
    WHERE u.`user_id` = p_user_id AND u.`role_name` = p_role_name;
    RETURN v_count IS NOT NULL AND v_count > 0;
END$$

DELIMITER ;