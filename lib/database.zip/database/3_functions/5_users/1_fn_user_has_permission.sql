-- 3.4 دالة للتحقق من وجود صلاحية لمستخدم (بناءً على role_id)
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_user_has_permission`(
    `p_user_id` INT, 
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM `Users` u
    JOIN `Role_Permissions` rp ON u.`role_id` = rp.`role_id`
    JOIN `Permissions` p ON rp.`permission_id` = p.`permission_id`
    WHERE u.`user_id` = p_user_id AND p.`permission_name` = p_permission_name;
    RETURN v_count > 0;
END$$

DELIMITER ;