use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_user_id_is_exists`(
    `p_user_id` INT, 
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count FROM `Users` u
    WHERE u.`user_id` = p_user_id;
    RETURN v_count IS NOT NULL AND v_count > 0;
END$$

DELIMITER ;