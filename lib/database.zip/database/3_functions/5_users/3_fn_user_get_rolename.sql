use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_user_get_rolename`(
    `p_user_id` INT, 
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_role_name VARCHAR(50) CHARSET utf8mb4;

    SELECT u.`role_name` INTO v_role_name FROM `Roles` u
    WHERE u.`user_id` = p_user_id AND u.`role_name` = p_role_name;
    RETURN v_count;
END$$

DELIMITER ;