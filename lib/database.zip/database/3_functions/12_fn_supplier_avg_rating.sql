-- 3.5 دالة لحساب متوسط التقييم لمورد معين
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_supplier_avg_rating`(
    `p_supplier_id` INT
    ) RETURNS DECIMAL(3,2) DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_avg DECIMAL(3,2);
    SELECT ROUND(AVG(r.`value_rating`), 2) INTO v_avg
    FROM `Ratings_Task` r
    JOIN `Tasks` t ON r.`task_id` = t.`task_id`
    WHERE t.`assigned_supplier_id` = p_supplier_id;
    RETURN IFNULL(v_avg, 0);
END$$

DELIMITER ;