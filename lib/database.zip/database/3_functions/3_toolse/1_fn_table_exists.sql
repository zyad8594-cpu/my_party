use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_table_exists`(
    `p_table_name` VARCHAR(255) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC
BEGIN
    DECLARE table_count INT;
    
    SELECT COUNT(*) INTO table_count
        FROM information_schema.tables 
        WHERE `table_schema` = DATABASE() -- يبحث في قاعدة البيانات الحالية
        AND `table_name` = p_table_name;
    
    RETURN table_count > 0;
END$$

DELIMITER ;
