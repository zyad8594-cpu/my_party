use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_permission_get_name_by_id`(
    `p_permission_id` INT
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret VARCHAR(50) CHARSET utf8mb4;
    SELECT `permission_name` INTO ret FROM `Permissions` WHERE `permission_id` = p_permission_id;
    RETURN ret;
END$$

DELIMITER ;