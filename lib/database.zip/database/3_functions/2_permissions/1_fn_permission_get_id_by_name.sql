use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_permission_get_id_by_name`(
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret INT;
    SELECT `permission_id` INTO ret FROM `Permissions` WHERE `permission_name` = p_permission_name;
    RETURN ret;
END$$

DELIMITER ;