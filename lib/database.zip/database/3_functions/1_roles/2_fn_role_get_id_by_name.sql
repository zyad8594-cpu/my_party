use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_role_get_id_by_name`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret INT;
    SELECT `role_id` INTO ret FROM `Roles` WHERE `role_name` = p_role_name;
    RETURN ret;
END$$

DELIMITER ;