use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_role_has_permission`(
    `p_role_name` VARCHAR(50) CHARSET utf8mb4, 
    `p_permission_name` VARCHAR(100) CHARSET utf8mb4
    ) RETURNS BOOLEAN DETERMINISTIC READS SQL DATA SQL SECURITY DEFINER
BEGIN
    DECLARE v_count INT;

    SELECT COUNT(*) INTO v_count
    FROM `Role_Permissions` rp
    JOIN `Roles` r ON rp.`role_id` = r.`role_id`
    JOIN `Permissions` p ON rp.`permission_id` = p.`permission_id`
    WHERE r.`role_name` = p_role_name AND p.`permission_name` = p_permission_name;
    RETURN v_count > 0;
END$$

DELIMITER ;