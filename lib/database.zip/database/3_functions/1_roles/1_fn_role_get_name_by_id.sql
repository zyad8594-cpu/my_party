-- 3. إنشاء FUNCTIONS (الدوال) – عمليات حسابية ومنطقية متقدمة 
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_role_get_name_by_id`(
    `p_role_id` INT
    ) RETURNS VARCHAR(50) CHARSET utf8mb4 DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE ret VARCHAR(50) CHARSET utf8mb4;
    SELECT `role_name` INTO ret FROM `Roles` WHERE `role_id` = p_role_id;
    RETURN ret;
END$$

DELIMITER ;