-- 3.6 دالة لحساب عدد المهام المتأخرة لحدث
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_event_overdue_tasks`(
    `p_event_id` INT
    ) RETURNS INT DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_count INT;
    SELECT COUNT(*) INTO v_count
    FROM `Tasks`
    WHERE `event_id` = p_event_id 
      AND `status` NOT IN ('COMPLETED', 'CANCELLED')
      AND `date_due` < CURDATE();
    RETURN v_count;
END$$

DELIMITER ;