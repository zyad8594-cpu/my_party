-- 3.2 دالة لحساب إجمالي مصروفات حدث
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_event_total_expenses`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
BEGIN
    DECLARE v_total DECIMAL(10,2);
    SELECT IFNULL(SUM(`cost`), 0) INTO v_total
    FROM `Tasks` WHERE `event_id` = p_event_id;
    RETURN v_total;
END$$

DELIMITER ;