-- 3.3 دالة لحساب صافي الربح لحدث
use my_party_1;
DELIMITER $$

CREATE FUNCTION `fn_event_net_profit`(
    `p_event_id` INT
    ) RETURNS DECIMAL(10,2) DETERMINISTIC READS SQL DATA
BEGIN
    RETURN fn_event_total_income(p_event_id) - fn_event_total_expenses(p_event_id);
END$$

DELIMITER ;
