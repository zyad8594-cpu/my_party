-- 1.9 جدول المناسبات (Events)
use `my_party_1`;
DROP TABLE IF EXISTS 'Events';

CREATE TABLE IF NOT EXISTS `Events` (
    `event_id` INT PRIMARY KEY AUTO_INCREMENT,
    `client_id` INT NOT NULL,
    `coordinator_id` INT NOT NULL,
    `name_event` VARCHAR(100) NOT NULL,
    `description` TEXT NULL,
    `event_date` DATE NOT NULL,
    `location` VARCHAR(255) NULL,
    `budget` DECIMAL(10,2) DEFAULT 0.00,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    `status` ENUM('not_started', 'in_progress', 'completed', 'cancelled') DEFAULT 'not_started',
    FOREIGN KEY (`client_id`) REFERENCES `Clients`(`client_id`) ON DELETE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Coordinators`(`coordinator_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;