-- 1.4 جدول المستخدمين (Users) – نظام الدخول الموحد
use `my_party_1`;
DROP TABLE IF EXISTS 'Users';

CREATE TABLE IF NOT EXISTS `Users` (
    `user_id` INT PRIMARY KEY AUTO_INCREMENT,
    `email` VARCHAR(100) UNIQUE NOT NULL,
    `password` VARCHAR(255) NOT NULL,
    `role_id` INT NOT NULL,
    `is_active` BOOLEAN DEFAULT FALSE,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`role_id`) REFERENCES `Roles`(`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE PROCEDURE `sp_create_user`(
    IN `p_email` VARCHAR(100) CHARSET utf8mb4, 
    IN `p_password` VARCHAR(255) CHARSET utf8mb4,
    IN `p_role_id` INT,
    IN `is_active` BOOLEAN, 
)
BEGIN
    
END$$


