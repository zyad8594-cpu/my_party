-- 1.6 جدول الموردين (Suppliers)
use `my_party_1`;
DROP TABLE IF EXISTS 'Suppliers';

CREATE TABLE IF NOT EXISTS `Suppliers` (
    `supplier_id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT UNIQUE NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `phone_number` VARCHAR(20) NOT NULL,
    `address` VARCHAR(255) NULL,
    `notes` TEXT NULL,

    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE,

    CONSTRAINT chk_only_one_assign CHECK (fn_user_get_rolename(`user_id`) = 'supplier')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
