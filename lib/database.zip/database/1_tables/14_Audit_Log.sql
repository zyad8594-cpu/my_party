-- 1.14 جدول سجل التدقيق (Audit_Log) – لإضفاء الاحترافية وتتبع التغييرات
use `my_party_1`;
DROP TABLE IF EXISTS 'Audit_Log';

CREATE TABLE IF NOT EXISTS `Audit_Log` (
    `log_id` BIGINT PRIMARY KEY AUTO_INCREMENT,
    `table_name` VARCHAR(50) NOT NULL,
    `action` ENUM('INSERT', 'UPDATE', 'DELETE') NOT NULL,
    `record_id` INT NOT NULL,
    `old_data` JSON NULL,
    `new_data` JSON NULL,
    `changed_by` INT NULL, -- user_id (يمكن ربطه إذا كان متاحًا)
    `changed_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_table_record (`table_name`, `record_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
