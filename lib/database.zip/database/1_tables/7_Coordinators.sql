-- 1.7 جدول المنسقين (Coordinators)
use `my_party_1`;
DROP TABLE IF EXISTS 'Coordinators';

CREATE TABLE IF NOT EXISTS `Coordinators` (
    `coordinator_id` INT PRIMARY KEY AUTO_INCREMENT,
    `user_id` INT UNIQUE NOT NULL,
    `full_name` VARCHAR(100) NOT NULL,
    `phone_number` VARCHAR(20) NULL,
    FOREIGN KEY (`user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE,

    CONSTRAINT chk_only_one_assign CHECK (fn_user_get_rolename(`user_id`) = 'coordinator')
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
