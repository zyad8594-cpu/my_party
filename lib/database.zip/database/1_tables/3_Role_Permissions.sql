-- 1.3 جدول صلاحيات الأدوار (Role_Permissions)
use `my_party_1`;
DROP TABLE IF EXISTS 'Role_Permissions';

CREATE TABLE IF NOT EXISTS `Role_Permissions` (
    `role_id` INT NOT NULL,
    `permission_id` INT NOT NULL,
    PRIMARY KEY (`role_id`, `permission_id`),
    FOREIGN KEY (`role_id`) REFERENCES `Roles`(`role_id`) ON DELETE CASCADE,
    FOREIGN KEY (`permission_id`) REFERENCES `Permissions`(`permission_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

