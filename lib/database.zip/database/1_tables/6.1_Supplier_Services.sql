-- 1.6.1 جدول خدمات الموردين (Supplier_Services) - العلاقة المتعددة المتعدد
use `my_party_1`;
DROP TABLE IF EXISTS 'Supplier_Services';

CREATE TABLE IF NOT EXISTS `Supplier_Services` (
    `supplier_id` INT NOT NULL,
    `service_id` INT NOT NULL,
    PRIMARY KEY (`supplier_id`, `service_id`),
    FOREIGN KEY (`supplier_id`) REFERENCES `Suppliers`(`supplier_id`) ON DELETE CASCADE,
    FOREIGN KEY (`service_id`) REFERENCES `Services`(`service_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

