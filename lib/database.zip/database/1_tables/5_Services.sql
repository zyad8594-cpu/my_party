-- 1.5 جدول الخدمات (Services)
use `my_party_1`;
DROP TABLE IF EXISTS 'Services';

CREATE TABLE IF NOT EXISTS `Services` (
    `service_id` INT PRIMARY KEY AUTO_INCREMENT,
    `service_name` VARCHAR(100) NOT NULL,
    `description` TEXT NULL, 
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
