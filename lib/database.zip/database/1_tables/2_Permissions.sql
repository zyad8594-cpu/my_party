-- 1.2 جدول الصلاحيات (Permissions)
use `my_party_1`;
DROP TABLE IF EXISTS 'Permissions';

CREATE TABLE IF NOT EXISTS `Permissions` (
    `permission_id` INT PRIMARY KEY AUTO_INCREMENT,
    `permission_name` VARCHAR(100) UNIQUE NOT NULL,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

