-- 1.10 جدول المهام (Tasks)
use `my_party_1`;
DROP TABLE IF EXISTS 'Tasks';

CREATE TABLE IF NOT EXISTS `Tasks` (
    `task_id` INT PRIMARY KEY AUTO_INCREMENT,
    `event_id` INT NOT NULL,
    `asigned_to_user_id` INT NOT NULL,      -- قمنا بإضافة هذا العمود
    `coordinator_id` INT NOT NULL,  -- المنسق الذي أنشاء المهمة
    
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,

    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE,
    FOREIGN KEY (`asigned_to_user_id`) REFERENCES `Users`(`user_id`) ON DELETE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Coordinators`(`coordinator_id`) ON DELETE CASCADE,

    -- قيد فريد يمنع تكرار نفس المهمة (نفس الخدمة ونفس المورد) في نفس الحدث
    UNIQUE INDEX `unique_task_per_event` (`event_id`, `asigned_to_user_id`, `coordinator_id`),

    CONSTRAINT chk_only_one_assign CHECK (
        fn_user_get_rolename(`asigned_to_user_id`) = 'coordinator' OR
        fn_user_get_rolename(`asigned_to_user_id`) = 'supplier'
    )
);

CREATE TABLE IF NOT EXISTS `Task_Detailes` (
    `task_detaile_id` INT PRIMARY KEY AUTO_INCREMENT,
    `task_id` INT NOT NULL,
    `description` TEXT NULL,
    `cost` DECIMAL(10,2) DEFAULT 0.00,
    `status` ENUM('PENDING','IN_PROGRESS','UNDER_REVIEW','COMPLETED','CANCELLED') DEFAULT 'PENDING',
    `notes` TEXT NULL,
    `url_image` VARCHAR(255) NULL,
    `date_start` DATE NULL,
    `date_due` DATE NULL,
    `date_completion` TIMESTAMP NULL,
    `reminder_type` ENUM('INTERVAL','BEFORE_DUE') NULL,
    `reminder_value` INT NULL,
    `reminder_unit` ENUM('MINUTE','HOUR','DAY') NULL,

    FOREIGN KEY (`task_id`) REFERENCES `Tasks`(`task_id`) ON DELETE CASCADE
);

-- 4.3 إجراء تحديث حالة مهمة مع إنشاء إشعار تلقائي
CREATE PROCEDURE `sp_create_task`(
    IN `p_event_id` INT,
    IN `p_asigned_to_user_id` INT,
    IN `p_coordinator_id` INT,
    IN `p_description` TEXT CHARSET utf8mb4,
    IN `p_cost` DECIMAL(10,2),
    IN `p_status` ENUM('PENDING','IN_PROGRESS','UNDER_REVIEW','COMPLETED','CANCELLED') CHARSET utf8mb4,
    IN `p_notes` TEXT CHARSET utf8mb4,
    IN `p_url_image` VARCHAR(255) CHARSET utf8mb4,
    IN `p_date_start` DATE,
    IN `p_date_due` DATE,
    IN `p_date_completion` TIMESTAMP,
    IN `p_reminder_type` ENUM('INTERVAL','BEFORE_DUE') CHARSET utf8mb4,
    IN `p_reminder_value` INT,
    IN `p_reminder_unit` ENUM('MINUTE','HOUR','DAY') CHARSET utf8mb4
)
BEGIN
    DECLARE v_task_id INT;
    DECLARE v_role_name VARCHAR(50) CHARSET utf8mb4;
    SET v_role_name = fn_user_get_rolename(p_asigned_to_user_id);

    IF v_role_name IS NOT NULL THEN
        INSERT INTO `Tasks`(`event_id`, `asigned_to_user_id`, `coordinator_id`) VALUES(p_event_id, p_asigned_to_user_id, p_coordinator_id);
        SET v_task_id = LAST_INSERT_ID();

        INSERT INTO `Task_Detailes`(`task_id`, `description`, `cost`, `status`, `notes`, `url_image`, `date_start`, `date_due`, `date_completion`, `reminder_type`, `reminder_value`, `reminder_unit`) 
            VALUES(v_task_id, p_description, p_cost, p_status, p_notes, p_url_image, p_date_start, p_date_due, p_date_completion, p_reminder_type, p_reminder_value, p_reminder_unit);
    END IF;



    
    -- إنشاء إشعار حسب الحالة الجديدة
    IF p_new_status = 'COMPLETED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
        SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_COMPLETED', 'تم إكمال مهمة',
               CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' قد اكتملت.')
            FROM `Tasks` t
            JOIN `Events` e ON t.`event_id` = e.`event_id`
            WHERE t.`task_id` = p_task_id;
        
    ELSEIF p_new_status = 'CANCELLED' THEN
        -- إشعار للمنسق
        INSERT INTO `Notifications` (`user_id`, `supplier_id`, `task_id`, `type`, `title`, `message`)
            SELECT e.`coordinator_id`, NULL, p_task_id, 'TASK_CANCELLED', 'تم إلغاء مهمة',
                CONCAT('المهمة ', t.`type_task`, ' في حدث ', e.`name_event`, ' تم إلغاؤها.')
                FROM `Tasks` t
                JOIN `Events` e ON t.`event_id` = e.`event_id`
                WHERE t.`task_id` = p_task_id;
    END IF;
    
END$$


CREATE TABLE IF NOT EXISTS `Tasks` (
    `task_id` INT PRIMARY KEY AUTO_INCREMENT,
    `event_id` INT NOT NULL,
    `service_id` INT NOT NULL,      -- قمنا بإضافة هذا العمود
    -- `assignment_type` ENUM('SUPPLIER', 'USER') NOT NULL, -- قمنا بإزالة هذا العمود
    -- `assigned_user_id` INT NULL, -- يشير إلى coordinator_id       قمنا بإزالة هذا العمود
    -- `assigned_supplier_id` INT NULL, -- يشير إلى supplier_id      قمنا بإزالة هذا العمود
    -- `type_task` VARCHAR(100) NOT NULL,   -- قمنا بإزالة هذا العمود
    `description` TEXT NULL,
    `cost` DECIMAL(10,2) DEFAULT 0.00,
    `status` ENUM('PENDING','IN_PROGRESS','UNDER_REVIEW','COMPLETED','CANCELLED') DEFAULT 'PENDING',
    `notes` TEXT NULL,
    `url_image` VARCHAR(255) NULL,
    `date_start` DATE NULL,
    `date_due` DATE NULL,
    `date_completion` TIMESTAMP NULL,
    `reminder_type` ENUM('INTERVAL','BEFORE_DUE') NULL,
    `reminder_value` INT NULL,
    `reminder_unit` ENUM('MINUTE','HOUR','DAY') NULL,
    -- `completion_at` TIMESTAMP NULL,   -- قمنا بإزالة هذا العمود
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,

    -- المفاتيح الخارجية
    FOREIGN KEY (`event_id`) REFERENCES `Events`(`event_id`) ON DELETE CASCADE,
    FOREIGN KEY (`service_id`) REFERENCES `Services`(`service_id`) ON DELETE RESTRICT ON UPDATE CASCADE,

    -- مفتاح خارجي مركب يضمن أن المورد يقدم الخدمة المحددة
    FOREIGN KEY (`supplier_id`, `service_id`) 
        REFERENCES `supplier_services`(`supplier_id`, `service_id`)
        ON DELETE RESTRICT ON UPDATE CASCADE,

    -- قيد فريد يمنع تكرار نفس المهمة (نفس الخدمة ونفس المورد) في نفس الحدث
    UNIQUE INDEX `unique_task_per_event` (`event_id`, `service_id`, `supplier_id`)
    -- FOREIGN KEY (`assigned_user_id`) REFERENCES `Coordinators`(`coordinator_id`) ON DELETE SET NULL,
    -- FOREIGN KEY (`assigned_supplier_id`) REFERENCES `Suppliers`(`supplier_id`) ON DELETE SET NULL, 
    

    -- CONSTRAINT chk_only_one_assign CHECK ((
    --     `assignment_type` = 'USER' AND 
    --     `assigned_user_id` IS NOT NULL AND 
    --     `assigned_supplier_id` IS NULL
    -- ) OR (
    --     `assignment_type` = 'SUPPLIER' AND 
    --     `assigned_user_id` IS NULL AND 
    --     `assigned_supplier_id` IS NOT NULL
    -- ))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
