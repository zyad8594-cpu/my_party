-- 1.11 جدول تقييم المهام (Ratings_Task)
use `my_party_1`;
DROP TABLE IF EXISTS 'Ratings_Task';

CREATE TABLE IF NOT EXISTS `Ratings_Task` (
    `rating_id` INT PRIMARY KEY AUTO_INCREMENT,
    `task_id` INT NOT NULL UNIQUE,
    `coordinator_id` INT NOT NULL,
    `value_rating` INT NOT NULL CHECK (value_rating BETWEEN 1 AND 5),
    `comment` TEXT NULL,
    `rated_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP NULL ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (`task_id`) REFERENCES `Tasks`(`task_id`) ON DELETE CASCADE,
    FOREIGN KEY (`coordinator_id`) REFERENCES `Coordinators`(`coordinator_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;